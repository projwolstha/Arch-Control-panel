# Sphere Hub `6.18.0`

**Sphere Hub** is a native Wayland / Hyprland overlay dashboard built on **Quickshell (Qt6 / WlrLayerShell)** with a **zero-dependency, ultra-low-memory Rust backend** (`sphere-backend` and `jarvis-organize`).

While summoned (`SUPER+A`), Sphere Hub renders a smoked-glass visionOS orbital interface over `WlrLayer.Overlay` with five dedicated control orbs (**Wi-Fi**, **Bluetooth**, **Battery & Power Profile**, **System Memory/Storage**, and **Safe File Organizer**) plus a 4-point UFO top-orb & volumetric beam reveal. When dismissed (`Escape` or `SUPER+A`), both Quickshell and the backend exit cleanly so hidden state consumes **0 MB RAM and 0% CPU**.

---

## Native Rust Backend — Memory & Startup Footprint

Both runtime backend processes (`sphere-backend` and `jarvis-organize`) are written in **100% pure Rust (`std` only, zero external crates, offline builds)** with a 1-to-1 NDJSON IPC and CLI contract:

| Metric (`serve` with 120 `.desktop` apps & 15,000 icons) | Legacy Python Backend | Native Rust Backend | Improvement |
| :--- | ---: | ---: | ---: |
| **Total Resident Memory (`VmRSS`)** | `28,704 kB` (`28.0 MB`) | **`2,852 kB` (`2.78 MB`)** | **`90.1%` less RAM (~10x smaller)** |
| **Private Heap Memory (`RssAnon`)** | `21,756 kB` (`21.2 MB`) | **`204 kB` (`0.20 MB`)** | **`99.1%` less heap (>100x smaller)** |
| **Virtual Address Space (`VmSize`)** | `474,652 kB` (`463.5 MB`) | **`5,636 kB` (`5.50 MB`)** | **`98.8%` smaller address space** |
| **Cold Startup to Initial Snapshot** | `591.3 ms` | **`14.3 ms`** | **`41x` faster startup** |
| **Compiled Binary Size (LTO + stripped)** | Python runtime + stdlib | **`791 KB` / `651 KB`** | Zero runtime interpreter |

### Key Low-Memory Optimizations
- **Zero External Crates (`--offline` ready):** Custom RFC 8259 JSON parser/serializer, Unix domain socket Hyprland IPC client (`.socket.sock` / `.socket2.sock`), sysfs/UPower battery reader, `/proc/meminfo` & `/proc/[pid]/statm` reader, `nmcli` / `bluetoothctl` monitors, and `jarvis-organize` engine using only Rust `std`.
- **Zero-Retention Icon Resolution:** Scans XDG `.desktop` entries first, collects only the ~50–150 referenced icon names, resolves their `file://` URIs across icon themes in one pass, and immediately drops the lookup table instead of pinning ~100,000 theme icon paths in memory.
- **Compact `128 KiB` Thread Stacks & Single Arena (`mallopt`):** Background event watchers spawn with `128 KiB` stacks (instead of the `8 MiB` OS default) and cap glibc `M_ARENA_MAX` to `1`.
- **Direct `exec` Process Handoff:** `native/backend-launch.sh` replaces `/bin/sh` in-place via `execve` with `~/.local/bin/sphere-backend`, leaving zero wrapper shells or Python processes resident.

---

## Repository Structure

```text
.
├── Cargo.toml                  # Workspace manifest + size/LTO release profile
├── rust-backend/               # Zero-dependency Rust backend crate
│   ├── Cargo.toml
│   ├── src/
│   │   ├── bin/
│   │   │   ├── sphere-backend.rs   # NDJSON stdio desktop adapter CLI
│   │   │   └── jarvis-organize.rs  # Safe undoable file organizer CLI
│   │   ├── battery.rs          # UPower + /sys/class/power_supply + powerprofilesctl
│   │   ├── bluetooth.rs        # bluetoothctl + rfkill monitor & controller
│   │   ├── bridge.rs           # Action router, watchers & 64 KiB-capped NDJSON server
│   │   ├── catalog.rs          # XDG .desktop parser & zero-retention icon resolver
│   │   ├── config.rs           # Atomic 0600 JSON state & preferences store
│   │   ├── constants.rs        # Package recipes, 128 KiB thread spawner & allocator tuning
│   │   ├── hypr.rs             # Direct Hyprland Unix socket IPC client
│   │   ├── json.rs             # Zero-dependency RFC 8259 JSON parser & writer
│   │   ├── organize.rs         # Safe file organizer (scan, run, dry-run, undo, watch)
│   │   ├── pathutil.rs         # XDG roots, file:// URIs & shell-free Exec= tokenizer
│   │   ├── resources.rs        # /proc/meminfo, df -P & in-process /proc/pid/statm
│   │   ├── system.rs           # Distro/package-manager detection & terminal launcher
│   │   └── wifi.rs             # nmcli terse parser, 0600 passwd-file connect & monitor
│   └── tests/
│       └── parity.rs           # Rust unit & protocol parity tests
├── native/                     # Quickshell Qt6 / Wayland Layer-Shell QML UI & SVG assets
│   ├── shell.qml               # WlrLayer.Overlay surface, IPC handler & backend bridge
│   ├── SphereWidget.qml        # Ring geometry, 4-point UFO beam reveal & 5 orb panels
│   ├── PanelFrame.qml          # Data-driven visionOS smoked-glass panel frame
│   ├── backend-launch.sh       # Direct `exec` launcher for native `sphere-backend`
│   ├── assets/                 # Deterministic SVG rings, runes, sigils & UFO beam assets
│   └── tests/                  # 486-test verification suite (QML, safety & Rust parity)
├── config/                     # Canonical layout, theme, panel & motion JSON mirrors
├── installer/                  # Transactional installer, doctor, repair & uninstaller
├── shell/                      # Arch/Linux preflight & service preparation scripts
├── tools/
│   ├── artwork.py              # Deterministic SVG asset entry points
│   └── build.py                # Self-contained single-file installer builder
└── install.sh                  # One-command build + install from a git clone
```

---

## Quick Start

### Requirements
- **Linux** with **Wayland** and **Hyprland**
- **Quickshell `>= 0.3`** (Qt6)
- **Rust toolchain** (`cargo` / `rustc >= 1.75`) for building the native backend (`install.sh` and `sphere-setup` also compile automatically offline)
- **Python `>= 3.10`** (used by the transactional setup/doctor manager and test suite)

### Install from Git Clone

Run as your normal desktop user (**never** `sudo ./install.sh`):

```sh
git clone https://github.com/<your-username>/sphere-hub.git
cd sphere-hub
./install.sh
```

Preview the installation plan without modifying anything:

```sh
./install.sh --dry-run
```

### Build Only the Rust Binaries

```sh
cargo build --release --offline
# Produces:
#   target/release/sphere-backend
#   target/release/jarvis-organize
```

### Build the Self-Contained Single-File Installer

```sh
python3 tools/build.py
# Produces:
#   dist/sphere-setup-6.18.0.sh
```

---

## Everyday Usage & Management

Once installed, `~/.local/bin/sphere-setup` manages the overlay and `SUPER+A` summons or dismisses it in Hyprland:

```sh
sphere-setup summon      # Summon the overlay immediately
sphere-setup toggle      # Toggle overlay visibility (bound to SUPER+A)
sphere-setup status      # Show current installation & session status
sphere-setup doctor      # Run full health, ABI, catalog & hardware diagnostics
sphere-setup restart     # Reload Quickshell & native Rust backend
sphere-setup repair      # Re-verify files and recompile/redeploy cleanly
sphere-setup uninstall   # Remove Sphere Hub while keeping your ~/.config/jarvis rules
```

### Custom Center Logo
Drop an SVG (preferred) or PNG at `~/.config/jarvis/logo.svg` (or `logo.png`). `FileView` watches it via `inotify` and hot-reloads it live without restarting.

### Standalone File Organizer (`jarvis-organize`)
```sh
jarvis-organize scan ~/Downloads             # JSON preview of categorized moves
jarvis-organize run ~/Downloads --dry-run    # Human-readable preview table (moves nothing)
jarvis-organize run ~/Downloads              # Safely sort files (no clobber, 0600 undo log)
jarvis-organize undo                         # Restore every file from the last run
jarvis-organize rules --open                 # Edit ~/.config/jarvis/organize.json
```

---

## Running the Test Suites

```sh
# 1. Rust unit & IPC parity tests
cargo test --offline

# 2. Full 486-test QML, organizer, safety & Rust resident-memory suite
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s native/tests
```

## License

Released under the [MIT License](LICENSE).
