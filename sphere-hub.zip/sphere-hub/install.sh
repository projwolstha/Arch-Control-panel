#!/bin/sh
# Build the native Rust backend and run the Sphere Hub installer from a git checkout.
set -eu
REPO=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if command -v cargo >/dev/null 2>&1; then
    printf '%s\n' "Building Sphere Hub native Rust backend (release, std-only)…"
    cargo build --release --offline --manifest-path "$REPO/Cargo.toml"
elif [ -x "$HOME/.cargo/bin/cargo" ]; then
    printf '%s\n' "Building Sphere Hub native Rust backend via ~/.cargo/bin/cargo…"
    "$HOME/.cargo/bin/cargo" build --release --offline --manifest-path "$REPO/Cargo.toml"
fi

python3 "$REPO/tools/build.py" >/dev/null
exec sh "$REPO/dist/sphere-setup-6.18.0.sh" "$@"
