"""Sphere's user-owned, path-scoped native installer/manager (stdlib only).

The package is deliberately split one concern per module; ``manager.py`` in this
directory is only a thin executable entry point.
"""
from __future__ import annotations

from .constants import VERSION
from .errors import SetupError

__all__ = ["VERSION", "SetupError"]
