"""Arch-specific dependency, service, rfkill and group checks for Bluetooth.

Everything here is deliberately forgiving: a missing adapter, a stopped service
or an rfkill block is *reported* and the run continues. Only an actual package
transaction failure is treated as an error, because that is the only thing the
user can act on (and the only thing that changes the summary).
"""
from __future__ import annotations

import json
import shutil
import subprocess

# Arch packages this feature needs. bluez/bluez-utils are the Bluetooth stack;
# the Qt 6 modules are what Quickshell renders the panel with; networkmanager is
# only listed because its daemon must be up for the Wi-Fi orb next to it.
PACMAN_PACKAGES = [
    ("bluez", "Bluetooth stack (bluetoothd)"),
    ("bluez-utils", "bluetoothctl, the command line this panel drives"),
    ("util-linux", "provides rfkill, which reports and clears radio blocks"),
    ("quickshell", "the shell runtime"),
    ("networkmanager", "the Wi-Fi orb beside it"),
    ("qt6-base", "core Qt 6"),
    ("qt6-declarative", "Qt Quick / QML engine"),
    ("qt6-wayland", "Wayland client platform plugin (Hyprland)"),
    ("qt6-svg", "SVG decoding for app icons"),
    ("qt6-imageformats", "PNG/WebP image plugins"),
]

FONT_PACKAGES = [
    ("noto-fonts", "the sans face the panel's text uses"),
]
FONT_FALLBACK = ("ttf-dejavu", "fallback face if Noto is not installed")

SERVICES = ["bluetooth", "NetworkManager"]


def _run(argv, timeout=20, check=False):
    try:
        return subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                              env={"LC_ALL": "C", "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"},
                              check=check)
    except (OSError, subprocess.TimeoutExpired) as error:
        return subprocess.CompletedProcess(argv, 1, "", str(error))


# ── privilege ───────────────────────────────────────────────────────────────
ELEVATORS = ("sudo", "doas", "pkexec")


def elevator():
    """The privilege helper that exists here, in packages.py's order.

    ``sudo`` is not universal on Arch — doas is a common substitute — so the
    argv this module hands to its runner must name the helper that is really
    installed instead of assuming one.
    """
    return next((candidate for candidate in ELEVATORS if shutil.which(candidate)), "sudo")


# ── packages ────────────────────────────────────────────────────────────────
def installed(name):
    """True when pacman says the package is installed (never raises)."""
    if not shutil.which("pacman"):
        return False
    result = _run(["pacman", "-Q", name], timeout=10)
    return result.returncode == 0


def missing(packages=None):
    packages = packages or PACMAN_PACKAGES
    return [name for name, _ in packages if not installed(name)]


def pacman_install(names, runner):
    """Install exactly ``names`` with --needed, through the caller's runner.

    ``runner`` is called as ``runner(argv)`` and is the only thing that touches
    privilege, so a dry run can pass a no-op and nothing is executed.
    """
    if not names:
        return True
    argv = [elevator(), "pacman", "-S", "--needed", "--noconfirm", *names]
    return runner(argv)


def describe(packages=None):
    """'name — purpose' lines, for the summary and the plan."""
    packages = packages or PACMAN_PACKAGES
    return [f"{name} — {why}" for name, why in packages]


# ── services ────────────────────────────────────────────────────────────────
def service_state(name):
    """active | inactive | failed | unknown (systemctl absent in a container)."""
    if not shutil.which("systemctl"):
        return "unknown"
    result = _run(["systemctl", "is-active", name], timeout=10)
    return (result.stdout or "").strip() or "unknown"


def enable_service(name, runner):
    """``systemctl enable --now NAME``; a failure is reported, never fatal."""
    return runner([elevator(), "systemctl", "enable", "--now", name])


# ── adapter, rfkill, groups ─────────────────────────────────────────────────
def controllers():
    """The lines ``bluetoothctl list`` returns (empty when there is no adapter)."""
    if not shutil.which("bluetoothctl"):
        return []
    result = _run(["bluetoothctl", "list"], timeout=15)
    return [line.strip() for line in (result.stdout or "").splitlines()
            if line.strip().startswith("Controller ")]


def rfkill_blocked():
    """(soft, hard) — both False when rfkill cannot answer."""
    if not shutil.which("rfkill"):
        return False, False
    result = _run(["rfkill", "list", "bluetooth"], timeout=10)
    text = (result.stdout or "").lower()
    return ("soft blocked: yes" in text), ("hard blocked: yes" in text)


def unblock(runner):
    """``rfkill unblock bluetooth`` — the user's own call, no privilege needed."""
    return runner(["rfkill", "unblock", "bluetooth"])


def groups_missing():
    """Groups the desktop user should be in for this to work without friction.

    bluetooth: some distros gate HID/rfkill access on it. wheel/admin are the
    usual Arch privilege groups; ``input`` is needed by nothing here, so it is
    deliberately not touched.
    """
    if not shutil.which("id"):
        return []
    result = _run(["id", "-nG"], timeout=10)
    current = set((result.stdout or "").split())
    wanted = [g for g in ("wheel", "bluetooth") if g in _known_groups()]
    return [g for g in wanted if g not in current]


def _known_groups():
    result = _run(["getent", "group"], timeout=10)
    return {line.split(":")[0] for line in (result.stdout or "").splitlines() if ":" in line}


def add_group(group, user, runner):
    return runner([elevator(), "gpasswd", "-a", user, group])


def report():
    """Everything the end-of-run summary needs, gathered without side effects."""
    soft, hard = rfkill_blocked()
    return {
        "adapter": controllers(),
        "rfkill": {"soft": soft, "hard": hard},
        "services": {name: service_state(name) for name in SERVICES},
        "bluetoothctl": shutil.which("bluetoothctl") or "",
        "pacmanMissing": missing(),
        "groupsMissing": groups_missing(),
    }


def as_json(data):
    return json.dumps(data, indent=2, sort_keys=True)
