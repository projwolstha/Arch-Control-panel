"""Argument parsing, the cross-process operation lock and command dispatch."""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import os
import sys

from .constants import VERSION
from .errors import SetupError
from .ops.manager import Manager


def parser():
    p = argparse.ArgumentParser(description="Sphere native Hyprland/Quickshell setup and manager. Run without arguments to install automatically.")
    p.add_argument("command", nargs="?", default="install", choices=("install","repair","update","start","stop","restart","status","doctor","logs","picker","pause","resume","lock","unlock","refresh","enable","disable","uninstall","_supervise","toggle","summon","dismiss"))
    p.add_argument("--version", action="version", version="Sphere native setup "+VERSION)
    p.add_argument("--dry-run", "--plan", action="store_true", help="show the plan without installing/modifying anything")
    p.add_argument("--no-deps", action="store_true", help="require an existing native stack, do not use package managers")
    p.add_argument("--no-autostart", action="store_true", help="do not edit any Hyprland autostart config")
    p.add_argument("--pacman-upgrade", action="store_true", help="on Arch, run one full `pacman -Syu` before installing (never done implicitly)")
    p.add_argument("--no-start", action="store_true", help="install/check files without launching a GUI")
    p.add_argument("--seed-installed", action="store_true", help=argparse.SUPPRESS)  # accepted compatibility no-op
    p.add_argument("--empty-orbs", action="store_true", help=argparse.SUPPRESS)  # accepted compatibility no-op; empty is now the default
    p.add_argument("--hyprland-config", metavar="PATH", help="override automatic active/custom Hyprland config detection")
    p.add_argument("--software", action="store_true", help="use Qt Quick software rendering for this widget only")
    p.add_argument("--purge", action="store_true", help="uninstall also removes Sphere assignments, backups and private build")
    p.add_argument("--json", action="store_true", help="machine-readable status/doctor/plan output")
    p.add_argument("--slot", type=int, choices=range(1,9), default=1, help=argparse.SUPPRESS)  # accepted compatibility no-op
    p.add_argument("--lines", type=int, default=60, help="tail length for logs")
    return p


@contextlib.contextmanager
def operation_lock(manager):
    args = manager.args
    if args.dry_run or args.command in ("_supervise", "status", "doctor", "logs"):
        yield
        return
    if manager.p.data.is_symlink():
        raise SetupError("The Sphere data folder is a symlink/declaratively managed; it was not changed.")
    manager.p.data.mkdir(parents=True, exist_ok=True, mode=0o700)
    with open(manager.p.data/"operation.lock", "a+") as lock:
        os.chmod(lock.name, 0o600)
        try:
            fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            raise SetupError("Another Sphere setup/management operation is running; no second operation was started.")
        yield


def main(argv=None):
    args = parser().parse_args(argv)
    if sys.platform != "linux":
        raise SetupError("This is a native Linux Hyprland/Wayland widget, not a Windows/macOS/browser application.")
    if os.getuid() == 0 and not args.dry_run:
        raise SetupError("Run this script as your desktop user, not with sudo. It asks sudo only for system packages.")
    manager = Manager(args)
    with operation_lock(manager):
        return dispatch(manager, args)


def console_main(argv=None):
    """Run main() and turn Sphere's own failures into a clean, non-zero exit."""
    try:
        return main(argv)
    except SetupError as error:
        print("Sphere setup error: "+str(error), file=sys.stderr)
        return 1
    except OSError as error:
        print("Sphere OS error (no success claimed): "+str(error), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nSphere setup cancelled. Passwords are not retained.", file=sys.stderr)
        return 130


def console_main(argv=None):
    """Run main() and turn Sphere's own failures into a clean, non-zero exit."""
    try:
        return main(argv)
    except SetupError as error:
        print("Sphere setup error: "+str(error), file=sys.stderr)
        return 1
    except OSError as error:
        print("Sphere OS error (no success claimed): "+str(error), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nSphere setup cancelled. Passwords are not retained.", file=sys.stderr)
        return 130


def dispatch(manager, args):
    command = args.command
    if args.dry_run and command not in ("install","repair","update","uninstall"):
        manager.plan()
        return 0
    if command in ("install","repair","update"):
        manager.install()
    elif command == "_supervise":
        manager.supervise()
    elif command == "status":
        manager.status()
    elif command == "doctor":
        return manager.doctor()
    elif command == "logs":
        manager.logs()
    elif command == "stop":
        manager.stop()
    elif command in ("start","restart"):
        if command == "restart":
            manager.stop(quiet=True)
        manager.start()
    elif command in ("enable","disable"):
        manager.open_log()
        manager.enable_autostart() if command == "enable" else manager.disable_autostart()
        manager.save_meta()
    elif command == "uninstall":
        manager.uninstall()
    elif command == "toggle":
        manager.open_log()
        health = manager.health()
        if health and health.get("sphereVisible"):
            manager.dismiss()
        else:
            manager.summon()
    elif command == "dismiss":
        manager.dismiss()
    elif command == "summon":
        manager.summon()
    elif command == "picker":
        # The dashboard has five fixed gems and no assignable orbs, so there is no
        # picker to open. The verb stays so old bindings and docs keep working: it
        # shows the dashboard, which is what "open the picker" used to do.
        manager.summon()
        manager.say("The dashboard has five fixed gems — nothing to assign. Showing it instead.")
    else:
        target, values = {"pause":("pause",[True]),"resume":("pause",[False]),"lock":("lock",[True]),"unlock":("lock",[False]),"refresh":("refresh",[])}[command]
        code, out, err = manager.ipc(target, *values)
        if code or "Not ready" in out or "No running" in out:
            raise SetupError("Native control failed: "+(err or out or "widget not running"))
        manager.say("Native "+command+" requested."+(" "+out.strip() if command == "toggle" and out.strip() else ""))
    return 0
