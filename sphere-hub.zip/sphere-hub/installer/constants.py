"""Version pins, package lists and the inventory of managed native files."""
from __future__ import annotations

from pathlib import Path


VERSION = "6.18.0"


MIN_QS = (0, 3, 0)


QS_REV = "4f508be500dea6e5732cc3d50382a0048b17e7b1"


QS_SHA = "f14115a73c9fff6aa6399f924b632e88c3ce2cead2657f814a7825341f35baad"


QS_URL = f"https://git.outfoxxed.me/quickshell/quickshell/archive/{QS_REV}.tar.gz"


# The gold ring sheet, pinned: tools/artwork.py is deterministic, so a changed
# hash means the shipped artwork is not the artwork this build was tested with.


MARKER = "SPHERE-HUB MANAGED AUTOSTART"


TERMINALS = ("foot", "kitty", "ghostty", "alacritty", "wezterm", "konsole", "gnome-terminal", "xfce4-terminal", "xterm")


# Every module bridge.py imports must be listed here: the payload carries the whole
# tree, but deploy_native() copies exactly this inventory into the Quickshell dir.
ADAPTER_FILES = ("__init__.py", "battery.py", "bluetooth.py", "bridge.py", "catalog.py", "cli.py",
                 "config.py", "constants.py", "hypr.py", "install.py", "pathutil.py", "resources.py",
                 "system.py", "terminal.py", "wifi.py")
# Everything copied into the Quickshell config directory, relative to native/.
NATIVE_FILES = ("shell.qml", "SphereWidget.qml", "PanelFrame.qml",
                # the living ring: tokens, the energy stroke, the rune rings, the
                # spark, the Jarvis core and its data, then the circle and the gems
                "Theme.qml", "Geometry.qml", "Panels.qml", "Motion.qml",
                "EnergyLine.qml", "OuterRings.qml", "RuneRing.qml", "Sigil.qml", "Web.qml",
                "Spark.qml",
                "JarvisCore.qml", "SysStats.qml", "MagicRing.qml", "MagicGem.qml",
                "backend.py", "backend-launch.sh", "start.sh", "README.md",
                "hyprland.conf.example", "hyprland.lua.example",
                # the ring's artwork: the gem bezel, the atmosphere and spark
                # glows, the core's orb and halo, then one glyph, one ray cone
                # and one halo per gem, the 60 rune band glyphs and the five
                # sigil stations (the legacy sheets and study set are retired)
                "assets/magic-bezel.svg",
                "assets/liquid-torus-body.svg", "assets/liquid-torus-glaze.svg",
                "assets/liquid-lens.svg", "assets/gem-liquid-dome.svg",
    "assets/core-orb-swirl.svg",
    "assets/gem-aurora-swirl.svg",
    "assets/visionos-astro-web.svg",
    "assets/visionos-dial-scale.svg",
    "assets/visionos-dome-collar.svg",
    "assets/visionos-ufo-cone.svg",
    "assets/visionos-ufo-pool.svg",
                "assets/atmosphere.svg", "assets/spark.svg",
                # the core's light: the orb, the halo it throws, and the dark
                # lens the clock's type sits on
                "assets/core-orb.svg", "assets/core-halo.svg", "assets/core-scrim.svg",
                "assets/core-sweep.svg",
                *("assets/glyph-%s.svg" % name for name in
                  ("wifi", "bluetooth", "battery", "chip", "folder")),
                *("assets/ray-%s.svg" % name for name in
                  ("wifi", "bluetooth", "battery", "resources", "organize")),
                *("assets/glow-%s.svg" % name for name in
                  ("wifi", "bluetooth", "battery", "resources", "organize")),
                *("assets/rune-%02d.svg" % i for i in range(60)),
                *("assets/sigils/sigil-%02d.svg" % i for i in range(1, 6)),
                "tests/test_backend.py", "tests/test_rust_backend.py", "tests/test_shell_ui.py", "tests/test_bluetooth.py",
                "tests/test_battery.py", "tests/test_resources.py", "tests/test_platform.py",
                *("sphere_adapter/"+name for name in ADAPTER_FILES))


def _find_bundle():
    """Return the native/ payload directory, in place or inside the extracted payload."""
    here = Path(__file__).resolve().parent        # installer/ (project checkout or payload)
    for base in (here.parent, here.parent.parent):
        candidate = base/"native"
        if (candidate/"shell.qml").is_file():
            return candidate
    return here.parent/"native"


BUNDLE = _find_bundle()


RUNTIME_PACKAGES = {
    "apt": ["python3", "ca-certificates", "qml6-module-qtquick", "qml6-module-qtquick-controls", "qml6-module-qtquick-layouts", "qml6-module-qtquick-window", "qml6-module-qtquick-templates", "qml6-module-qtqml-workerscript", "qt6-wayland", "libqt6svg6", "qt6-svg-plugins", "qt6-image-formats-plugins"],
    "pacman": ["python", "ca-certificates", "qt6-base", "qt6-declarative", "qt6-wayland", "qt6-svg", "qt6-imageformats",
               # the cartouches are set in a serif: this one is in extra, tiny, and
               # makes the plate type the same on every Arch install (Cinzel itself
               # is AUR-only, so it is used only when it is already present)
               "adobe-source-serif-fonts",
               "upower", "power-profiles-daemon", "coreutils", "procps-ng", "util-linux"],
    "dnf": ["python3", "ca-certificates", "qt6-qtbase", "qt6-qtdeclarative", "qt6-qtwayland", "qt6-qtsvg", "qt6-qtimageformats"],
    "zypper": ["python3", "ca-certificates", "qt6-declarative-imports", "qt6-wayland", "qt6-svg", "qt6-imageformats"],
}


BUILD_PACKAGES = {
    "apt": ["build-essential", "cmake", "ninja-build", "pkg-config", "qt6-base-dev", "qt6-base-private-dev", "qt6-declarative-dev", "qt6-declarative-private-dev", "qt6-shadertools-dev", "qt6-wayland-dev", "qt6-wayland-private-dev", "libcli11-dev", "libdrm-dev", "libwayland-dev", "wayland-protocols", "spirv-tools"],
    "pacman": ["base-devel", "cmake", "ninja", "pkgconf", "qt6-base", "qt6-declarative", "qt6-shadertools", "qt6-wayland", "cli11", "libdrm", "wayland", "wayland-protocols", "spirv-tools"],
    "dnf": ["gcc-c++", "cmake", "ninja-build", "pkgconf-pkg-config", "qt6-qtbase-devel", "qt6-qtbase-private-devel", "qt6-qtdeclarative-devel", "qt6-qtdeclarative-private-devel", "qt6-qtshadertools-devel", "qt6-qtwayland-devel", "qt6-qtwayland-private-devel", "cli11-devel", "libdrm-devel", "wayland-devel", "wayland-protocols-devel", "spirv-tools-devel"],
    "zypper": ["gcc-c++", "cmake", "ninja", "pkg-config", "qt6-base-devel", "qt6-base-private-devel", "qt6-declarative-devel", "qt6-declarative-private-devel", "qt6-shadertools-devel", "qt6-wayland-devel", "qt6-wayland-private-devel", "CLI11-devel", "libdrm-devel", "wayland-devel", "wayland-protocols-devel", "spirv-tools-devel"],
}


OFF_FEATURES = ("CRASH_HANDLER", "USE_JEMALLOC", "BUILD_TESTING", "X11", "I3", "HYPRLAND_IPC", "BLUETOOTH", "NETWORK", "SCREENCOPY", "WAYLAND_SESSION_LOCK", "HYPRLAND_GLOBAL_SHORTCUTS", "HYPRLAND_FOCUS_GRAB", "SERVICE_STATUS_NOTIFIER", "SERVICE_PIPEWIRE", "SERVICE_MPRIS", "SERVICE_PAM", "SERVICE_POLKIT", "SERVICE_GREETD", "SERVICE_UPOWER", "SERVICE_NOTIFICATIONS")
