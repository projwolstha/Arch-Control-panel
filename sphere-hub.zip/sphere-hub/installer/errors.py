"""Sphere's single user-facing error type."""
from __future__ import annotations


class SetupError(Exception):
    pass
