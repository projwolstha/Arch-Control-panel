#!/usr/bin/env python3
"""Sphere's installer/manager — thin executable entry point.

Everything lives in the ``installer`` package next to this file (one concern per
module). This shim only makes the project importable and calls the CLI, so it can
be run in place (``python3 installer/manager.py``) or from the extracted payload of
the single-file ``sphere-setup.sh``, where it sits next to ``installer/``.
"""
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent if (HERE.parent / "installer").is_dir() else HERE
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from installer.cli import console_main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(console_main())
