"""Manager operations, one module per concern; the facade is re-exported here."""
from __future__ import annotations

from .manager import Manager

__all__ = ["Manager"]
