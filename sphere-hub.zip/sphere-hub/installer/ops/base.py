"""BaseManager: shared plumbing (logging, atomic writes, backups, undo)."""
from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import stat
import subprocess
import uuid
from pathlib import Path

from ..errors import SetupError
from ..packages import Packages
from ..paths import Paths
from ..util import atomic, read_json, utcstamp


class BaseManager:
    """Shared plumbing: paths, logging, atomic file replacement, backups and undo."""

    def __init__(self, args):
        self.args = args
        self.p = Paths()
        self.meta = read_json(self.p.manifest)
        self.packages = Packages(self)
        self.log = None
        self.session_backup = None
        self.undo = []
        self.backed_up = set()

    def say(self, text):
        if not self.args.json:
            print("Sphere · "+str(text), flush=True)
        if self.log:
            self.log.write(utcstamp()+" "+str(text)+"\n")
            self.log.flush()

    def open_log(self):
        self.p.logdir.mkdir(parents=True, exist_ok=True, mode=0o700)
        if self.p.managerlog.exists() and self.p.managerlog.stat().st_size > 2_000_000:
            os.replace(self.p.managerlog, self.p.managerlog.with_suffix(".previous.log"))
        fd = os.open(self.p.managerlog, os.O_WRONLY|os.O_APPEND|os.O_CREAT, 0o600)
        self.log = os.fdopen(fd, "a", buffering=1)
        os.chmod(self.p.managerlog, 0o600)

    def run(self, argv, timeout=600, cwd=None, env=None):
        self.say("$ "+shlex.join(list(map(str, argv))))
        if self.args.dry_run:
            return
        try:
            # Inherit the actual terminal for sudo/package-manager messages and prompts.
            result = subprocess.run(list(map(str, argv)), timeout=timeout, cwd=cwd, env=env)
        except (OSError, subprocess.TimeoutExpired) as e:
            raise SetupError(str(e)) from e
        if result.returncode:
            raise SetupError(f"Command exited {result.returncode}: {shlex.join(list(map(str, argv)))}. Existing desktop packages/configuration were not force-replaced.")

    def backup(self, path):
        path = Path(path)
        if path in self.backed_up or not path.exists():
            return
        if self.session_backup is None:
            self.session_backup = self.p.backups/(utcstamp()+"-"+uuid.uuid4().hex[:6])
            self.session_backup.mkdir(parents=True, mode=0o700)
        name = path.name+"-"+hashlib.sha256(str(path).encode()).hexdigest()[:10]
        destination = self.session_backup/name
        if path.is_dir():
            shutil.copytree(path, destination, symlinks=True)
        else:
            shutil.copy2(path, destination)
        self.backed_up.add(path)
        self.say("Backup: "+str(destination))

    def replace(self, path, data, mode=0o600):
        path = Path(path)
        if path.is_symlink():
            path = path.resolve(strict=True)
        data = data.encode() if isinstance(data, str) else data
        old = path.read_bytes() if path.exists() else None
        old_mode = stat.S_IMODE(path.stat().st_mode) if old is not None else mode
        if old == data:
            return
        self.backup(path)
        atomic(path, data, mode)
        self.undo.append((path, old, old_mode))

    def write_controller(self):
        """Install the manager package and its entry point into the data directory.

        The manager is a package, so the detached controller (used for supervision
        and by `sphere-setup` after the download is gone) needs its modules next to
        its entry point: entry at data/manager.py, package at data/installer/.
        """
        import installer as _package
        package = Path(_package.__file__).resolve().parent
        self.replace(self.p.controller, (package/"manager.py").read_bytes(), 0o700)
        for path in sorted(package.rglob("*.py")):
            if "__pycache__" in path.parts:
                continue
            self.replace(self.p.controller_pkg/path.relative_to(package), path.read_bytes(), 0o644)

    def write_controller(self):
        """Install the manager package and its entry point into the data directory.

        The manager is a package, so the detached controller (used for supervision
        and by `sphere-setup` after the download is gone) needs its modules next to
        its entry point: entry at data/manager.py, package at data/installer/.
        """
        import installer as _package
        package = Path(_package.__file__).resolve().parent
        self.replace(self.p.controller, (package/"manager.py").read_bytes(), 0o700)
        for path in sorted(package.rglob("*.py")):
            if "__pycache__" in path.parts:
                continue
            self.replace(self.p.controller_pkg/path.relative_to(package), path.read_bytes(), 0o644)

    def save_meta(self):
        self.replace(self.p.manifest, json.dumps(self.meta, indent=2, ensure_ascii=False)+"\n")
