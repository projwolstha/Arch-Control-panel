"""Transactional deployment of the native widget payload."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path

from ..constants import BUNDLE, NATIVE_FILES, VERSION
from ..errors import SetupError
from ..util import atomic, qt_version, read_json, version

# Files earlier builds wrote into this same directory and that this one does not
# ship any more. The deploy used to *merge* into ~/.config/quickshell/sphere-hub,
# so an upgrade left the old orb's files sitting next to the new ring — and the
# tests then (correctly) refused the result. They are removed explicitly, so
# "the old sphere is gone" is true on disk and not only in the scene graph.
LEGACY_NATIVE_FILES = ("MainOrb.qml", "SphereFlow.js", "ArcaneOrb.qml",
                       "assets/centre-orb.png",
                       # the gem → centre reflections: they lived in that orb
                       "assets/refl-wifi.svg", "assets/refl-bluetooth.svg",
                       "assets/refl-battery.svg", "assets/refl-chip.svg",
                       "assets/refl-folder.svg",
                       "shaders/glass.frag", "shaders/glass.frag.qsb",
                       "assets/sphere-artwork.png")


def pathlib_exists(path):
    return Path(path).is_file()


class DeployMixin:
    """Transactional deployment of the native widget bundle, slots, launcher and self-tests."""

    def prepare_logo_dir(self):
        """Give the centre mark somewhere obvious to live.

        The dashboard watches ~/.config/jarvis/logo.svg and falls back to
        logo.png and then to its own arch glyph. Creating the directory (never a
        file) means the place to drop a mark exists without the installer ever
        writing one, and the summary line tells the user the path.
        """
        target = Path(os.environ.get("XDG_CONFIG_HOME", "~/.config")).expanduser()/"jarvis"
        try:
            target.mkdir(parents=True, exist_ok=True, mode=0o700)
        except OSError:
            return
        self.say("Logo directory ready: "+str(target/"logo.svg")+" (SVG preferred, PNG accepted; missing is fine).")

    def clear_qml_cache(self):
        """Drop Quickshell's compiled-QML cache after new files land.

        Quickshell keeps the compiled form of every .qml it has loaded. The key
        is normally the file's timestamp, but a copy that keeps the old mtime (or
        a cache written by a different build of the same version) can hand back
        the previous ring after a correct deployment. The cache is disposable —
        it is rebuilt on the next start — so an update removes it rather than
        trusting it.
        """
        cache = Path(os.environ.get("XDG_CACHE_HOME") or (Path.home()/".cache"))/"quickshell"
        if not cache.is_dir():
            return
        try:
            shutil.rmtree(cache)
        except OSError:
            return
        self.say("Cleared Quickshell's compiled-QML cache (it rebuilds on the next start).")

    def deploy_native(self):
        if self.p.config.is_symlink():
            raise SetupError("The Sphere Quickshell directory is a symlink. It may be declaratively managed; it was not replaced.")
        self.p.config.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        stage = Path(tempfile.mkdtemp(prefix=".sphere-stage-", dir=self.p.config.parent))
        self.backup(self.p.config)
        rollback = self.p.config.with_name(".sphere-rollback-"+uuid.uuid4().hex)
        try:
            if self.p.config.exists():
                shutil.copytree(self.p.config, stage, dirs_exist_ok=True, symlinks=True, ignore=shutil.ignore_patterns("__pycache__"))
            for name in NATIVE_FILES:
                target = stage/name
                # Do not follow an old symlink when overwriting managed native files.
                relative_parent = Path(name).parent
                current = stage
                for part in relative_parent.parts:
                    current = current/part
                    if current.is_symlink():
                        current.unlink()
                    current.mkdir(exist_ok=True)
                if target.is_symlink():
                    target.unlink()
                shutil.copyfile(BUNDLE/name, target)
                target.chmod(0o755 if name in ("start.sh", "backend.py", "backend-launch.sh") else 0o644)
            # What the previous install deployed, read from its own manifest. The
            # union of that and the hard-coded legacy list, minus what this build
            # ships, is exactly the set of files to delete.
            previous = set()
            manifest = self.p.config/"sphere-package.json"
            if manifest.is_file():
                try:
                    previous = set((read_json(manifest) or {}).get("sha256") or {})
                except (OSError, ValueError):
                    previous = set()
            stale = (previous | set(LEGACY_NATIVE_FILES)) - set(NATIVE_FILES)
            removed = []
            for name in sorted(stale):
                victim = stage/name
                if victim.is_file() or victim.is_symlink():
                    victim.unlink()
                    removed.append(name)
                    parent = victim.parent
                    while parent != stage and parent != parent.parent:
                        try:
                            parent.rmdir()          # only ever removes empty dirs
                        except OSError:
                            break
                        parent = parent.parent
            if removed:
                self.say("Removed what this build no longer ships: " + ", ".join(removed))
            inventory = {name:hashlib.sha256((stage/name).read_bytes()).hexdigest() for name in NATIVE_FILES}
            atomic(stage/"sphere-package.json", json.dumps({"version":VERSION,"sha256":inventory}, indent=2)+"\n", 0o644)
            if self.p.config.exists():
                os.replace(self.p.config, rollback)
            try:
                os.replace(stage, self.p.config)
            except BaseException:
                if rollback.exists():
                    os.replace(rollback, self.p.config)
                raise
            self.prepare_logo_dir()
            self.native_swapped = True
            self.native_rollback = rollback if rollback.exists() else None
            self.native_created = not rollback.exists()
        finally:
            if stage.exists():
                shutil.rmtree(stage)

    def _find_cargo_toolchain(self):
        cargo = shutil.which("cargo")
        rustc = shutil.which("rustc")
        if cargo and rustc:
            return cargo, rustc
        rustup_bin = Path.home()/".cargo"/"bin"
        if (rustup_bin/"cargo").is_file() and (rustup_bin/"rustc").is_file():
            return str(rustup_bin/"cargo"), str(rustup_bin/"rustc")
        return None, None

    def install_rust_backend(self):
        """Build and install the zero-dependency Rust `sphere-backend` + `jarvis-organize` binaries."""
        self._built_organizer = None
        crate_dir = BUNDLE.parent/"rust-backend"
        if not (crate_dir/"Cargo.toml").is_file():
            return
        self.p.bin.mkdir(parents=True, exist_ok=True, mode=0o700)

        # Reuse prebuilt release binaries if present and runnable on this host
        prebuilt_backend = crate_dir/"target"/"release"/"sphere-backend"
        prebuilt_org = crate_dir/"target"/"release"/"jarvis-organize"
        if prebuilt_backend.is_file() and prebuilt_org.is_file():
            try:
                probe = subprocess.run([str(prebuilt_backend), "--version"],
                                       capture_output=True, text=True, timeout=5)
                if probe.returncode == 0 and "sphere-backend" in probe.stdout:
                    self.replace(self.p.bin/"sphere-backend", prebuilt_backend.read_bytes(), 0o755)
                    self._built_organizer = prebuilt_org.read_bytes()
                    self.say("Installed native Rust backend: "+str(self.p.bin/"sphere-backend"))
                    return
            except (OSError, subprocess.SubprocessError):
                pass

        cargo, rustc = self._find_cargo_toolchain()
        if not (cargo and rustc) and not getattr(self.args, "no_deps", False) and self.packages.kind:
            pkgs = ["rust"] if self.packages.kind == "pacman" else ["cargo", "rustc"]
            self.say("Installing Rust toolchain to compile the low-memory native backend…")
            self.packages.install(pkgs, required=False)
            cargo, rustc = self._find_cargo_toolchain()

        if not (cargo and rustc):
            self.say("Rust toolchain not found; keeping Python stdlib backend fallback.")
            return

        with tempfile.TemporaryDirectory(prefix="sphere-rust-build-") as build_dir:
            env = os.environ.copy()
            env["CARGO_TARGET_DIR"] = build_dir
            env["RUSTC"] = rustc
            self.say("Compiling native Rust backend (sphere-backend + jarvis-organize, offline std-only)…")
            result = subprocess.run(
                [cargo, "build", "--release", "--offline", "--manifest-path", str(crate_dir/"Cargo.toml")],
                capture_output=True, text=True, timeout=300, env=env
            )
            if result.returncode != 0:
                raise SetupError("Failed to compile native Rust backend:\n" + (result.stderr or result.stdout)[-1200:])
            built_backend = Path(build_dir)/"release"/"sphere-backend"
            built_org = Path(build_dir)/"release"/"jarvis-organize"
            self.replace(self.p.bin/"sphere-backend", built_backend.read_bytes(), 0o755)
            self._built_organizer = built_org.read_bytes()
            self.say("Compiled and installed native Rust backend: "+str(self.p.bin/"sphere-backend"))

    def install_organizer(self):
        """Install the file organizer: one command, and its rules if there are none.

        ``jarvis-organize`` is installed as a compiled native Rust binary (or the
        reference Python 3 script if built with ``--no-deps`` without ``rustc``)
        at 0755 in ~/.local/bin, usable from a terminal, and the only thing the
        panel ever calls. The rules file is created with the default categories
        the first time and never rewritten — a user who edits a category or an
        ignore pattern keeps that edit through every repair.
        """
        built_org = getattr(self, "_built_organizer", None)
        source = BUNDLE/"jarvis-organize"
        if built_org is None and not source.is_file():
            self.say("The file organizer is not part of this bundle; skipping it.")
            return
        self.p.bin.mkdir(parents=True, exist_ok=True, mode=0o700)
        payload = built_org if built_org is not None else source.read_bytes()
        self.replace(self.p.bin/"jarvis-organize", payload, 0o755)
        self.say("Installed the file organizer: "+str(self.p.bin/"jarvis-organize"))
        rules_dir = self.p.config_home/"jarvis"
        if not (rules_dir/"organize.json").exists():
            rules_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
            # Ask the backend for its own defaults, so the categories have exactly
            # one definition. If that fails, write a minimal file it can extend.
            created = False
            try:
                cmd = ([str(self.p.bin/"jarvis-organize"), "init"]
                       if built_org is not None
                       else [sys.executable, str(self.p.bin/"jarvis-organize"), "init"])
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
                created = result.returncode == 0 and (rules_dir/"organize.json").is_file()
            except (OSError, subprocess.SubprocessError):
                created = False
            if not created:
                self.replace(rules_dir/"organize.json", '{\n  "version": 1,\n  "categories": {},\n  "ignore": []\n}\n', 0o644)
            self.say("Created the organizer rules at "+str(rules_dir/"organize.json")+" (default categories).")
        else:
            self.say("Kept the existing organizer rules at "+str(rules_dir/"organize.json")+" (never overwritten).")

    def seed_slots(self):
        if self.p.state.exists():
            self.say("Preserving all eight existing orb assignments and preferences.")
            return
        old_bytecode_setting = sys.dont_write_bytecode
        sys.dont_write_bytecode = True
        try:
            spec = importlib.util.spec_from_file_location("sphere_backend_setup", self.p.config/"backend.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
        finally:
            sys.dont_write_bytecode = old_bytecode_setting
        catalog = module.DesktopCatalog()
        catalog.refresh()
        # The dashboard has five fixed gems now, so nothing is ever assigned into
        # these eight legacy entries; the list stays (empty) because the state
        # file's schema and `doctor` still know the key.
        slots = [None]*8
        if self.args.seed_installed:
            priority = ("firefox", "org.mozilla.firefox", "firefox-esr", "chromium", "foot", "kitty", "org.kde.konsole", "org.kde.dolphin", "org.gnome.nautilus", "thunar", "code", "codium", "org.kde.kate", "org.gnome.texteditor", "vlc", "mpv", "pavucontrol")
            entries = list(catalog.entries)
            ordered = []
            for name in priority:
                ordered += [entry for entry in entries if entry.removesuffix(".desktop").lower() == name and entry not in ordered]
            ordered += [entry for entry in entries if entry not in ordered and entry != "sphere-hub.desktop"]
            for index, app in enumerate(ordered[:8]):
                slots[index] = {"kind":"desktop", "id":app}
        store = module.ConfigStore(self.p.state)
        store.data["slots"] = slots
        self.replace(self.p.state, json.dumps(store.data, indent=2)+"\n")
        self.say("Saved the state file. The dashboard's five gems are fixed; the legacy slot list stays empty.")

    def desktop_entry(self):
        # Desktop Exec has its own escaping rules; never reuse shell quoting here.
        value = str(self.p.installer)
        value = value.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`").replace("$", "\\$").replace("%", "%%")
        value = value.replace("\\", "\\\\")
        text = '[Desktop Entry]\nType=Application\nName=Sphere Hub\nComment=Show the Sphere dashboard\nExec="'+value+'" summon\nIcon=preferences-desktop\nTerminal=false\nCategories=Utility;\nStartupNotify=false\nOnlyShowIn=Hyprland;\n'
        self.replace(self.p.desktop, text, 0o644)

    def self_tests(self):
        env = os.environ.copy()
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        self.run([sys.executable, "-m", "unittest", "discover", "-s", str(self.p.config/"tests"), "-q"], timeout=60, env=env)
