"""Integrity, doctor, status and logs."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import time
from pathlib import Path

from ..constants import MARKER, TERMINALS, VERSION
from ..util import read_json


class DiagnoseMixin:
    """Integrity checks, doctor, status and log tailing."""

    def check_integrity(self):
        record = read_json(self.p.config/"sphere-package.json")
        failures = []
        for name, expected in record.get("sha256", {}).items():
            relative = Path(name)
            if relative.is_absolute() or ".." in relative.parts:
                failures.append("invalid package inventory path")
                continue
            path = self.p.config/relative
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                failures.append(name)
        return bool(record.get("sha256")) and not failures, failures

    def doctor(self):
        health = self.health()
        integrity, bad_files = self.check_integrity()
        qs = self.candidate_qs()
        checks = []
        def add(name, ok, detail, pending=False):
            checks.append({"check":name,"status":"pending" if pending else "pass" if ok else "fail","detail":detail})
        add("normal-user", os.getuid() != 0, "GUI and personal configuration must never run as root")
        add("python", sys.version_info >= (3,10), sys.version.split()[0])
        rust_bin = self.p.bin/"sphere-backend"
        rust_ok = rust_bin.is_file() and os.access(rust_bin, os.X_OK)
        add("native Rust backend", True,
            str(rust_bin) if rust_ok else "using Python stdlib fallback (install `rust`/`cargo` and run repair)")
        add("installed payload", integrity, "verified file hashes" if integrity else ", ".join(bad_files) or "not installed")
        add("native Quickshell >=0.3 / Qt ABI", bool(qs), qs or "missing/old/private build ABI mismatch; run repair")
        add("Hyprland/hyprctl", bool(shutil.which("hyprctl")) and self.hypr_version() != (0,0,0), ".".join(map(str,self.hypr_version())))
        add("terminal", any(shutil.which(t) for t in TERMINALS), next((t for t in TERMINALS if shutil.which(t)), "missing"))
        state = read_json(self.p.state)
        add("persistent eight slots", isinstance(state.get("slots"), list) and len(state["slots"]) == 8 and "workspace" not in state, str(self.p.state))
        # Deterministic proof that the picker can see YOUR installed apps:
        # count real .desktop files across every root the adapter scans.
        found, scanned, scan_dirs = 0, 0, []
        try:
            import importlib.util as _il
            spec = _il.spec_from_file_location("sphere_backend_doctor", self.p.config/"backend.py")
            module = _il.module_from_spec(spec)
            old_bytecode = sys.dont_write_bytecode
            sys.dont_write_bytecode = True
            try:
                spec.loader.exec_module(module)
            finally:
                sys.dont_write_bytecode = old_bytecode
            catalog = module.DesktopCatalog()
            catalog.refresh()
            found, scanned = len(catalog.entries), catalog.scan_report["files"]
            scan_dirs = [str(d/"applications") for d in catalog.dirs if (d/"applications").is_dir()]
        except Exception as probe_error:
            scan_dirs = ["discovery probe failed: "+str(probe_error)]
        add("installed apps visible to the catalog", found > 0, f"{found} apps from {scanned} files; roots: " + ("; ".join(scan_dirs[:6]) or "none existed"))
        config_path = self.meta.get("autostart")
        block_ok = bool(config_path and Path(config_path).is_file() and "BEGIN "+MARKER in Path(config_path).read_text())
        add("managed autostart", block_ok if self.meta.get("enabled") else True, config_path or "disabled by choice")
        session = self.real_session()
        add("live Hyprland Wayland session", session, "current owned compositor/Wayland sockets" if session else "will be verified on Hyprland login", pending=not session)
        add("live native IPC", bool(health), "path-scoped IpcHandler, no HTTP/browser bridge", pending=not session)
        add("live backend / Hyprland", bool(health and health.get("backendConnected") and health.get("hyprland")), "real local stdio + compositor IPC", pending=not session)
        add("live painted ring", bool(health and health.get("gemCount",0) > 0 and health.get("renderedFrames",0)>0 and health.get("visible")), "actual painted layer-shell surface", pending=not session)
        # Input is one full-screen surface while the dashboard is visible: the
        # mask, the layer, the keyboard focus and the system orb's own rect are
        # reported live, because "the orb does not click" is a one-command question.
        surface = health or {}
        region = surface.get("inputRegion") or {}
        system = surface.get("system") or {}
        orb = system.get("orb") or {}
        if not surface:
            add("overlay input surface", True, "not running", pending=True)
        elif not surface.get("visible"):
            add("overlay input surface", True, "dismissed: surface unmapped, input passes through")
        elif region.get("width", 0) > 0:
            add("overlay input surface", True,
                f"mask {round(region.get('width',0))}x{round(region.get('height',0))} px, "
                f"layer {surface.get('layer','?')}, keyboard {surface.get('keyboardFocus','?')}"
                + (f"; system orb {round(orb.get('width',0))}x{round(orb.get('height',0))} px at "
                   f"{round(orb.get('x',0))},{round(orb.get('y',0))}" if orb else ""))
        else:
            add("overlay input surface", False,
                "the shell reports a 0x0 input mask while the surface is visible - run: sphere-setup restart")
        # The fourth orb's panel reads upower, falling back to sysfs. A desktop
        # with no battery is a supported machine: this check informs, never fails.
        power = self.power_report()
        add("battery / power profile", True, power["detail"])
        # Bluetooth: same rule as the panel, so "not available" is explainable.
        bluetooth = self.bluetooth_report()
        add("bluetooth adapter", bluetooth["ok"], bluetooth["detail"])
        # Wi-Fi: the same scan the panel runs, and the same four causes named.
        wifi = self.wifi_report()
        add("wifi scan", wifi["ok"], wifi["detail"])
        # The system panel reads /proc/meminfo and df. Both are basic; a failure is
        # reported and the run continues, because the panel says the same thing.
        resources = self.resources_report()
        add("memory / storage", resources["ok"], resources["detail"])
        report = {"version":VERSION,"installed":self.p.manifest.exists(),"checks":checks,"failures":sum(c["status"]=="fail" for c in checks),"pending":sum(c["status"]=="pending" for c in checks),"health":health,"logs":str(self.p.logdir)}
        if self.args.json:
            print(json.dumps(report, indent=2))
        else:
            for c in checks:
                print(f"{c['status'].upper():7} {c['check']}: {c['detail']}")
            print(f"\n{report['failures']} failed; {report['pending']} pending. Logs: {self.p.logdir}")
            print("Per-application installation still requires its own review and INSTALL confirmation in a real terminal.")
        return 1 if report["failures"] else 2 if report["pending"] else 0

    @staticmethod
    def power_report():
        """What the power panel would see, gathered without touching any service."""
        root = Path("/sys/class/power_supply")
        supplies = sorted(p.name for p in root.iterdir()) if root.is_dir() else []
        batteries = [name for name in supplies if name.startswith("BAT")]
        upower = shutil.which("upower") or ""
        devices = 0
        if upower:
            try:
                import subprocess
                out = subprocess.run([upower, "-e"], capture_output=True, text=True, timeout=8,
                                     env={"LC_ALL": "C", "PATH": "/usr/local/bin:/usr/bin:/bin"}).stdout or ""
                devices = sum(1 for line in out.splitlines() if "battery_" in line)
            except (OSError, subprocess.SubprocessError):
                devices = 0
        profiles = shutil.which("powerprofilesctl") or ""
        if batteries:
            detail = f"{', '.join(batteries)} in /sys/class/power_supply; upower devices: {devices}"
        else:
            detail = "no battery in /sys/class/power_supply (desktop or VM) — the panel says 'No battery detected'"
        if not upower:
            detail += "; upower missing (install it for kernel-level events)"
        if not profiles:
            detail += "; powerprofilesctl missing (profile buttons hidden)"
        return {"supplies": supplies, "batteries": batteries, "upower": upower,
                "devices": devices, "profiles": profiles, "detail": detail}

    @staticmethod
    def wifi_report():
        """What the Wi-Fi panel would decide, using the same rule it uses.

        `nmcli -t -f IN-USE,SSID,SIGNAL,SECURITY device wifi list --rescan yes`
        is the one call the panel trusts; an empty answer is retried once, two
        seconds later, because the first rescan after login is slow. When it comes
        back empty the reason is named (NetworkManager down, no device, device
        unmanaged, radio off) instead of reported as "no networks".
        """
        import subprocess
        import time
        cli = shutil.which("nmcli")
        if not cli:
            for candidate in ("/usr/bin/nmcli", "/bin/nmcli", "/usr/local/bin/nmcli",
                              "/usr/sbin/nmcli"):
                if os.access(candidate, os.X_OK):
                    cli = candidate
                    break
        if not cli:
            return {"ok": False, "count": 0, "radio": None,
                    "detail": "nmcli is not installed (pacman -S networkmanager)"}
        env = dict(os.environ)
        env["PATH"] = env.get("PATH", "") + ":/usr/local/bin:/usr/bin:/bin"
        env.setdefault("LC_ALL", "C")

        def run(args, timeout=20):
            try:
                return subprocess.run([cli, *args], capture_output=True, text=True,
                                      timeout=timeout, env=env, check=False)
            except (OSError, subprocess.SubprocessError) as error:
                return None

        def field(text, wanted):
            """`RUNNING:running` in terse mode; a bare word on some nmcli builds."""
            for row in (text or "").splitlines():
                row = row.strip()
                if not row:
                    continue
                if ":" in row:
                    key, _, value = row.partition(":")
                    if key.strip().lower() == wanted:
                        return value.strip().lower()
                elif wanted in row.lower():
                    return row.lower()
            return ""

        nm = run(["-t", "-f", "RUNNING", "general", "status"])
        running = field(nm.stdout, "running") if nm else ""
        nm_error = ""
        if nm is not None and nm.returncode != 0:
            nm_error = next((row.strip() for row in (nm.stderr or nm.stdout or "").splitlines()
                             if row.strip()), "")[:200]
        radio_result = run(["-t", "radio", "wifi"])
        radio = field(radio_result.stdout, "enabled") if radio_result else ""
        radio_on = radio in ("enabled", "on", "yes", "true")
        devices = run(["-t", "-f", "DEVICE,TYPE,STATE", "device", "status"])
        wifi_states = [row.split(":")[2] for row in (devices.stdout or "").splitlines()
                       if len(row.split(":")) >= 3 and row.split(":")[1] == "wifi"]
        count, detail = 0, ""
        for attempt in range(2):
            listing = run(["-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi",
                           "list", "--rescan", "yes"])
            if listing is None:
                detail = "nmcli could not be started"
                break
            count = sum(1 for row in (listing.stdout or "").splitlines()
                        if len(row.split(":")) >= 2 and row.split(":")[1].strip())
            if count:
                detail = ""
                break
            note = (listing.stderr or listing.stdout or "").strip().splitlines()
            detail = note[0][:200] if note else ""
            if "not running" in detail.lower() or "unmanaged" in (devices.stdout or "").lower():
                break
            if attempt == 0:
                time.sleep(2)
        if running in ("not running", "no", "false", "stopped") or (not running and nm_error):
            said = detail or nm_error
            return {"ok": False, "count": count, "radio": radio_on,
                    "detail": "NetworkManager is not running" + (f" — nmcli said: {said}" if said else "")}
        if running == "" and detail:
            return {"ok": False, "count": count, "radio": radio_on,
                    "detail": "NetworkManager did not answer" + (f" — nmcli said: {detail}" if detail else "")}
        if not radio_on:
            return {"ok": True, "count": count, "radio": False,
                    "detail": "radio off (the panel says 'Wi-Fi off'; Wi-Fi on switches it)"}
        if not wifi_states:
            return {"ok": False, "count": 0, "radio": radio_on,
                    "detail": "no Wi-Fi device in `nmcli device status`"
                              + (f" — nmcli said: {detail}" if detail else "")}
        if set(wifi_states) <= {"unmanaged", "unavailable"}:
            return {"ok": False, "count": 0, "radio": radio_on,
                    "detail": "the Wi-Fi device is " + ", ".join(sorted(set(wifi_states)))
                              + " — check /etc/NetworkManager/conf.d for unmanaged-devices"}
        if count:
            return {"ok": True, "count": count, "radio": radio_on,
                    "detail": f"{count} networks visible · radio {'on' if radio_on else 'off'}"
                              f" · device {', '.join(wifi_states[:2])}"}
        return {"ok": True, "count": 0, "radio": radio_on,
                "detail": "no networks in range (the adapter answered; the panel says so)"
                          + (f" — nmcli said: {detail}" if detail else "")}

    @staticmethod
    def bluetooth_report():
        """What the Bluetooth panel would decide, using the same rule it uses.

        An adapter is available iff `bluetoothctl list` prints a Controller line on
        stdout; stderr and the exit code are notes. The first empty answer is
        retried once, a second later, exactly like the panel's adapter does.
        """
        import subprocess
        import time
        cli = shutil.which("bluetoothctl")
        if not cli:
            for candidate in ("/usr/bin/bluetoothctl", "/bin/bluetoothctl",
                              "/usr/local/bin/bluetoothctl", "/usr/sbin/bluetoothctl"):
                if os.access(candidate, os.X_OK):
                    cli = candidate
                    break
        if not cli:
            return {"ok": False, "adapter": "", "powered": None, "cli": "",
                    "detail": "bluetoothctl is not installed (pacman -S bluez bluez-utils)"}
        env = dict(os.environ)
        env["PATH"] = env.get("PATH", "") + ":/usr/local/bin:/usr/bin:/bin"
        env.setdefault("LC_ALL", "C")
        line, note, powered = "", "", None
        for attempt in range(2):
            try:
                result = subprocess.run([cli, "list"], capture_output=True, text=True,
                                        timeout=10, env=env, check=False)
            except (OSError, subprocess.SubprocessError) as error:
                note = str(error)
            else:
                line = next((row.strip() for row in (result.stdout or "").splitlines()
                             if row.strip().lower().startswith("controller ")), "")
                if not line:
                    note = next((row.strip() for row in (result.stderr or "").splitlines()
                                 if row.strip()), "")
                    if "no default controller" in (note or "").lower():
                        break          # a real answer, not a hiccup
            if line:
                break
            if attempt == 0:
                time.sleep(1)
        if line:
            try:
                shown = subprocess.run([cli, "show"], capture_output=True, text=True,
                                       timeout=10, env=env, check=False).stdout or ""
                for row in shown.splitlines():
                    if row.strip().lower().startswith("powered:"):
                        powered = row.split(":", 1)[1].strip().lower() in ("yes", "on", "true")
            except (OSError, subprocess.SubprocessError):
                powered = None
        if line and powered is True:
            return {"ok": True, "adapter": line, "powered": True, "cli": cli,
                    "detail": line + " · powered on"}
        if line:
            return {"ok": True, "adapter": line, "powered": False, "cli": cli,
                    "detail": line + " · powered off — the panel shows 'Bluetooth is off' and "
                                     "the Power on button switches it on"}
        return {"ok": False, "adapter": "", "powered": None, "cli": cli,
                "detail": ("no Controller line from " + cli +
                           ((" — bluetoothctl said: " + note) if note else "")
                           + " — check: sudo systemctl status bluetooth")}

    @staticmethod
    def resources_report():
        """What the SYSTEM panel would see: memory, swap and the mount count."""
        detail, ok = "", False
        try:
            with open("/proc/meminfo", "r", encoding="utf-8") as handle:
                lines = handle.read().splitlines()
            fields = {}
            for line in lines:
                if ":" in line:
                    key, _, rest = line.partition(":")
                    number = rest.strip().split(" ")[0] if rest.strip() else ""
                    if number.isdigit():
                        fields[key.strip()] = int(number)
            total = fields.get("MemTotal")
            if total:
                available = fields.get("MemAvailable")
                used_pct = int(round(100 * (total - (available or 0)) / total))
                swap = fields.get("SwapTotal", 0)
                detail = f"{total // 1048576} GiB RAM, {used_pct}% used"
                detail += f"; swap {swap // 1048576} GiB" if swap else "; no swap"
                ok = True
            else:
                detail = "/proc/meminfo has no MemTotal"
        except OSError as error:
            detail = f"/proc/meminfo is unreadable ({error.__class__.__name__})"
        tools = [name for name in ("df", "ps") if not shutil.which(name)]
        if tools:
            detail += "; missing " + ", ".join(tools) + " (rows hidden, not an error)"
        return {"ok": ok, "detail": detail}

    def status(self):
        health = self.health()
        result = {"version":self.meta.get("version"),"installed":self.p.manifest.exists(),"running":bool(health),"healthy":bool(health and health.get("backendConnected") and health.get("hyprland") and health.get("gemCount",0) > 0),"autostart":self.meta.get("enabled",False),"supervisorPid":self.supervisor_pid(),"config":str(self.p.config),"state":str(self.p.state),"health":health}
        print(json.dumps(result, indent=2) if self.args.json else "\n".join(f"{key}: {value}" for key,value in result.items() if key != "health"))

    def logs(self):
        for path in (self.p.managerlog, self.p.logdir/"supervisor.log", self.p.renderlog):
            print("\n=== "+str(path)+" ===")
            try:
                # Logs are rotated to bound memory usage.
                with path.open("rb") as stream:
                    stream.seek(max(0,path.stat().st_size-1_000_000))
                    text = stream.read().decode("utf-8", "replace")
                print("\n".join(text.splitlines()[-max(1,min(self.args.lines,2000)):]))
            except OSError:
                print("No log yet.")
