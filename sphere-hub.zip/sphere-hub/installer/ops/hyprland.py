"""Hyprland config discovery and Sphere's own autostart block."""
from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import stat
import tempfile
from pathlib import Path

from ..constants import MARKER, TERMINALS
from ..errors import SetupError
from ..util import query


class HyprlandMixin:
    """Locating, verifying and editing only Sphere's own Hyprland autostart block."""

    def active_hyprland_config(self):
        if self.args.hyprland_config:
            return Path(self.args.hyprland_config).expanduser().absolute()
        explicit = os.environ.get("HYPRLAND_CONFIG")
        signature = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE", "")
        runtime = os.environ.get("XDG_RUNTIME_DIR", "")
        # The lock records the compositor PID. Inspect only a same-user, actual Hyprland.
        if signature and "/" not in signature and runtime:
            lock = Path(runtime)/"hypr"/signature/"hyprland.lock"
            try:
                pid = int(lock.read_text().splitlines()[0])
                proc = Path("/proc")/str(pid)
                if proc.stat().st_uid == os.getuid():
                    raw = (proc/"cmdline").read_bytes().split(b"\0")
                    argv = [a.decode(errors="replace") for a in raw if a]
                    if argv and Path(argv[0]).name.lower() == "hyprland":
                        for index, value in enumerate(argv):
                            if value in ("-c", "--config") and index+1 < len(argv):
                                explicit = argv[index+1]
                            elif value.startswith("--config="):
                                explicit = value.split("=", 1)[1]
                        for value in (proc/"environ").read_bytes().split(b"\0"):
                            if value.startswith(b"HYPRLAND_CONFIG=") and not explicit:
                                explicit = value.partition(b"=")[2].decode(errors="replace")
            except (OSError, ValueError, IndexError):
                pass
        if explicit:
            p = Path(os.path.expandvars(explicit)).expanduser()
            if not p.is_absolute():
                raise SetupError("The compositor uses a relative custom configuration path; pass --hyprland-config with its absolute path to avoid editing the wrong file.")
            return p
        folder = self.p.config_home/"hypr"
        lua, legacy = folder/"hyprland.lua", folder/"hyprland.conf"
        if self.hypr_version() >= (0, 55, 0):
            return lua if lua.exists() or not legacy.exists() else legacy
        return legacy if legacy.exists() or not lua.exists() else lua

    def template(self, path):
        terminal = next((t for t in TERMINALS if shutil.which(t)), "foot")
        is_lua = path.suffix == ".lua"
        for directory in (Path("/usr/share/hypr"), Path("/usr/share/hyprland"), Path("/usr/local/share/hypr")):
            candidate = directory/("hyprland.lua" if is_lua else "hyprland.conf")
            if candidate.is_file():
                text = candidate.read_text()
                if is_lua:
                    text = re.sub(r'(local\s+terminal\s*=\s*)"kitty"', r'\1"'+terminal+'"', text)
                else:
                    text = text.replace("$terminal = kitty", "$terminal = "+terminal)
                return text
        if is_lua:
            return '''-- Usable native Lua defaults created by Sphere; never replace an existing config.
hl.monitor({ output = "", mode = "preferred", position = "auto", scale = 1 })
hl.config({ input = { kb_layout = "us" }, general = { gaps_in = 5, gaps_out = 12, border_size = 2 } })
local terminal = TERMINAL
hl.bind("SUPER + Return", hl.dsp.exec_cmd(terminal))
hl.bind("SUPER + C", hl.dsp.window.close())
hl.bind("SUPER + M", hl.dsp.exit())
for i = 1, 9 do
  hl.bind("SUPER + " .. i, hl.dsp.focus({ workspace = i }))
  hl.bind("SUPER + SHIFT + " .. i, hl.dsp.window.move({ workspace = i }))
end
'''.replace("TERMINAL", json.dumps(terminal))
        text = "# Usable native defaults created by Sphere; edit freely.\nmonitor = ,preferred,auto,1\n$mainMod = SUPER\n$terminal = "+terminal+"\ninput {\n  kb_layout = us\n}\ngeneral {\n  gaps_in = 5\n  gaps_out = 12\n  border_size = 2\n}\nbind = $mainMod, Return, exec, $terminal\nbind = $mainMod, C, killactive,\nbind = $mainMod, M, exit,\n"
        for i in range(1, 10):
            text += f"bind = $mainMod, {i}, workspace, {i}\nbind = $mainMod SHIFT, {i}, movetoworkspace, {i}\n"
        return text

    def strip_block(self, text):
        # Exact, bounded markers only. Never regex-delete an unrelated QS/bar line.
        pattern = rf"(?m)^(?:#|--) BEGIN {re.escape(MARKER)}\s*\n.*?^(?:#|--) END {re.escape(MARKER)}[^\n]*(?:\n|$)"
        return re.sub(pattern, "", text, flags=re.S)

    def verify_hyprland_text(self, path, text):
        if path.suffix == ".lua" and self.hypr_version() < (0, 55, 0):
            raise SetupError("Lua autostart requires Hyprland >=0.55. This existing Lua configuration was not modified for an older compositor.")
        binary = shutil.which("Hyprland") or shutil.which("hyprland")
        if not binary:
            raise SetupError("Native Hyprland config verifier is missing.")
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd, name = tempfile.mkstemp(prefix=".sphere-verify-", suffix=path.suffix, dir=path.parent)
        os.close(fd)
        try:
            Path(name).write_text(text)
            env = os.environ.copy()
            with tempfile.TemporaryDirectory(prefix="sphere-verify-runtime-") as temporary:
                if not self.p.runtime():
                    os.chmod(temporary, 0o700)
                    env["XDG_RUNTIME_DIR"] = temporary
                code, out, err = query([binary, "--verify-config", "-c", name], timeout=35, env=env)
            result = out+"\n"+err
            if "config ok" in result.lower() and code == 0:
                return "native Hyprland --verify-config passed"
            if "unknown" in result.lower() and ("verify-config" in result or "argument" in result):
                # Old compositors did not all provide the static verifier.
                self.say("This older Hyprland has no static config verifier; managed legacy syntax is checked, full validation will use its live IPC.")
                return "static verifier unavailable on this old version"
            raise SetupError("Hyprland rejected the proposed configuration; the original file is unchanged.\n"+result[-5000:])
        finally:
            Path(name).unlink(missing_ok=True)

    def enable_autostart(self):
        path = self.active_hyprland_config()
        if path.is_symlink():
            path = path.resolve(strict=True)
        original = path.read_text() if path.exists() else self.template(path)
        clean = self.strip_block(original)
        command = shlex.join([str(self.p.installer), "start"])
        toggle = shlex.join([str(self.p.installer), "toggle"])
        if path.suffix == ".lua":
            block = (f'-- BEGIN {MARKER}\n'
                     f'hl.on("hyprland.start", function()\n  hl.exec_cmd({json.dumps(command, ensure_ascii=False)})\nend)\n'
                     f'-- Sphere owns the pointer and the keyboard while it is on screen; SUPER + A\n'
                     f'-- hides it again (nothing underneath is reachable meanwhile). No other\n'
                     f'-- hyprland.conf change is needed: see docs/INPUT.md.\n'
                     f'hl.bind("SUPER + A", hl.dsp.exec_cmd({json.dumps(toggle, ensure_ascii=False)}))\n'
                     f'-- END {MARKER}\n')
        else:
            # Hyprlang treats # as a comment even inside shell quoting, and bind
            # arguments are comma separated. Such paths are rejected, never mangled.
            if any(c in command+toggle for c in "#,\n\r"):
                raise SetupError("This installation path cannot be represented safely in legacy hyprlang. Lua configurations support such paths.")
            block = (f"# BEGIN {MARKER}\nexec-once = {command}\n"
                     f"# Sphere owns the pointer and the keyboard while it is on screen; SUPER + A\n"
                     f"# hides it again (nothing underneath is reachable meanwhile). No other\n"
                     f"# hyprland.conf change is needed: see docs/INPUT.md.\n"
                     f"bind = SUPER, A, exec, {toggle}\n"
                     f"# END {MARKER}\n")
        updated = clean.rstrip()+"\n\n"+block
        checked = self.verify_hyprland_text(path, updated)
        self.replace(path, updated, mode=stat.S_IMODE(path.stat().st_mode) if path.exists() else 0o644)
        configs = self.meta.get("autostartConfigs", [])
        if str(path) not in configs:
            configs.append(str(path))
        self.meta.update(autostartConfigs=configs, autostart=str(path), autostartCheck=checked, enabled=True)
        self.say("Autostart enabled in "+str(path)+" · "+checked)


    def disable_autostart(self):
        configs = list(self.meta.get("autostartConfigs", []))
        if self.meta.get("autostart"):
            configs.append(self.meta["autostart"])
        if self.args.hyprland_config:
            configs.append(str(Path(self.args.hyprland_config).expanduser().absolute()))
        for value in dict.fromkeys(configs):
            path = Path(value)
            if path.exists():
                text = path.read_text()
                updated = self.strip_block(text)
                if updated != text:
                    self.replace(path, updated, stat.S_IMODE(path.stat().st_mode))
        self.meta["enabled"] = False
        self.say("Only Sphere's marked autostart block was removed; the rest of Hyprland is untouched.")
