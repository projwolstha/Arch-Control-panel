"""Install/repair/update and the read-only plan output."""
from __future__ import annotations

import json
import os
import shlex
import shutil
import sys
from pathlib import Path

from ..constants import RUNTIME_PACKAGES, VERSION
from ..errors import SetupError
from ..util import atomic, utcstamp


class InstallMixin:
    """The install/repair/update operation and its read-only plan."""

    def install(self):
        self.verify_bundle()
        if self.p.config.is_symlink() and not self.args.dry_run:
            raise SetupError("The Sphere config is a symlink/declaratively managed. It was not stopped, replaced or removed.")
        if self.args.dry_run:
            return self.plan()
        self.open_log()
        self.say("Native setup "+VERSION+"; no browser server, WebEngine or workspace restart hook.")
        qs = self.ensure_dependencies()
        script = Path(os.environ.get("SPHERE_INSTALLER_FILE", ""))
        if not script.is_file():
            raise SetupError("Install/repair must be run using the self-contained sphere-setup.sh, not a detached manager.py.")
        self.stop(quiet=True)
        self.native_rollback = None
        self.native_created = False
        self.native_swapped = False
        try:
            self.deploy_native()
            self.clear_qml_cache()
            self.install_rust_backend()
            self.install_organizer()
            self.write_controller()
            self.replace(self.p.installer, script.read_bytes(), 0o700)
            self.replace(self.p.command, '#!/bin/sh\nexec '+shlex.quote(str(self.p.installer))+' "$@"\n', 0o755)
            self.seed_slots()
            os.chmod(self.p.state, 0o600)
            self.desktop_entry()
            self.meta.update(version=VERSION, quickshell=qs, python=sys.executable, config=str(self.p.config), installedAt=self.meta.get("installedAt", utcstamp()), repairedAt=utcstamp(), native=True, software=self.args.software or self.meta.get("software", False))
            if not self.args.no_autostart:
                self.enable_autostart()
            self.self_tests()
            for cache in self.p.config.rglob("__pycache__"):
                shutil.rmtree(cache)
            self.save_meta()
        except BaseException:
            self.say("Deployment failed. Rolling back managed files; preserving the prior native configuration and saved orbs.")
            for path, old, mode in reversed(self.undo):
                if old is None:
                    path.unlink(missing_ok=True)
                else:
                    atomic(path, old, mode)
            if self.native_swapped:
                if self.p.config.exists():
                    shutil.rmtree(self.p.config)
                if self.native_rollback and self.native_rollback.exists():
                    os.replace(self.native_rollback, self.p.config)
            raise
        if self.native_rollback and self.native_rollback.exists():
            shutil.rmtree(self.native_rollback)
        # An update is only finished when the thing on screen is the thing on
        # disk. `--no-start` and a headless run are the two honest exceptions.
        if not self.args.no_start and not self.args.dry_run:
            self.restart_after_update()
            self.say("Ready. Manager: "+str(self.p.command)+" (or rerun this same downloaded script).")
            return
        if not self.args.no_start and self.real_session():
            self.start()
        else:
            self.say("Installed and statically checked. Live checks are pending: "+("--no-start requested." if self.args.no_start else "no active Hyprland/Wayland session; it will start on your next Hyprland login."))
        self.say("Ready. Manager: "+str(self.p.command)+" (or rerun this same downloaded script).")
        self.say("Commands: status · doctor · start · stop · restart · toggle · summon · repair · logs · enable · disable · uninstall")
        self.say("Your mark: drop an SVG (or PNG) at ~/.config/jarvis/logo.svg — it is watched and reloaded in place, no restart. Without one the centre shows a gold arch glyph.")
        self.say("Interaction: while the dashboard is on screen it owns every click, scroll and key (full-screen Overlay layer, exclusive keyboard focus); Escape or SUPER+A dismisses it and the surface unmaps, so nothing is captured; SUPER+A again summons it ready to use.")
        if self.args.json:
            print(json.dumps({"installed":True,"version":VERSION,"config":str(self.p.config),"manager":str(self.p.command),"liveCheck":self.health() if self.real_session() else None}))

    def plan(self):
        info = {"version":VERSION,"mode":"dry-run","distribution":self.packages.describe(),"packageManager":self.packages.kind,"existingQuickshell":self.candidate_qs(),"hyprlandVersion":".".join(map(str,self.hypr_version())),"nativeConfig":str(self.p.config),"statePreserved":str(self.p.state),"manager":str(self.p.command),"autostartFile":str(self.active_hyprland_config()),"runtimePackages":RUNTIME_PACKAGES.get(self.packages.kind, []),"terminalPolicy":"keep installed supported terminal, otherwise install foot/kitty/xterm","quickshellPolicy":"signed distro package >=0.3; otherwise checksum-pinned official v0.3.2 private source build against host Qt >=6.6 using WlrLayerShell (Hyprland IPC lives in Sphere's stdlib backend)","hyprlandPolicy":"signed distro package only; never replace session or compile the ecosystem","workspacePolicy":"one layer-shell surface; never start/restart on workspace change",
            "inputPolicy":"full-screen WlrLayer.Overlay surface anchored top/bottom/left/right, exclusion ignored; input mask = the whole monitor while visible and 0x0 while hidden; keyboard focus exclusive while visible, none while hidden; Escape or SUPER+A dismisses and unmaps it","dismissalPolicy":"SUPER+A dismiss exits the widget+adapter processes (0 MB while hidden, honored across logins); SUPER+A summon relaunches usable from disk state","modifications":False}
        print(json.dumps(info, indent=2))
