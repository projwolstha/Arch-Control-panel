"""One Manager class assembled from the operation mixins."""
from __future__ import annotations

from .base import BaseManager
from .payload import PayloadMixin
from .quickshell import QuickshellMixin
from .deploy import DeployMixin
from .hyprland import HyprlandMixin
from .install import InstallMixin
from .session import SessionMixin
from .diagnose import DiagnoseMixin
from .uninstall import UninstallMixin


class Manager(InstallMixin, DeployMixin, HyprlandMixin, SessionMixin, DiagnoseMixin, UninstallMixin, QuickshellMixin, PayloadMixin, BaseManager):
    """Sphere's installer/manager. Each concern lives in its own mixin module."""

    pass
