"""Payload integrity checks for the extracted installer bundle."""
from __future__ import annotations

import hashlib
from pathlib import Path

from ..constants import BUNDLE
from ..errors import SetupError
from ..util import read_json


class PayloadMixin:
    """Verification of the embedded native payload against its inventory."""

    def verify_bundle(self):
        root = BUNDLE.parent
        inventory = read_json(root/"checksums.json")
        if not inventory:
            raise SetupError("The embedded payload inventory is missing; nothing was installed.")
        for name, expected in sorted(inventory.items()):
            relative = Path(name)
            if relative.is_absolute() or ".." in relative.parts or not relative.parts:
                raise SetupError("Unsafe path in the embedded payload inventory: "+name)
            path = root/relative
            if not path.is_file() or path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise SetupError("Embedded payload verification failed: "+name)
        # Every Python file in the payload must at least compile before we deploy it.
        for path in sorted(root.rglob("*.py")):
            compile(path.read_text(), str(path), "exec")
