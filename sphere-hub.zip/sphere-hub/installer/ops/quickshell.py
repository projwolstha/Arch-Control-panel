"""Quickshell discovery, dependency resolution and pinned source builds."""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import shutil
import tarfile
import tempfile
import urllib.request
from pathlib import Path

from ..constants import BUILD_PACKAGES, MIN_QS, OFF_FEATURES, QS_REV, QS_SHA, QS_URL, RUNTIME_PACKAGES, TERMINALS, VERSION
from ..errors import SetupError
from ..util import atomic, native_environment, qt_version, query, read_json, version


class QuickshellMixin:
    """Quickshell discovery, dependency resolution and the private pinned source build."""

    def candidate_qs(self):
        seen = set()
        for path in (self.meta.get("quickshell"), shutil.which("qs"), shutil.which("quickshell"), str(self.p.tools/"bin/qs")):
            if not path or path in seen or not Path(path).is_file():
                continue
            seen.add(path)
            code, out, err = query([path, "--version"], env=native_environment(), timeout=8)
            if code == 0 and version(out+"\n"+err) >= MIN_QS:
                if str(path).startswith(str(self.p.tools)+os.sep):
                    built = read_json(self.p.tools/"sphere-build.json")
                    current = qt_version()
                    if built.get("qt") and current and built["qt"] != current:
                        continue
                return str(Path(path).absolute())
        return None

    def hypr_version(self):
        binary = shutil.which("Hyprland") or shutil.which("hyprland")
        if not binary:
            return (0, 0, 0)
        env = os.environ.copy()
        if self.p.runtime():
            code, out, err = query([binary, "--version-json"], env=env)
            if code == 0 and version(out):
                return version(out)
            return version(query([binary, "--version"], env=env)[1])
        with tempfile.TemporaryDirectory(prefix="sphere-version-") as directory:
            os.chmod(directory, 0o700)
            env["XDG_RUNTIME_DIR"] = directory
            code, out, _ = query([binary, "--version"], env=env)
            return version(out) if code == 0 else (0, 0, 0)

    def ensure_dependencies(self):
        qs = self.candidate_qs()
        hypr = bool(shutil.which("Hyprland") or shutil.which("hyprland")) and bool(shutil.which("hyprctl"))
        terminal = next((t for t in TERMINALS if shutil.which(t)), None)
        if self.args.no_deps:
            if not qs or not hypr or not terminal:
                raise SetupError("--no-deps requires existing Quickshell >=0.3, Hyprland/hyprctl and a supported terminal.")
            return qs
        if not self.packages.kind:
            if qs and hypr and terminal:
                self.say("Using the preinstalled native stack on this declarative/unsupported package system.")
                return qs
            raise SetupError("Automatic dependencies support apt, pacman, dnf and zypper on mutable Linux. This OS needs an existing native stack; no system/session replacement will be attempted.")
        if self.packages.os.get("VARIANT_ID") in ("silverblue", "kinoite", "sericea", "onyx", "sway-atomic") or shutil.which("rpm-ostree") and Path("/run/ostree-booted").exists():
            if qs and hypr and terminal:
                return qs
            raise SetupError("This is an immutable/Atomic OS. Host package layering or a desktop replacement will not be done behind your back.")
        if not qs or not hypr:
            self.packages.debian_backports()
        # Arch: a database that has never been synced resolves nothing, so every
        # package would be dropped and the failure would surface much later. The
        # upgrade is opt-in (--pacman-upgrade) because it upgrades the whole OS.
        if getattr(self.args, "pacman_upgrade", False):
            self.packages.upgrade()
        self.packages.refresh()
        runtime = RUNTIME_PACKAGES[self.packages.kind]
        # Exact split QML packages are important on Debian/Ubuntu. Other distros bundle them.
        self.packages.install(runtime, required=self.packages.kind == "apt")
        if not hypr:
            self.packages.install(["hyprland"])
        if not terminal:
            chosen = next((p for p in ("foot", "kitty", "xterm") if self.packages.package_version(p)), None)
            if not chosen:
                raise SetupError("No supported native terminal package is available in enabled repositories.")
            self.packages.install([chosen])
        if not qs and version(self.packages.package_version("quickshell")) >= MIN_QS:
            self.packages.install(["quickshell"])
            qs = self.candidate_qs()
        if not qs:
            qs = self.build_quickshell()
        if not qs or not shutil.which("hyprctl") or not (shutil.which("Hyprland") or shutil.which("hyprland")):
            raise SetupError("The native stack did not pass post-install executable/version checks.")
        return qs

    def build_quickshell(self):
        self.say("No suitable repository Quickshell: building pinned official v0.3.2 privately against host Qt. Hyprland itself is never source-built.")
        if self.packages.kind == "apt" and version(qt_version() or self.packages.package_version("qt6-base-dev")) < (6,6,0):
            raise SetupError("This distribution provides Qt older than 6.6. A compatible repository Quickshell is required; system Qt will not be replaced from a third-party repo.")
        build_packages = BUILD_PACKAGES[self.packages.kind]
        # Private-header packages are separate only on some RPM distributions.
        optional = [p for p in build_packages if self.packages.kind in ("dnf", "zypper") and "private" in p]
        required = [p for p in build_packages if p not in optional]
        self.packages.install(required)
        self.packages.install(optional, required=False)
        qt = qt_version()
        if version(qt) < (6, 6, 0):
            raise SetupError("Quickshell needs Qt >=6.6 with matching private headers. This distribution is too old; system Qt will not be replaced from an untrusted third-party repository.")
        cache = self.p.data/"downloads"
        cache.mkdir(parents=True, exist_ok=True, mode=0o700)
        archive = cache/"quickshell-v0.3.2.tar.gz"
        if not archive.exists() or hashlib.sha256(archive.read_bytes()).hexdigest() != QS_SHA:
            self.say("Downloading checksum-pinned upstream source over verified HTTPS.")
            request = urllib.request.Request(QS_URL, headers={"User-Agent":"SphereNativeSetup/"+VERSION})
            try:
                with urllib.request.urlopen(request, timeout=90) as reply:
                    if urllib.parse.urlparse(reply.url).scheme != "https":
                        raise SetupError("Insecure source redirect rejected.")
                    data = reply.read(20_000_001)
            except OSError as e:
                raise SetupError("Official source download failed: "+str(e)) from e
            if len(data) > 20_000_000 or hashlib.sha256(data).hexdigest() != QS_SHA:
                raise SetupError("Official source SHA-256 mismatch. Download was not executed or extracted.")
            atomic(archive, data)
        work = self.p.data/"source-build"/("quickshell-v0.3.2-Qt"+qt)
        work.mkdir(parents=True, exist_ok=True, mode=0o700)
        source = work/"source"
        if source.exists():
            shutil.rmtree(source)
        source.mkdir()
        with tarfile.open(archive, "r:gz") as tgz:
            for member in tgz.getmembers():
                parts = Path(member.name).parts
                if len(parts) < 2:
                    continue
                relative = Path(*parts[1:])
                if relative.is_absolute() or ".." in relative.parts or not (member.isfile() or member.isdir()):
                    raise SetupError("Unsafe object in the pinned source archive.")
                target = source/relative
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with tgz.extractfile(member) as stream:
                        target.write_bytes(stream.read())
        # Build into a new prefix so a failed build does not destroy a working one.
        prefix = work/"prefix"
        build = work/"compile"
        if build.exists():
            shutil.rmtree(build)
        cmake = ["cmake", "-S", str(source), "-B", str(build), "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Release", "-DCMAKE_INSTALL_PREFIX="+str(prefix), "-DGIT_REVISION="+QS_REV, "-DDISTRIBUTOR=Sphere-native-setup", "-DWAYLAND=ON", "-DWAYLAND_WLR_LAYERSHELL=ON", "-DSOCKETS=ON", "-DWAYLAND_TOPLEVEL_MANAGEMENT=ON", "-DHYPRLAND=OFF", *["-D"+p+"=OFF" for p in OFF_FEATURES]]
        self.run(cmake, timeout=600)
        # Qt private-header compilation is memory-hungry. One job on <4GB systems.
        memory = 0
        with contextlib.suppress(OSError, ValueError, IndexError):
            memory = int(re.search(r"MemAvailable:\s*(\d+)", Path("/proc/meminfo").read_text()).group(1))
        jobs = min(os.cpu_count() or 1, 4 if memory > 8_000_000 else 2 if memory > 4_000_000 else 1)
        self.run(["cmake", "--build", str(build), "--parallel", str(jobs)], timeout=None)
        self.run(["cmake", "--install", str(build)], timeout=300)
        code, out, err = query([prefix/"bin/qs", "--version"], env=native_environment())
        if code or version(out+err) < MIN_QS:
            raise SetupError("The pinned source build did not pass its executable self-check.")
        atomic(prefix/"sphere-build.json", json.dumps({"qt":qt,"revision":QS_REV,"sha256":QS_SHA,"version":"0.3.2"}, indent=2)+"\n")
        self.p.tools.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        old = self.p.tools.with_name("quickshell.previous")
        if old.exists():
            shutil.rmtree(old)
        if self.p.tools.exists():
            os.replace(self.p.tools, old)
        shutil.copytree(prefix, self.p.tools, symlinks=True)
        self.say("Private Quickshell built against Qt "+qt+"; repair automatically rebuilds after a Qt ABI change.")
        return str(self.p.tools/"bin/qs")
