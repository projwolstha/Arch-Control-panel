"""Session detection, IPC, supervisor, dismiss/summon."""
from __future__ import annotations

import contextlib
import fcntl
import json
import os
import signal
import stat
import subprocess
import sys
import time
from pathlib import Path

from ..errors import SetupError
from ..util import atomic, native_environment, query, read_json, utcstamp


class SessionMixin:
    """Real-session checks, path-scoped IPC, supervisor lifecycle, dismiss and summon."""

    def real_session(self):
        runtime = self.p.runtime()
        signature = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE", "")
        display = os.environ.get("WAYLAND_DISPLAY", "")
        if not runtime or not signature or "/" in signature or not display:
            return False
        base = Path(os.environ["XDG_RUNTIME_DIR"])
        wayland = Path(display) if Path(display).is_absolute() else base/display
        command = base/"hypr"/signature/".socket.sock"
        try:
            return stat.S_ISSOCK(wayland.stat().st_mode) and stat.S_ISSOCK(command.stat().st_mode) and command.stat().st_uid == os.getuid()
        except OSError:
            return False

    def ipc(self, method, *values, timeout=5):
        qs = self.candidate_qs()
        if not qs or not self.p.runtime():
            return 1, "", "Native Quickshell/runtime unavailable"
        args = [qs, "ipc", "-p", str(self.p.config), "call", "sphere", method, *[str(v).lower() if isinstance(v, bool) else str(v) for v in values]]
        return query(args, timeout=timeout, env=native_environment(self.meta.get("software", False)))

    def dismiss(self):
        # SUPER+A hide = full teardown: marker first (supervisor honors it even if
        # the widget's own quit stalls), then the widget unmaps and exits cleanly.
        # Slots/preferences live on disk, so the process tree can die safely.
        self.p.data.mkdir(parents=True, exist_ok=True)
        atomic(self.p.dismiss_marker, (utcstamp()+" user dismissed via SUPER+A\n").encode(), 0o600)
        if self.health():
            self.ipc("dismiss", timeout=3)  # widget unmaps + Qt.quit; errors mean it is already gone
            self.say("Sphere dismissed: surface unmapped and widget/adapter processes exited — 0 MB, zero CPU while hidden. SUPER+A or 'sphere-setup toggle' summons it.")
        else:
            self.say("Sphere is not running; dismissal is saved and it will stay hidden across logins until summoned.")

    def summon(self):
        self.p.dismiss_marker.unlink(missing_ok=True)
        if not self.health():
            try:
                self.start()
            except SetupError:
                # start() is deliberately strict: it will not claim success until
                # full Hyprland health passes. The widget may still be coming up,
                # so the summon handshake below gets its own retries.
                time.sleep(2)
        code, _, err = self.ipc("summon", timeout=4)
        if code:
            time.sleep(2)
            code, _, err = self.ipc("summon", timeout=4)
        if code:
            raise SetupError("Sphere restarted but the summon handshake failed: "+(err or "no response"))
        self.say("Sphere summoned: visible and usable (orb ring unlocked). SUPER+A hides it again.")

    def health(self):
        code, out, _ = self.ipc("health", timeout=3)
        if code:
            return None
        # qs can print an informational line and still return success when not ready.
        for line in reversed(out.splitlines()):
            try:
                value = json.loads(line)
                if isinstance(value, dict) and value.get("protocol") == 1 and value.get("namespace") == "sphere-hub":
                    return value
            except ValueError:
                pass
        return None

    def start(self):
        if not self.p.controller.exists() or not self.p.config.exists():
            raise SetupError("Sphere is not installed; run this script without a command first.")
        if self.p.dismiss_marker.exists():
            self.say("Sphere was dismissed with SUPER+A and is fully stopped (0 MB, no processes). SUPER+A or 'sphere-setup toggle' summons it.")
            return
        if not self.real_session():
            raise SetupError("No active Hyprland Wayland session was detected. Setup is retained for next login; Sphere will not launch through X11 or take over another desktop.")
        found = self.health()
        # A hidden sphere (SUPER+A) is still a healthy running instance; never
        # spawn a duplicate just because its surface is currently unmapped.
        if found and found.get("backendConnected"):
            self.say("Sphere is already running"+(" (currently hidden — SUPER+A summons it)" if not found.get("visible") else "")+"; the existing native instance was kept.")
            return
        # Nothing healthy answered, but something may still be alive on this
        # config (an instance the IPC could not reach, half-dead, or left over
        # from the previous build). Clear it before spawning, or the new
        # supervisor would fight it for the layer surface.
        self.stop(quiet=True)
        qs = self.candidate_qs()
        if not qs:
            raise SetupError("Quickshell is missing, too old, or its private Qt ABI changed. Run repair.")
        runtime = self.p.runtime()
        runtime.mkdir(mode=0o700, exist_ok=True)
        self.p.logdir.mkdir(parents=True, exist_ok=True, mode=0o700)
        with open(self.p.logdir/"supervisor.log", "ab", buffering=0) as log:
            os.chmod(log.name, 0o600)
            subprocess.Popen([sys.executable, str(self.p.controller), "_supervise"], stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True, env=os.environ.copy())
        deadline = time.monotonic()+22
        while time.monotonic() < deadline:
            health = self.health()
            if health and health.get("backendConnected") and health.get("hyprland") and health.get("gemCount",0) > 0 and health.get("renderedFrames", 0) > 0 and health.get("visible"):
                self.say("Native layer-shell, the painted ring, Python adapter and live Hyprland IPC passed.")
                return
            time.sleep(.45)
        raise SetupError("Live health checks did not pass; do not treat this as a successful start. Run doctor/logs. Widget log: "+str(self.p.renderlog))

    def supervisor_pid(self):
        runtime = self.p.runtime()
        if not runtime:
            return None
        record = read_json(runtime/"supervisor.json")
        pid = record.get("pid")
        if type(pid) is not int or pid <= 1:
            return None
        try:
            proc = Path("/proc")/str(pid)
            argv = [v.decode() for v in (proc/"cmdline").read_bytes().split(b"\0") if v]
            started = (proc/"stat").read_text().rpartition(")")[2].split()[19]
            if proc.stat().st_uid == os.getuid() and len(argv) >= 3 and Path(argv[1]).resolve() == self.p.controller.resolve() and argv[2] == "_supervise" and started == record.get("startTime"):
                return pid
        except (OSError, ValueError, IndexError, UnicodeError):
            pass
        return None

    def restart_after_update(self):
        """Stop, then start — using our own code, not a binary that may not exist.

        `stop`/`start` here run in the installer process, so the restart cannot
        depend on `sphere-setup` being on the user's PATH (a fresh shell, a
        minimal environment, an unusual XDG prefix). An update that leaves the
        previous ring on screen is the one failure a user cannot diagnose, so the
        restart is done here and its outcome is reported, not assumed.
        """
        self.stop(quiet=True)
        # a second pass: dropping the compiled-QML cache and ending anything that
        # survived the IPC attempt
        self.clear_qml_cache()
        if self.p.dismiss_marker.exists():
            self.say("Sphere is dismissed (SUPER+A); it will start, with these files, "
                     "the next time you summon it.")
            return
        if not self.real_session():
            self.say("No live Hyprland session here, so the new files will load at your "
                     "next login. Nothing else to do.")
            return
        try:
            self.start()
        except SetupError as exc:
            self.say("The files are updated but the live restart did not pass its checks: "
                     + str(exc))
            self.say("Run 'sphere-setup restart' once your session is up; the files are already new.")

    def own_instances(self):
        """Every Quickshell process that was started against THIS config dir.

        `qs kill -p <dir>` only reaches an instance whose build speaks the same
        IPC as the binary we happen to pick. A widget launched from the distro
        package while we selected the private build (or an older IPC version)
        survives that, keeps its layer surface mapped and goes on drawing the
        old QML — the installer then says "already running — kept" and the user
        sees an update that changed nothing.

        This finds those processes by their own command line: `-p <dir>`,
        `--path <dir>` or `--path=<dir>`, resolved and compared against our
        config. Only our directory is ever matched — another bar is never a
        candidate, whatever it is called.
        """
        try:
            target = self.p.config.resolve()
        except OSError:
            return []
        found = []
        for entry in Path("/proc").iterdir():
            if not entry.name.isdigit():
                continue
            try:
                if entry.stat().st_uid != os.getuid():
                    continue
                argv = [v.decode("utf-8", "replace")
                        for v in (entry/"cmdline").read_bytes().split(b"\0") if v]
            except OSError:
                continue
            # the binary, or a wrapper script that execs it ("sh .../qs -p DIR"
            # shows up as argv[0]=sh argv[1]=.../qs)
            names = {Path(a).name for a in argv[:2]}
            if not names & {"qs", "quickshell"}:
                continue
            named = []
            for i, arg in enumerate(argv):
                if arg in ("-p", "--path") and i + 1 < len(argv):
                    named.append(argv[i + 1])
                elif arg.startswith("--path="):
                    named.append(arg.split("=", 1)[1])
            for name in named:
                try:
                    if Path(name).expanduser().resolve() == target:
                        found.append(int(entry.name))
                        break
                except OSError:
                    continue
        return found

    def stop(self, quiet=False):
        pid = self.supervisor_pid()
        if pid:
            with contextlib.suppress(ProcessLookupError):
                os.kill(pid, signal.SIGTERM)
            deadline = time.monotonic()+6
            while time.monotonic() < deadline and self.supervisor_pid():
                time.sleep(.1)
            if self.supervisor_pid() == pid:
                with contextlib.suppress(ProcessLookupError):
                    os.kill(pid, signal.SIGKILL)
        qs = self.candidate_qs()
        if qs and self.p.runtime() and self.p.config.exists():
            # The selected config is mandatory: never pkill qs / kill another bar.
            query([qs, "kill", "-p", str(self.p.config)], timeout=6, env=native_environment())
        # …and whatever that did not reach, by its own command line. Same rule:
        # only processes bound to this exact directory.
        others = self.own_instances()
        for other in others:
            with contextlib.suppress(ProcessLookupError, PermissionError):
                os.kill(other, signal.SIGTERM)
        deadline = time.monotonic()+3
        while others and time.monotonic() < deadline:
            others = [p for p in others if (Path("/proc")/str(p)).exists()]
            if others:
                time.sleep(.1)
        for other in others:
            with contextlib.suppress(ProcessLookupError, PermissionError):
                os.kill(other, signal.SIGKILL)
        if not quiet:
            self.say("Stopped only this Sphere config. Your other Quickshell panels were not touched.")

    def supervise(self):
        if not self.real_session() or self.p.dismiss_marker.exists():
            return
        runtime = self.p.runtime()
        runtime.mkdir(exist_ok=True, mode=0o700)
        with open(runtime/"supervisor.lock", "a+") as lock:
            os.chmod(lock.name, 0o600)
            try:
                fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:
                return
            start_time = (Path("/proc")/str(os.getpid())/"stat").read_text().rpartition(")")[2].split()[19]
            atomic(runtime/"supervisor.json", json.dumps({"pid":os.getpid(),"startTime":start_time,"config":str(self.p.config)}))
            child = None
            stopping = False
            dismissed = self.p.dismiss_marker.exists()
            def terminate(*_):
                nonlocal stopping
                stopping = True
                if child and child.poll() is None:
                    child.terminate()
            signal.signal(signal.SIGTERM, terminate)
            signal.signal(signal.SIGINT, terminate)
            try:
                for attempt in range(3):
                    if stopping or not self.real_session():
                        break
                    qs = self.candidate_qs()
                    if not qs:
                        break
                    if self.p.renderlog.exists() and self.p.renderlog.stat().st_size > 4_000_000:
                        os.replace(self.p.renderlog, self.p.renderlog.with_suffix(".previous.log"))
                    with open(self.p.renderlog, "ab", buffering=0) as log:
                        os.chmod(log.name, 0o600)
                        log.write(("\n--- Sphere native start "+utcstamp()+" ---\n").encode())
                        env = native_environment(self.meta.get("software", False) or self.args.software)
                        child = subprocess.Popen([qs,"-p",str(self.p.config),"--no-duplicate"], stdin=subprocess.DEVNULL, stdout=log, stderr=log, env=env)
                        while child.poll() is None and not stopping:
                            if not self.real_session() or self.p.dismiss_marker.exists():
                                terminate()
                            time.sleep(.4)
                        if stopping and child.poll() is None:
                            try:
                                child.wait(timeout=4)
                            except subprocess.TimeoutExpired:
                                child.kill()
                                child.wait()
                    if stopping or child.returncode == 0:
                        break
                    time.sleep(min(2*(attempt+1), 5))
            finally:
                if child and child.poll() is None:
                    child.terminate()
                    with contextlib.suppress(subprocess.TimeoutExpired):
                        child.wait(timeout=3)
                    if child.poll() is None:
                        child.kill()
                        child.wait()
                (runtime/"supervisor.json").unlink(missing_ok=True)
