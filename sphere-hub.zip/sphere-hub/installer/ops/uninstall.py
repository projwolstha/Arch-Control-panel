"""Uninstall and purge."""
from __future__ import annotations

import contextlib
import shutil

from ..constants import NATIVE_FILES
from ..errors import SetupError


class UninstallMixin:
    """Uninstall, with optional purge of Sphere's own saved state."""

    def uninstall(self):
        if self.args.dry_run:
            self.say("Dry run: stop only Sphere, remove its autostart block, native config, user manager/launcher. Keep saved slots/backups and all system packages. --purge also removes Sphere's own saved state/backups/tools.")
            return
        self.open_log()
        self.stop(quiet=True)
        self.disable_autostart()
        self.backup(self.p.config)
        if self.p.config.is_symlink():
            raise SetupError("Refusing to recursively remove a symlinked native configuration.")
        if self.p.config.exists():
            root = self.p.config.resolve()
            for name in (*NATIVE_FILES, "sphere-package.json"):
                path = self.p.config/name
                if not path.parent.resolve().is_relative_to(root):
                    self.say("Skipped an externally symlinked path: "+str(path))
                    continue
                if path.is_file() or path.is_symlink():
                    path.unlink()
            for path in (self.p.config/"assets", self.p.config/"tests", self.p.config/"sphere_adapter", self.p.config):
                with contextlib.suppress(OSError):
                    path.rmdir()
        for path in (self.p.desktop, self.p.command, self.p.controller, self.p.installer, self.p.manifest):
            path.unlink(missing_ok=True)
        # The native backend and organizer commands go with Sphere; rules and undo
        # logs stay, because they are the user's own settings and file history.
        (self.p.bin/"sphere-backend").unlink(missing_ok=True)
        (self.p.bin/"jarvis-organize").unlink(missing_ok=True)
        if self.p.controller_pkg.is_symlink():
            self.say("Skipped a symlinked manager package: "+str(self.p.controller_pkg))
        elif self.p.controller_pkg.is_dir():
            shutil.rmtree(self.p.controller_pkg, ignore_errors=True)
        if self.p.controller_pkg.is_symlink():
            self.say("Skipped a symlinked manager package: "+str(self.p.controller_pkg))
        elif self.p.controller_pkg.is_dir():
            shutil.rmtree(self.p.controller_pkg, ignore_errors=True)
        if self.args.purge:
            self.p.state.unlink(missing_ok=True)
            if self.log:
                self.log.close()
                self.log = None
            if self.p.data.is_symlink():
                raise SetupError("Refusing to purge a symlinked Sphere data directory.")
            shutil.rmtree(self.p.data, ignore_errors=True)
            shutil.rmtree(self.p.logdir, ignore_errors=True)
        self.say("Uninstalled Sphere. Existing Hyprland settings, unrelated Quickshell bars, shared OS packages and signed repository configuration were kept.")
        self.say("Kept the organizer rules and undo log: "+str(self.p.config_home/"jarvis"))
        if not self.args.purge:
            self.say("Saved assignments and backups kept for reinstall: "+str(self.p.state))
