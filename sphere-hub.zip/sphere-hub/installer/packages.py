"""Thin, fully interactive wrappers over apt/pacman/dnf/zypper."""
from __future__ import annotations

import os
import re
import shutil
import tempfile
from pathlib import Path

from .constants import MIN_QS
from .errors import SetupError
from .util import arch_native, arch_stratum, os_release, query, version

# Distribution family → the package manager that owns it. ID wins over ID_LIKE.
FAMILY_MANAGER = {
    "arch": "pacman", "archlinux": "pacman", "archarm": "pacman", "manjaro": "pacman",
    "endeavouros": "pacman", "cachyos": "pacman", "garuda": "pacman", "artix": "pacman",
    "arcolinux": "pacman", "xmimos": "pacman",
    "debian": "apt", "ubuntu": "apt", "linuxmint": "apt", "pop": "apt", "raspbian": "apt",
    "elementary": "apt", "zorin": "apt", "kali": "apt", "pureos": "apt",
    "fedora": "dnf", "rhel": "dnf", "centos": "dnf", "rocky": "dnf", "almalinux": "dnf",
    "nobara": "dnf", "ol": "dnf",
    "opensuse": "zypper", "opensuse-leap": "zypper", "opensuse-tumbleweed": "zypper",
    "suse": "zypper", "sles": "zypper", "sled": "zypper",
}
ARCH_IDS = {name for name, manager in FAMILY_MANAGER.items() if manager == "pacman"}
MANAGER_BINARY = {"apt": "apt-get", "pacman": "pacman", "dnf": "dnf", "zypper": "zypper"}


def manager_for_release(release):
    """The manager the release file names, if its binary is actually installed."""
    names = [str(release.get("ID", "")).strip().lower()]
    names += str(release.get("ID_LIKE", "")).lower().split()
    for name in names:
        manager = FAMILY_MANAGER.get(name)
        if manager and shutil.which(MANAGER_BINARY[manager]):
            return manager
    return None


def detect_manager(release=None):
    """The package manager that belongs to this machine.

    Arch is checked first, because a machine can carry more than one package
    tree: on Bedrock Linux ``/etc/os-release`` may say Debian while pacman owns
    every package the desktop runs, and installing with apt there would write
    into the wrong stratum. ``SPHERE_PKG_MANAGER`` overrides the guess.
    """
    forced = os.environ.get("SPHERE_PKG_MANAGER", "").strip().lower()
    if forced:
        return forced if shutil.which(MANAGER_BINARY.get(forced, forced)) else None
    release = os_release() if release is None else release
    if arch_native() and shutil.which("pacman"):
        return "pacman"
    chosen = manager_for_release(release)
    if chosen:
        return chosen
    return next((m for m in ("pacman", "apt", "dnf", "zypper")
                 if shutil.which(MANAGER_BINARY[m])), None)


class Packages:
    def __init__(self, manager):
        self.m = manager
        self.os = os_release()
        self.kind = detect_manager(self.os)
        self.cache = {}
        self._sync_ready = None
        self.authenticated = False
        self.elevator = next((p for p in ("sudo", "doas", "pkexec") if shutil.which(p)), None)
        self.target = None
        if self.kind == "apt" and self.os.get("ID") == "debian" and self.os.get("VERSION_ID", "").split(".")[0] == "13":
            code, out, _ = query(["apt-cache", "policy"])
            if code == 0 and "trixie-backports" in out:
                self.target = "trixie-backports"

    def describe(self):
        """The platform as it will be treated, not just what os-release claims."""
        if self.kind == "pacman" and str(self.os.get("ID", "")).lower() not in ARCH_IDS:
            stratum = arch_stratum()
            return "Arch Linux" + (f" (Bedrock stratum '{stratum}')" if stratum else "")
        return self.os.get("PRETTY_NAME") or "Unknown Linux"

    def auth(self):
        if self.authenticated or self.m.args.dry_run:
            return
        if not self.elevator:
            raise SetupError("sudo/doas/pkexec is required for OS packages. No GUI/configuration is ever run as root.")
        self.m.say("Your OS may request authentication; Sphere never stores passwords.")
        if self.elevator == "sudo":
            self.m.run(["sudo", "-v"], timeout=None)
        self.authenticated = True

    def privileged(self, argv):
        self.auth()
        self.m.run([self.elevator, *argv], timeout=None)

    def pacman_sync_ready(self):
        """Is pacman's sync database usable?

        `bash` is always in core, so it is a sentinel that does not depend on
        anything this installer wants. A tool that skips this probe ends up
        believing *no* package is installable, which looks like an empty
        repository rather than an unsynchronised one.
        """
        if self.kind != "pacman":
            return True
        if self._sync_ready is None:
            code, _out, _err = query(["pacman", "-Si", "bash"])
            self._sync_ready = code == 0
        return self._sync_ready

    def upgrade(self):
        """An explicit whole-system `pacman -Syu` — the only Arch-safe refresh.

        `-Sy` alone is never run: it leaves the system in a partial-upgrade state.
        """
        if self.kind != "pacman":
            return
        self.m.say("Refreshing the package databases and upgrading every package: pacman -Syu (asked for explicitly).")
        self.privileged(["pacman", "-Syu", "--noconfirm"])
        self.cache.clear()
        self._sync_ready = None

    def refresh(self):
        if self.kind == "apt":
            self.privileged(["apt-get", "update"])
        elif self.kind == "dnf":
            self.privileged(["dnf", "-y", "makecache"])
        elif self.kind == "zypper":
            self.privileged(["zypper", "--non-interactive", "refresh"])
        # Arch: never use -Sy without -u, or silently upgrade the entire OS.
        # Existing, coherent package metadata is used. A failed transaction is not forced.
        # The database still has to *exist*: see pacman_sync_ready() and upgrade().
        self.cache.clear()
        self._sync_ready = None

    def package_version(self, name):
        if name in self.cache:
            return self.cache[name]
        if self.kind == "apt":
            code, out, _ = query(["apt-cache", "policy", name])
            match = re.search(r"Candidate:\s*(\S+)", out)
        elif self.kind == "pacman":
            code, out, _ = query(["pacman", "-Si", name])
            match = re.search(r"^Version\s*:\s*(\S+)", out, re.M)
        elif self.kind == "dnf":
            code, out, _ = query(["dnf", "-q", "repoquery", "--latest-limit=1", "--qf=%{version}", name], timeout=45)
            match = re.search(r"^(\d[^\s]*)$", out, re.M)
        elif self.kind == "zypper":
            code, out, _ = query(["zypper", "--non-interactive", "--xmlout", "info", name], timeout=45)
            match = re.search(r'<edition\b[^>]*version="([^"]+)"', out)
        else:
            return ""
        result = match.group(1) if code == 0 and match else ""
        self.cache[name] = "" if result == "(none)" else result
        return self.cache[name]

    def install(self, packages, required=True):
        names = list(dict.fromkeys(packages))
        if not names:
            return
        if not self.kind:
            raise SetupError("No supported mutable-system package manager was found. Preinstalled native tools can be used with --no-deps; declarative/read-only OSes are not modified.")
        if self.kind == "pacman" and not self.m.args.dry_run and not self.pacman_sync_ready():
            raise SetupError(
                "pacman's sync database is empty, so no package name can be resolved. "
                "Run `sudo pacman -Syu` first, then re-run this installer (Arch never refreshes half a system), "
                "or re-run with --pacman-upgrade to let Sphere do that one full upgrade. Nothing was changed.")
        missing = [p for p in names if not self.package_version(p)]
        # a dry run reports, it never fails: an unsynced database is a fact to
        # print, not an error to throw at someone who asked for a plan
        if missing and required and not self.m.args.dry_run:
            raise SetupError("Required packages not found in enabled signed repositories: "+", ".join(missing)+". No third-party PPA/COPR/AUR or insecure download will be added.")
        if missing:
            self.m.say("Optional distro package names unavailable: "+", ".join(missing))
            names = [p for p in names if p not in missing]
        if not names:
            return
        if self.kind == "apt":
            argv = ["apt-get", "install", "-y", "--no-install-recommends"]
            if self.target:
                argv += ["-t", self.target]
        elif self.kind == "pacman":
            argv = ["pacman", "-S", "--needed", "--noconfirm"]
        elif self.kind == "dnf":
            argv = ["dnf", "install", "-y"]
        else:
            argv = ["zypper", "--non-interactive", "install", "--no-recommends"]
        self.privileged(argv+names)

    def debian_backports(self):
        if self.kind != "apt" or self.os.get("ID") != "debian" or self.os.get("VERSION_ID", "").split(".")[0] != "13":
            return
        self.target = "trixie-backports"
        if self.package_version("quickshell") and version(self.package_version("quickshell")) >= MIN_QS:
            return
        # Official Debian archive; use the distribution's installed signing key.
        dest = Path("/etc/apt/sources.list.d/sphere-hub-backports.sources")
        text = "Types: deb\nURIs: https://deb.debian.org/debian\nSuites: trixie-backports\nComponents: main\nSigned-By: /usr/share/keyrings/debian-archive-keyring.gpg\n"
        key = Path("/usr/share/keyrings/debian-archive-keyring.gpg")
        if not key.is_file():
            raise SetupError("Debian's official archive keyring is missing; repository authentication will not be bypassed.")
        if dest.exists():
            if dest.read_text() != text:
                raise SetupError(str(dest)+" already exists with different content; it was not overwritten.")
            return
        code, policy, _ = query(["apt-cache", "policy"])
        if "trixie-backports" in policy:
            return
        self.m.say("Enabling signed official Debian 13 trixie-backports for native Hyprland/Quickshell.")
        with tempfile.TemporaryDirectory(prefix="sphere-repo-") as temp:
            src = Path(temp)/"backports.sources"
            src.write_text(text)
            self.privileged(["install", "-m", "0644", str(src), str(dest)])
