"""All XDG paths Sphere owns, resolved once per process."""
from __future__ import annotations

import hashlib
import os
import stat
from pathlib import Path

from .errors import SetupError


class Paths:
    def __init__(self):
        home = Path.home()
        def xdg(name, default):
            p = Path(os.environ.get(name) or default).expanduser()
            if not p.is_absolute():
                raise SetupError(name+" must be an absolute path.")
            if any(c in str(p) for c in "\n\r\x00"):
                raise SetupError("Newlines and NULs in installation paths are not supported.")
            return p
        self.config_home = xdg("XDG_CONFIG_HOME", home/".config")
        self.data_home = xdg("XDG_DATA_HOME", home/".local/share")
        self.state_home = xdg("XDG_STATE_HOME", home/".local/state")
        self.bin = home/".local/bin"
        self.config = self.config_home/"quickshell/sphere-hub"
        self.state = self.config_home/"sphere-hub/state.json"
        self.data = self.data_home/"sphere-hub"
        self.logdir = self.state_home/"sphere-hub"
        self.manifest = self.data/"installation.json"
        self.controller = self.data/"manager.py"
        self.controller_pkg = self.data/"installer"
        self.controller_pkg = self.data/"installer"
        self.installer = self.data/"sphere-setup.sh"
        self.command = self.bin/"sphere-setup"
        self.desktop = self.data_home/"applications/sphere-hub.desktop"
        self.backups = self.data/"backups"
        self.tools = self.data/"tools/quickshell"
        self.renderlog = self.logdir/"widget.log"
        self.managerlog = self.logdir/"setup.log"
        self.dismiss_marker = self.data/"dismissed"

    def runtime(self):
        raw = os.environ.get("XDG_RUNTIME_DIR", "")
        if not raw:
            return None
        directory = Path(raw)
        try:
            st = directory.stat()
            if not directory.is_absolute() or st.st_uid != os.getuid() or not stat.S_ISDIR(st.st_mode) or stat.S_IMODE(st.st_mode) & 0o022:
                return None
        except OSError:
            return None
        # One supervisor per Sphere config, not a global Quickshell process lock.
        key = hashlib.sha256(str(self.config.resolve()).encode()).hexdigest()[:16]
        return directory/("sphere-hub-"+key)
