"""Small dependency-free helpers shared by every manager module."""
from __future__ import annotations

import contextlib
import datetime as dt
import json
import os
import re
import subprocess
import tempfile
from pathlib import Path


def version(text):
    m = re.search(r"(?<!\d)(\d+)\.(\d+)(?:\.(\d+))?", text or "")
    return tuple(int(v or 0) for v in m.groups()) if m else (0, 0, 0)


def utcstamp():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return {} if default is None else default


def atomic(path, data, mode=0o600):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, name = tempfile.mkstemp(prefix=".sphere-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as out:
            out.write(data.encode() if isinstance(data, str) else data)
            out.flush()
            os.fsync(out.fileno())
            os.fchmod(out.fileno(), mode)
        os.replace(name, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(name)


def os_release():
    result = {}
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                result[k] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    return result


BEDROCK_STRATA = Path("/bedrock/strata")


def bedrock_strata():
    """The Bedrock Linux strata, when this machine is a Bedrock system.

    Bedrock composes several distributions under one root. The host's
    ``/etc/os-release`` belongs to the base stratum and says nothing about
    which stratum owns the desktop: a Fedora base can hand out ``dnf`` and a
    ``fedora`` release file while the session, the GPU drivers and the
    package manager the user actually wants all come from an Arch stratum.
    The release file is therefore a hint, never the answer; the stratum that
    provides the running desktop decides, and ``/etc/arch-release`` inside a
    root is the marker that says Arch owns it.
    """
    try:
        return sorted(p for p in BEDROCK_STRATA.iterdir() if p.is_dir())
    except OSError:
        return []


PACMAN_DB = Path("/var/lib/pacman/local")


def arch_native():
    """True when Arch Linux owns this root, directly or as a Bedrock stratum.

    Three signals, cheapest first: the release marker, an Arch stratum beside
    the others, and a populated pacman database — the last one is what proves
    Arch packages are actually installed here (Debian's own ``pacman`` package
    is an arcade game and leaves no database).
    """
    if Path("/etc/arch-release").exists():
        return True
    if any((p / "etc" / "arch-release").exists() for p in bedrock_strata()):
        return True
    try:
        return PACMAN_DB.is_dir() and next(PACMAN_DB.iterdir(), None) is not None
    except OSError:
        return False


def arch_stratum():
    """Name of the Bedrock stratum that is Arch, or an empty string."""
    for path in bedrock_strata():
        if (path / "etc" / "arch-release").exists():
            return path.name
    return ""


def query(argv, timeout=10, env=None):
    try:
        p = subprocess.run(list(map(str, argv)), capture_output=True, text=True, timeout=timeout, env={**(os.environ if env is None else env), "LC_ALL":"C"})
        return p.returncode, p.stdout, p.stderr
    except (OSError, subprocess.TimeoutExpired) as e:
        return 125, "", str(e)


def qt_version():
    for argv in (("qtpaths6", "--query", "QT_VERSION"), ("qtpaths-qt6", "--query", "QT_VERSION"), ("qmake6", "-query", "QT_VERSION"), ("pkg-config", "--modversion", "Qt6Core")):
        code, out, _ = query(argv, timeout=5)
        if code == 0 and version(out) >= (6, 0, 0):
            return out.strip()
    return ""


def native_environment(software=False):
    env = os.environ.copy()
    for key in ("QS_CONFIG_NAME", "QS_MANIFEST", "QS_CONFIG_PATH"):
        env.pop(key, None)
    for key, value in (("QT_QPA_PLATFORM", "wayland"), ("QT_QUICK_CONTROLS_STYLE", "Basic")):
        env.setdefault("SPHERE_SAVED_"+key, env.get(key, "__SPHERE_UNSET__"))
        env[key] = value
    if software:
        env.setdefault("SPHERE_SAVED_QT_QUICK_BACKEND", env.get("QT_QUICK_BACKEND", "__SPHERE_UNSET__"))
        env["QT_QUICK_BACKEND"] = "software"
    return env
