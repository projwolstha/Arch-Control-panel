import QtQuick
import QtQuick.Shapes

// ── EnergyLine — a stroke that looks like light, not like ink ───────────────
//
// Every geometric line in the interface is drawn through this item, so the
// three-layer recipe exists once: a wide, very transparent wash (the bloom), a
// saturated middle stroke (the colour), and a thin near-white filament (the
// light). Thickening the middle alone reads as paint; the white core is what
// makes it read as an illuminated edge on a dark screen.
//
// It also carries the *flow*: with `flow: true` the middle stroke becomes a
// moving dash pattern and a bright bead can run along the same path — the
// travelling highlights the design asks for. The beads are positioned by the
// caller (see MagicRing), because a bead is a moving dot, not new geometry: it
// costs one transform per frame instead of a path rebuild.
//
// Nothing here takes input, and nothing here animates by itself: `clock` is the
// widget's single time source, so a hidden dashboard freezes the whole ring.
Shape {
    id: line

    property string path: ""                    // SVG path data, already in this item's pixels
    property color tint: theme.gold
    property real weight: 1                     // the core stroke width in px
    property real glow: 1                       // 0…2, brightness of all three layers
    property bool flow: false                   // animate the dash pattern
    property real clock: 0                      // seconds, from the widget
    property real flowSpeed: 40                 // dash units per second
    property real dashOn: 1.6                   // dash lengths, in multiples of weight
    property real dashOff: 2.6
    property real coreScale: 1                  // 0 hides the white filament
    property Theme theme: Theme {}

    width: parent ? parent.width : 0
    height: parent ? parent.height : 0

    // ── 1. the bloom ────────────────────────────────────────────────────────
    ShapePath {
        fillColor: "transparent"
        strokeColor: line.theme.alpha(line.tint, line.theme.glowAlpha * Math.min(1, line.glow))
        strokeWidth: Math.max(1.5, line.weight * line.theme.glowScale)
        capStyle: ShapePath.RoundCap
        joinStyle: ShapePath.RoundJoin
        PathSvg { path: line.path }
    }
    // ── 2. the colour ───────────────────────────────────────────────────────
    ShapePath {
        fillColor: "transparent"
        strokeColor: line.theme.alpha(line.tint, line.theme.midAlpha * Math.min(1.1, line.glow))
        strokeWidth: Math.max(0.8, line.weight * line.theme.midScale)
        capStyle: ShapePath.RoundCap
        joinStyle: ShapePath.RoundJoin
        strokeStyle: line.flow ? ShapePath.DashLine : ShapePath.SolidLine
        dashPattern: [line.dashOn, line.dashOff]
        // dash units are multiples of the pen width, so the speed is too
        dashOffset: line.flow ? -(line.clock * line.flowSpeed) : 0
        PathSvg { path: line.path }
    }
    // ── 3. the light itself ─────────────────────────────────────────────────
    ShapePath {
        fillColor: "transparent"
        // a hint of white, not white: the filament has to sit inside the colour
        strokeColor: line.theme.alpha(line.theme.light(line.tint, 0.46),
                                     line.theme.coreAlpha * Math.min(1, line.glow) * line.coreScale * 0.62)
        strokeWidth: Math.max(0.6, line.weight * line.theme.coreScale)
        capStyle: ShapePath.RoundCap
        joinStyle: ShapePath.RoundJoin
        PathSvg { path: line.path }
    }
}
