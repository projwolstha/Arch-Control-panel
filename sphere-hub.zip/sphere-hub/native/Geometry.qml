import QtQuick

// ── Geometry — the crest's layout, mirrored from config/layout.json ─────────
//
// The JSON is the single source of truth (the demo embeds it; this file is the
// QML side, and native/tests/test_config.py fails if the two ever disagree).
// Every radius is a fraction of R, every angle is screen degrees (0 = straight
// up, clockwise). Nothing in the drawing code keeps a second copy of these
// numbers and there is no hand-placed point anywhere in the crest.
//
// Segment angles are DERIVED — the segment between gem i and gem i+1 sits at
// gemAnglesDeg[i] + 180/gemCount — so the five sigil stations can never drift
// from the five gems.
QtObject {
    id: geometry
    objectName: "geometry"

    // ── the circle ─────────────────────────────────────────────────────────
    readonly property real ringScreenShare: 0.41   // R, × the smaller screen edge
    readonly property var outerRadii: [0.955, 0.97, 0.985, 1.0]
    readonly property string outerStyle: "classic"   // classic | current (falls back)
    readonly property real liquidTorusScale: 1.15    // × 2R, sculpted liquid-glass torus
    readonly property real gemOrbit: 0.71          // × R
    readonly property real gemDiameter: 0.34       // × R
    readonly property int gemCount: 5
    readonly property var gemAnglesDeg: [-90, -18, 54, 126, 198]
    readonly property real coreRingRadius: 0.485   // the outer edge of the core's gold ring

    // ── the rune band: the old plate band, rebuilt ─────────────────────────
    readonly property real runeBandOuter: 0.90     // × R
    readonly property real runeBandInner: 0.62     // × R
    readonly property real runeRadius: 0.76        // where the glyphs sit
    readonly property int runeCount: 60
    readonly property real runeSize: 0.05          // × R
    readonly property real segmentGapDeg: 4.0      // the gap at each segment boundary
    readonly property real boundaryNodeSize: 0.036  // × R, the diamond in each gap

    // ── the tick comb on the outermost ring ────────────────────────────────

    // ── the quiet rings ────────────────────────────────────────────────────
    readonly property real dashedRadius: 0.70      // just inside the glyphs
    readonly property real guideRadius: 0.62       // the rune band's inner edge
    readonly property bool guideEnabled: true     // the guide circle is optional
    readonly property bool sigilsEnabled: false   // sigils: keep the code, default off

    // ── sigils and the web ─────────────────────────────────────────────────
    readonly property real sigilRadius: 0.84        // where the sigil stations sit
    readonly property real sigilSize: 0.09         // × R
    readonly property real gemHaloRadius: 0.2635   // × R — the halo's visible edge
    readonly property real spokeGemFrom: 0.545     // the gem's inner edge
    readonly property real spokeGemTo: 0.485       // the outer edge of the core's gold ring
    readonly property real spokeSegmentFrom: 0.62
    readonly property real spokeSegmentTo: 0.485
    readonly property real nodeSize: 0.012         // × R
    readonly property real connectorArc: 0.06      // the sigil → gem-halo inscription
    readonly property bool gemStarEnabled: true
    readonly property real gemStarRadius: 0.71

    // ── derived: the five segment stations, midway between the gems ────────
    function gemAngle(i, count) {
        return -90 + 360 * i / Math.max(1, count === undefined ? gemCount : count);
    }
    function segmentAngle(i, count) {
        var n = Math.max(1, count === undefined ? gemCount : count);
        return gemAngle(i, n) + 180 / n;
    }
}
