import QtQuick
import QtQuick.Shapes

// ── JarvisCore — the agent's centre ─────────────────────────────────────────
//
// What sits inside the gold bevel while no panel is open: a glowing orb on the
// dark face, the time over it, a seconds arc, and three segmented rings carrying
// CPU, RAM and battery — with the idle life of a machine that is thinking: a
// slow breath, a sway on each ring and a radar sweep. Around the orb, three
// dials of dots read the clock: 12 hours, 60 minutes, 60 seconds.
//
// Layout, from the outside in (all fractions of the core's own radius, so the
// core scales with the disc):
//     outer ring  48 segments   ◀ CPU
//     middle ring 36 segments   ◀ RAM
//     inner ring  24 segments   ◀ battery
//     the orb     0.36 of the core radius, ≈ 0.16 R
//
// Cost: the segments are plain Rectangles turned by a static transform — no
// path is rebuilt when a value changes, and there is not one timer here. A
// segment lights by changing its colour, which is a binding, not geometry. The
// four motions are QML animations, every one of them gated on `animated` and on
// its own toggle in Theme.qml, so a hidden dashboard is a still picture.
Item {
    id: core

    property Theme theme: Theme {}
    property real diameter: 240
    // the three values, 0…1, handed down by SysStats. 0 renders as an empty ring.
    property real cpu: 0
    property real ram: 0
    property real battery: 0
    // false when the source is absent (no /proc/stat, no battery on a desktop):
    // the ring stays dark and its zero mark turns grey, so an empty ring never
    // reads as "measured zero"
    property bool cpuLive: false
    property bool ramLive: false
    property bool batteryLive: false
    // the one gate on every motion below: true only while the dashboard is on
    // screen, awake and not in low power. False is a still frame, not a slow one.
    property bool animated: false
    // the clock. shell.qml owns the SystemClock (one tick a second, stopped while
    // the dashboard is hidden) and hands the three numbers down; the date string
    // is formatted there too, because the small-caps spelling is a choice, not a
    // locale. The core only decides how they look.
    property int hours: 0
    property int minutes: 0
    property int seconds: 0
    property string dateText: ""
    // the plate serif, from the widget — the core never picks a font of its own
    property string serif: "serif"

    readonly property string timeText: (hours < 10 ? "0" : "") + hours
                                         + ":" + (minutes < 10 ? "0" : "") + minutes

    readonly property real r: diameter / 2
    readonly property real orbRadius: r * theme.coreOrbRadius
    readonly property real stroke: Math.max(1.5, r * theme.coreRingStroke)

    width: diameter
    height: diameter

    // ── the halo: the orb's light spreading onto the dark face ──────────────
    // Both this and the orb below are SVG radial gradients, not Shape fills. A
    // RadialGradient inside a Shape degenerates in Qt 6.8 when its centre radius
    // is small against the path and paints a sliver — measured, five variants —
    // while the SVG renderer draws the same gradient correctly. They are drawn
    // as images so the light is identical at every size.
    // ── the radar sweep ────────────────────────────────────────────────────
    // A cone of light with a bright leading edge, turning once every 11 s. It sits
    // *behind* the orb — it is light on the dark face, not a wash over the ball —
    // and it is a generated SVG on a rotating item: a conical gradient would
    // describe it exactly, but ConicalGradient paints nothing in this Qt
    // (measured, like the radial one), so the wedge and its fade are baked in.
    Image {
        objectName: "coreSweep"
        anchors.fill: parent
        source: Qt.resolvedUrl("assets/core-sweep.svg")
        smooth: true
        visible: core.theme.coreSweep
        fillMode: Image.PreserveAspectFit

        RotationAnimation on rotation {
            from: 0; to: 360
            duration: core.theme.coreSweepMs
            loops: Animation.Infinite
            running: core.animated && core.theme.coreSweep
        }
    }

    // The halo and the orb are one thing that breathes: they scale together about
    // the centre, so the light spreads as the orb swells. The scrim and the type
    // stay outside the holder — the clock must not breathe with it.
    Item {
        id: orbHolder
        objectName: "coreOrbHolder"
        anchors.fill: parent
        transformOrigin: Item.Center

        Image {
            anchors.centerIn: parent
            // coreHaloScale is a multiple of the orb's *diameter*, not its radius
            width: core.orbRadius * 2 * core.theme.coreHaloScale
            height: width
            source: Qt.resolvedUrl("assets/core-halo.svg")
            smooth: true
            opacity: core.theme.coreHaloAlpha
        }

        Image {
            objectName: "coreOrb"
            anchors.centerIn: parent
            width: core.orbRadius * 2
            height: width
            source: Qt.resolvedUrl("assets/core-orb.svg")
            smooth: true
        }

        Image {
            objectName: "coreOrbSwirl"
            anchors.centerIn: parent
            width: core.orbRadius * 2
            height: width
            source: Qt.resolvedUrl("assets/core-orb-swirl.svg")
            smooth: true
            visible: core.theme.coreOrbSwirl
            RotationAnimation on rotation {
                from: 0; to: 360
                duration: core.theme.coreOrbSwirlMs
                loops: Animation.Infinite
                running: core.animated && core.theme.coreOrbSwirl
            }
        }

        // one slow breath: 5.2 s, easing at both ends, and it stops dead when the
        // dashboard goes away (a QML animation, not a timer)
        SequentialAnimation on scale {
            running: core.animated && core.theme.coreBreath
            loops: Animation.Infinite
            NumberAnimation {
                from: 1.0; to: 1.0 + core.theme.coreBreathScale
                duration: core.theme.coreBreathMs / 2
                easing.type: Easing.InOutSine
            }
            NumberAnimation {
                from: 1.0 + core.theme.coreBreathScale; to: 1.0
                duration: core.theme.coreBreathMs / 2
                easing.type: Easing.InOutSine
            }
        }
    }

    // ── the clock: a dark lens, then large thin type over it ───────────────
    // The orb's centre is the brightest thing in the widget and cream serif on it
    // would vanish, so a soft scrim (another generated SVG) sits between them: the
    // orb's rim still glows around the type, and the numerals read.
    Image {
        objectName: "coreScrim"
        anchors.centerIn: parent
        width: core.orbRadius * 2 * core.theme.coreScrimScale
        height: width
        source: Qt.resolvedUrl("assets/core-scrim.svg")
        smooth: true
        opacity: core.theme.coreScrimAlpha
    }

    Column {
        objectName: "coreClock"
        anchors.centerIn: parent
        spacing: core.r * core.theme.coreClockGap

        Text {
            objectName: "coreTime"
            textFormat: Text.PlainText
            anchors.horizontalCenter: parent.horizontalCenter
            text: core.timeText
            color: core.theme.coreClockTime
            font.family: core.serif
            font.pixelSize: Math.max(8, core.r * core.theme.coreClockTimeSize)
            font.weight: core.theme.coreClockWeight
            font.letterSpacing: core.r * core.theme.coreClockTimeSpacing
        }
        Text {
            objectName: "coreDate"
            textFormat: Text.PlainText
            anchors.horizontalCenter: parent.horizontalCenter
            text: core.dateText
            color: core.theme.alpha(core.theme.coreClockDate, core.theme.coreClockDateAlpha)
            font.family: core.serif
            font.pixelSize: Math.max(5, core.r * core.theme.coreClockDateSize)
            font.letterSpacing: core.r * core.theme.coreClockDateSpacing
        }
    }

    // ── the seconds: a thin arc riding outside the inner ring ──────────────
    // One Shape, rebuilt once a second when `seconds` changes — never per frame.
    // At zero the sweep is zero and nothing is drawn.
    Shape {
        objectName: "coreSecondsArc"
        anchors.fill: parent
        visible: core.seconds > 0
        ShapePath {
            strokeWidth: core.r * core.theme.coreArcWidth
            strokeColor: core.theme.alpha(core.theme.coreArcColor, core.theme.coreArcAlpha)
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            PathAngleArc {
                centerX: core.r; centerY: core.r
                radiusX: core.r * core.theme.coreArcRadius
                radiusY: core.r * core.theme.coreArcRadius
                startAngle: -90
                sweepAngle: 6 * core.seconds
            }
        }
    }
    // the head of that arc: a bead of light at the leading edge
    Rectangle {
        objectName: "coreSecondsHead"
        visible: core.seconds > 0
        readonly property real d: core.r * core.theme.coreArcWidth * core.theme.coreArcHeadScale
        readonly property real a: core.seconds / 60 * 2 * Math.PI
        width: d; height: d; radius: d / 2
        color: core.theme.coreArcHead
        x: core.r + Math.sin(a) * core.r * core.theme.coreArcRadius - d / 2
        y: core.r - Math.cos(a) * core.r * core.theme.coreArcRadius - d / 2
    }

    // ── the three rings ─────────────────────────────────────────────────────
    // One instance per ring. `value` lights the segments from the top, walking
    // clockwise; at 0 every segment stays dim.
    Ring {
        radiusFraction: core.theme.coreRingOuter
        segments: core.theme.coreCpuSegments
        value: core.cpu
        live: core.cpuLive
        swayMs: core.theme.coreDriftMsOuter
    }
    Ring {
        radiusFraction: core.theme.coreRingMiddle
        segments: core.theme.coreRamSegments
        value: core.ram
        live: core.ramLive
        swayMs: core.theme.coreDriftMsMiddle
    }
    Ring {
        radiusFraction: core.theme.coreRingInner
        segments: core.theme.coreBatterySegments
        value: core.battery
        live: core.batteryLive
        swayMs: core.theme.coreDriftMsInner
    }

    // ── the time dials: 12 / 60 / 60 dots, one per unit ─────────────────────
    // Three fixed rings of dots read the clock the way a dial does: the dot for
    // the current unit is lit, and in `coreDialFill` the ones already spent stay
    // warm. Nothing animates — the `current` binding re-evaluates once a second
    // at most — so there is no frame work to stop when the core leaves the screen.
    //   innermost = hours, middle = minutes, outermost = seconds
    Dial {
        objectName: "dialHours"
        count: core.theme.coreDialHours
        radiusFraction: core.theme.coreDialHoursRadius
        current: core.hours % core.theme.coreDialHours
        dotSize: core.theme.coreDialHourDot
        nowSize: core.theme.coreDialHourNow
        dotColor: core.theme.coreDialColor
    }
    Dial {
        objectName: "dialMinutes"
        count: core.theme.coreDialMinutes
        radiusFraction: core.theme.coreDialMinutesRadius
        current: core.minutes
        dotSize: core.theme.coreDialMinuteDot
        nowSize: core.theme.coreDialMinuteNow
        dotColor: core.theme.coreDialColor
    }
    Dial {
        objectName: "dialSeconds"
        count: core.theme.coreDialSeconds
        radiusFraction: core.theme.coreDialSecondsRadius
        current: core.seconds
        dotSize: core.theme.coreDialSecondDot
        nowSize: core.theme.coreDialSecondNow
        dotColor: core.theme.coreDialAccent
    }

    component Dial: Item {
        id: dial
        anchors.fill: parent
        visible: core.theme.coreDials
        property int count: 12
        property real radiusFraction: 0.445
        property int current: 0
        property real dotSize: 0.031
        property real nowSize: 0.070
        property color dotColor: core.theme.coreDialColor

        readonly property real radius: core.r * radiusFraction
        // the dot walks clockwise from twelve o'clock, the way every dial here does
        readonly property real step: 360 / Math.max(1, count)

        // the whole dial is one numbered list: 0 is the top, then clockwise
        Repeater {
            model: dial.count
            delegate: Item {
                required property int index
                anchors.fill: parent
                rotation: index * dial.step
                Rectangle {
                    objectName: "dialDot"
                    readonly property bool lit: index === dial.current
                    readonly property bool past: !lit && index < dial.current
                    readonly property real d: Math.max(1.5,
                                                      core.r * (lit ? dial.nowSize : dial.dotSize))
                    width: d; height: d; radius: d / 2
                    x: dial.width / 2 - width / 2
                    y: dial.height / 2 - dial.radius - height / 2
                    // the lit dot is the hand: near-white, and ringed in ink so it
                    // still reads when it lands on a load ring's bar
                    color: core.theme.alpha(lit ? core.theme.coreDialNow : dial.dotColor,
                                            lit ? core.theme.coreDialNowAlpha
                                                : (past && core.theme.coreDialFill
                                                   ? core.theme.coreDialPastAlpha
                                                   : core.theme.coreDialDimAlpha))
                    border.width: lit ? Math.max(1, core.r * core.theme.coreDialNowRing) : 0
                    border.color: core.theme.alpha(core.theme.coreDialRingColor,
                                                   core.theme.coreDialRingAlpha)
                }
            }
        }
    }

    component Ring: Item {
        id: ring
        anchors.fill: parent

        property real radiusFraction: 0.88
        property int segments: 48
        property real value: 0
        property bool live: true
        property int swayMs: 21000

        readonly property real radius: core.r * radiusFraction
        // how much of each pitch a segment takes up; the rest is the gap
        readonly property real arc: (2 * Math.PI * radius / Math.max(1, segments))
                                    * (1 - core.theme.coreSegmentGap)

        // the drift: a slow 1.6° sway, never a turn — the lit arc has to keep
        // meaning what it means, so the zero mark stays at the top
        SequentialAnimation on rotation {
            running: core.animated && core.theme.coreDrift
            loops: Animation.Infinite
            NumberAnimation {
                from: 0; to: core.theme.coreDriftDeg
                duration: ring.swayMs / 4; easing.type: Easing.InOutSine
            }
            NumberAnimation {
                from: core.theme.coreDriftDeg; to: -core.theme.coreDriftDeg
                duration: ring.swayMs / 2; easing.type: Easing.InOutSine
            }
            NumberAnimation {
                from: -core.theme.coreDriftDeg; to: 0
                duration: ring.swayMs / 4; easing.type: Easing.InOutSine
            }
        }

        Repeater {
            model: ring.segments
            delegate: Item {
                required property int index
                anchors.fill: parent
                // the bar starts at the top; a positive rotation walks it
                // clockwise, which is the direction the rings fill
                rotation: index * (360 / Math.max(1, ring.segments))
                Rectangle {
                    // a rounded bar on the tangent, at the ring's radius
                    width: Math.max(1, ring.arc)
                    height: core.stroke
                    radius: height / 2
                    x: ring.width / 2 - width / 2
                    y: ring.height / 2 - ring.radius - height / 2
                    // the first segment of every ring is the gold zero mark — grey
                    // when the source is missing, so silence is not mistaken for zero
                    color: index === 0
                           ? (ring.live
                              ? core.theme.alpha(core.theme.coreAccent,
                                                 ring.value > 0 ? core.theme.coreLitAlpha
                                                                : core.theme.coreLitAlpha * 0.55)
                              : core.theme.alpha(core.theme.coreRingDim,
                                                 core.theme.coreMissingAlpha))
                           : (ring.live && index < ring.value * ring.segments
                              ? core.theme.alpha(core.theme.coreRingLit, core.theme.coreLitAlpha)
                              : core.theme.alpha(core.theme.coreRingDim, core.theme.coreDimAlpha))
                }
            }
        }
    }

}
