import QtQuick
import QtQuick.Shapes

// ── MagicGem — one of the five stones on the ring ────────────────────────────
//
// A physical cabochon: a transparent glass shell over a coloured body, a bright
// rim, an inner reflection that turns slowly inside the stone, the pre-rendered
// gold bezel with its claws, and a black silhouette glyph. It breathes when idle,
// lifts and throws sparks when the pointer is on it, and sends one ripple out
// when it is clicked.
//
// Every moving part is a transform or an opacity: the glass geometry is built
// once. Nothing here takes input — the widget owns every hit area, so a gem can
// never eat a click meant for the disc behind it.
Item {
    id: gem
    objectName: "magicGem"

    property real size: 132                   // the bezel's outer diameter
    property color tint: theme.gemWifi
    property url bezelSource
    property url glyphSource
    property url haloSource
    property url sparkSource
    property bool hovered: false
    property bool active: false              // its panel is the one on screen
    property bool dimmed: false              // another gem owns the pointer
    property real time: 0
    property bool animated: true
    property bool lowPower: false
    property Theme theme: Theme {}

    readonly property real bodyR: size * 0.39  // the glass, inside the bezel's inner ring
    readonly property bool lit: hovered || active
    // a slow breath; frozen when the dashboard is hidden or in low power, where
    // a steady half-lit stone is cheaper and just as readable
    readonly property real breath: (animated && !lowPower) ? (0.5 + 0.5 * Math.sin(time * 1.1)) : 0.5

    width: size
    height: size

    function withAlpha(c, a) {
        c = Qt.color(c);
        return Qt.rgba(c.r, c.g, c.b, a);
    }

    // the float: a few tenths of a percent of the stone's size, so it reads as
    // levitating without ever looking like it moved off the ring
    y: (animated && !lowPower) ? Math.sin(time * 0.62 + size) * size * 0.012 : 0

    // ── the halo: light the stone throws on the ring, under everything ──────
    // A pre-rendered radial glow, so it is exactly round at every size and costs
    // one image draw. It widens and brightens while the stone is lit.
    Image {
        id: halo
        anchors.centerIn: parent
        width: parent.size * (gem.lit ? 2.15 : 1.95)
        height: width
        source: gem.haloSource
        smooth: true
        mipmap: true
        opacity: (gem.lit ? 0.95 : 0.42 + 0.16 * gem.breath) * (gem.dimmed ? 0.34 : 1)
        visible: gem.haloSource.toString().length > 0
        Behavior on width { NumberAnimation { duration: 260; easing.type: Easing.OutQuad } }
        Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutQuad } }
    }

    // ── the stone ───────────────────────────────────────────────────────────
    Rectangle {
        id: body
        anchors.centerIn: parent
        width: gem.bodyR * 2
        height: width
        radius: width / 2
        antialiasing: true
        color: "transparent"
        gradient: Gradient {
            GradientStop { position: 0.00; color: gem.theme.visionOsGlass ? gem.withAlpha(gem.theme.smokedCore, 0.84) : gem.withAlpha(Qt.lighter(gem.tint, 1.28), 0.96) }
            GradientStop { position: 0.52; color: gem.withAlpha(gem.tint, gem.theme.visionOsGlass ? 0.72 : 0.93) }
            GradientStop { position: 1.00; color: gem.withAlpha(Qt.lighter(gem.tint, 1.22), 0.95) }
        }
        border.width: Math.max(1, gem.size * 0.006)
        border.color: gem.withAlpha("#000000", 0.45)

        // inner shadow: the dome's own edge, darker all the way round
        Rectangle {
            anchors.fill: parent
            anchors.margins: -1
            radius: width / 2
            color: "transparent"
            border.width: Math.max(1.2, gem.size * 0.022)
            border.color: gem.withAlpha("#000000", 0.30)
        }
        // specular: a soft streak across the upper-left of the dome
        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            y: parent.height * 0.10
            width: parent.width * 0.62
            height: parent.height * 0.34
            radius: width / 2
            rotation: -18
            opacity: gem.lit ? 0.55 : 0.30 + 0.12 * gem.breath
            gradient: Gradient {
                GradientStop { position: 0.0; color: gem.theme.alpha(gem.theme.white, 0) }
                GradientStop { position: 0.5; color: gem.theme.alpha(gem.theme.white, 0.40) }
                GradientStop { position: 1.0; color: gem.theme.alpha(gem.theme.white, 0) }
            }
            Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutQuad } }
        }

        // ── the inner reflection: a thin arc that turns inside the glass ────
        Item {
            anchors.fill: parent
            rotation: (gem.animated && !gem.lowPower) ? gem.time * (gem.lit ? 46 : 18) : 0
            Shape {
                anchors.fill: parent
                ShapePath {
                    strokeWidth: Math.max(1.0, gem.bodyR * 0.09)
                    strokeColor: gem.withAlpha(Qt.lighter(gem.tint, 1.5), gem.lit ? 0.55 : 0.26)
                    fillColor: "transparent"
                    PathSvg { path: gem.arcPath(0.66, -70, 62) }
                }
                ShapePath {
                    strokeWidth: Math.max(0.7, gem.bodyR * 0.05)
                    strokeColor: gem.theme.alpha(gem.theme.white, gem.lit ? 0.40 : 0.16)
                    fillColor: "transparent"
                    PathSvg { path: gem.arcPath(0.46, 120, 44) }
                }
            }
        }

        // the glass shell: a cold white sheen over the top of the body, so the
        // stone reads as something you could put a finger through
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            gradient: Gradient {
                GradientStop { position: 0.00; color: gem.theme.alpha(gem.theme.white, 0.22) }
                GradientStop { position: 0.32; color: gem.theme.alpha(gem.theme.white, 0.05) }
                GradientStop { position: 0.60; color: gem.theme.alpha(gem.theme.white, 0) }
                GradientStop { position: 1.00; color: gem.withAlpha("#000000", 0.22) }
            }
        }
    }

    // ── the bezel ───────────────────────────────────────────────────────────
    Image {
        anchors.fill: parent
        source: gem.bezelSource
        fillMode: Image.PreserveAspectFit
        smooth: true
        mipmap: true
        opacity: gem.dimmed ? 0.72 : 1
        Behavior on opacity { NumberAnimation { duration: 180 } }
    }

    // ── internal liquid-aurora swirl ────────────────────────────────────────
    Image {
        objectName: "gemAuroraSwirl"
        anchors.centerIn: parent
        width: gem.bodyR * 1.94
        height: width
        source: Qt.resolvedUrl("assets/gem-aurora-swirl.svg")
        fillMode: Image.PreserveAspectFit
        smooth: true
        mipmap: true
        visible: gem.theme.visionOsGlass
        rotation: (gem.animated && !gem.lowPower) ? gem.time * 18 : 0
        opacity: gem.dimmed ? 0.45 : 0.88
    }

    // ── the silhouette ──────────────────────────────────────────────────────
    Image {
        anchors.centerIn: parent
        width: gem.bodyR * 1.16
        height: width
        source: gem.glyphSource
        fillMode: Image.PreserveAspectFit
        smooth: true
        opacity: gem.dimmed ? 0.66 : 0.92
        Behavior on opacity { NumberAnimation { duration: 180 } }
    }

    // ── the liquid-glass dome: curved meniscus & internal caustic ─────────
    Image {
        objectName: "gemLiquidDome"
        anchors.fill: parent
        source: Qt.resolvedUrl("assets/gem-liquid-dome.svg")
        fillMode: Image.PreserveAspectFit
        smooth: true
        mipmap: true
        visible: gem.theme.liquidGlass
        opacity: gem.theme.gemDomeAlpha * (gem.dimmed ? 0.75 : 1)
        Behavior on opacity { NumberAnimation { duration: 180 } }
    }

    // ── sparks: they only exist while the stone is lit ──────────────────────
    Repeater {
        model: 4
        delegate: Spark {
            id: mote
            required property int index
            readonly property real seed: Math.sin(mote.index * 45.233) * 9876.54321
            readonly property real phase: mote.seed - Math.floor(mote.seed)
            readonly property real ang: (gem.animated ? gem.time * (0.55 + 0.35 * mote.phase) : 0)
                                         + mote.phase * Math.PI * 2
            readonly property real rad: gem.bodyR * (1.08 + 0.28 * Math.sin(gem.time * 0.9 + mote.index))
            source: gem.sparkSource
            diameter: Math.max(3, gem.size * (0.035 + 0.02 * mote.phase))
            amount: (gem.lit ? 0.9 : 0) * (gem.dimmed ? 0.2 : 1)
            x: gem.width / 2 + Math.cos(mote.ang) * mote.rad - width / 2
            y: gem.height / 2 + Math.sin(mote.ang) * mote.rad - height / 2
        }
    }

    // ── the ignition ripple: one expanding ring per click ──────────────────
    Rectangle {
        id: ripple
        anchors.centerIn: parent
        width: gem.size * 0.86
        height: width
        radius: width / 2
        color: "transparent"
        border.width: Math.max(1.2, gem.size * 0.012)
        border.color: gem.withAlpha(Qt.lighter(gem.tint, 0.6), 0.85)
        opacity: 0
        scale: 0.7
        visible: opacity > 0.01
    }
    ParallelAnimation {
        id: rippleAnim
        NumberAnimation { target: ripple; property: "scale"; from: 0.7; to: 2.1; duration: 620; easing.type: Easing.OutCubic }
        SequentialAnimation {
            NumberAnimation { target: ripple; property: "opacity"; from: 0.9; to: 0.0; duration: 620; easing.type: Easing.OutQuad }
        }
    }
    function ignite() {
        // low power keeps the reaction but drops it to a single cheap flash
        if (gem.lowPower) { ripple.opacity = 0; return; }
        ripple.scale = 0.7;
        ripple.opacity = 0.9;
        rippleAnim.restart();
    }
    // a click that opens (or pins) this gem's panel is exactly the moment the
    // panel becomes active — no extra plumbing from the widget
    onActiveChanged: if (active) gem.ignite()

    function arcPath(fraction, startDeg, sweepDeg) {
        var rr = gem.bodyR * fraction;
        var a0 = startDeg * Math.PI / 180, a1 = (startDeg + sweepDeg) * Math.PI / 180;
        var x0 = gem.bodyR + Math.cos(a0) * rr, y0 = gem.bodyR + Math.sin(a0) * rr;
        var x1 = gem.bodyR + Math.cos(a1) * rr, y1 = gem.bodyR + Math.sin(a1) * rr;
        var large = Math.abs(sweepDeg) > 180 ? 1 : 0;
        return "M " + x0.toFixed(2) + " " + y0.toFixed(2)
             + " A " + rr.toFixed(2) + " " + rr.toFixed(2) + " 0 " + large + " 1 "
             + x1.toFixed(2) + " " + y1.toFixed(2);
    }
}
