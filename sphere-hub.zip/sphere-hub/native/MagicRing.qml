import QtQuick
import QtQuick.Shapes

// ── MagicRing — the living arcane circle ────────────────────────────────────
//
// One item, sized from a single measurement (R). Back to front, and why:
//
//   rays        one wide cone of each gem's own colour, from under the disc out
//               through its stone. Pre-rendered, so a hover costs one opacity.
//   dust        fixed gold dust plus a few blue motes; static in low power.
//   atmosphere  a soft radial wash behind the whole circle.
//   web         Web: the static radial web (spokes, nodes, star, guide)
//   runering    RuneRing: the band rings and the glyph ring
//   sigils      Sigil: the five station emblems and their inscriptions
//               (and, from the next step, the glyph ring) — exact geometry
//               computed from Geometry.qml, never a pre-rendered sheet
//   energy      the illuminated geometry: the outer rings and the ignition
//               sweep, each one an EnergyLine (bloom + colour + white core).
//               The rings are static; only the ignition moves, and only while
//               the spell is forming.
//   bridges     gem → centre lines, in the gem's colour, lit by the pointer.
//
// Everything animated here is a transform or an opacity driven by `time`
// (and by `activation`, the spell's own ramp), so a hidden dashboard animates
// nothing at all: the widget stops handing out time. No line here moves on its
// own — the web and the rings are completely static (motion.json); the legacy
// sparkle (dust, beads, comets) keeps its old clock until the tuning pass.
//
// Nothing in this file takes input. The widget owns every hit area, which is why
// the ring can never swallow a click meant for a gem or a panel.
Item {
    id: ring
    objectName: "magicRing"

    property real radius: 300                  // R — every measurement below is a fraction of it
    property var gemAngles: []                 // screen degrees, -90 = straight up, clockwise
    property var gemColors: []
    property int hoveredIndex: -1
    property int activeIndex: -1
    property real time: 0
    property real orbitDeg: 0                      // seconds since the dashboard first appeared
    property real activation: 1                // 0 = dormant, 1 = fully cast
    property bool animated: true
    property Motion motion: Motion {}
    property bool lowPower: false
    property url sparkSource
    property url atmosphereSource
    property var gemRaySources: []
    property Theme theme: Theme {}
    property Geometry geometry: Geometry {}
    property Panels panels: Panels {}

    readonly property int count: gemAngles.length
    readonly property bool moving: animated && !lowPower
    readonly property real charge: Math.max(0, Math.min(1, activation))

    width: radius * 2
    height: width

    function withAlpha(c, a) {
        c = Qt.color(c);
        return Qt.rgba(c.r, c.g, c.b, a);
    }
    // clock degrees of a gem (0 = straight up, clockwise) — one definition,
    // used by every ring, ray and spoke that points at a stone
    function clockAngle(i) {
        return (gemAngles[i] + 90 + 360) % 360;
    }
    function gemColor(i) {
        var list = gemColors || [];
        return i >= 0 && i < list.length ? list[i] : ring.theme.gold;
    }
    // How much of its light a gem's ray carries right now: the gem under the
    // pointer (or the one whose panel is open) is the bright one, its
    // neighbours fall back, and the idle ring breathes on a slow sine.
    function rayGain(i) {
        if (!animated)
            return (i === hoveredIndex || i === activeIndex) ? 1 : 0.42;
        var breath = 0.86 + 0.14 * Math.sin(time * 0.55 + i * 1.37);
        if (i === hoveredIndex)
            return 1;
        if (i === activeIndex)
            return 0.94;
        if (hoveredIndex >= 0 || activeIndex >= 0)
            return 0.24;
        return 0.55 * breath;
    }
    // the gem whose light the pointer is borrowing, or -1
    readonly property int litIndex: hoveredIndex >= 0 ? hoveredIndex : activeIndex
    function gemGain(i) {
        if (i === litIndex)
            return 1;
        if (litIndex >= 0)
            return 0.34;
        return 0.62;
    }

    // ── light: one cone per gem ──────────────────────────────────────────────
    // Each gem's cone is a pre-rendered sheet (tools/artwork.py), drawn as an
    // image and turned onto its gem. Only its opacity moves with the pointer, so
    // the light never rebuilds geometry or a gradient: a hover costs one number.
    Repeater {
        model: ring.count
        delegate: Item {
            id: ray
            required property int index
            anchors.fill: parent
            rotation: ring.gemAngles[ray.index] + 90
            visible: ring.visible
            opacity: ring.rayGain(ray.index) * (0.35 + 0.65 * ring.charge)
            Behavior on opacity {
                NumberAnimation {
                    duration: 240
                    easing.type: Easing.OutQuad
                }
            }
            Image {
                anchors.fill: parent
                source: (ring.gemRaySources || [])[ray.index] || ""
                fillMode: Image.PreserveAspectFit
                smooth: true
                mipmap: true
            }
        }
    }

    // ── dust ────────────────────────────────────────────────────────────────
    Repeater {
        model: 48
        delegate: Rectangle {
            id: mote
            required property int index
            // a deterministic scatter: the same star map every session
            readonly property real seedA: Math.sin(mote.index * 12.9898) * 43758.5453
            readonly property real fracA: mote.seedA - Math.floor(mote.seedA)
            readonly property real seedB: Math.sin(mote.index * 78.233) * 12345.6789
            readonly property real fracB: mote.seedB - Math.floor(mote.seedB)
            readonly property real dist: ring.radius * (0.10 + 0.86 * mote.fracB)
            readonly property real ang: mote.fracA * Math.PI * 2
            x: ring.radius + Math.cos(mote.ang) * mote.dist - width / 2
            y: ring.radius + Math.sin(mote.ang) * mote.dist - height / 2
            width: Math.max(1.0, ring.radius * (0.004 + 0.007 * mote.fracA))
            height: width
            radius: width / 2
            // every third mote is holographic blue, the rest are gold dust
            color: mote.index % 3 === 0 ? ring.theme.cyan : (ring.theme.visionOsGlass ? ring.theme.silverWhite : ring.theme.goldBright)
            opacity: {
                var base = (mote.index % 3 === 0 ? 0.16 : 0.10) + 0.26 * mote.fracA;
                if (!ring.moving)
                    return base;
                return base * (0.55 + 0.45 * Math.sin(ring.time * (0.6 + mote.fracB * 1.4) + mote.index));
            }
        }
    }

    // ── atmosphere: the room the circle is lit in ───────────────────────────
    Image {
        anchors.centerIn: parent
        width: parent.width * 1.25
        height: width
        source: ring.atmosphereSource
        fillMode: Image.PreserveAspectFit
        smooth: true
        opacity: ring.lowPower ? 0.22 : (0.20 + 0.06 * Math.sin(ring.time * 0.35))
    }

    // ── the web: the ring's bottom layer, completely static ───────────────
    Image {
        objectName: "visionOsDialScale"
        visible: ring.theme.visionOsGlass
        anchors.centerIn: parent
        width: ring.radius * 2
        height: width
        rotation: ring.orbitDeg
        source: Qt.resolvedUrl("assets/visionos-dial-scale.svg")
        fillMode: Image.PreserveAspectFit
        smooth: true
        mipmap: true
    }
    Image {
        objectName: "visionOsAstroWeb"
        visible: ring.theme.visionOsGlass
        anchors.centerIn: parent
        width: ring.radius * 2
        height: width
        rotation: ring.orbitDeg
        source: Qt.resolvedUrl("assets/visionos-astro-web.svg")
        fillMode: Image.PreserveAspectFit
        smooth: true
        mipmap: true
    }

    Web {
        visible: !ring.theme.visionOsGlass
        anchors.centerIn: parent
        radius: ring.radius
        theme: ring.theme
        geometry: ring.geometry
        motion: ring.motion
        clock: ring.time
        animated: ring.moving
    }

    // ── the ring structure ─────────────────────────────────────────────────
    // The tick comb and the runic ring's band replace the old pre-rendered
    // sheets: the engraved frame and the numeral band are gone (the numeral
    // band was readable type, and the crest carries no words).
    RuneRing {
        visible: !ring.theme.visionOsGlass
        anchors.centerIn: parent
        radius: ring.radius
        theme: ring.theme
        geometry: ring.geometry
        motion: ring.motion
        clock: ring.time
        animated: ring.moving
        highlight: ring.litIndex
    }

    // ── the sigil stations ────────────────────────────────────────────────
    // Above the glyph ring: the emblems sit at 0.84 R where nothing else
    // runs, and their inscriptions graze above the glyph band to the gems.
    Sigil {
        visible: ring.geometry.sigilsEnabled        // sigils: false hides the layer
        anchors.centerIn: parent
        radius: ring.radius
        theme: ring.theme
        geometry: ring.geometry
        motion: ring.motion
        panels: ring.panels
        clock: ring.time
        animated: ring.moving
        highlight: ring.litIndex
    }

    // ── the illuminated geometry ────────────────────────────────────────────
    // The tight outer edge rings — the bold, glowing, engraved edge — live in
    // OuterRings.qml (the old double ring and its dashes are deleted).
    OuterRings {
        anchors.centerIn: parent
        radius: ring.radius
        geometry: ring.geometry
        theme: ring.theme
    }

    // The ignition: a bright head running round the rim with a tail behind it, so
    // the spell reads as being *drawn* rather than switched on. Two short arcs
    // whose geometry changes while they are visible, and nothing at all once the
    // circle is fully cast.
    EnergyLine {
        anchors.fill: parent
        theme: ring.theme
        path: ring.arcPath(1.0, -90 + Math.max(0, 360 * ring.charge - 16), Math.min(16, 360 * ring.charge))
        tint: ring.theme.cyanWhite
        weight: Math.max(1.2, ring.radius * 0.0065)
        glow: 1.7
        coreScale: 1
        opacity: ring.charge < 0.999 ? 1 : 0
        visible: opacity > 0.01
    }
    EnergyLine {
        anchors.fill: parent
        theme: ring.theme
        path: ring.arcPath(1.0, -90 + Math.max(0, 360 * ring.charge - 150), Math.min(134, Math.max(0, 360 * ring.charge - 16)))
        tint: ring.theme.cyan
        weight: Math.max(0.9, ring.radius * 0.0045)
        glow: 0.85
        coreScale: 0.7
        opacity: ring.charge < 0.999 ? 0.8 : 0
        visible: opacity > 0.01
    }

    // ── the bridges: gem → centre, in the gem's own colour ─────────────────
    // Five straight lines of light. The disc is opaque and drawn above them, so
    // only the part between the disc and its stone is ever seen; the pointer's
    // gem lights its own bridge and dims the other four.
    Repeater {
        model: ring.count
        delegate: EnergyLine {
            id: bridge
            required property int index
            anchors.fill: parent
            theme: ring.theme
            path: "M " + ring.radius.toFixed(2) + " " + ring.radius.toFixed(2) + " L " + ring.polar(0.71, ring.clockAngle(bridge.index)).x.toFixed(2) + " " + ring.polar(0.71, ring.clockAngle(bridge.index)).y.toFixed(2)
            tint: ring.gemColor(bridge.index)
            weight: Math.max(0.7, ring.radius * 0.0028)
            glow: (0.35 + 0.65 * ring.gemGain(bridge.index)) * ring.charge
            flow: ring.moving
            clock: ring.time
            flowSpeed: 30 + bridge.index * 3
            dashOn: 1.4
            dashOff: 3.0
            coreScale: 0.8
        }
    }
    // …and the beads that run inward along them, one pair per gem
    Repeater {
        model: ring.count * 2
        delegate: Spark {
            id: bead
            required property int index
            readonly property int gemIndex: Math.floor(bead.index / 2)
            readonly property real phase: (bead.index % 2) * 0.5
            readonly property real t: {
                if (!ring.moving)
                    return (bead.phase + 0.25) % 1;
                var cycle = (ring.time * 0.22 + bead.phase + bead.gemIndex * 0.17) % 1;
                return cycle;
            }
            readonly property point p: ring.bridgePoint(bead.gemIndex, 0.02 + 0.30 * bead.t)
            source: ring.sparkSource
            diameter: Math.max(4, ring.radius * (0.020 + 0.010 * (1 - bead.t)))
            amount: ring.gemGain(bead.gemIndex) * ring.charge * (0.35 + 0.65 * bead.t)
            x: bead.p.x - width / 2
            y: bead.p.y - height / 2
        }
    }

    // ── the outer ring's own travellers ────────────────────────────────────
    // Two comets going round the rim with short tails, plus the occasional flare
    // at random stations. They cost one transform per bead per frame.
    Repeater {
        model: ring.lowPower ? 1 : 2
        delegate: Item {
            id: comet
            required property int index
            anchors.fill: parent
            readonly property real speed: comet.index === 0 ? 0.030 : -0.019
            property real head: (ring.time * comet.speed + comet.index * 0.5) % 1
            Repeater {
                model: 4
                delegate: Spark {
                    id: tail
                    required property int index
                    readonly property real at: comet.head - tail.index * 0.006 * Math.sign(comet.speed)
                    readonly property point p: ring.polar(1.0, ((at * 360) % 360 + 360) % 360)
                    source: ring.sparkSource
                    diameter: Math.max(3, ring.radius * (0.020 - tail.index * 0.004))
                    amount: ring.charge * (0.85 - tail.index * 0.20)
                    x: tail.p.x - width / 2
                    y: tail.p.y - height / 2
                }
            }
        }
    }

    // ── path helpers ────────────────────────────────────────────────────────
    // a point between gem i and the centre: t = 0 at the stone, 1 at the centre
    function bridgePoint(i, t) {
        var g = ring.polar(0.71, ring.clockAngle(i));
        return Qt.point(g.x + (radius - g.x) * t, g.y + (radius - g.y) * t);
    }
    // polar → pixels. `fraction` of R, CLOCK degrees (0 = straight up, clockwise).
    function polar(fraction, clockDeg) {
        var rr = radius * fraction;
        var a = clockDeg * Math.PI / 180;
        return Qt.point(radius + Math.sin(a) * rr, radius - Math.cos(a) * rr);
    }
    // an arc of the ring, in clock degrees
    function arcPath(fraction, startClock, sweep) {
        var a = ring.polar(fraction, startClock);
        var b = ring.polar(fraction, startClock + sweep);
        var rr = radius * fraction;
        var large = Math.abs(sweep) > 180 ? 1 : 0;
        var sweepFlag = sweep >= 0 ? 1 : 0;
        return "M " + a.x.toFixed(2) + " " + a.y.toFixed(2) + " A " + rr.toFixed(2) + " " + rr.toFixed(2) + " 0 " + large + " " + sweepFlag + " " + b.x.toFixed(2) + " " + b.y.toFixed(2);
    }
}
