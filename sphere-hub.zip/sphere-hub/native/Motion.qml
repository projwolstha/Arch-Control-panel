import QtQuick

// ── Motion — every motion of the crest, mirrored from config/motion.json ────
//
// The JSON is the source of truth (test_config.py keeps this file honest).
// Nothing in the crest may move unless one of these flags allows it: the web
// is completely static (webRotation false), the rings' light sweep and the
// spokes' pulse are opt-in, and all of it pauses when the window is hidden.
QtObject {
    id: motion
    objectName: "motion"

    readonly property bool webRotation: false      // the web never turns
    readonly property bool runeRotation: true      // the runes turn in place, ~10 min a lap
    readonly property bool runeFlicker: true       // a soft brightness wave
    readonly property bool sigilPulse: true        // the sigils breathe, staggered
    readonly property bool goldShimmer: false      // light sweep along the rings
    readonly property bool webPulse: false         // faint light along the spokes
}
