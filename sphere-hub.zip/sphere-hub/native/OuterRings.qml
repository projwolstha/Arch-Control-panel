import QtQuick

// ── OuterRings — sculpted optical Liquid-Glass torus + recessed metallic inlay ─
//
// Back to front:
//   liquid-torus-body   translucent curved glass body and inner bevel shoulder
//   outerRadii          four concentric gold (or silver) rings recessed in the channel
//   liquid-torus-glaze  convex crown specular crescent, meniscus and chromatic dispersion
//
// Every radius is a fraction of R from Geometry.qml, every stroke from
// Theme.qml — no raw colour or size here. Nothing moves and nothing takes
// input: the ring is the still optical-glass frame the runes drift inside.
Item {
    id: outerRings
    objectName: "outerRings"

    property real radius: 300                  // R
    property Geometry geometry: Geometry {}
    property Theme theme: Theme {}

    width: radius * 2
    height: width

    // one weight language: theme px at R = 500, scaled to this ring
    function weight(px) { return Math.max(0.6, radius / 500 * px); }

    // the active family, deepest first: the outermost ring is the last and
    // the brightest, so the packed rings read as one glowing edge
    function familyColor(i) {
        if (theme.outerColor === "silver" || theme.visionOsGlass) {
            return [theme.silverDeep, theme.silver, theme.silverBright,
                    theme.silverWhite][Math.min(i, 3)];
        }
        return [theme.goldDeep, theme.gold, theme.goldBright,
                theme.goldWhite][Math.min(i, 3)];
    }

    // ── 1. sculpted optical-glass torus body ───────────────────────────────
    Image {
        objectName: "liquidTorusBody"
        anchors.centerIn: parent
        width: outerRings.radius * 2 * outerRings.geometry.liquidTorusScale
        height: width
        source: Qt.resolvedUrl("assets/liquid-torus-body.svg")
        fillMode: Image.PreserveAspectFit
        smooth: true
        mipmap: true
        visible: outerRings.theme.liquidGlass
        opacity: outerRings.theme.liquidTorusAlpha
    }

    // the outermost ring blooms softly inside the glass channel
    Rectangle {
        anchors.centerIn: parent
        width: outerRings.radius * 2 * outerRings.geometry.outerRadii[
                   outerRings.geometry.outerRadii.length - 1] + outerRings.weight(6)
        height: width
        radius: width / 2
        color: "transparent"
        border.width: outerRings.weight(3 + outerRings.theme.crestGoldGlow * 2)
        border.color: outerRings.theme.alpha(
            outerRings.familyColor(outerRings.geometry.outerRadii.length - 1),
            (0.2 + 0.2 * outerRings.theme.crestGoldGlow)
            * (outerRings.theme.liquidGlass ? 0.65 : 1))
    }

    // ── 2. four concentric metallic rings recessed inside the glass ────────
    Repeater {
        model: outerRings.geometry.outerRadii.length
        delegate: Item {
            required property int index
            anchors.fill: parent
            readonly property real frac: outerRings.geometry.outerRadii[index]
            Rectangle {
                anchors.centerIn: parent
                width: outerRings.radius * 2 * frac
                height: width
                radius: outerRings.radius * frac
                color: "transparent"
                border.color: outerRings.familyColor(index)
                border.width: outerRings.weight(
                    outerRings.theme.crestOuterEdgeWidths[index]
                    * (outerRings.theme.liquidGlass ? 0.68 : 1))
                opacity: outerRings.theme.crestOuterEdgeAlphas[index]
                         * (outerRings.theme.liquidGlass
                            ? outerRings.theme.liquidGoldEmbedAlpha : 1)
            }
        }
    }

    // ── 3. upper-left crown specular crescent & prismatic rim dispersion ───
    Image {
        objectName: "liquidTorusGlaze"
        anchors.centerIn: parent
        width: outerRings.radius * 2 * outerRings.geometry.liquidTorusScale
        height: width
        source: Qt.resolvedUrl("assets/liquid-torus-glaze.svg")
        fillMode: Image.PreserveAspectFit
        smooth: true
        mipmap: true
        visible: outerRings.theme.liquidGlass
        opacity: outerRings.theme.liquidGlazeAlpha
    }
}
