import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// ── PanelFrame — the one frame every panel lives in ───────────────────────────
//
// Every list and every dashboard that opens INSIDE the main orb is built here,
// once. A panel never lays anything out: it hands over a title, a state line, a
// subtitle, a body (rows, a value, a few cards, bars, segments) and an action
// row, and this component decides where all of that goes. Adding a panel later
// therefore means adding data — not copying a layout — so a new panel cannot
// drift out of alignment with the others.
//
// What the frame owns
//   • the content circle: a near-black circle with a thin gold rim, concentric
//     with the centre disc and separated from it by an even gap. It draws no
//     sphere of its own — the disc outside it is the orb now.
//   • the gold rule under the header, the status pill, the gem-coloured accent
//     that follows the stone which opened the panel.
//   • the safe area: side = (0.70·radius)·√2·0.935, i.e. the square inscribed in
//     the visible sphere with a margin. It is clipped, so no row, card or chip
//     can ever cross the rim, at any orb size.
//   • the vertical structure, top to bottom, all centred:
//         header (icon + title) → rule → status pill → body → action row
//     with the close button inside the safe area, on the header's baseline.
//   • the scales: one spacing quantum u = radius/200 (s1…s4) and one type scale
//     (title, value, label, caption) on one font family.
//   • the motion: a 170 ms fade + scale when a panel opens. It never gates
//     input — hit testing does not look at opacity, and `visible` is what the
//     widget flips, so a click lands on the first frame exactly as before.
//
// Row widths are additionally bounded by the circle's chord at the row's own
// height (`rowWidth()`), so even content that tried to grow past the slab would
// be tapered to the rim instead of cut off by it.
Item {
    id: frame

    // ── the one measurement ──────────────────────────────────────────────────
    property real radius: 150                 // = widget.orbRadius
    property real uiScale: 1
    // marker the tests use to prove every panel really is framed
    readonly property bool isPanelFrame: true
    // short name used for the objectNames of the frame's own parts
    property string key: "panel"
    // Optional per-part objectName overrides ({ring:"batteryRing", …}). A panel
    // still writes no layout: this only renames an element the frame already owns.
    property var names: ({})
    function n(part, fallback) {
        var override = names ? names[part] : undefined;
        return override ? override : key + fallback;
    }

    // ── spacing scale (4 / 8 / 12 / 16 × radius/200) ─────────────────────────
    readonly property real u: radius / 200
    readonly property real s1: u * 4
    readonly property real s2: u * 8
    readonly property real s3: u * 12
    readonly property real s4: u * 16

    // ── type scale ───────────────────────────────────────────────────────────
    // Four steps, all from the same quantum, each with a floor: below ~7 px type
    // is no longer readable, so at a small orb the panel keeps legible sizes and
    // lets the body scroll instead of shrinking into a grey smear.
    readonly property real fsTitle: Math.max(9.5, u * 9.0)
    readonly property real fsValue: Math.max(16, u * 22)
    readonly property real fsLabel: Math.max(8.0, u * 8.4)
    readonly property real fsCaption: Math.max(7.0, u * 6.9)
    // the status pill needs real room; below this the header state line carries it
    readonly property bool hasStatusRoom: safeSide >= 152
    // One family for every string in every panel. The widget hands the serif
    // family in (`root.serifFamily`), so the panels speak with one voice.
    property string typeFamily: Qt.application.font.family

    // ── the visible circle and the box that fits inside it ───────────────────
    // `radius` is the open disc's radius. The content circle sits inside it with
    // an even gap, and everything the panel draws obeys that circle — not the
    // 2·radius item — so no row can ever cross the gold rim.
    readonly property real glassR: radius * 0.80
    // the gap between this circle and the disc's rim, and the rim's own width.
    // 0.80 is the largest circle that still leaves the five stones outside a
    // panel's reach: a gem is always clickable, even with a panel open.
    readonly property real rimGap: radius * 0.20
    readonly property real rimWidth: Math.max(1, radius * 0.012)
    readonly property real safeSide: glassR * Math.SQRT2 * 0.935
    // The compact case is the tablet/small-screen one: the frame is measured in
    // the same units as everything else, so the threshold is a radius, not a
    // pixel size that would drift the moment `glassR` changed.
    readonly property bool compact: radius < 155

    // Half the circle's width at `dy` from the centre, minus a hairline margin.
    function chordHalf(dy) {
        var r = glassR - s1;
        var d = r * r - dy * dy;
        return d <= 0 ? 0 : Math.sqrt(d);
    }
    // Widest a row centred at `dy` may be. The inscribed square already fits;
    // this is the safety net that also tapers content closer to the rim.
    function rowWidth(dy) {
        return Math.min(safeSide, chordHalf(dy) * 2 * 0.97);
    }

    // ── orb ──────────────────────────────────────────────────────────────────
    property bool animated: true
    property real time: 0
    property bool hovered: panelArea.containsMouse
    property string orbStatus: "disconnected"
    property bool orbAvailable: true
    property string orbReason: ""
    property color orbTint: "#0a0806"
    property color orbAccent: "#F5B82E"
    property int batteryLevel: -1
    property string batteryState: ""

    // ── palette ──────────────────────────────────────────────────────────────
    // semantic tone: gold is neutral, green good, amber warning, red critical.
    // The tone colours are the panel's *data* language (a bad wallet, a charging
    // cell); the gem's colour is the panel's identity, and it wins.
    property string tone: "neutral"
    // An orb may have an identity colour of its own (the file organizer is
    // amber); setting `accent` overrides the tone without changing the rest of
    // the palette, and leaves the semantic tones intact for every other panel.
    property string accent: ""
    readonly property color cAccent: accent.length > 0 ? c(accent)
        : tone === "good" ? "#55f49a"
        : tone === "warn" ? "#ffd36a"
        : tone === "bad" ? "#ff7777"
        : "#F5B82E"
    readonly property color cPaint: orbTint
    readonly property color cText: mix(cAccent, "#ffffff", 0.94)
    readonly property color cSoft: mix(cAccent, "#ffffff", 0.80)
    readonly property color cMuted: withAlpha(mix(cAccent, "#ffffff", 0.58), 0.94)
    readonly property color cFaint: withAlpha(mix(cAccent, "#ffffff", 0.44), 0.90)
    readonly property color cSurface: withAlpha(mix(cPaint, "#060b12", 0.66), 0.63)
    readonly property color cSurfaceHot: withAlpha(mix(mix(cPaint, cAccent, 0.22), "#04070c", 0.60), 0.72)
    readonly property color cLine: withAlpha(cAccent, 0.22)
    readonly property color cLineHot: withAlpha(cAccent, 0.60)
    readonly property color cTrack: withAlpha(mix(cPaint, "#000000", 0.72), 0.66)
    // the frosted slab's own colour, so the fade edges above/below the content
    // dissolve into it instead of drawing a band of a slightly different tint
    readonly property color cSlab: withAlpha(mix(cPaint, "#05090f", 0.66), 0.62)
    // what a row dissolves into at the top and bottom of a scrolling body: the
    // slab colour, taken down to near-black, so a partially scrolled row reads as
    // "there is more below" instead of "the text was cut off"
    readonly property color cFade: withAlpha(mix(cPaint, "#04070a", 0.90), 0.95)

    function c(v) { return toColor(v); }
    function toColor(v) {
        if (typeof v === "string") {
            var h = v.charAt(0) === "#" ? v.substring(1) : v;
            if (h.length === 6)
                return Qt.rgba(parseInt(h.substring(0, 2), 16) / 255, parseInt(h.substring(2, 4), 16) / 255,
                               parseInt(h.substring(4, 6), 16) / 255, 1);
            if (h.length === 8)
                return Qt.rgba(parseInt(h.substring(2, 4), 16) / 255, parseInt(h.substring(4, 6), 16) / 255,
                               parseInt(h.substring(6, 8), 16) / 255, parseInt(h.substring(0, 2), 16) / 255);
        }
        return v;
    }
    function mix(a, b, t) {
        a = toColor(a); b = toColor(b);
        return Qt.rgba(a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t, a.a + (b.a - a.a) * t);
    }
    function withAlpha(col, alpha) { col = toColor(col); return Qt.rgba(col.r, col.g, col.b, alpha); }

    // Tabular figures where the runtime has them (Qt ≥ 6.7). On older builds the
    // property simply does not exist on the font value type, so the guard keeps
    // the panel working instead of breaking the component.
    function tabular(target) {
        if (!target) return;
        try { if (target.font.features !== undefined) target.font.features = { "tnum": 1 }; } catch (e) { }
    }

    // ── header ───────────────────────────────────────────────────────────────
    property string icon: "dot"                 // wifi | bluetooth | battery | system | slot | app
    property string title: ""
    property string state: ""                   // right-aligned, before the close button
    property bool pulse: false                  // breathe the status dot
    property bool showClose: true
    // ── subtitle ─────────────────────────────────────────────────────────────
    property string status: ""
    property bool statusWarn: false

    // ── body ─────────────────────────────────────────────────────────────────
    // "list"   rows from `items` (cards), with the empty state when there are none
    // "value"  a ring + big value + stats + bars + segments + tags
    // "empty"  just the empty state (the placeholder panel of an unassigned orb)
    // "custom" whatever the panel puts in the default property — content only
    property string mode: "list"
    property var items: []
    property var actions: []
    property string emptyIcon: "dot"
    property string emptyText: ""
    property string emptyHint: ""

    // value mode
    property string value: ""
    property string valueSub: ""
    property real ring: -1
    property real ringSecondary: -1
    property string ringCaption: ""
    property var stats: []                      // [{label, value}] → 2×2 cards
    property var segments: []                   // [{label, active}] → segmented control
    property var bars: []                       // [{label, detail, value, progress, tone}]
    property var tags: []                       // small pills, e.g. top processes

    // prompt (used by Wi-Fi; any future panel that needs a secret gets it free)
    property bool promptVisible: false
    property string promptLabel: ""
    property string promptPlaceholder: ""
    // …and it is not Wi-Fi-only: a folder path is typed into the same field, so
    // the masking and the two button words are the panel's choice, not the frame's
    property bool promptMasked: true
    property string promptAcceptLabel: "Connect"
    property string promptCancelLabel: "Cancel"

    // indeterminate work (a scan, a move): a sweep line over the body. It is
    // purely decorative and never gates input — `visible` does not change.
    property bool busy: false
    property alias promptText: promptInput.text
    function focusPrompt() { promptInput.forceActiveFocus(); }
    function clearPrompt() { promptInput.text = ""; }

    // The pointer entered/left the frame's own surface. A frame cannot know its
    // host, so it reports; the host counts it as one more hover area, which is
    // what keeps a panel open while the pointer is reading its rows — including
    // over a row's own MouseArea, because a HoverHandler on the frame sees every
    // pointer move inside it, not just over empty background.
    signal hoverChanged(bool inside)
    // Declared inside the slab, not on the frame: a handler on the frame's own
    // 2·radius square would reach the gems' orbit with its corners and, being
    // above them, take their hover away the moment a panel opened. The slab is
    // the circle the panel actually is, so the keep-alive area is the circle too.
    // (Moved with the surface, below — `frameHover` is a child of `slab`.)

    // ── signals ──────────────────────────────────────────────────────────────
    signal close()
    signal action(string name, var payload)
    signal rowActivated(var item)
    signal promptAccepted(string text)
    signal promptCancelled()

    property int openMs: 170
    property bool visionOsDome: true
    property real cascade: 1.4
    readonly property string pillSentence: status.length > 0 ? status : (visionOsDome ? state : "")
    function stageAlpha(step) {
        if (!visionOsDome) return 1;
        var v = (cascade - step * 0.22) / 0.30;
        return Math.max(0, Math.min(1, v));
    }
    function stageSlide(step) {
        if (!visionOsDome) return 0;
        return (1 - stageAlpha(step)) * (-s2 * 1.15);
    }

    // ── hosted mode: the frame is *content inside* the main orb ──────────────
    // The widget keeps ONE disc alive and draws every panel inside it, so a panel
    // switch never touches the circle around it. In that mode the frame draws no
    // sphere of its own and runs no open animation (the host crossfades opacity).
    // Everything else — the surface, its rim, the header, the gold rule, the
    // status pill, the clipped body with its fades, the action row — is the frame
    // every panel shares, which is what keeps them identical.
    property bool hosted: false
    // Only the panel that is actually showing may take clicks; a frame that is
    // mid-crossfade is still visible but already inert, so a click can never land
    // in the outgoing panel by accident.
    readonly property bool interactive: !hosted || active
    // The host's one source of truth, read: is this the panel the orb is showing?
    property bool active: true
    // Panel → panel crossfade. The frame stays mounted for exactly this long after
    // it stops being active, which is what makes the switch a crossfade instead of
    // a blank frame between two panels.
    property int switchMs: 140
    property bool keepAlive: false
    visible: !hosted || active || keepAlive
    onActiveChanged: {
        if (!hosted) return;
        if (active) { keepTimer.stop(); keepAlive = false; }
        else { keepAlive = true; keepTimer.restart(); }
    }
    Timer {
        id: keepTimer
        objectName: frame.key + "KeepAlive"
        interval: frame.switchMs + 20
        repeat: false
        onTriggered: if (!frame.active) frame.keepAlive = false
    }
    // Hosted: the host fades the frames, so this is a binding (a Behavior animates
    // it). Standalone: this stays 0 and the opening animation writes `opacity`.
    opacity: hosted ? (active ? 1 : 0) : 0
    Behavior on opacity { enabled: frame.hosted; NumberAnimation { duration: frame.switchMs; easing.type: Easing.OutCubic } }
    // Never clear the orb from under the pointer while one of these is up: a
    // prompt (a password, a folder path), a focused field, or a hold-to-confirm
    // button that is being pressed right now.
    property bool holdActive: false
    property int pressedActions: 0
    readonly property bool promptFocused: promptVisible && promptInput.activeFocus
    readonly property bool modalOpen: promptVisible || holdActive || pressedActions > 0

    width: radius * 2
    height: width
    scale: 1
    transformOrigin: Item.Center

    // A panel that is not the active one must not react to anything.
    enabled: !hosted || interactive

    // The panel is a surface: it absorbs its own clicks. It sits *under* the
    // content, so it never steals a row or a button, and it is inert unless this
    // panel is the one showing. Its box is the square inscribed in the content
    // circle — never the whole 2·radius item, whose corners would reach into the
    // gems' orbit and take their hover for themselves.
    MouseArea {
        id: panelArea
        objectName: frame.key + "PanelArea"
        width: frame.glassR * Math.SQRT2 * 0.98
        height: width
        anchors.centerIn: parent
        hoverEnabled: true
        enabled: frame.interactive
        onClicked: { }
    }

    // ── the surface ──────────────────────────────────────────────────────────
    // ONE circle: near-black, thin gold rim, a concentric inner hairline. No
    // glass, no second sphere, no blur — the disc behind it already carries the
    // depth, and this is the sheet the words are printed on.
    Rectangle {
        id: slab
        objectName: frame.key + "PanelScrim"
        anchors.centerIn: parent
        width: frame.glassR * 2
        height: width
        radius: width / 2
        z: 2
        opacity: frame.visionOsDome ? 0.01 : 1
        antialiasing: true
        color: "#f2070605"
        border.width: frame.rimWidth
        border.color: frame.withAlpha("#F5B82E", 0.55)

        HoverHandler {
            id: frameHover
            objectName: frame.key + "FrameHover"
            enabled: frame.interactive
            onHoveredChanged: frame.hoverChanged(frameHover.hovered)
        }
        Image {
            objectName: frame.key + "PanelLiquidSheen"
            anchors.fill: parent
            source: Qt.resolvedUrl("assets/liquid-lens.svg")
            fillMode: Image.PreserveAspectFit
            smooth: true
            opacity: 0.28
        }
        // gem-coloured rim light: the stone that opened the panel colours its edge
        Rectangle {
            anchors.fill: parent
            anchors.margins: -frame.rimWidth * 0.5
            radius: width / 2
            color: "transparent"
            border.width: Math.max(1, frame.rimWidth * 2.4)
            border.color: frame.withAlpha(frame.cAccent, 0.10)
        }
        // the concentric inner hairline: the even gap that reads as inlay
        Rectangle {
            anchors.fill: parent
            anchors.margins: frame.s1 * 1.2
            radius: width / 2
            color: "transparent"
            border.width: Math.max(0.8, frame.rimWidth * 0.5)
            border.color: frame.withAlpha("#F5B82E", 0.20)
        }
        // the panel's own light: a faint gem-coloured glow inside the rim
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: "transparent"
            gradient: Gradient {
                GradientStop { position: 0.00; color: "#00000000" }
                GradientStop { position: 0.72; color: "#00000000" }
                GradientStop { position: 0.94; color: frame.withAlpha(frame.cAccent, 0.09) }
                GradientStop { position: 1.00; color: "#00000000" }
            }
        }
    }
    // ── the safe area ────────────────────────────────────────────────────────
    // The inscribed square, clipped. Everything the user reads lives in here.
    Item {
        id: body
        objectName: frame.key + "PanelBody"
        anchors.centerIn: parent
        width: frame.safeSide
        height: frame.safeSide
        clip: true
        z: 4

        ColumnLayout {
            anchors.fill: parent
            spacing: frame.u * 7

            // ── header: icon + title ………………………… state + close ────────────
            // ── header: icon + title ………………………… state + close ────────────
            // Anchored, not stretched: the close disc owns the right edge, the
            // state sits against it, and the title elides into whatever is left.
            // (A layout that has to distribute space between three texts and a
            // disc will, on a small orb, squeeze the title and push the disc out
            // of the safe area — anchors make each one's box explicit.)
            Item {
                id: headerRow
                objectName: frame.key + "Header"
                Layout.fillWidth: true
                Layout.preferredHeight: frame.compact ? Math.max(frame.s4 * 0.95, frame.fsTitle * 1.5) : frame.s4 * 2.25
                Layout.maximumHeight: Layout.preferredHeight
                Layout.minimumHeight: Layout.preferredHeight
                opacity: frame.stageAlpha(0)
                transform: Translate { y: frame.stageSlide(0) }

                PanelGlyph {
                    objectName: frame.key + "HeaderGlyph"
                    // at the smallest orb the icon is the first thing to go: the
                    // title and the state are the words that carry information
                    visible: !frame.compact
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.top: parent.top
                    width: frame.s4 * 1.08
                    height: frame.s4 * 1.08
                    kind: frame.icon
                    tint: "#ffffff"
                    pulse: frame.pulse
                }
                // close disc: inside the safe area, on the header baseline
                Item {
                    id: closeDisc
                    objectName: frame.key + "CloseArea"
                    visible: frame.showClose
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    width: frame.s3
                    height: frame.s3
                    Rectangle {
                        anchors.centerIn: parent
                        width: frame.s3 * 1.35
                        height: width
                        radius: width / 2
                        color: closeArea.containsMouse ? frame.withAlpha(frame.cAccent, 0.32) : frame.withAlpha("#434b5c", 0.62)
                        border.width: 1
                        border.color: closeArea.containsMouse ? frame.cLineHot : frame.withAlpha("#ffffff", 0.18)
                        Text {
                            anchors.centerIn: parent
                            text: "×"
                            font.family: frame.typeFamily
                            font.pixelSize: frame.s3 * 0.86
                            color: "#e4ecf7"
                        }
                    }
                    MouseArea {
                        id: closeArea
                        objectName: frame.key + "Close"
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: frame.close()
                    }
                }
                // The title and the state share one line, and the title wins:
                // the state line only appears when the title still fits beside
                // it. That is measured here rather than guessed from a size
                // class, so a long title can never be squeezed into an ellipsis
                // by a short state — which is what "FILE ORGANIZ…" was.
                TextMetrics {
                    id: titleMetrics
                    font.family: frame.typeFamily
                    font.pixelSize: frame.fsTitle * 1.18
                    font.weight: Font.DemiBold
                    font.letterSpacing: frame.compact ? 0 : frame.u * 1.6
                    text: frame.title
                }
                TextMetrics {
                    id: stateMetrics
                    font.family: frame.typeFamily
                    font.pixelSize: frame.fsCaption * 0.94
                    text: frame.state
                }
                readonly property real headerGlyphRoom: frame.compact ? 0 : frame.s3 + frame.s2
                readonly property real headerStateRoom: stateMetrics.advanceWidth + frame.s1 * 2
                readonly property real headerCloseRoom: frame.showClose ? frame.s3 + frame.s1 : 0
                readonly property bool stateHasRoom: !frame.visionOsDome && !frame.compact && frame.state.length > 0
                    && (titleMetrics.advanceWidth + headerGlyphRoom + headerStateRoom + headerCloseRoom
                        <= frame.safeSide)
                Text {
                    id: stateText
                    objectName: frame.n("state", "State")
                    // the compact header shows the title only; the status pill
                    // carries the sentence there
                    visible: headerRow.stateHasRoom && text.length > 0
                    anchors.right: frame.showClose ? closeDisc.left : parent.right
                    anchors.rightMargin: frame.s1
                    anchors.verticalCenter: parent.verticalCenter
                    width: Math.min(implicitWidth, frame.safeSide * 0.46)
                    text: frame.state
                    font.family: frame.typeFamily
                    font.pixelSize: frame.fsCaption * 0.94
                    color: frame.cMuted
                    elide: Text.ElideRight
                    horizontalAlignment: Text.AlignRight
                    verticalAlignment: Text.AlignVCenter
                    style: Text.Outline
                    styleColor: frame.withAlpha(frame.mix(frame.cPaint, "#000000", 0.86), 0.85)
                    Component.onCompleted: frame.tabular(stateText)
                }
                Text {
                    objectName: frame.key + "Title"
                    anchors.left: parent.left
                    anchors.leftMargin: closeDisc.visible ? frame.s3 + frame.s1 : 0
                    anchors.right: stateText.visible ? stateText.left : (closeDisc.visible ? closeDisc.left : parent.right)
                    anchors.rightMargin: frame.s1
                    anchors.bottom: parent.bottom
                    text: frame.title
                    font.family: frame.typeFamily
                    font.pixelSize: frame.fsTitle * (frame.compact ? 1.0 : 1.18)
                    font.weight: Font.DemiBold
                    font.letterSpacing: frame.compact ? 0 : frame.u * 1.6
                    color: "#ffffff"
                    elide: Text.ElideRight
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    style: Text.Outline
                    styleColor: frame.withAlpha("#050810", 0.72)
                }
            }

            // ── hairline rule ────────────────────────────────────────────────
            Rectangle {
                objectName: frame.key + "Rule"
                Layout.fillWidth: true
                Layout.preferredHeight: 1
                Layout.maximumHeight: 1
                opacity: frame.visionOsDome ? 0.16 * frame.stageAlpha(0.5) : 1
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: "#00000000" }
                    GradientStop { position: 0.5; color: frame.withAlpha(frame.cAccent, 0.26) }
                    GradientStop { position: 1; color: "#00000000" }
                }
            }

            // ── status pill (glowing emerald-mint stadium pill) ──────────────
            Item {
                objectName: frame.key + "StatusRow"
                Layout.fillWidth: true
                Layout.preferredHeight: (frame.pillSentence.length > 0 && frame.hasStatusRoom) ? Math.max(frame.s3 * 1.15, frame.fsLabel * 1.85) : 0
                Layout.maximumHeight: Layout.preferredHeight
                visible: frame.pillSentence.length > 0 && frame.hasStatusRoom
                opacity: frame.stageAlpha(1.0)
                transform: Translate { y: frame.stageSlide(1.0) }

                Rectangle {
                    readonly property color pillTone: frame.statusWarn ? "#ff7777" : frame.cAccent
                    anchors.centerIn: parent
                    width: Math.min(parent.width, statusLabel.implicitWidth + frame.s2 * 2.1)
                    height: parent.height
                    radius: height / 2
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0.0; color: frame.statusWarn ? frame.mix(parent.pillTone, "#d94f56", 0.5) : "#29e8be" }
                        GradientStop { position: 1.0; color: frame.statusWarn ? "#992b36" : "#159b86" }
                    }
                    border.width: 1
                    border.color: frame.withAlpha(frame.statusWarn ? pillTone : "#8affea", 0.62)
                    Text {
                        id: statusLabel
                        objectName: frame.key + "Status"
                        anchors.centerIn: parent
                        width: Math.min(parent.width - frame.s2, implicitWidth)
                        text: frame.pillSentence
                        elide: Text.ElideRight
                        font.family: frame.typeFamily
                        font.pixelSize: frame.fsCaption * 1.04
                        font.weight: Font.DemiBold
                        color: "#ffffff"
                        horizontalAlignment: Text.AlignHCenter
                    }
                }
            }

            // ── body area: clipped, scrollable, fade-edged ───────────────────
            Item {
                id: bodyArea
                objectName: frame.key + "Body"
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumHeight: 0
                clip: true

                // list of cards
                ListView {
                    id: list
                    objectName: frame.n("list", "List")
                    anchors.fill: parent
                    visible: frame.mode === "list" && !frame.promptVisible
                    clip: true
                    // a dense list (one line per row) also breathes less between
                    // rows: that is how ten categories fit where four used to
                    spacing: (frame.items && frame.items.length > 0 && frame.items[0].dense) ? frame.u * 5 : frame.s2
                    topMargin: frame.s1 * 1.5
                    bottomMargin: frame.s4
                    model: frame.items || []
                    boundsBehavior: Flickable.StopAtBounds
                    ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }
                    delegate: Rectangle {
                        id: row
                        required property var modelData
                        required property int index
                        // rows taper with the circle's chord at their own height
                        width: frame.rowWidth(row.y + row.height / 2 - bodyArea.height / 2)
                        x: (list.width - width) / 2
                        radius: frame.s2
                        color: "transparent"
                        border.width: frame.u * 0
                        readonly property bool rowActive: !!(modelData && modelData.inUse)
                        readonly property real rowStage: 1.7 + Math.min(row.index, 4) * 0.55
                        opacity: frame.stageAlpha(rowStage)
                        transform: Translate { y: frame.stageSlide(rowStage) }
                        property real hot: 0
                        Behavior on hot { NumberAnimation { duration: 140; easing.type: Easing.OutQuad } }
                        // Stadium glass capsule inside the tapered row box
                        Rectangle {
                            anchors.fill: parent
                            radius: height / 2
                            gradient: Gradient {
                                orientation: row.rowActive ? Gradient.Horizontal : Gradient.Vertical
                                GradientStop {
                                    position: 0.0
                                    color: row.rowActive ? frame.withAlpha("#3c8393", 0.92)
                                           : frame.withAlpha(row.hot > 0 ? "#485468" : "#3a4454", 0.68)
                                }
                                GradientStop {
                                    position: 0.52
                                    color: row.rowActive ? frame.withAlpha("#44b7c2", 0.94)
                                           : frame.withAlpha(row.hot > 0 ? "#384152" : "#303746", 0.72)
                                }
                                GradientStop {
                                    position: 1.0
                                    color: row.rowActive ? frame.withAlpha("#4fe0e8", 0.96)
                                           : frame.withAlpha(row.hot > 0 ? "#303644" : "#282d38", 0.76)
                                }
                            }
                            border.width: row.rowActive ? Math.max(1, frame.u * 2.2) : 1
                            border.color: row.rowActive ? frame.withAlpha(frame.cAccent, 0.92)
                                          : (row.hot > 0 ? frame.withAlpha("#ffffff", 0.24) : frame.withAlpha("#ffffff", 0.12))
                        }
                        // a row may carry a 0…1 value (a category's share of the
                        // files); the bar is drawn under the text, never over it
                        readonly property bool hasBar: modelData !== undefined && modelData !== null
                                                      && typeof modelData.progress === "number"
                                                      && modelData.progress >= 0
                        // `dense` rows are one line of text plus their bar: a list
                        // of ten categories has to show more than two of them.
                        readonly property bool dense: !!(modelData && modelData.dense)
                        readonly property bool showSubtitle: !!(modelData && modelData.subtitle)
                                                           && !dense && textRoom.height > 0
                        height: dense
                                ? Math.max(frame.s3 * 1.15, frame.fsLabel * 1.9) + (hasBar ? frame.s1 * 1.4 : 0)
                                : (hasBar ? Math.max(frame.s3 * 1.75, frame.fsLabel * 2.6) : Math.max(frame.s3 * 1.9, frame.fsLabel * 3.0))
                                  + (hasBar ? frame.s1 * 1.5 : 0)

                        // rail: hidden on visionOS stadium pill (border + turquoise fill own active state)
                        Rectangle {
                            visible: !frame.visionOsDome && !!(row.modelData && row.modelData.inUse)
                            width: frame.u * 2
                            radius: width / 2
                            color: frame.toneColor(row.modelData && row.modelData.tone ? row.modelData.tone : "neutral")
                            anchors { left: parent.left; top: parent.top; bottom: parent.bottom
                                      leftMargin: frame.u * 2.4; topMargin: frame.s2 * 0.7; bottomMargin: frame.s2 * 0.7 }
                        }
                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: frame.s2 * 1.35
                            anchors.rightMargin: frame.s2 * 1.25
                            spacing: frame.s2
                            PanelGlyph {
                                Layout.preferredWidth: frame.s3 * 0.86
                                Layout.preferredHeight: frame.s3 * 0.86
                                Layout.alignment: Qt.AlignVCenter
                                kind: (row.modelData && row.modelData.glyph) ? row.modelData.glyph : "dot"
                                tint: row.rowActive ? "#ffffff" : frame.withAlpha("#ffffff", 0.88)
                                progress: (row.modelData && row.modelData.progress !== undefined) ? row.modelData.progress : -1
                            }
                            ColumnLayout {
                                id: textRoom
                                Layout.fillWidth: true
                                spacing: 0
                                Text {
                                    text: row.modelData ? row.modelData.title : ""
                                    Layout.fillWidth: true
                                    elide: Text.ElideRight
                                    font.family: frame.typeFamily
                                    font.pixelSize: frame.fsLabel
                                    font.weight: row.rowActive ? Font.DemiBold : Font.Medium
                                    color: row.rowActive ? "#ffffff" : "#eef5fc"
                                    style: Text.Outline
                                    styleColor: row.rowActive ? frame.withAlpha("#174e58", 0.45) : frame.withAlpha("#050810", 0.72)
                                }
                                Text {
                                    visible: row.showSubtitle && text.length > 0
                                    text: row.modelData && row.modelData.subtitle ? row.modelData.subtitle : ""
                                    Layout.fillWidth: true
                                    elide: Text.ElideRight
                                    font.family: frame.typeFamily
                                    font.pixelSize: frame.fsCaption
                                    color: row.rowActive ? "#e6fcff" : "#b8c7da"
                                }
                            }
                            // signal bars (0…4) — the compact stand-in for a value
                            Row {
                                visible: row.modelData && row.modelData.level !== undefined && row.modelData.level >= 0
                                spacing: frame.u
                                Layout.alignment: Qt.AlignVCenter
                                Repeater {
                                    model: 4
                                    delegate: Rectangle {
                                        required property int index
                                        width: frame.u * 1.9
                                        height: frame.s2 * (0.55 + index * 0.28)
                                        radius: width / 2
                                        anchors.bottom: parent.bottom
                                        color: index < Math.max(1, Math.round(((row.modelData && row.modelData.level) || 0)))
                                               ? (row.rowActive ? "#ffffff" : frame.withAlpha("#d5e2f0", 0.90))
                                               : frame.withAlpha("#ffffff", 0.24)
                                    }
                                }
                            }
                            PanelGlyph {
                                visible: !!(row.modelData && row.modelData.badge)
                                Layout.preferredWidth: frame.s3 * 0.62
                                Layout.preferredHeight: frame.s3 * 0.62
                                Layout.alignment: Qt.AlignVCenter
                                kind: (row.modelData && row.modelData.badge) ? row.modelData.badge : "dot"
                                tint: row.rowActive ? "#ffffff" : frame.withAlpha("#d5e2f0", 0.80)
                            }
                            Text {
                                visible: !!(row.modelData && row.modelData.tail)
                                text: row.modelData && row.modelData.tail ? row.modelData.tail : ""
                                font.family: frame.typeFamily
                                font.pixelSize: frame.fsCaption
                                font.weight: Font.DemiBold
                                color: row.rowActive ? "#ffffff" : "#d5e2f0"
                                Layout.maximumWidth: frame.safeSide * 0.28
                                elide: Text.ElideRight
                            }
                        }
                        // the value bar: track + fill, tone-coloured, under the text
                        Rectangle {
                            visible: row.hasBar
                            anchors { left: parent.left; right: parent.right; bottom: parent.bottom
                                      leftMargin: frame.s2 * 1.5; rightMargin: frame.s2 * 1.5
                                      bottomMargin: frame.s1 * 0.55 }
                            height: Math.max(1, frame.u * 1.6)
                            radius: height / 2
                            color: frame.withAlpha("#ffffff", 0.16)
                            Rectangle {
                                width: parent.width * Math.max(0.02, Math.min(1, row.modelData.progress || 0))
                                height: parent.height
                                radius: height / 2
                                color: row.rowActive ? "#ffffff" : "#4fe0e8"
                            }
                        }
                        MouseArea {
                            id: rowArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: frame.rowActivated(row.modelData)
                            onEntered: row.hot = 1
                            onExited: row.hot = 0
                        }
                    }
                }

                // value dashboard: ring, big number, cards, bars, segments, tags
                Flickable {
                    id: valueFlick
                    objectName: frame.key + "Value"
                    anchors.fill: parent
                    visible: frame.mode === "value"
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    contentWidth: width
                    contentHeight: valueColumn.implicitHeight
                    interactive: contentHeight > height
                    ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }

                    ColumnLayout {
                        id: valueColumn
                        width: valueFlick.width
                        spacing: frame.u * 6

                        // ── ring + value ─────────────────────────────────────
                        Item {
                            visible: frame.ring >= 0
                            Layout.fillWidth: true
                            opacity: frame.stageAlpha(1.8)
                            transform: Translate { y: frame.stageSlide(1.8) }
                            Layout.preferredHeight: Math.min(frame.safeSide * 0.38,
                                Math.max(frame.s3 * 2.7, bodyArea.height * 0.42))

                            Canvas {
                                id: ringCanvas
                                objectName: frame.n("ring", "Ring")
                                width: Math.min(parent.width, parent.height) * 0.96
                                height: width
                                anchors.centerIn: parent
                                renderTarget: Canvas.FramebufferObject
                                renderStrategy: Canvas.Cooperative
                                property real shownRing: Math.max(0, Math.min(1, frame.ring))
                                property real shownSecondary: Math.max(-1, Math.min(1, frame.ringSecondary))
                                property real shownPhase: frame.value
                                onShownRingChanged: requestPaint()
                                onShownSecondaryChanged: requestPaint()
                                Component.onCompleted: requestPaint()
                                onPaint: {
                                    var ctx = getContext("2d"), w = width, h = height, cx = w / 2, cy = h / 2;
                                    var lw = Math.max(1.5, w * 0.078);
                                    ctx.clearRect(0, 0, w, h);
                                    ctx.lineCap = "round";
                                    ctx.beginPath(); ctx.arc(cx, cy, w / 2 - lw, 0, Math.PI * 2);
                                    ctx.lineWidth = lw; ctx.strokeStyle = frame.withAlpha("#303b4d", 0.80); ctx.stroke();
                                    if (shownSecondary >= 0) {
                                        var r0 = w / 2 - lw * 2.05;
                                        ctx.beginPath(); ctx.arc(cx, cy, r0, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * shownSecondary);
                                        ctx.lineWidth = Math.max(1.1, lw * 0.44);
                                        ctx.strokeStyle = frame.withAlpha(frame.cAccent, 0.85);
                                        ctx.stroke();
                                    }
                                    if (shownRing > 0) {
                                        var grad = ctx.createLinearGradient(0, 0, w, h);
                                        grad.addColorStop(0.0, "#4fe0e8");
                                        grad.addColorStop(1.0, frame.cAccent.toString());
                                        ctx.beginPath(); ctx.arc(cx, cy, w / 2 - lw, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * shownRing);
                                        ctx.lineWidth = lw;
                                        ctx.strokeStyle = grad;
                                        ctx.shadowColor = frame.withAlpha("#4fe0e8", 0.55);
                                        ctx.shadowBlur = w * 0.14;
                                        ctx.stroke();
                                        ctx.shadowBlur = 0;
                                    }
                                }
                            }
                            // the number, and the "used / total" that belongs beside
                            // it, both inside the ring so nothing has to stack below
                            ColumnLayout {
                                anchors.centerIn: parent
                                width: ringCanvas.width * 0.74
                                spacing: 0
                                Text {
                                    id: valueText
                                    objectName: frame.n("value", "ValueText")
                                    Layout.fillWidth: true
                                    horizontalAlignment: Text.AlignHCenter
                                    text: frame.value
                                    font.family: frame.typeFamily
                                    font.pixelSize: Math.max(frame.fsCaption * 1.45,
                                        Math.min(frame.fsValue, ringCanvas.height * 0.40))
                                    font.weight: Font.Light
                                    color: frame.cText
                                    style: Text.Outline
                                    styleColor: frame.withAlpha(frame.mix(frame.cPaint, "#000000", 0.88), 0.9)
                                    Component.onCompleted: frame.tabular(valueText)
                                }
                                Text {
                                    objectName: frame.n("valueSub", "ValueSub")
                                    // below ~40 px of ring the sub-line is a smear:
                                    // the value alone is the honest reading there
                                    visible: text.length > 0 && ringCanvas.height >= 40
                                    Layout.fillWidth: true
                                    horizontalAlignment: Text.AlignHCenter
                                    text: frame.valueSub
                                    elide: Text.ElideRight
                                    font.family: frame.typeFamily
                                    font.pixelSize: Math.min(frame.fsCaption * 0.86, ringCanvas.height * 0.17)
                                    color: frame.cMuted
                                    Component.onCompleted: frame.tabular(this)
                                }
                            }
                        }

                        // ── value caption (used / total) ─────────────────────
                        Text {
                            id: valueSubText
                            objectName: frame.n("valueSubLoose", "ValueSubLoose")
                            visible: text.length > 0 && frame.ring < 0
                            text: frame.valueSub
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                            font.family: frame.typeFamily
                            font.pixelSize: frame.fsLabel
                            font.weight: Font.Medium
                            color: frame.cText
                            style: Text.Outline
                            styleColor: frame.withAlpha(frame.mix(frame.cPaint, "#000000", 0.86), 0.85)
                            Component.onCompleted: frame.tabular(valueSubText)
                        }

                        // ── 2×2 stat cards (frosted smoked-glass stadium pills)
                        GridLayout {
                            objectName: frame.n("stats", "Stats")
                            visible: (frame.stats || []).length > 0
                            Layout.fillWidth: true
                            opacity: frame.stageAlpha(2.6)
                            transform: Translate { y: frame.stageSlide(2.6) }
                            columns: 2
                            columnSpacing: frame.s2
                            rowSpacing: frame.s2 * 0.75
                            Repeater {
                                model: frame.stats || []
                                delegate: Rectangle {
                                    required property var modelData
                                    Layout.fillWidth: true
                                    Layout.preferredHeight: Math.max(frame.s2 * 1.7, frame.fsLabel * 2.05)
                                    radius: height / 2
                                    gradient: Gradient {
                                        GradientStop { position: 0.0; color: frame.withAlpha("#3a4454", 0.68) }
                                        GradientStop { position: 1.0; color: frame.withAlpha("#282d38", 0.78) }
                                    }
                                    border.width: 1
                                    border.color: frame.withAlpha("#ffffff", 0.13)
                                    RowLayout {
                                        anchors.fill: parent
                                        anchors.leftMargin: frame.s2
                                        anchors.rightMargin: frame.s2
                                        spacing: frame.u * 2
                                        Text {
                                            text: modelData ? modelData.label : ""
                                            Layout.fillWidth: true
                                            elide: Text.ElideRight
                                            font.family: frame.typeFamily
                                            font.pixelSize: frame.fsCaption * 0.94
                                            color: "#c5d3e6"
                                            font.letterSpacing: frame.u * 0.4
                                        }
                                        Text {
                                            id: statValue
                                            text: modelData ? modelData.value : ""
                                            elide: Text.ElideRight
                                            Layout.maximumWidth: frame.safeSide * 0.4
                                            horizontalAlignment: Text.AlignRight
                                            font.family: frame.typeFamily
                                            font.pixelSize: frame.fsCaption * 1.12
                                            font.weight: Font.DemiBold
                                            color: "#ffffff"
                                            Component.onCompleted: frame.tabular(statValue)
                                        }
                                    }
                                }
                            }
                        }

                        // ── thin bars: swap, storage ─────────────────────────
                        ColumnLayout {
                            objectName: frame.n("bars", "Bars")
                            visible: (frame.bars || []).length > 0
                            Layout.fillWidth: true
                            opacity: frame.stageAlpha(2.5)
                            transform: Translate { y: frame.stageSlide(2.5) }
                            spacing: frame.s2 * 0.9
                            Repeater {
                                model: frame.bars || []
                                delegate: ColumnLayout {
                                    required property var modelData
                                    Layout.fillWidth: true
                                    spacing: frame.u * 1.2
                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: frame.s2
                                        Text {
                                            text: modelData ? modelData.label : ""
                                            Layout.fillWidth: true
                                            elide: Text.ElideRight
                                            font.family: frame.typeFamily
                                            font.pixelSize: frame.fsCaption
                                            font.weight: Font.Medium
                                            color: "#eef5fc"
                                        }
                                        Text {
                                            id: barDetail
                                            text: modelData && modelData.detail ? modelData.detail : ""
                                            Layout.maximumWidth: frame.safeSide * 0.56
                                            elide: Text.ElideRight
                                            horizontalAlignment: Text.AlignRight
                                            font.family: frame.typeFamily
                                            font.pixelSize: frame.fsCaption
                                            color: "#b8c7da"
                                            Component.onCompleted: frame.tabular(barDetail)
                                        }
                                        Text {
                                            id: barValue
                                            text: modelData && modelData.value ? modelData.value : ""
                                            Layout.maximumWidth: frame.safeSide * 0.22
                                            elide: Text.ElideRight
                                            horizontalAlignment: Text.AlignRight
                                            font.family: frame.typeFamily
                                            font.pixelSize: frame.fsCaption
                                            font.weight: Font.DemiBold
                                            color: "#ffffff"
                                            Component.onCompleted: frame.tabular(barValue)
                                        }
                                    }
                                    Rectangle {
                                        Layout.fillWidth: true
                                        Layout.preferredHeight: Math.max(1.6, frame.u * 2.1)
                                        radius: height / 2
                                        color: frame.withAlpha("#2b3342", 0.78)
                                        Rectangle {
                                            anchors.left: parent.left
                                            anchors.top: parent.top
                                            anchors.bottom: parent.bottom
                                            width: parent.width * Math.max(0, Math.min(1, modelData ? (modelData.progress || 0) : 0))
                                            radius: height / 2
                                            gradient: Gradient {
                                                orientation: Gradient.Horizontal
                                                GradientStop { position: 0.0; color: "#3c8393" }
                                                GradientStop { position: 1.0; color: "#4fe0e8" }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // ── segmented control (power profiles) ───────────────
                        Rectangle {
                            objectName: frame.n("segments", "Segments")
                            visible: (frame.segments || []).length > 0
                            Layout.fillWidth: true
                            opacity: frame.stageAlpha(3.4)
                            transform: Translate { y: frame.stageSlide(3.4) }
                            Layout.preferredHeight: Math.max(frame.s3 * 1.35, frame.fsCaption * 2.5)
                            radius: height / 2
                            color: frame.withAlpha("#282d38", 0.80)
                            border.width: 1
                            border.color: frame.withAlpha("#ffffff", 0.14)
                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: frame.u * 1.6
                                spacing: frame.u * 1.6
                                Repeater {
                                    model: frame.segments || []
                                    delegate: Rectangle {
                                        required property var modelData
                                        Layout.fillWidth: true
                                        Layout.fillHeight: true
                                        radius: height / 2
                                        color: modelData && modelData.active
                                               ? frame.withAlpha("#38b8c4", 0.82)
                                               : (segmentArea.containsMouse ? frame.withAlpha("#ffffff", 0.10) : "transparent")
                                        border.width: modelData && modelData.active ? 1 : 0
                                        border.color: frame.withAlpha(frame.cAccent, 0.85)
                                        Text {
                                            anchors.centerIn: parent
                                            width: parent.width - frame.u * 2
                                            text: modelData ? modelData.label : ""
                                            elide: Text.ElideRight
                                            horizontalAlignment: Text.AlignHCenter
                                            font.family: frame.typeFamily
                                            font.pixelSize: frame.fsCaption * (frame.compact ? 0.86 : 1.0)
                                            font.weight: modelData && modelData.active ? Font.DemiBold : Font.Medium
                                            color: modelData && modelData.active ? "#ffffff" : "#d5e2f0"
                                        }
                                        MouseArea {
                                            id: segmentArea
                                            anchors.fill: parent
                                            hoverEnabled: true
                                            cursorShape: Qt.PointingHandCursor
                                            onClicked: frame.action("segment", modelData ? modelData.label : "")
                                        }
                                    }
                                }
                            }
                        }

                        // ── compact chips: top processes ─────────────────────
                        Flow {
                            objectName: frame.n("tags", "Tags")
                            visible: (frame.tags || []).length > 0
                            Layout.fillWidth: true
                            opacity: frame.stageAlpha(3.2)
                            transform: Translate { y: frame.stageSlide(3.2) }
                            spacing: frame.u * 2.4
                            Repeater {
                                model: frame.tags || []
                                delegate: Rectangle {
                                    required property var modelData
                                    width: Math.min(frame.safeSide, tagText.implicitWidth + frame.s2 * 1.5)
                                    height: Math.max(frame.s3 * 0.96, frame.fsCaption * 2.0)
                                    radius: height / 2
                                    color: frame.withAlpha("#343c4b", 0.72)
                                    border.width: 1
                                    border.color: frame.withAlpha("#ffffff", 0.13)
                                    Text {
                                        id: tagText
                                        anchors.centerIn: parent
                                        width: Math.min(parent.width - frame.s1 * 2, implicitWidth)
                                        text: typeof modelData === "string" ? modelData : (modelData && modelData.label ? modelData.label : "")
                                        elide: Text.ElideRight
                                        font.family: frame.typeFamily
                                        font.pixelSize: frame.fsCaption * 0.96
                                        color: "#eef5fc"
                                    }
                                }
                            }
                        }
                    }
                }

                // custom content (the panel's own, inside the same clipped box)
                Item {
                    id: customHolder
                    objectName: frame.key + "Custom"
                    anchors.fill: parent
                    visible: frame.mode === "custom"
                }

                // ── empty state: one icon, one line, one hint ────────────────
                Item {
                    id: emptyState
                    objectName: frame.key + "Empty"
                    anchors.fill: parent
                    visible: !frame.promptVisible
                             && (frame.mode === "empty"
                                 || (frame.mode === "list" && (frame.items || []).length === 0))

                    ColumnLayout {
                        anchors.centerIn: parent
                        width: Math.min(parent.width, frame.safeSide * 0.92)
                        spacing: frame.s2
                        PanelGlyph {
                            Layout.alignment: Qt.AlignHCenter
                            Layout.preferredWidth: frame.s4 * 1.1
                            Layout.preferredHeight: frame.s4 * 1.1
                            kind: frame.emptyIcon
                            tint: frame.withAlpha(frame.cAccent, 0.55)
                        }
                        Text {
                            objectName: frame.n("empty", "EmptyState")
                            text: frame.emptyText
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.WordWrap
                            maximumLineCount: 4
                            elide: Text.ElideRight
                            lineHeight: 1.2
                            font.family: frame.typeFamily
                            font.pixelSize: frame.fsLabel
                            font.weight: Font.Medium
                            color: frame.cSoft
                        }
                        Text {
                            objectName: frame.n("hint", "EmptyHint")
                            visible: text.length > 0
                            text: frame.emptyHint
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.WordWrap
                            maximumLineCount: 3
                            elide: Text.ElideRight
                            lineHeight: 1.15
                            font.family: frame.typeFamily
                            font.pixelSize: frame.fsCaption
                            color: frame.cFaint
                        }
                    }
                }

                // ── prompt: a secret, asked once, never stored ───────────────
                ColumnLayout {
                    id: promptBox
                    objectName: frame.key + "Prompt"
                    anchors.centerIn: parent
                    visible: frame.promptVisible
                    width: parent.width
                    spacing: frame.s2
                    Text {
                        text: frame.promptLabel
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                        horizontalAlignment: Text.AlignHCenter
                        font.family: frame.typeFamily
                        font.pixelSize: frame.fsLabel
                        font.weight: Font.Medium
                        color: frame.cText
                    }
                    TextField {
                        id: promptInput
                        objectName: frame.key + "PasswordField"
                        Layout.fillWidth: true
                        Layout.preferredHeight: Math.max(frame.s3 * 1.3, frame.fsLabel * 2.2)
                        // the prompt exists only while a secret is needed: ready to type
                        focus: frame.promptVisible
                        echoMode: frame.promptMasked ? TextInput.Password : TextInput.Normal
                        selectByMouse: true
                        placeholderText: frame.promptPlaceholder
                        font.family: frame.typeFamily
                        font.pixelSize: frame.fsLabel
                        color: frame.cText
                        placeholderTextColor: frame.cFaint
                        selectionColor: frame.withAlpha(frame.cAccent, 0.35)
                        selectedTextColor: frame.cText
                        background: Rectangle {
                            radius: frame.s2 * 0.7
                            color: frame.withAlpha(frame.mix(frame.cPaint, "#05090f", 0.62), 0.72)
                            border.width: 1
                            border.color: promptInput.activeFocus ? frame.cLineHot : frame.cLine
                        }
                        onAccepted: frame.promptAccepted(text)
                    }
                }

                // ── busy sweep: "something is happening", without a spinner in
                // the middle of the content. It sits above the list, ignores the
                // pointer entirely, and disappears with `busy`.
                Item {
                    objectName: frame.key + "Sweep"
                    visible: frame.busy
                    anchors { left: parent.left; right: parent.right; top: parent.top }
                    height: Math.max(1, frame.u * 1.6)
                    clip: true
                    Rectangle {
                        width: parent.width * 0.34
                        height: parent.height
                        radius: height / 2
                        gradient: Gradient {
                            orientation: Gradient.Horizontal
                            GradientStop { position: 0.0; color: "#00000000" }
                            GradientStop { position: 0.5; color: frame.withAlpha(frame.cAccent, 0.85) }
                            GradientStop { position: 1.0; color: "#00000000" }
                        }
                        SequentialAnimation on x {
                            running: frame.busy
                            loops: Animation.Infinite
                            NumberAnimation { from: -parent.width * 0.4; to: parent.width; duration: 1100; easing.type: Easing.InOutSine }
                        }
                    }
                }

                // fade edges: content dissolves into the slab instead of being cut
                Rectangle {
                    objectName: frame.key + "FadeTop"
                    anchors { left: parent.left; right: parent.right; top: parent.top }
                    height: Math.max(frame.s3, bodyArea.height * 0.14)
                    // the fade says "there is more this way". When the content
                    // already ends in view it is not drawn at all, so nothing ever
                    // looks cut off when there is nothing below it.
                    visible: (list.visible && list.contentY > 1)
                             || (valueFlick.visible && valueFlick.contentY > 1)
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: frame.cFade }
                        GradientStop { position: 1.0; color: "#00000000" }
                    }
                }
                Rectangle {
                    objectName: frame.key + "FadeBottom"
                    anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
                    height: Math.max(frame.s3, bodyArea.height * 0.14)
                    visible: (list.visible && list.contentHeight > list.height + 1 && !list.atYEnd)
                             || (valueFlick.visible && valueFlick.contentHeight > valueFlick.height + 1
                                 && !valueFlick.atYEnd)
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: "#00000000" }
                        GradientStop { position: 1.0; color: frame.cFade }
                    }
                }
            }

            // ── action row: consistent pill buttons, centred ────────────────
            // Up to five actions. With four or five the frame wraps them into two
            // centred rows when the orb cannot give each label a real width, so
            // "ORGANIZE NOW" never becomes a 20 px sliver with three dots in it.
            // The buttons stay direct children of this item (explicit geometry),
            // which keeps them stable across data updates and easy to find.
            Item {
                id: actionBlock
                objectName: frame.key + "Actions"
                Layout.fillWidth: true
                Layout.preferredHeight: frame.actionBlockHeight
                Layout.maximumHeight: Layout.preferredHeight
                Layout.minimumHeight: Layout.preferredHeight
                visible: actionCount() > 0
                opacity: frame.stageAlpha(4.0)
                transform: Translate { y: frame.stageSlide(4.0) }

                Repeater {
                    model: 5
                    delegate: Rectangle {
                        id: actionBtn
                        required property int index
                        readonly property var modelData: frame.actionAt(index)
                        readonly property var geometry2: frame.actionSlot(index)
                        objectName: modelData && modelData.objectName ? modelData.objectName : (frame.key + "ActionSlot" + index)
                        visible: modelData !== null
                        property string label: modelData && modelData.label ? modelData.label : ""
                        property string labelShort: modelData && modelData.labelShort ? modelData.labelShort : ""
                        property string name: modelData && modelData.name ? modelData.name : ""
                        property bool active: !!(modelData && (modelData.active || modelData.primary))
                        property bool enabled: !(modelData && modelData.disabled)
                        TextMetrics {
                            id: actionMetrics
                            font.family: frame.typeFamily
                            font.pixelSize: frame.fsCaption
                            font.weight: actionBtn.active ? Font.DemiBold : Font.Normal
                            text: actionBtn.label
                        }
                        readonly property bool useShort: actionBtn.labelShort.length > 0
                            && actionMetrics.advanceWidth > Math.max(0, actionBtn.width - frame.s1 * 1.2)
                        x: geometry2.x
                        y: geometry2.y
                        width: geometry2.width
                        height: geometry2.height
                        radius: height / 2
                        opacity: enabled ? 1 : 0.42
                        gradient: Gradient {
                            GradientStop {
                                position: 0.0
                                color: actionBtn.active ? frame.withAlpha("#38b8c4", 0.85)
                                       : (actionArea.containsMouse && actionBtn.enabled ? frame.withAlpha("#575f72", 0.85) : frame.withAlpha("#484d5c", 0.78))
                            }
                            GradientStop {
                                position: 1.0
                                color: actionBtn.active ? frame.withAlpha("#266878", 0.90)
                                       : (actionArea.containsMouse && actionBtn.enabled ? frame.withAlpha("#353946", 0.90) : frame.withAlpha("#2b2e38", 0.86))
                            }
                        }
                        border.width: 1
                        border.color: actionBtn.active ? frame.withAlpha(frame.cAccent, 0.85)
                                             : (actionArea.containsMouse && enabled ? frame.withAlpha("#ffffff", 0.30) : frame.withAlpha("#ffffff", 0.16))
                        Text {
                            id: actionText
                            anchors.centerIn: parent
                            width: Math.min(parent.width - frame.s1 * 1.2, implicitWidth)
                            text: actionBtn.useShort ? actionBtn.labelShort : actionBtn.label
                            elide: Text.ElideRight
                            horizontalAlignment: Text.AlignHCenter
                            font.family: frame.typeFamily
                            font.pixelSize: frame.fsCaption * (frame.compact ? 0.94 : 1.0)
                            font.weight: Font.DemiBold
                            color: "#f3f7fc"
                        }
                        MouseArea {
                            id: actionArea
                            anchors.fill: parent
                            hoverEnabled: true
                            enabled: actionBtn.enabled
                            cursorShape: actionBtn.enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                            // A press is a hold: the frame reports it so the host
                            // cannot fade the panel out between press and release.
                            onPressed: frame.pressedActions = frame.pressedActions + 1
                            onReleased: frame.pressedActions = Math.max(0, frame.pressedActions - 1)
                            onCanceled: frame.pressedActions = Math.max(0, frame.pressedActions - 1)
                            onClicked: {
                                if (actionBtn.name === "promptAccept") frame.promptAccepted(promptInput.text);
                                else if (actionBtn.name === "promptCancel") frame.promptCancelled();
                                else frame.action(actionBtn.name, actionBtn.modelData);
                            }
                        }
                    }
                }
            }
        }
    }

    // how many buttons the action row really shows right now
    function actionCount() {
        if (promptVisible) return 2;
        return (actions || []).length;
    }
    // the i-th visible button, or null — a stable slot model keeps the buttons
    // alive while their labels follow the state
    function actionAt(i) {
        var list = promptVisible
                 ? [{ label: promptAcceptLabel, name: "promptAccept", primary: true },
                    { label: promptCancelLabel, name: "promptCancel" }]
                 : (actions || []);
        return i < list.length ? list[i] : null;
    }

    // ── action geometry ──────────────────────────────────────────────────────
    // One row for up to three buttons; four or five get two rows unless the orb
    // is wide enough (safe side ≥ 300 px) to give every label room in one.
    readonly property real actionPillHeight: Math.max(s3 * 1.28, fsCaption * 2.6)
    readonly property real actionGap: u * 4
    function actionRowCount() {
        var n = actionCount();
        if (n <= 3) return 1;
        // Four or five buttons only share one row when that row is wide enough
        // to spell the longest action out ("ORGANIZE NOW", ~ 3.3 × the safe side
        // ÷ 10). Below that they wrap 2 + 3, and every label stays whole.
        return safeSide >= 380 ? 1 : 2;
    }
    readonly property real actionBlockHeight: actionRowCount() * actionPillHeight
        + (actionRowCount() - 1) * actionGap
    // The primary action carries more of the row than the others, so a call to
    // action ("ORGANIZE NOW") keeps its words while the secondary buttons are
    // compact. Everything else is shared out evenly.
    function actionWeight(i) {
        var item = actionAt(i);
        return (item && (item.primary || item.active)) ? 1.9 : 1;
    }
    // How many buttons each row holds when they wrap. The short row comes
    // first, so the row that carries the primary action has two buttons in it
    // and the primary keeps a real, honest width — never a sliver next to two
    // secondaries. (Five actions at a small orb: PREVIEW + ORGANIZE NOW on top,
    // UNDO / AUTO / RULES beneath.)
    function actionRowSizes() {
        var n = actionCount(), rows = actionRowCount(), out = [];
        var base = Math.floor(n / rows), extra = n % rows;
        for (var r = 0; r < rows; r++) out.push(base + (r >= rows - extra ? 1 : 0));
        return out;
    }
    // x/y/width/height of the i-th button inside the action block
    function actionSlot(index) {
        var n = actionCount();
        var rows = actionRowCount();
        // a hidden slot gets no geometry — never a pixel literal in the tree
        if (index < 0 || index >= n || rows <= 0) return ({ x: -safeSide, y: -safeSide, width: u * 0, height: u * 0 });
        var sizes = actionRowSizes();
        var row = 0, first = 0, count = sizes.length > 0 ? sizes[0] : 0;
        while (row < sizes.length - 1 && index >= first + count) { first += count; row++; count = sizes[row]; }
        var column = index - first;
        var usable = safeSide * 0.98;
        var weights = 0, offset = 0, i;
        for (i = first; i < first + count; i++) weights += actionWeight(i);
        for (i = first; i < column + first; i++) offset += actionWeight(i);
        var free = usable - (count - 1) * actionGap;
        var unit = free / Math.max(1, weights);
        var width = unit * actionWeight(index);
        var rowWidth = free + (count - 1) * actionGap;
        return ({
            x: (safeSide - rowWidth) / 2 + offset * unit + column * actionGap,
            y: row * (actionPillHeight + actionGap),
            width: width,
            height: actionPillHeight
        });
    }
    function toneColor(name) {
        if (name === "good") return "#55f49a";
        if (name === "warn") return "#ffd36a";
        if (name === "bad") return "#ff7777";
        return cAccent;
    }

    // ── open transition: fade + scale, and it never delays a click ───────────
    // `visible` stays the widget's own switch, so hit testing is unchanged;
    // only the painted opacity/scale ease in over openMs.
    onVisibleChanged: {
        if (hosted) return;                 // the host owns opacity; no boot-in per switch
        if (visible) {
            openAnim.restart();
        } else {
            openAnim.stop();
            opacity = 0;
            scale = 1;
        }
    }
    ParallelAnimation {
        id: openAnim
        NumberAnimation { target: frame; property: "opacity"; from: 0; to: 1; duration: frame.openMs; easing.type: Easing.OutCubic }
        NumberAnimation { target: frame; property: "scale"; from: 0.94; to: 1; duration: frame.openMs; easing.type: Easing.OutCubic }
    }
    // ── glyphs: painted, never a font or an image ────────────────────────────
    // One small Canvas per glyph, cooperative, redrawn only when its colour or
    // kind changes. It is the only canvas inside a panel besides the ring.
    component PanelGlyph: Item {
        id: glyph
        property string kind: "dot"
        property color tint: frame.cAccent
        property real progress: -1          // -1 = unknown, else 0…1 (battery rows)
        property bool pulse: false
        onTintChanged: canvas.requestPaint()
        onKindChanged: canvas.requestPaint()
        onProgressChanged: canvas.requestPaint()
        SequentialAnimation on opacity {
            running: glyph.pulse
            loops: Animation.Infinite
            NumberAnimation { to: 0.45; duration: 760; easing.type: Easing.InOutQuad }
            NumberAnimation { to: 1.0; duration: 760; easing.type: Easing.InOutQuad }
        }
        Canvas {
            id: canvas
            anchors.fill: parent
            renderTarget: Canvas.FramebufferObject
            renderStrategy: Canvas.Cooperative
            onPaint: {
                var ctx = getContext("2d"), w = width, h = height;
                var k = glyph.kind, col = glyph.tint;
                ctx.clearRect(0, 0, w, h);
                ctx.strokeStyle = col; ctx.fillStyle = col;
                ctx.lineWidth = Math.max(1, w * 0.085);
                ctx.lineCap = "round"; ctx.lineJoin = "round";
                if (k === "wifi") {
                    // three waves + a dot: the classic, drawn small and clean
                    for (var i = 0; i < 3; i++) {
                        var r = w * (0.20 + i * 0.17);
                        ctx.beginPath(); ctx.arc(w * 0.5, h * 0.74, r, Math.PI * 1.22, Math.PI * 1.78); ctx.stroke();
                    }
                    ctx.beginPath(); ctx.arc(w * 0.5, h * 0.76, w * 0.055, 0, Math.PI * 2); ctx.fill();
                } else if (k === "bluetooth" || k === "other") {
                    ctx.beginPath();
                    ctx.moveTo(w * 0.36, h * 0.26); ctx.lineTo(w * 0.66, h * 0.40);
                    ctx.lineTo(w * 0.36, h * 0.72); ctx.lineTo(w * 0.36, h * 0.16);
                    ctx.lineTo(w * 0.66, h * 0.60); ctx.lineTo(w * 0.36, h * 0.74);
                    ctx.stroke();
                } else if (k === "audio") {
                    ctx.beginPath(); ctx.arc(w * 0.5, h * 0.52, w * 0.29, Math.PI, 0); ctx.stroke();
                    ctx.beginPath(); ctx.arc(w * 0.23, h * 0.56, w * 0.10, 0, Math.PI * 2); ctx.fill();
                    ctx.beginPath(); ctx.arc(w * 0.77, h * 0.56, w * 0.10, 0, Math.PI * 2); ctx.fill();
                } else if (k === "keyboard") {
                    ctx.strokeRect(w * 0.18, h * 0.34, w * 0.64, h * 0.34);
                    ctx.beginPath(); ctx.moveTo(w * 0.30, h * 0.58); ctx.lineTo(w * 0.70, h * 0.58); ctx.stroke();
                } else if (k === "mouse") {
                    ctx.beginPath(); ctx.ellipse(w * 0.5, h * 0.52, w * 0.22, h * 0.30, 0, 0, Math.PI * 2); ctx.stroke();
                    ctx.beginPath(); ctx.moveTo(w * 0.5, h * 0.26); ctx.lineTo(w * 0.5, h * 0.44); ctx.stroke();
                } else if (k === "phone") {
                    ctx.strokeRect(w * 0.33, h * 0.18, w * 0.34, h * 0.64);
                    ctx.beginPath(); ctx.moveTo(w * 0.44, h * 0.72); ctx.lineTo(w * 0.56, h * 0.72); ctx.stroke();
                } else if (k === "computer") {
                    ctx.strokeRect(w * 0.22, h * 0.26, w * 0.56, h * 0.38);
                    ctx.beginPath(); ctx.moveTo(w * 0.13, h * 0.74); ctx.lineTo(w * 0.87, h * 0.74); ctx.stroke();
                } else if (k === "watch") {
                    ctx.strokeRect(w * 0.30, h * 0.30, w * 0.40, h * 0.40);
                    ctx.beginPath(); ctx.moveTo(w * 0.42, h * 0.16); ctx.lineTo(w * 0.58, h * 0.16); ctx.stroke();
                    ctx.beginPath(); ctx.moveTo(w * 0.42, h * 0.84); ctx.lineTo(w * 0.58, h * 0.84); ctx.stroke();
                } else if (k === "battery") {
                    // cell + level, when the row knows it
                    ctx.strokeRect(w * 0.16, h * 0.32, w * 0.60, h * 0.36);
                    ctx.beginPath(); ctx.moveTo(w * 0.80, h * 0.42); ctx.lineTo(w * 0.88, h * 0.42);
                    ctx.lineTo(w * 0.88, h * 0.58); ctx.lineTo(w * 0.80, h * 0.58); ctx.fill();
                    var fill = glyph.progress < 0 ? 0.6 : Math.max(0.06, Math.min(1, glyph.progress));
                    ctx.fillRect(w * 0.20, h * 0.37, (w * 0.52) * fill, h * 0.26);
                } else if (k === "system") {
                    ctx.strokeRect(w * 0.20, h * 0.34, w * 0.60, h * 0.20);
                    ctx.strokeRect(w * 0.20, h * 0.60, w * 0.60, h * 0.20);
                    ctx.beginPath(); ctx.moveTo(w * 0.28, h * 0.44); ctx.lineTo(w * 0.44, h * 0.44); ctx.stroke();
                } else if (k === "lock") {
                    ctx.strokeRect(w * 0.28, h * 0.46, w * 0.44, h * 0.36);
                    ctx.beginPath(); ctx.arc(w * 0.5, h * 0.46, w * 0.15, Math.PI, 0); ctx.stroke();
                } else if (k === "slot") {
                    // a dashed placeholder frame with a plus: "nothing here yet"
                    ctx.setLineDash([w * 0.09, w * 0.07]);
                    ctx.strokeRect(w * 0.16, h * 0.16, w * 0.68, h * 0.68);
                    ctx.setLineDash([]);
                    ctx.beginPath(); ctx.moveTo(w * 0.5, h * 0.34); ctx.lineTo(w * 0.5, h * 0.66); ctx.stroke();
                    ctx.beginPath(); ctx.moveTo(w * 0.34, h * 0.5); ctx.lineTo(w * 0.66, h * 0.5); ctx.stroke();
                } else if (k === "app") {
                    ctx.beginPath(); ctx.arc(w * 0.5, h * 0.5, w * 0.26, 0, Math.PI * 2); ctx.stroke();
                } else if (k === "folder") {
                    // folder with a tab: the organizer's own mark
                    ctx.beginPath();
                    ctx.moveTo(w * 0.14, h * 0.34);
                    ctx.lineTo(w * 0.42, h * 0.34);
                    ctx.lineTo(w * 0.50, h * 0.44);
                    ctx.lineTo(w * 0.86, h * 0.44);
                    ctx.lineTo(w * 0.86, h * 0.74);
                    ctx.lineTo(w * 0.14, h * 0.74);
                    ctx.closePath();
                    ctx.stroke();
                } else if (k === "file") {
                    // a page with a folded corner
                    ctx.beginPath();
                    ctx.moveTo(w * 0.28, h * 0.16);
                    ctx.lineTo(w * 0.62, h * 0.16);
                    ctx.lineTo(w * 0.74, h * 0.30);
                    ctx.lineTo(w * 0.74, h * 0.84);
                    ctx.lineTo(w * 0.28, h * 0.84);
                    ctx.closePath();
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.moveTo(w * 0.62, h * 0.16); ctx.lineTo(w * 0.62, h * 0.30);
                    ctx.lineTo(w * 0.74, h * 0.30);
                    ctx.stroke();
                } else if (k === "back") {
                    ctx.beginPath();
                    ctx.moveTo(w * 0.62, h * 0.24); ctx.lineTo(w * 0.36, h * 0.5);
                    ctx.lineTo(w * 0.62, h * 0.76);
                    ctx.stroke();
                } else if (k === "plus") {
                    ctx.beginPath(); ctx.moveTo(w * 0.5, h * 0.26); ctx.lineTo(w * 0.5, h * 0.74); ctx.stroke();
                    ctx.beginPath(); ctx.moveTo(w * 0.26, h * 0.5); ctx.lineTo(w * 0.74, h * 0.5); ctx.stroke();
                } else if (k === "sort") {
                    // three rows settling into a folder: "put things where they go"
                    ctx.beginPath(); ctx.moveTo(w * 0.16, h * 0.30); ctx.lineTo(w * 0.58, h * 0.30); ctx.stroke();
                    ctx.beginPath(); ctx.moveTo(w * 0.16, h * 0.50); ctx.lineTo(w * 0.46, h * 0.50); ctx.stroke();
                    ctx.beginPath(); ctx.moveTo(w * 0.16, h * 0.70); ctx.lineTo(w * 0.34, h * 0.70); ctx.stroke();
                    ctx.beginPath();
                    ctx.moveTo(w * 0.62, h * 0.52); ctx.lineTo(w * 0.86, h * 0.52);
                    ctx.lineTo(w * 0.86, h * 0.72); ctx.lineTo(w * 0.62, h * 0.72);
                    ctx.closePath(); ctx.stroke();
                } else {
                    // dot: the state lamp
                    ctx.beginPath(); ctx.arc(w * 0.5, h * 0.5, w * 0.20, 0, Math.PI * 2); ctx.fill();
                }
            }
        }
    }
}
