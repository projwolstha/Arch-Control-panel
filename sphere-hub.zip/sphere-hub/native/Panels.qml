import QtQuick

// ── Panels — the five segments of the crest, mirrored from config/panels.json ─
//
// The JSON is the source of truth (test_config.py keeps this file and
// SphereWidget's gemSpecs in lock-step with it). The labels are kept for
// later hover tooltips and are NOT drawn anywhere: showLabels is false and
// no drawing code may read anything but that.
QtObject {
    id: panels
    objectName: "panels"

    readonly property bool showLabels: false
    readonly property var segments: [
        { "id": "wifi",      "label": "WI-FI",     "gemColor": "#ff3b3b", "sigil": "assets/sigils/sigil-01.svg" },
        { "id": "bluetooth", "label": "BLUETOOTH", "gemColor": "#3ddc84", "sigil": "assets/sigils/sigil-02.svg" },
        { "id": "battery",   "label": "BATTERY",   "gemColor": "#ff3bd4", "sigil": "assets/sigils/sigil-03.svg" },
        { "id": "resources", "label": "SYSTEM",    "gemColor": "#3b7bff", "sigil": "assets/sigils/sigil-04.svg" },
        { "id": "organize",  "label": "FILES",     "gemColor": "#ffd23b", "sigil": "assets/sigils/sigil-05.svg" }
    ]
}
