# Sphere — native Hyprland + Quickshell

Sphere is a native Qt Quick layer-shell widget, not a browser page and not Qt WebEngine. It keeps your holographic artwork as the animated core, exposes eight manually chosen application orbs, saves those choices outside workspace state, and can open a real terminal for reviewed installations of missing apps.

## One-script setup

Download **`sphere-setup.sh`** from the project and run it **as your desktop user**:

```sh
sh ./sphere-setup.sh
```

Do **not** use `sudo sh`. The script itself stays unprivileged; it asks `sudo`, `doas`, or `pkexec` only for system packages. The same file is also the manager after installation:

```sh
sphere-setup status
sphere-setup doctor
sphere-setup start
sphere-setup stop
sphere-setup restart
sphere-setup summon
sphere-setup dismiss
sphere-setup repair
sphere-setup logs
sphere-setup enable
sphere-setup disable
sphere-setup uninstall
```

`sphere-setup` is installed to `~/.local/bin/sphere-setup`. If that directory is not on PATH, use `~/.local/share/sphere-hub/sphere-setup.sh` or rerun your downloaded file.

### What setup does automatically

1. Verifies the embedded native payload by SHA-256 before using it.
2. Creates user-owned folders under:
   - `$XDG_CONFIG_HOME/quickshell/sphere-hub` (native QML/backend, normally `~/.config/quickshell/sphere-hub`)
   - `$XDG_CONFIG_HOME/sphere-hub` (saved assignments/preferences)
   - `$XDG_DATA_HOME/sphere-hub` (manager, manifest, backups)
   - `$XDG_STATE_HOME/sphere-hub` (logs)
3. Installs required runtime files through your existing signed package manager when needed:
   - Linux with `apt`, `pacman`, `dnf`, or `zypper`
   - Python 3.10+
   - Qt Quick / Quick Controls / Layouts / WorkerScript / SVG / Wayland modules
   - Hyprland and `hyprctl`
   - Quickshell 0.3+ and one supported terminal
4. Preserves an existing terminal. Otherwise it tries `foot`, `kitty`, then `xterm` from enabled repositories.
5. Enables the official signed Debian 13 `trixie-backports` repository only when needed for packaged Hyprland/Quickshell.
6. If no recent Quickshell package is available, builds official pinned Quickshell v0.3.2 from source against your host Qt 6.6+ using a fixed archive hash. That private build is kept in your home directory and rebuilt by `repair` after Qt ABI changes.
7. Never source-builds or replaces Hyprland; it uses your distribution's signed Hyprland package only.
8. Deploys the native widget, runs its 50 backend and shell self-tests, checks artwork and file hashes, and creates a desktop launcher.
9. Adds a single marked autostart block to your active Hyprland config. On Hyprland 0.55+ this is Lua; older Hyprland gets legacy `hyprland.conf` syntax. The generated text is checked with Hyprland's static config verifier when the binary supports it.
10. Starts Sphere if it is being run inside a real Hyprland/Wayland session. Otherwise setup finishes safely and autostart happens at your next Hyprland login.

Useful checks before changing anything:

```sh
sh ./sphere-setup.sh --dry-run
sh ./sphere-setup.sh --dry-run --json
```

Useful non-default choices:

```sh
sh ./sphere-setup.sh --no-deps        # require existing Hyprland/Quickshell; no package changes
sh ./sphere-setup.sh --no-autostart   # install only, no Hyprland config edit
sh ./sphere-setup.sh --no-start       # install/check, no GUI launch
sh ./sphere-setup.sh --seed-installed # suggest up to eight apps already installed
sh ./sphere-setup.sh --software       # software-render Qt for this widget only
sh ./sphere-setup.sh --purge uninstall # also remove saved assignments/backups/private build
```

No OS desktop environment or existing window manager session is replaced. Immutable/read-only operating systems are not layered behind your back; use their own packaging with `--no-deps`.

## What the native widget does

- **Five gems on one gold magic circle**, fixed and never assigned: WI-FI, BLUETOOTH, BATTERY, SYSTEM and FILES, clockwise from the top. There are no app orbs, no "+" slots and no assign flow any more.
- Resting on a gem, on its name plate, or on the bridge between it and the centre previews that panel inside the disc: the mark fades, the disc grows from 0.48 R to 0.70 R, and the content crossfades in the shared circular frame. Leaving everything fades it back after a short grace. A click pins what you are looking at; a second click, `Escape`, the frame's close disc or a click on empty space releases it.
- The five gems are the classic colours — Wi-Fi **red**, Bluetooth **green**, Battery **pink**, System **blue**, Files **yellow**. The centre is the Jarvis core (`JarvisCore.qml`): a small glowing orb inside three segmented rings, sized to sit inside the gold bevel and drawn from the same `Theme.qml` tokens as everything else. The three rings are live: CPU (48 segments, outside), memory (36) and battery (24) light clockwise from the top, sampled from `/proc/stat` and `/proc/meminfo` every two seconds by `SysStats.qml` and blended over 400 ms, with the battery coming from the adapter's own UPower reading so the ring and the battery panel cannot disagree. A source that is not there — no battery on a desktop, no `/proc/meminfo` — drops the ring to zero and turns its gold zero mark grey, so an empty ring never reads as a measurement of zero. The orb also carries the clock: large thin time and a small-caps date in the plate serif, over a soft dark lens so cream type reads against its white-cyan centre, with the seconds running as a thin gold arc just outside the inner ring. One Quickshell `SystemClock` at second precision drives it, stopped while the dashboard is hidden.
- The centre is a hover area and a click target for its own content, so every button inside a panel works. It is **not** a picker: the app picker and the slot model it served are gone.
- The transparent panel is one workspace-independent layer-shell surface. Switching workspaces does not run a restart hook, reread state, reorder anything or recreate the ring.
- While the dashboard is on screen it **owns the mouse and the keyboard**: a full-screen `WlrLayer.Overlay` surface anchored to all four edges with `exclusionMode: Ignore`, its input mask is the whole monitor, and keyboard focus is `Exclusive`. A full-screen catcher under the gems absorbs empty-space clicks (they close the open panel) and `Escape` dismisses. **SUPER+A** (the managed Hyprland binding runs `toggle`) **dismisses it entirely**: the surface unmaps and the Quickshell + adapter processes exit cleanly — **0 MB, 0% CPU while hidden**. Pressing it again relaunches the dashboard already usable.
- Keyboard focus is `Exclusive` for as long as the surface is visible — that is what makes `Escape` and the Wi-Fi passphrase reach the dashboard — and `None` the moment it is unmapped, so your window keybinds (including the one that summoned it) work again immediately. The passphrase prompt keeps its own inner focus order.
- The supplied sphere artwork is animated by a bounded 12×12 fluid mesh in a single framebuffer-backed Qt Canvas (`Canvas.FramebufferObject`, cooperative painting) at ~22fps — memory stays flat even on software rendering; the old `Canvas.Image`+threaded path that ballooned RAM was removed. A Preferences "Power saving" option drops it to ~7fps. The animation is local and fully offline.

## Installing missing applications

From an empty or assigned orb, choose **Get / install**. Sphere shows a review page containing the detected package manager and exact package command. It may use `pacman`, `apt`, `dnf`, `zypper`, `apk`, or user Flatpak, depending on your system. Nothing runs silently.

After you choose **Open terminal**, a real terminal opens and requires you to type **INSTALL** exactly before the package manager starts. The sudo and package-manager prompts remain interactive. There are no `-y`/`--noconfirm` flags, no automatic repository creation, no root widget process, and no browser-to-OS bridge. After installation, Sphere requires a desktop-entry refresh before it will call the app installed.

Assign-only is available for supported missing recipes; the orb remains marked missing until the underlying desktop entry exists.

## Autostart and workspace behavior

The installer adds one exact marked block to the active Hyprland config. Modern Hyprland (0.55+) uses:

```lua
hl.on("hyprland.start", function()
  hl.exec_cmd("~/.local/share/sphere-hub/sphere-setup.sh start")
end)
hl.bind("SUPER + A", hl.dsp.exec_cmd("~/.local/share/sphere-hub/sphere-setup.sh toggle"))
```

The managed block adds the **SUPER+A** hide/summon binding for both the modern Lua and the legacy `hyprland.conf` (`bind = SUPER, A, exec, … toggle`) format automatically.

Older Hyprland uses one `exec-once` command in `hyprland.conf`. It starts once per login, not on each workspace change. You can remove it safely with:

```sh
sphere-setup disable
```

Re-enable with `sphere-setup enable`. The script edits only its own `BEGIN SPHERE-HUB MANAGED AUTOSTART` block; your other Hyprland settings and other Quickshell bars are left alone. Sphere's own Hyprland config lookup understands `HYPRLAND_CONFIG`, detects an active compositor's `--config` path securely, and defaults to `hyprland.lua` or legacy `hyprland.conf` according to the installed Hyprland version.

Preferences are stored separately at:

```text
$XDG_CONFIG_HOME/sphere-hub/state.json
# Normally: ~/.config/sphere-hub/state.json
```

The file contains eight slot targets and preferences only—no workspace ID. Browser-preview assignments are kept separately because browser tools are not desktop applications.

## Management and diagnostics

```sh
sphere-setup status --json
sphere-setup doctor --json
sphere-setup logs
sphere-setup repair
```

`doctor` checks file integrity, original artwork hash, Python, Qt/Quickshell version and ABI, Hyprland, terminal, persistence/autostart paths, live session status, backend / Hyprland IPC, and actual artwork painting. In a non-Hyprland environment the last four checks are reported as pending; setup does not fake a live result.

This widget intentionally has no HTTP server, browser bridge, eval endpoint, WebEngine view, network listener, or arbitrary shell command action. Native control uses Quickshell's path-scoped per-instance IPC target `sphere`. Stop/restart selects this configuration path; it never kills unrelated Quickshell panels.

## Testing boundary

Verified during development:

- 29 isolated backend tests pass, including persistence rollback, XDG desktop filtering, Hyprland socket transport against a fake compositor, launch/focus dispatch behavior, terminal plans, and malicious input rejection.
- Official Hyprland 0.55.2 package config validation passed (`--verify-config`).
- Quickshell 0.3.0 loaded the native QML on a real Wayland compositor; its Python backend connected, the artwork was actually painted, and path-scoped Quickshell IPC returned a healthy native state.
- Installer dry-run, install, repair, state preservation, marked autostart enable/disable, corruption detection, uninstall, and no-cache deployment passed in isolated homes.
- Pinned official Quickshell v0.3.2 checksum-matched source fallback compiled, installed privately, and passed its executable version check with the minimal WlrLayerShell stack used by this widget.

The development sandbox had no GPU and could not host a real Hyprland compositor. Manager `doctor` intentionally verifies live Hyprland behavior when the script is used from your real session; treat any live-session failure there as authoritative and run `sphere-setup repair`/`logs`.

## Audit source layout

- `shell.qml`: ShellRoot, one centered transparent PanelWindow, Region masks and path-scoped native IPC.
- `SphereWidget.qml`: the scene — the veil, the ring, the gems, the plates, the disc, the five hosted panels and the hover state machine.
- `MagicRing.qml`: the decorative circle: rays, dust, pentagon and pentagram, the gold sheets, the plates and the arc type. It takes no input.
- `MagicGem.qml`: one glass stone — halo, bezel, specular, inner shadow, silhouette glyph.
- `PanelFrame.qml`: the one frame all five panels are drawn in.
- `assets/`: the generated artwork (`magic-*.svg`, `glyph-*.svg`, `ray-*.svg`, `glow-*.svg`) plus the tool that makes them, `tools/artwork.py`.
- `backend.py`: stdlib Python desktop registry, atomic state, direct Hyprland Unix-socket IPC, safe launch/focus, and terminal-only install helper.
- `start.sh`: standalone/manual launcher for the extracted native source package.
- `hyprland.lua.example`, `hyprland.conf.example`: examples; the installer modifies the active file safely instead of requiring copy/paste.
- `tests/test_backend.py`: local tests; no real installations or app launches.

References: [Quickshell](https://quickshell.org/docs/v0.3.0/guide/install-setup/), [PanelWindow](https://quickshell.org/docs/v0.3.0/types/Quickshell/PanelWindow/), [Process](https://quickshell.org/docs/v0.3.0/types/Quickshell.Io/Process/), [WlrLayershell](https://quickshell.org/docs/v0.3.0/types/Quickshell.Wayland/WlrLayershell/), and [Hyprland IPC](https://wiki.hypr.land/IPC/).

## The circle

One radius `R` (41 % of the smaller screen side) sizes everything: the gems sit on
an orbit at 0.71 R, each stone is 0.17 R across, the outer double ring is at R,
the name plates live in the 0.62–0.90 R band, and the centre disc is 0.48 R when
idle and 0.70 R while a panel is showing. A sixth gem would be one more line in
`gemSpecs` — the layout, the plates, the rays and the hit areas are all derived
from that table.

Back to front: a near-black veil over the wallpaper; one soft light cone per gem
(coloured, additive, slow shimmer, brighter for the one under the pointer);
the pre-rendered gold sheets — outer double ring, hairlines, notches, rune band,
pentagon and pentagram; a cartouche per gem with its word set letter by letter
along the arc (Cinzel when the system has it, the desktop serif otherwise);
five glass gems with gold bezels and dark silhouette glyphs; and the centre disc,
a beveled gold rim with a dark inner groove over a near-black face.

Everything decorative is **pre-rendered SVG generated by `tools/artwork.py`** and
loaded as a scalable image; QML only animates opacity and rotation. There are no
blur passes, no per-gem canvases and no full-screen effects, so a hover costs no
repaint of the ring.

**The centre is the Jarvis core** (`JarvisCore.qml`) inside that bevel: a soft
orb at 0.16 R, large thin time over a small-caps date, a thin seconds arc, and
three segmented rings — CPU 48, RAM 36, battery 24 — lit clockwise from a gold
zero mark, with a radar sweep and a slow breath over the orb and its halo.
Around the orb sit the **time dials**: 12 dots for the hour (closest in), 60 for
the minute, 60 for the second — the dot for the current unit lit, the elapsed
ones warm, and each dot jumping one place per unit rather than sliding. A dial
is not an animation: it repaints when the clock ticks, so there is nothing to
pause and no per-frame work. The three motions are QML animations behind one
flag: they run only while the dashboard is on screen and awake, and each has an
off switch in `Theme.qml` (`coreBreath`, `coreDrift`, `coreSweep`); the dials
have `coreDials`, and `coreDialFill` picks fill (elapsed dots warm) or marker
(one dot lit). The sweep is a generated SVG, not a conical gradient: that
gradient paints nothing in this Qt.

**The centre mark** is `~/.config/jarvis/logo.svg` if it exists, else
`~/.config/jarvis/logo.png`. Both are watched: writing the file updates the
dashboard without a restart. With no file there, a small glowing ring glyph stands
in — never an error. `LOGO_TINT` (default `false`) tints the mark gold.

**The knobs** are at the top of `SphereWidget.qml`:

```qml
readonly property int  hoverIntentMs: 70      // HOVER_INTENT_MS
readonly property int  leaveGraceMs: 280      // LEAVE_GRACE_MS
readonly property bool pinOnClick: true       // PIN_ON_CLICK
readonly property bool logoTint: false        // LOGO_TINT
readonly property bool lowPowerAuto: true     // LOW_POWER below 30 % on battery
readonly property var  gemSpecs: [ … ]        // GEM_COLORS / GEM_MAP, five entries
```

The five panels — Wi-Fi, Bluetooth, Battery, System and the file organizer — keep
their data, their layouts and their behaviour; only the frame around them is new:
a black circle with a thin gold rim, the gold header rule, and the accent of the
gem that opened it. Details of the Wi-Fi behaviour (nmcli, the passphrase field,
the 0600 passwd-file) are unchanged and live in `docs/WIFI.md`.

## Source layout of this directory

`backend.py` and `shell.qml` are only entry points: the adapter implementation lives
in `sphere_adapter/`, one concern per module (`bridge.py` for the stdin/stdout JSON
protocol, `catalog.py` for `.desktop` discovery, `config.py` for the legacy state file,
`pathutil.py`, `system.py`, `terminal.py`, `install.py`, `hypr.py`, `cli.py`, `wifi.py` for the
NetworkManager bridge, `bluetooth.py` for `bluetoothctl`, `battery.py` for upower plus the
`/sys/class/power_supply` fallback, and `resources.py` for `/proc/meminfo`, `df` and `ps`). Quickshell instantiates `shell.qml`
as the component root; the scene is `SphereWidget.qml`, the decorative circle is
`MagicRing.qml`, one stone is `MagicGem.qml`, and all five panels share
`PanelFrame.qml`. See
`docs/SPLIT.md` at the project root for the full map.
