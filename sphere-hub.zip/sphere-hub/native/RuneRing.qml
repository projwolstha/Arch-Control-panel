import QtQuick
import QtQuick.Shapes

// ── RuneRing — the crest's ring structure, computed from one geometry ──────
//
// Every circle here is a fraction of R taken from Geometry.qml (mirrored from
// config/layout.json), every stroke reads Theme.qml (mirrored from
// config/theme.json) — there is no hand-placed point and no raw colour or
// size in this file. Back to front:
//
//   (the tight outer edge rings live in OuterRings.qml; the dense tick comb
//    is deleted — fine ticks come back small, between the runes, at step 4)
//   band rings  two concentric thin rings at the band the plates used to own
//               (0.90 R and 0.62 R) — the runic ring's frame
//   glyphs      60 invented rune glyphs in five segments of twelve, upright
//               outward, with a gap of segmentGapDeg at every gem angle; the
//               glyph at a segment's end lights when that gem's station is
//               highlighted
//   diamonds    one diamond node in each gap, at the gem angles — the
//               boundary marks of the five segments
//   dashed      a faint dashed ring just inside the glyphs
//
// The runes' slow turn and the flicker wave read `clock`, `animated` and
// Motion.qml — never a timer of their own, so they pause with the widget.
// Nothing else here moves (motion.json webRotation is false) and nothing
// here takes input.
Item {
    id: runeRing
    objectName: "runeRing"

    property real radius: 300                  // R — every measurement is a fraction of it
    property real clock: 0                     // the runes' turn and the flicker read this
    property bool animated: false
    property Motion motion: Motion {}
    property int highlight: -1                 // the hovered gem's glyph station (step 3)
    property Geometry geometry: Geometry {}
    property Theme theme: Theme {}

    width: radius * 2
    height: width

    // one weight language: theme px at R = 500, scaled to this ring
    function weight(px) { return Math.max(0.6, radius / 500 * px); }

    // a full circle as one path (two half arcs — SVG cannot sweep 360 in one)
    function circlePath(fraction) {
        var rr = radius * fraction;
        return "M " + radius.toFixed(2) + " " + (radius - rr).toFixed(2)
             + " A " + rr.toFixed(2) + " " + rr.toFixed(2) + " 0 1 1 " + radius.toFixed(2) + " " + (radius + rr).toFixed(2)
             + " A " + rr.toFixed(2) + " " + rr.toFixed(2) + " 0 1 1 " + radius.toFixed(2) + " " + (radius - rr).toFixed(2) + " Z";
    }

    // ── the two band rings ─────────────────────────────────────────────────
    // The frame of the runic ring. Static solid lines: the engraved look comes
    // from exact geometry, not from crawling dashes.
    EnergyLine {
        anchors.fill: parent
        theme: runeRing.theme
        path: runeRing.circlePath(runeRing.geometry.runeBandOuter)
        tint: runeRing.theme.gold
        weight: runeRing.weight(runeRing.theme.crestRuneRingWidth)
        glow: runeRing.theme.crestGoldGlow
        opacity: runeRing.theme.crestRuneRingAlpha
        flow: runeRing.motion.goldShimmer && runeRing.animated
        clock: runeRing.clock
    }
    EnergyLine {
        anchors.fill: parent
        theme: runeRing.theme
        path: runeRing.circlePath(runeRing.geometry.runeBandInner)
        tint: runeRing.theme.gold
        weight: runeRing.weight(runeRing.theme.crestRuneRingWidth)
        glow: runeRing.theme.crestGoldGlow
        opacity: runeRing.theme.crestRuneRingAlpha
        flow: runeRing.motion.goldShimmer && runeRing.animated
        clock: runeRing.clock
    }

    function runeSource(i) {
        return Qt.resolvedUrl("assets/rune-" + (i < 10 ? "0" : "") + i + ".svg");
    }

    // ── the glyph band: five segments of twelve, gaps at the gems ──────────
    // The band never moves — the delivered composition stays exactly as it
    // is, gaps locked at the gems. The rotation lives on the runes
    // themselves (motion runeRotation): each glyph turns slowly in place,
    // one lap per ten minutes. Hover lighting is the delivered slot rule.
    Repeater {
        model: runeRing.geometry.runeCount
        delegate: Item {
            required property int index
            anchors.fill: parent
            readonly property int perSegment:
                runeRing.geometry.runeCount / runeRing.geometry.gemCount
            readonly property int segment: Math.floor(index / perSegment)
            readonly property int slot: index % perSegment
            readonly property real stepDeg:
                (360 / runeRing.geometry.gemCount - runeRing.geometry.segmentGapDeg) / perSegment
            readonly property real angleDeg:
                runeRing.geometry.segmentAngle(segment, runeRing.geometry.gemCount)
                + (slot - (perSegment - 1) / 2) * stepDeg
            // a gem's station is the gap at its angle: the glyph just before
            // the gap and the glyph just after it light with the diamond
            readonly property bool lit:
                (slot === 0 && runeRing.highlight === segment)
                || (slot === perSegment - 1
                    && runeRing.highlight === (segment + 1) % runeRing.geometry.gemCount)
            // each rune turns in place, one slow lap per 10 minutes
            readonly property real turn:
                runeRing.motion.runeRotation ? (runeRing.clock % 600) * 0.6 : 0
            // a soft brightness wave travels the band (runeFlicker)
            readonly property real flick:
                runeRing.animated && runeRing.motion.runeFlicker
                ? 0.86 + 0.14 * (0.5 + 0.5 * Math.sin(
                      angleDeg * Math.PI / 180 - runeRing.clock * 0.5))
                : 1
            rotation: angleDeg + 90                 // screen angle: 0 = up, clockwise
            Image {
                x: parent.width / 2 - width / 2
                y: runeRing.radius * (1 - runeRing.geometry.runeRadius) - height / 2
                width: runeRing.radius * runeRing.geometry.runeSize
                height: width
                rotation: turn                       // the rune's own slow turn
                source: runeRing.runeSource(index)
                opacity: (lit ? 1 : runeRing.theme.crestRuneGlyphAlpha) * flick
            }
        }
    }

    // ── the diamond boundary nodes, one per gap ────────────────────────────
    // On the OUTER band ring at each gem angle, not in the glyph band: the
    // opaque gem discs (0.54–0.88 R) cover the glyph radius there, while the
    // ring line at 0.90 R grazes above them — the node marks the break in the
    // glyph arc the way the target's band marks sit where the ring meets a
    // gem.
    Repeater {
        model: runeRing.geometry.gemCount
        delegate: Item {
            required property int index
            anchors.fill: parent
            readonly property bool lit: runeRing.highlight === index
            rotation: runeRing.geometry.gemAngle(index, runeRing.geometry.gemCount) + 90
            Rectangle {
                x: parent.width / 2 - width / 2
                y: runeRing.radius * (1 - runeRing.geometry.runeBandOuter) - height / 2
                width: runeRing.radius * runeRing.geometry.boundaryNodeSize * (lit ? 1.4 : 1)
                height: width
                rotation: 45
                // goldBright, not plain gold: the node lives inside the
                // gem halos' wash at every gap and must still read there
                color: lit ? runeRing.theme.goldWhite
                           : runeRing.theme.alpha(runeRing.theme.goldBright,
                                                  runeRing.theme.crestNodeAlpha)
            }
        }
    }

    // ── the dashed ring, just inside the glyphs ────────────────────────────
    Shape {
        anchors.fill: parent
        ShapePath {
            strokeWidth: runeRing.weight(runeRing.theme.crestDashedWidth)
            strokeColor: runeRing.theme.alpha(runeRing.theme.gold,
                                              runeRing.theme.crestDashedAlpha)
            strokeStyle: ShapePath.DashLine
            dashPattern: [runeRing.weight(runeRing.theme.crestDashedOn),
                          runeRing.weight(runeRing.theme.crestDashedOff)]
            fillColor: "transparent"
            PathSvg { path: runeRing.circlePath(runeRing.geometry.dashedRadius) }
        }
    }
}
