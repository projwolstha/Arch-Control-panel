import QtQuick
import QtQuick.Shapes

// ── Sigil — the five station emblems and their inscriptions ────────────────
//
// One station per segment. The emblem file each segment carries is ASSIGNED
// in config/panels.json (mirrored in Panels.qml) — the art is generated
// (assets/sigils/sigil-01..05.svg), original, stroke-built, never a letter.
// Each station sits at the segment's derived angle at sigilRadius, upright
// outward like the glyph ring. From each emblem, two curved connectors — the
// sigil's inscriptions — bow toward the core and touch the two neighbouring
// gem halos; every connector ends in a diamond node: a small stud where the
// line leaves the emblem, the boundary diamond where it meets the halo.
//
// Every coordinate here is computed from Geometry.qml (mirrored from
// config/layout.json) and every stroke reads Theme.qml — no hand-placed
// point, no raw colour or size. `clock`, `animated` and `highlight` are the
// motion step's hooks (sigilPulse); the drawing itself is completely static,
// and nothing here takes input.
Item {
    id: sigils
    objectName: "sigilLayer"

    property real radius: 300                  // R — every measurement is a fraction of it
    property real clock: 0                     // sigilPulse will read this
    property bool animated: false
    property Motion motion: Motion {}
    property int highlight: -1                 // the hovered gem's station
    property Geometry geometry: Geometry {}
    property Theme theme: Theme {}
    property Panels panels: Panels {}

    width: radius * 2
    height: width

    // one weight language: theme px at R = 500, scaled to this ring
    function weight(px) { return Math.max(0.6, radius / 500 * px); }

    // screen degrees (0 = straight up is -90, clockwise), y down — the same
    // convention as gemAnglesDeg and the demo's pt()
    function pt(frac, deg) {
        var a = deg * Math.PI / 180;
        return [radius + Math.cos(a) * frac * radius,
                radius + Math.sin(a) * frac * radius];
    }

    // the inscription: from the emblem's edge to the neighbouring gem halo's
    // visible edge, bowed toward the core by connectorArc (a quadratic — the
    // curve dips half the control offset, hence the factor of two)
    function connector(staPos, gemPos) {
        var dx = gemPos[0] - staPos[0], dy = gemPos[1] - staPos[1];
        var len = Math.sqrt(dx * dx + dy * dy);
        var ux = dx / len, uy = dy / len;
        var h = radius * geometry.sigilSize / 2;
        var gl = radius * geometry.gemHaloRadius;
        var sx = staPos[0] + ux * h, sy = staPos[1] + uy * h;
        var ex = gemPos[0] - ux * gl, ey = gemPos[1] - uy * gl;
        var mx = (sx + ex) / 2, my = (sy + ey) / 2;
        var vx = radius - mx, vy = radius - my;
        var vl = Math.sqrt(vx * vx + vy * vy);
        var bow = radius * geometry.connectorArc * 2;
        var qx = mx + vx / vl * bow, qy = my + vy / vl * bow;
        return { sx: sx, sy: sy, ex: ex, ey: ey,
                 path: "M " + sx.toFixed(2) + " " + sy.toFixed(2)
                     + " Q " + qx.toFixed(2) + " " + qy.toFixed(2)
                     + " " + ex.toFixed(2) + " " + ey.toFixed(2) };
    }

    Repeater {
        model: sigils.panels.segments.length
        delegate: Item {
            required property int index
            anchors.fill: parent
            readonly property var segment: sigils.panels.segments[index]
            readonly property real stationDeg:
                sigils.geometry.segmentAngle(index, sigils.geometry.gemCount)
            readonly property bool lit: sigils.highlight === index
            readonly property var staPos:
                sigils.pt(sigils.geometry.sigilRadius, stationDeg)
            readonly property var gemA:
                sigils.pt(sigils.geometry.gemOrbit,
                          sigils.geometry.gemAngle(index, sigils.geometry.gemCount))
            readonly property var gemB:
                sigils.pt(sigils.geometry.gemOrbit,
                          sigils.geometry.gemAngle(index + 1, sigils.geometry.gemCount))
            readonly property var linkA: sigils.connector(staPos, gemA)
            readonly property var linkB: sigils.connector(staPos, gemB)
            // the sigils breathe, staggered (motion sigilPulse)
            opacity: sigils.animated && sigils.motion.sigilPulse
                ? 0.84 + 0.16 * (0.5 + 0.5 * Math.sin(
                      sigils.clock * (2 * Math.PI / 7)
                      - index * (2 * Math.PI / sigils.geometry.gemCount)))
                : 1

            // ── the emblem, upright outward ───────────────────────────────
            Image {
                x: staPos[0] - width / 2
                y: staPos[1] - height / 2
                width: sigils.radius * sigils.geometry.sigilSize
                height: width
                rotation: stationDeg + 90              // upright outward
                source: Qt.resolvedUrl(segment.sigil)
                opacity: lit ? 1 : sigils.theme.crestSigilAlpha
            }

            // ── the two inscriptions ──────────────────────────────────────
            Shape {
                anchors.fill: parent
                ShapePath {
                    strokeWidth: sigils.weight(sigils.theme.crestConnectorWidth)
                    strokeColor: sigils.theme.alpha(
                        sigils.theme.gold, lit ? sigils.theme.crestSigilAlpha
                                               : sigils.theme.crestConnectorAlpha)
                    strokeStyle: ShapePath.SolidLine
                    fillColor: "transparent"
                    PathSvg { path: linkA.path }
                    PathSvg { path: linkB.path }
                }
            }

            // ── the diamond end nodes: studs at the emblem, boundary
            //    diamonds where the inscription meets the halo ─────────────
            Repeater {
                model: [
                    { p: linkA, s: sigils.geometry.nodeSize, big: false },
                    { p: linkB, s: sigils.geometry.nodeSize, big: false },
                    { p: linkA, s: sigils.geometry.boundaryNodeSize, big: true },
                    { p: linkB, s: sigils.geometry.boundaryNodeSize, big: true }
                ]
                delegate: Rectangle {
                    required property var modelData
                    x: (modelData.big ? modelData.p.ex : modelData.p.sx) - width / 2
                    y: (modelData.big ? modelData.p.ey : modelData.p.sy) - height / 2
                    width: sigils.radius * modelData.s * (lit && modelData.big ? 1.4 : 1)
                    height: width
                    rotation: 45
                    color: lit && modelData.big ? sigils.theme.goldWhite
                           : modelData.big
                             ? sigils.theme.alpha(sigils.theme.goldBright,
                                                  sigils.theme.crestNodeAlpha)
                             : sigils.theme.alpha(sigils.theme.goldBright,
                                                  sigils.theme.crestConnectorAlpha)
                }
            }
        }
    }
}
