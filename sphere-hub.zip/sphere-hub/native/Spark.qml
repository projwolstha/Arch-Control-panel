import QtQuick

// ── Spark — one travelling bead of light ────────────────────────────────────
//
// A pre-rendered radial glow with a white centre: the thing that runs along a
// line, trails behind a gem, or drifts inside the orb. One image plus one dot, so
// a hundred of them still cost less than a single extra path rebuild.
Item {
    id: spark
    property url source: ""
    property real diameter: 12
    property real amount: 1                  // 0…1 brightness
    property color core: "#FFF0B8"

    width: diameter
    height: diameter
    visible: amount > 0.01 && diameter > 0.5

    Image {
        anchors.fill: parent
        source: spark.source
        fillMode: Image.PreserveAspectFit
        smooth: true
        opacity: 0.55 * Math.min(1, spark.amount)
    }
    Rectangle {
        anchors.centerIn: parent
        width: Math.max(1.4, spark.diameter * 0.24)
        height: width
        radius: width / 2
        color: spark.core
        opacity: Math.min(1, spark.amount)
    }
}
