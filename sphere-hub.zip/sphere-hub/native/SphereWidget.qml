import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Shapes

Control {
    id: root
    objectName: "sphereWidget"
    padding: 0
    // Black and gold: the palette every stock control (fields, switches, sliders,
    // scroll bars) inside a panel inherits, so nothing falls back to a blue theme.
    palette.window: "#060912"
    palette.base: "#0b1120"
    palette.alternateBase: "#10182b"
    palette.button: "#162036"
    palette.buttonText: "#e8f0fc"
    palette.windowText: "#e8f0fc"
    palette.brightText: "#ffffff"
    palette.text: "#dce6f5"
    palette.placeholderText: "#64748b"
    palette.highlight: "#38bdf8"
    palette.highlightedText: "#040812"
    palette.mid: "#334155"
    palette.dark: "#050811"
    palette.light: "#475569"
    // ══ SETTINGS — everything below reads these, nothing re-derives a copy ═══
    // These are the five knobs. They are the same in the installer header; the
    // defaults here are what a fresh install runs with.
    readonly property int hoverIntentMs: 70          // HOVER_INTENT_MS
    readonly property int leaveGraceMs: 280          // LEAVE_GRACE_MS
    readonly property bool pinOnClick: true          // PIN_ON_CLICK
    readonly property bool logoTint: false           // LOGO_TINT
    readonly property bool lowPowerAuto: true        // LOW_POWER below 30 % on battery
    // The type of the panels and the numbers: Cinzel when the system
    // has it, the desktop's serif family otherwise (Qt falls back by itself).
    readonly property string serifFamily: "sans-serif"
    // ── THE CIRCLE ───────────────────────────────────────────────────────────
    // The five gems, in ring order, first at the top. The layout spaces however
    // many entries there are evenly around the circle, so a sixth gem is one
    // more entry here and nothing else.
    //   panel the panel it opens        label  the name (kept for tooltips)
    //   color the stone's light         glyph  the silhouette in its centre
    // (`panel` is the key `activePanel` takes; it is not called `key` because the
    // panels' own frames already use that word for theirs.)
    readonly property var gemSpecs: [
        { panel:"wifi",      label:"WI-FI",     color:theme.gemWifi,      glyph:"wifi" },
        { panel:"bluetooth", label:"BLUETOOTH", color:theme.gemBluetooth, glyph:"bluetooth" },
        { panel:"battery",   label:"BATTERY",   color:theme.gemBattery,   glyph:"battery" },
        { panel:"resources", label:"SYSTEM",    color:theme.gemSystem,    glyph:"chip" },
        { panel:"organize",  label:"FILES",     color:theme.gemFiles,     glyph:"folder" }
    ]
    // ── the theme ────────────────────────────────────────────────────────────
    // One token object for the whole interface: every line, gem, rune,
    // particle and the orb read their colours from here, so recolouring the
    // dashboard is an edit to Theme.qml and nothing else.
    readonly property Theme theme: Theme {}
    // the crest's layout, mirrored from config/layout.json — one copy of every
    // angle and radius, shared with MagicRing and RuneRing
    readonly property Geometry geometry: Geometry {}
    // ── the spell ────────────────────────────────────────────────────────────
    // 0 = dormant (dim engraving, slow runes), 1 = fully cast (everything lit).
    // It runs once when the dashboard appears and is held at 1 afterwards; low
    // power skips straight to 1 so nothing travels while the battery is low.
    property real activation: 0
    SequentialAnimation {
        id:ignition
        running:false
        NumberAnimation { target:root; property:"activation"; from:0; to:1
                          duration:1700; easing.type:Easing.InOutCubic }
    }
    function castSpell() {
        if(root.lowPower) { ignition.stop();root.activation=1;return; }
        if(root.activation>=1) return;
        ignition.restart();
    }
    onSphereVisibleChanged: {
        if(sphereVisible) root.castSpell();
        else { ignition.stop();root.activation=0; }
    }
    onLowPowerChanged: if(root.lowPower) { ignition.stop();root.activation=1; }
    // ── the logo ─────────────────────────────────────────────────────────────
    // shell.qml watches ~/.config/jarvis/logo.svg (or logo.png) and hands the file
    // over here; `logoRevision` bumps on every change so the image reloads.
    property url logoSource: ""
    property int logoRevision: 0
    // Re-read the mark from disk. Called whenever shell.qml sees the file change
    // (it watches the directory) or hands over a different path.
    function reloadLogo() {
        if (!logoImage) return;
        logoImage.source = "";
        Qt.callLater(function(){ logoImage.source = root.logoSource; });
    }
    readonly property bool hasLogo: logoSource.toString().length > 0
    readonly property string logoPathLabel: "~/.config/jarvis/logo.svg"
    signal request(var message)
    opacity: root.presence
    property var snapshot: ({ apps: [], recipes: [], slots: [null,null,null,null,null,null,null,null], slotApps: [null,null,null,null,null,null,null,null], preferences: {}, system: {managers:[],preferredManager:"",terminal:""} })
    property var nativeStatus: ({hyprland:false, activeDesktopId:"", runningDesktopIds:[]})
    // Panel → panel crossfade, and the fade of the content when the disc empties.
    readonly property int switchFadeMs: 140
    readonly property int clearFadeMs: 150
    // ── THE ONE SOURCE OF TRUTH ──────────────────────────────────────────────
    // `activePanel` names the panel the orb is showing — "wifi", "bluetooth",
    // "battery", "resources", "slot", "organize", or "" for the idle orb. Every
    // other open/closed question in this file is *derived* from it: the six
    // per-panel flags below are aliases, the panels' `visible` is a comparison,
    // and the main orb's readout is a function of it. Nothing keeps a second
    // copy of that state, which is why two panels can no longer disagree.
    property string activePanel: ""
    // A click pins the panel. While pinned, leaving every hover area does NOT
    // start the leave timer; only Escape, the close disc, a second click on the
    // same orb, or an empty-background click releases it.
    property bool pinned: false
    // Panels can be summoned (by IPC, by a button, by the picker) while the
    // pointer is nowhere near the orb. Such a panel is pinned with a *latched*
    // source: it is released the first time the pointer enters some other hover
    // area, so the very next hover takes over. That keeps `sphere-setup files`
    // and the keyboard usable without ever fighting the mouse.
    property bool activeLatched: false
    // Where the active panel came from — the orb that opened it. Used only to
    // decide what a second click on that orb means (unpin) and to report state.
    property string activeSource: ""
    // Every hover area currently under the pointer. Keys are stable strings
    // ("orb:wifi", "main", "beam:wifi", "panel"); a Set is not available in QML,
    // so it is an object used as a set: hoveredAreas[key] === true.
    property var hoveredAreas: ({})
    // True from the moment a hover is armed until the panel actually switches.
    property bool hoverPending: false
    // The panel the pointer has settled on but not yet switched to (the intent
    // timer is running), and the "+" slot it belongs to when it is one.
    property string pendingPanel: ""
    // The grace ran out while a prompt or a press owned the orb: clear as soon as
    // that is over instead of closing a password field from under the user.
    property bool clearWhenFree: false
    // One hover area whose entry must not open a panel until the pointer leaves it
    // again — set by the second click on an orb, so "click again closes it" is not
    // immediately undone by the hover that is still sitting there.
    property string suppressArea: ""
    // Temporary instrumentation: one line per state change, plus one per frame
    // created. Off in the shipped build; the hover test flips it on.
    property bool debugHover: false
    readonly property bool hoverActive: root.sphereVisible && root.presence > 0
    // A prompt, a focused field, a hold-to-confirm press or a dialog owns the
    // orb: the pointer can leave, nothing is cleared, and the leave timer stays
    // stopped until it closes (see activePanelFrame().modalOpen).
    readonly property bool panelModal: {
        var f = activePanelFrame();
        return f !== null && f.modalOpen === true;
    }
    // Hover must never act while a modal part of the active panel is up.
    readonly property bool autoClearBlocked: panelModal
                                             || wifiPasswordSsid.length > 0
                                             || organizerPrompt.length > 0
    property var screenNames: []
    property bool connected: false
    property int renderedFrames: 0
    focus: true
    Keys.onEscapePressed: event => {
        // Escape peels the innermost layer first — the passphrase prompt, then
        // whichever system list is open, then the picker — and closes the whole
        // dashboard once nothing is left. The surface holds keyboard focus
        // exclusively while it is visible, so this is the one guaranteed way out.
        if(wifiOpen && wifiPasswordSsid.length>0) { cancelWifiPassword();event.accepted=true; }
        else if(organizerOpen && organizerPrompt.length>0) { organizerPrompt="";event.accepted=true; }
        // Escape releases the pin and closes whatever the orb is showing — there
        // is only ever ONE panel to close, because there is only one activePanel.
        else if(activePanel!=="") { clearPanel("escape");event.accepted=true; }
        else { dismissRequested();event.accepted=true; }
    }
    signal dismissRequested()
    // Retained for protocol compatibility (`sphere-setup status`, IPC health).
    // It no longer decides whether input works: the dashboard owns the pointer for
    // as long as its surface is visible and gives it back when it is unmapped.
    property bool interactionEnabled: true
    // SUPER+A visibility toggle: false = fully hidden (surface unmapped, ~zero cost).
    property bool sphereVisible: true
    // Visual presence only — it fades the glass in and out and NEVER gates input,
    // hit-testing or the surface mask, so a click works on the first frame of the
    // fade-in and on the last frame of the fade-out. It starts at 0 and fades in
    // on the first frame: by then the surface is already mapped and already
    // taking input, which is the whole idea.
    property real presence: 0
    Behavior on presence { NumberAnimation { duration: 180; easing.type: Easing.OutQuad } }
    Component.onCompleted: root.presence=1
    property bool dismissing: false
    signal dismissFinished()
    property string notice: "Connecting to the local desktop adapter…"
    property string errorText: ""
    property int serial: 0
    property var requests: ({})
    // The ring's own clock. Every animation in this file and in MagicRing is a
    // function of it, and it stops when the dashboard is hidden or paused.
    property real aliveTime: 0
    property real orbitDeg: 0
    property real lastTick: Date.now()
    property int hoveredSlot: -1
    // ── UFO top-dock & tractor-beam choreography (Points 1–4) ────────────────
    property int ufoSlot: -1
    property bool ufoMoving: false
    property bool ufoLocked: false
    property real ufoFromDeg: 0
    property real ufoToDeg: 0
    property real ufoMoveElapsed: 0
    property real ufoMoveDur: 0.72
    property real ufoLockTime: 0
    property real ufoBeamLevel: 0
    property real ufoReveal: 0
    property real ufoCascade: 1.4
    readonly property color ufoAccentColor: activePanel !== "" ? gemColorAt(gemIndexOf(activePanel)) : "#7fe9f4"
    readonly property real panelCascade: ufoSlot >= 0 ? (ufoLocked ? ufoCascade : 0) : 1.4
    function startUfoDock(slotIndex) {
        if (slotIndex < 0 || slotIndex >= root.gemCount) return;
        root.ufoSlot = slotIndex;
        var target = -360 * slotIndex / Math.max(1, root.gemCount);
        var delta = (((target - root.orbitDeg) % 360) + 540) % 360 - 180;
        if (Math.abs(delta) < 0.35 || root.lowPower) {
            root.orbitDeg = ((target % 360) + 360) % 360;
            root.ufoMoving = false;
            root.ufoLocked = true;
            root.ufoLockTime = root.aliveTime;
            root.ufoReveal = root.lowPower ? 1 : 0;
            root.ufoCascade = root.lowPower ? 1.4 : 0;
        } else {
            root.ufoFromDeg = root.orbitDeg;
            root.ufoToDeg = root.orbitDeg + delta;
            root.ufoMoveElapsed = 0;
            root.ufoMoveDur = 0.62 + Math.abs(delta) * 0.0038;
            root.ufoMoving = true;
            root.ufoLocked = false;
            root.ufoBeamLevel = 0;
            root.ufoReveal = 0;
            root.ufoCascade = 0;
        }
    }
    function stopUfoDock() {
        root.ufoSlot = -1;
        root.ufoMoving = false;
        root.ufoLocked = false;
        root.ufoCascade = 1.4;
    }
    // ── Wi-Fi main orb ────────────────────────────────────────────────────────
    // The Wi-Fi orb is the main orb at the centre, not one of the eight ring
    // slots and not a ninth ring position: it never consumes an assignment.
    // Clicking it shows the live network list inside the sphere.
    // `scanning` is the adapter's answer — a rescan thread that really runs — and
    // `problem` is the specific sentence for the case at hand (NetworkManager not
    // running, no device, device unmanaged, radio off), never a generic empty list.
    property var wifi: ({ available:false, radioOn:false, active:null, networks:[], error:"",
                          state:"disconnected", reason:"", scanning:false, problem:"", detail:"", nm:"unknown" })
    // ── Bluetooth, on ring position 2 ─────────────────────────────────────────
    // Same contract as Wi-Fi above: the orb only ever reads these, and one place
    // (syncBluetoothStatus) writes the visual state.
    // `pending` is true until the adapter has actually been read: the panel says
    // "checking…" instead of guessing "not available". `scanning` is the *server's*
    // answer — a real `bluetoothctl scan on` process — never a local guess, and
    // `detail` is bluetoothctl's own words when something failed.
    property var bluetooth: ({ available:false, powered:false, adapter:null, devices:[], blocked:false,
                               blockedHard:false, pending:true, scanning:false, cli:"", error:"", detail:"" })
    property string bluetoothStatus: "disconnected"   // connected | connecting | disconnected
    readonly property bool bluetoothOpen: activePanel==="bluetooth"
    property bool bluetoothBusy: false
    property bool bluetoothScanning: false
    property string bluetoothError: ""
    readonly property int bluetoothSlot: 1            // gem 2 of 5, counting from 1
    // ── Battery, on gem 3 ─────────────────────────────────────────────────────
    // Same contract again: the adapter writes this object, the orb and the panel
    // only read it, and every missing field stays null so the panel can hide it
    // instead of printing an error.
    property var battery: ({ present:false, percent:null, state:"unknown",
                             timeToEmpty:null, timeToFull:null, watts:null,
                             health:{ full:null, design:null, percent:null },
                             cycles:null, voltage:null, profile:"", profiles:[], error:"" })
    property string batteryStatus: "disconnected"     // connected | connecting | disconnected
    readonly property bool batteryOpen: activePanel==="battery"
    property bool batteryBusy: false
    property string batteryError: ""
    readonly property int batterySlot: 2              // gem 3 of 5, counting from 1
    // ── System resources, on gem 4 ────────────────────────────────────────────
    // RAM, swap, storage and the heaviest processes. Written only by the adapter
    // message below; every optional field is null when the source had nothing,
    // and the panel simply does not draw that row.
    property var resources: ({ available:false, ram:null, swap:null, disks:[], diskPercent:null,
                               diskTarget:"", processes:[], error:"" })
    property string resourcesStatus: "disconnected"    // connected | connecting | disconnected
    readonly property bool resourcesOpen: activePanel==="resources"
    property bool resourcesBusy: false
    property string resourcesError: ""
    readonly property int resourcesSlot: 3            // gem 4 of 5, counting from 1
    // Any system list is open: the centre sphere shows that list instead of the clock.
    readonly property bool systemListOpen: wifiOpen || bluetoothOpen || batteryOpen || resourcesOpen || organizerOpen
    // Central visual state for the main orb: "connected" | "connecting" | "disconnected".
    // Written in exactly one place (syncWifiStatus) from the adapter's NetworkManager
    // reading; the orb only ever reads it. Nothing here infers the state from an icon.
    property string wifiStatus: "disconnected"
    // True between a user action and the adapter's answer, so an attempt shows gold
    // immediately and can never stay gold if the answer never arrives.
    property bool wifiPending: false
    readonly property string wifiReason: String(wifi.reason || "")
    readonly property bool wifiOpen: activePanel==="wifi"
    // ── the file organizer, on ORB 3 ─────────────────────────────────────────
    // The panel is a view over `jarvis-organize` and nothing else: it holds the
    // last JSON the backend printed, the view it is showing, and the progress of
    // a run. It never touches a file — every decision is the backend's.
    property var organizer: ({})                 // last scan/run summary
    property var organizerStatus: ({})           // folders, auto, schedule, undo
    readonly property bool organizerOpen: activePanel==="organize"
    property bool organizerBusy: false
    property real organizerRing: -1              // 0…1 while files are moving
    property int organizerMoved: 0
    property int organizerTotal: 0
    property string organizerView: "categories"  // categories | files | folders
    property string organizerCategory: ""
    property string organizerPrompt: ""          // "" | "folder" | "central"
    property string organizerError: ""
    // The panel asks the shell to run a command; the shell owns the process.
    signal organizerRequest(string command, var args)
    property bool wifiBusy: false
    property string wifiPasswordSsid: ""
    property string wifiPasswordSecurity: ""
    property string wifiError: ""
    readonly property bool wifiConnected: !!(wifi.active && wifi.active.ssid)
    readonly property bool wifiPanelOpen: wifiOpen
    // The device currently connected (if any) — drives the orb's tint and the
    // "Connected to …" line, exactly like wifiConnected does for Wi-Fi.
    function bluetoothConnectedDevice() {
        var list=bluetooth.devices || [];
        for(var i=0;i<list.length;i++) if(list[i] && list[i].connected) return list[i];
        return null;
    }
    function bluetoothDeviceCount() { return (bluetooth.devices || []).length; }
    // ── battery helpers ──────────────────────────────────────────────────────
    readonly property bool batteryPresent: battery.present===true;
    readonly property int batteryLevel: battery.percent===null || battery.percent===undefined
                                        ? -1 : Math.max(0, Math.min(100, Math.round(battery.percent)))
    // Colour language: emerald while charging or full, amber below 30, crimson
    // below 15 — the same three tints the orb palette already uses.
    readonly property color batteryAccent: !batteryPresent ? "#8496a8"
        : battery.state==="charging" || battery.state==="full" ? "#55F49A"
        : batteryLevel>=0 && batteryLevel<15 ? "#FF7777"
        : batteryLevel>=0 && batteryLevel<30 ? "#FFD36A"
        : "#55F49A"
    readonly property color batteryTint: !batteryPresent ? "#2a3440"
        : battery.state==="charging" || battery.state==="full" ? "#174D35"
        : batteryLevel>=0 && batteryLevel<15 ? "#552323"
        : batteryLevel>=0 && batteryLevel<30 ? "#59431C"
        : "#174D35"
    function batteryStateLabel() {
        // The empty state already says it in a full sentence; repeating "No
        // battery" here would be the same news twice, one line apart.
        if(!batteryPresent) return "";
        if(battery.state==="charging") return "Charging";
        if(battery.state==="full") return "Full";
        if(battery.state==="not-charging") return "Not charging";
        if(battery.state==="discharging") return "Discharging";
        return "Battery";
    }
    function batteryClock(seconds) {
        // "2 h 10 min" / "48 min" / "less than a minute" — never "0 h 0 min".
        if(seconds===null || seconds===undefined || seconds<=0) return "";
        var m=Math.round(seconds/60);
        if(m<1) return "less than a minute";
        if(m<60) return m+" min";
        var h=Math.floor(m/60), r=m%60;
        return r===0 ? h+" h" : h+" h "+r+" min";
    }
    function batteryTimeText() {
        if(!batteryPresent) return "";
        if(battery.state==="charging") {
            var toFull=batteryClock(battery.timeToFull);
            return toFull ? toFull+" to full" : "";
        }
        if(battery.state==="discharging") {
            var toEmpty=batteryClock(battery.timeToEmpty);
            return toEmpty ? toEmpty+" to empty" : "";
        }
        return "";
    }
    function batteryLine() {
        // "Charging · 1 h 12 min to full" — the dot only appears when there is
        // a second half to join.
        var time=batteryTimeText();
        return time ? batteryStateLabel()+" · "+time : batteryStateLabel();
    }
    function batteryProfileLabel(name) {
        return name==="power-saver" ? "Saver"
             : name==="performance" ? "Performance"
             : name==="balanced" ? "Balanced" : name;
    }
    function batteryValue(value, suffix, decimals) {
        // One formatter so every readout hides itself the same way.
        if(value===null || value===undefined || value==="") return "";
        var number=Number(value);
        if(isNaN(number)) return "";
        var text=decimals>0 ? number.toFixed(decimals) : String(Math.round(number));
        return suffix ? text+" "+suffix : text;
    }
    // How many networks the last scan found: the header's "on · N". A push that
    // carries no list keeps the previous rows, so the count never flickers to 0.
    readonly property int wifiNetworkCount: (wifi.networks || []).length
    // True while a scan is running, so the panel can say "Scanning…" and the orb
    // can pulse without anyone guessing.
    readonly property bool bluetoothPanelOpen: bluetoothOpen
    readonly property bool batteryPanelOpen: batteryOpen
    readonly property bool resourcesPanelOpen: resourcesOpen
    // 0–100 RAM / system-disk, and the pair the header prints as "RAM 62% · Disk 48%".
    readonly property int ramPercent: (resources.ram && resources.ram.percent!==null
                                       && resources.ram.percent!==undefined) ? resources.ram.percent : -1
    readonly property int diskPercent: (resources.diskPercent!==null && resources.diskPercent!==undefined)
                                       ? resources.diskPercent : -1
    // The orb speaks with the worst of the two: a full disk matters even when RAM is idle.
    readonly property int systemPercent: Math.max(ramPercent, diskPercent)
    readonly property bool resourcesAvailable: resources.available===true
    readonly property bool hasSwap: !!(resources.swap && resources.swap.total)
    readonly property var systemDisks: (resources.disks || []).slice(0, 4)
    // Under 60 % emerald, 60–85 % amber, above 85 % crimson — the panel and the
    // orb share this one function, so they can never disagree.
    function usageAccentFor(p) {
        if(p===null || p===undefined || p<0) return "#8496a8";
        if(p>85) return "#FF7777";
        if(p>=60) return "#FFD36A";
        return "#55F49A";
    }
    function usageTintFor(p) {
        if(p===null || p===undefined || p<0) return "#2a3440";
        if(p>85) return "#552323";
        if(p>=60) return "#59431C";
        return "#174D35";
    }
    readonly property color resourcesAccent: usageAccentFor(systemPercent)
    readonly property color resourcesTint: usageTintFor(systemPercent)
    function gibText(value) {
        // "31.2" / "465" — one decimal until the number gets long.
        if(value===null || value===undefined) return "—";
        return value>=100 ? String(Math.round(value)) : Number(value).toFixed(1);
    }
    function systemStatusText() {
        if(!resourcesAvailable) return resourcesBusy ? "reading…" : "unavailable";
        var ram=ramPercent>=0 ? "RAM "+ramPercent+"%" : "RAM —";
        var disk=diskPercent>=0 ? "Disk "+diskPercent+"%" : "";
        return disk.length>0 ? ram+" · "+disk : ram;
    }
    // ── panel data ────────────────────────────────────────────────────────────
    // Every panel is a list of rows, a value, or a placeholder — nothing here
    // knows where anything is drawn. PanelFrame owns the structure, so these
    // functions can only ever change *what* a panel says, never how it looks.
    function wifiRows() {
        var list=wifi.networks || [], out=[];
        for(var i=0;i<list.length;i++) {
            var n=list[i]; if(!n || !n.ssid) continue;
            out.push({ ssid:n.ssid, title:n.ssid,
                       subtitle:n.inUse ? "Connected"
                                : n.saved ? "Saved"
                                : n.secure ? "Password needed" : "Open",
                       glyph:"wifi",
                       level:Math.max(0, Math.min(4, Math.round((n.signal || 0)/25))),
                       tone:n.inUse ? "good" : (n.saved ? "neutral" : "neutral"),
                       inUse:n.inUse===true,
                       badge:n.secure ? "lock" : "",
                       // what chooseWifi() needs, carried through the row
                       secure:n.secure===true, saved:n.saved===true, label:n.label || "" });
        }
        return out;
    }
    function wifiActions() {
        return [{ label:wifi.scanning ? "Scanning…" : "Scan", name:"scan", objectName:"wifiScanChip" },
                { label:wifi.radioOn ? "Wi-Fi off" : "Wi-Fi on", name:"radio",
                  objectName:"wifiRadioChip", active:wifi.radioOn===true },
                { label:"Disconnect", name:"disconnect", objectName:"wifiDisconnectChip",
                  visible:root.wifiConnected }];
    }
    function wifiPanelAction(name) {
        if(name==="scan") root.refreshWifi();
        else if(name==="radio") root.setWifiRadio(!(root.wifi.radioOn===true));
        else if(name==="disconnect") root.disconnectWifi();
    }
    function wifiStatusLine() {
        if(String(wifiError || "").length>0) return wifiError;
        if(String(wifi.error || "").length>0) return wifi.error;
        if(!wifi.available) return "NetworkManager is not available on this system";
        if(wifiConnected) return "Connected to "+wifi.active.ssid;
        if(!wifi.radioOn) return "Wi-Fi is switched off";
        return "Choose a network";
    }
    function wifiEmptyText() {
        var problem=String(wifi.problem || "");
        return wifi.scanning===true ? "Scanning…"
             : !wifi.available ? "NetworkManager (nmcli) is not installed."
             : problem.length>0 ? problem
             : !wifi.radioOn ? "Wi-Fi is switched off. Press Wi-Fi on."
             : "No networks visible yet. Press Scan.";
    }
    function wifiEmptyHint() {
        var detail=String(wifi.detail || "");
        if(detail.length>0) return "nmcli said: "+detail;
        return wifi.radioOn ? "Scan again, or move closer to the access point."
                            : "The radio is off, so nothing can be seen.";
    }
    function bluetoothRows() {
        var list=bluetooth.devices || [], out=[];
        for(var i=0;i<list.length;i++) {
            var d=list[i]; if(!d || !d.address) continue;
            out.push({ address:d.address, title:d.label || d.name || d.address,
                       subtitle:d.connected ? "Connected"
                                : d.paired ? (d.trusted ? "Paired · trusted" : "Paired")
                                : "Tap to pair & connect",
                       glyph:d.kind || "other",
                       level:-1,
                       tone:d.connected ? "good" : "neutral",
                       inUse:d.connected===true,
                       badge:d.connected ? "bluetooth" : "",
                       paired:d.paired===true, trusted:d.trusted===true });
        }
        return out;
    }
    function bluetoothActions() {
        return [{ label:root.bluetooth.scanning ? "Scanning…" : "Scan", name:"scan",
                  objectName:"bluetoothScanChip" },
                { label:root.bluetooth.powered ? "Power off" : "Power on", name:"power",
                  objectName:"bluetoothPowerChip", active:root.bluetooth.powered===true }];
    }
    function bluetoothPanelAction(name) {
        if(name==="scan") root.scanBluetooth();
        else if(name==="power") root.setBluetoothPower(!(root.bluetooth.powered===true));
    }
    function bluetoothStatusLine() {
        if(String(bluetoothError || "").length>0) return bluetoothError;
        if(!bluetooth.available) return "Bluetooth is not available";
        if(bluetooth.blocked && bluetooth.blockedHard) return "Bluetooth is blocked";
        if(!bluetooth.adapter) return "No Bluetooth adapter";
        if(!bluetooth.powered) return "Bluetooth is off";
        var device=root.bluetoothConnectedDevice();
        return device ? ("Connected to "+device.label) : "Choose a device";
    }
    function bluetoothEmptyText() {
        return root.bluetooth.pending ? "Reading the adapter…"
             : !bluetooth.available ? "Bluetooth is not available on this system."
             : bluetooth.blocked && bluetooth.blockedHard ? "The adapter is hard-blocked, so nothing can be listed."
             : !bluetooth.adapter ? "No adapter was found, so there is nothing to list."
             : !bluetooth.powered ? "Bluetooth is off. Press Power on to list devices."
             : String(root.bluetoothError || "").length>0 ? root.bluetoothError
             : String(bluetooth.error || "").length>0 ? bluetooth.error
             : "No devices visible yet. Press Scan.";
    }
    function batteryTone() {
        if(!batteryPresent) return "bad";
        if(battery.state==="charging" || battery.state==="full") return "good";
        if(batteryLevel>=0 && batteryLevel<15) return "bad";
        if(batteryLevel>=0 && batteryLevel<30) return "warn";
        return "good";
    }
    function batteryValueSub() { return ""; }
    function batteryStats() {
        // Only the numbers the driver actually reported: no "N/A" anywhere.
        var out=[], draw=batteryValue(battery.watts, "W", 1);
        if(draw.length>0) out.push({label:"Draw", value:draw});
        var health=(battery.health && battery.health.percent) ? battery.health.percent+"%" : "";
        if(health.length>0) out.push({label:"Health", value:health});
        var cycles=batteryValue(battery.cycles, "", 0);
        if(cycles.length>0) out.push({label:"Cycles", value:cycles});
        var volts=batteryValue(battery.voltage, "V", 1);
        // At the smallest orb the grid shows what is actionable first: voltage
        // and cycles step aside before draw and health do.
        if(volts.length>0 && !batteryPanel.compact) out.push({label:"Voltage", value:volts});
        if(batteryPanel.compact && out.length>2) out=out.slice(0,2);
        return out;
    }
    function batterySegments() {
        var list=battery.profiles || [], out=[];
        for(var i=0;i<list.length;i++)
            out.push({ label:root.batteryProfileLabel(list[i]), value:list[i],
                       active:battery.profile===list[i] });
        return out;
    }
    function batteryActions() { return []; }
    function batteryPanelAction(name) {
        if(name==="refresh") root.refreshBattery(false);
    }
    function systemUsedText() {
        return resources.ram
             ? root.gibText(resources.ram.used)+" / "+root.gibText(resources.ram.total)+" GiB"
             : "";
    }
    function usageToneFor(p) { return p>85 ? "bad" : (p>=60 ? "warn" : "good"); }
    function systemBars() {
        var out=[];
        if(hasSwap && resources.swap && resources.swap.total)
            out.push({ label:"Swap",
                       detail:root.gibText(resources.swap.used)+" / "+root.gibText(resources.swap.total)+" GiB",
                       value:(resources.swap.percent===null || resources.swap.percent===undefined) ? ""
                             : resources.swap.percent+"%",
                       progress:(resources.swap.percent || 0)/100,
                       tone:root.usageToneFor(resources.swap.percent || 0) });
        var disks=systemDisks;
        for(var i=0;i<disks.length;i++) {
            var d=disks[i];
            // a mount on the same volume as / is a sub-line, not a second bar
            if(d.shared===true) {
                out.push({ label:"↳ "+d.target, detail:"same volume as /", value:"",
                           progress:-1, tone:"neutral" });
                continue;
            }
            out.push({ label:d.target,
                       detail:(d.used===undefined ? "" : root.gibText(d.used)+" / "+root.gibText(d.total)+" GiB"),
                       value:(d.percent===null || d.percent===undefined) ? "" : d.percent+"%",
                       progress:(d.percent || 0)/100,
                       tone:root.usageToneFor(d.percent || 0) });
        }
        return out;
    }
    function systemTags() {
        var list=resources.processes || [], out=[];
        for(var i=0;i<list.length && i<3;i++)
            out.push(list[i].name+" · "+root.gibText(list[i].rss)+" GiB");
        return out;
    }
    function systemActions() { return []; }
    function resourcesPanelAction(name) {
        if(name==="refresh") root.refreshResources(false);
    }
    // ═══ THE PANEL STATE MACHINE ══════════════════════════════════════════════
    // Six orbs, one panel, one truth. A panel is shown by setting `activePanel`
    // to its key; nothing else about "open" is written anywhere. Two timers own
    // all the timing (hover intent, leave grace) so a switch can never race a
    // close, and no panel carries its own open/close animation any more — the
    // frame you see simply crossfades while the orb behind it never changes.
    //
    //   hoverEnter/hoverLeave  ← the only writers of `hoveredAreas`
    //   hoverIntentFired       ← 70 ms after the last orb the pointer settled on
    //   leaveGraceFired        ← 280 ms after the pointer left every area
    // Gem index → the panel that gem owns. The table is `gemSpecs`, so hover,
    // click and IPC all read one list.
    function panelKeyAt(index) { return root.gemKey(index); }
    function dbg(message) { if(root.debugHover) console.log("[sphere] "+message); }
    function activePanelFrame() {
        // The frame that is on screen, without a second copy of the state: it is
        // whatever `activePanel` names. Used for one question only — is a prompt,
        // a focused field or a press owning the orb right now?
        var key=root.activePanel;
        if(key==="wifi") return typeof wifiPanel!=="undefined" ? wifiPanel : null;
        if(key==="bluetooth") return typeof bluetoothPanel!=="undefined" ? bluetoothPanel : null;
        if(key==="battery") return typeof batteryPanel!=="undefined" ? batteryPanel : null;
        if(key==="resources") return typeof resourcesPanel!=="undefined" ? resourcesPanel : null;
        if(key==="organize") return typeof organizerPanel!=="undefined" ? organizerPanel : null;
        return null;
    }

    function hoverEnter(area, key, index) {
        // The pointer entered a hover area. `key` is the panel that area owns
        // ("" = a keep-alive area: the main orb, the open panel's own surface).
        if(!root.hoverActive) return;
        var areas=root.hoveredAreas;
        if(areas[area]===true) return;
        areas[area]=true;
        root.hoveredAreas=areas;                  // reassignment is what notifies
        leaveTimer.stop();                   // coming back cancels the grace
        root.clearWhenFree=false;
        root.dbg("hover in "+area+(key.length>0?" → "+key:" (keep)"));
        if(key.length===0) return;                // keep-alive only
        if(root.suppressArea===area) { root.dbg("suppressed until the pointer leaves "+area); return; }
        if(root.pinned && root.pinOnClick) { root.dbg("pinned: hover does not steal it"); return; }
        if(key===root.activePanel) { hoverIntent.stop(); root.hoverPending=false; root.pendingPanel=""; return; }
        root.activeLatched=false;                 // the mouse has taken over from IPC
        root.pendingPanel=key;
        root.hoverPending=true;
        hoverIntent.restart();               // 70 ms of intent, on the NEWEST orb
    }
    function hoverLeave(area) {
        var areas=root.hoveredAreas;
        if(areas[area]!==true) return;
        delete areas[area];
        root.hoveredAreas=areas;
        root.dbg("hover out "+area);
        if(root.suppressArea===area) root.suppressArea="";
        if(root.hoverAreaCount()>0) return;       // still inside some other area
        root.hoverPending=false;root.pendingPanel="";
        hoverIntent.stop();
        if(root.pinned) { root.dbg("pinned: leave ignored"); return; }
        if(root.activePanel==="") return;
        leaveTimer.restart();                // 280 ms of grace, then fade
    }
    function hoverAreaCount() {
        var n=0;
        for(var key in root.hoveredAreas) if(root.hoveredAreas[key]===true) n++;
        return n;
    }
    function hoverIntentFired() {
        var key=root.pendingPanel;
        root.hoverPending=false;
        if(key==="" || key===root.activePanel || root.pinned) return;
        // A prompt, a focused field or a press owns the orb: the intent waits.
        if(root.autoClearBlocked) { root.dbg("intent held by a dialog/prompt"); return; }
        root.pendingPanel="";
        root.showPanel(key, "hover", false);
    }
    function leaveGraceFired() {
        if(root.activePanel==="") return;
        if(root.autoClearBlocked) { root.clearWhenFree=true;root.dbg("grace held by a dialog/prompt"); return; }
        root.clearPanel("leave");
    }
    onAutoClearBlockedChanged: {
        // The dialog/prompt/press is over: pick up exactly where we were.
        if(root.autoClearBlocked) return;
        if(root.clearWhenFree) {
            root.clearWhenFree=false;
            if(root.hoverAreaCount()===0 && !root.pinned) { root.dbg("dialog closed: resuming the leave"); leaveTimer.restart(); }
        } else if(root.pendingPanel!=="") {
            root.dbg("dialog closed: resuming the hover"); hoverIntent.restart();
        }
    }

    // ── showing, releasing, clearing ────────────────────────────────────────
    function showPanel(key, source, pin) {
        if(key===root.activePanel) {
            if(pin===true) { root.pinned=true;root.activeLatched=false;root.startUfoDock(root.gemIndexOf(key));root.dbg("panel pinned ("+source+")"); }
            return;
        }
        var previous=root.activePanel;
        if(previous.length>0) root.retirePanel(previous);
        root.activePanel=key;
        root.activeSource=source;
        root.pinned=(pin===true);
        root.activeLatched=(pin!==true);
        root.clearWhenFree=false;
        root.hoverPending=false;root.pendingPanel="";
        hoverIntent.stop();leaveTimer.stop();
        if(root.pinned) root.startUfoDock(root.gemIndexOf(key));
        root.enterPanel(key);
        root.dbg("panel "+key+" ("+source+(root.pinned?", pinned":", transient")+")");
    }
    function retirePanel(key) {
        // What a panel used to do in its own closeX(): stop what it started and
        // forget its transient input. It never touches the orb or the frame.
        if(key==="wifi") {
            root.wifiPasswordSsid="";root.wifiPasswordSecurity="";root.wifiError="";root.wifiBusy=false;
            wifiScanTimeout.stop();
            if(root.connected) root.emitRequest({action:"wifiPanel",open:false});
        } else if(key==="bluetooth") {
            root.bluetoothError="";root.bluetoothBusy=false;root.bluetoothScanning=false;
            bluetoothBusyTimer.stop();bluetoothScanPoll.stop();
            if(root.connected && root.bluetooth.scanning) root.emitRequest({action:"bluetoothScanStop"});
            root.syncBluetoothStatus();
        } else if(key==="battery") {
            root.batteryError="";root.batteryBusy=false;root.syncBatteryStatus();
        } else if(key==="resources") {
            root.resourcesError="";root.resourcesBusy=false;root.syncResourcesStatus();
        } else if(key==="organize") {
            root.organizerPrompt="";root.organizerBusy=false;root.organizerRing=-1;
        }
    }
    function enterPanel(key) {
        // What a panel used to do in its own openX(): ask the adapter for fresh
        // data. The panel itself is already loaded — nothing is created here.
        if(key==="wifi") {
            root.wifiError="";
            if(!root.connected) { root.wifiError="The local desktop adapter is not connected yet.";return; }
            root.wifiBusy=true;wifiScanTimeout.restart();
            root.emitRequest({action:"wifiPanel",open:true});
        } else if(key==="bluetooth") {
            root.bluetoothError="";
            if(!root.connected) { root.bluetoothError="The local desktop adapter is not connected yet.";return; }
            root.bluetoothBusy=true;bluetoothBusyTimer.restart();
            root.emitRequest({action:"bluetooth"});
        } else if(key==="battery") {
            root.batteryError="";
            if(!root.connected) { root.batteryError="The local desktop adapter is not connected yet.";return; }
            root.batteryBusy=true;root.emitRequest({action:"battery"});
        } else if(key==="resources") {
            root.resourcesError="";
            if(!root.connected) { root.resourcesError="The local desktop adapter is not connected yet.";return; }
            root.resourcesBusy=true;root.syncResourcesStatus();root.emitRequest({action:"resources"});
        } else if(key==="organize") {
            root.organizerError="";root.organizerView="categories";root.organizerCategory="";root.organizerPrompt="";
            root.refreshOrganizer();
        }
    }
    function clearPanel(reason) {
        if(root.activePanel==="") { root.pinned=false;root.activeLatched=false;root.stopUfoDock();return; }
        var previous=root.activePanel;
        root.retirePanel(previous);
        root.activePanel="";
        root.pinned=false;root.activeLatched=false;root.activeSource="";
        root.stopUfoDock();
        root.clearWhenFree=false;root.hoverPending=false;root.pendingPanel="";
        hoverIntent.stop();leaveTimer.stop();
        root.dbg("panel cleared ("+reason+")");
    }
    function unpinPanel() {
        // Unpin, not close: if the pointer is still on the orb the panel stays
        // (the hover keeps it), and it leaves with the pointer after the grace.
        root.pinned=false;root.activeLatched=false;
        root.stopUfoDock();
        root.dbg("panel unpinned");
        if(root.hoverAreaCount()===0) leaveTimer.restart();
    }
    function gemActivated(index, area) {
        // A click on a gem. The gem that owns a panel pins it, and a second click
        // on that same gem closes it again — the one click that must still win
        // over the hover.
        var key=root.panelKeyAt(index);
        if(key==="") return;
        if(root.activePanel===key) {
            // Already showing because the pointer is on it: the first click freezes
            // that preview, the next one closes it. Closing under a pointer that is
            // still hovering would be undone 70 ms later, so the clicked area stays
            // suppressed until the pointer leaves it — that is what makes the
            // second click final instead of a flicker.
            if(!root.pinned) { root.pinned=true;root.activeLatched=false;root.suppressArea="";root.startUfoDock(index);root.dbg("preview pinned by click");return; }
            root.suppressArea=(area && area.length>0) ? area : ("orb:"+index);
            root.clearPanel("click again");
            return;
        }
        root.suppressArea="";
        root.showPanel(key, "click", root.pinOnClick);
    }

    // ═══ THE FILE ORGANIZER (ORB 3) ═══════════════════════════════════════════
    // Everything below is a view over `jarvis-organize`: it parses the JSON the
    // shell hands back, turns it into rows/actions for the shared frame, and
    // forwards taps as commands. No file logic lives in QML — not one rename, not
    // one mkdir — which is why the backend can be tested on its own.
    // The organizer is the fifth gem (FILES); there is no orb bookkeeping left:
    // the ring's five stones are the whole layout, so no slot is ever displaced.
    function openOrganizer() { root.showPanel("organize", "api", true); }
    function closeOrganizer() { if(root.organizerOpen) root.clearPanel("close"); }
    function toggleOrganizer() { if(organizerOpen) closeOrganizer(); else openOrganizer(); }
    // status first (folders, auto, undo), then the plan for the current folder
    function refreshOrganizer() {
        root.organizerRequest("status", []);
        var folder=root.organizerFolderPath();
        if(folder.length>0) { root.organizerBusy=true; root.organizerRequest("scan", [folder]); }
        else root.organizerBusy=true;
    }
    function organizerFolderPath() {
        var status=root.organizerStatus || {};
        return String(status.folder || "");
    }
    // ── JSON in, rows out ────────────────────────────────────────────────────
    function organizerMerge(base, patch) {
        var out={}, key;
        for(key in base) out[key]=base[key];
        for(key in patch) out[key]=patch[key];
        return out;
    }
    // One JSON object per line from the backend. Progress arrives many times; the
    // rest arrives once per command.
    function applyOrganizerLine(line) {
        var text=String(line || "").trim();
        if(text.length===0) return;
        var message=null;
        try { message=JSON.parse(text); } catch(error) { return; }
        if(!message || typeof message!=="object") return;
        var event=String(message.event || message.command || "");
        if(event==="progress") {
            root.organizerBusy=true;
            root.organizerRing=(Number(message.percent) || 0)/100;
            root.organizerMoved=Number(message.done) || 0;
            root.organizerTotal=Number(message.total) || 0;
            return;
        }
        if(message.ok===false) root.organizerError=String(message.error || "The file organizer reported a problem.");
        else if(event==="scan" || event==="done" || event==="undo" || event==="status" || event==="auto"
                || event==="schedule" || event==="folders" || event==="config")
            root.organizerError="";
        if(event==="scan") {
            root.organizerBusy=false;root.organizerRing=-1;root.organizerMoved=0;root.organizerTotal=0;
            if(message.ok) root.organizer=message;
            return;
        }
        if(event==="done") {
            root.organizerBusy=false;root.organizerRing=-1;
            root.organizer=root.organizerMerge(root.organizer || {}, message);
            root.organizerView="categories";root.organizerCategory="";
            root.organizerRequest("status", []);
            return;
        }
        if(event==="undo") {
            root.organizerBusy=false;root.organizerRing=-1;
            root.organizer=root.organizerMerge(root.organizer || {}, message);
            root.organizerView="categories";root.organizerCategory="";
            root.organizerRequest("status", []);
            root.organizerRequest("scan", [root.organizerFolderPath()]);
            return;
        }
        if(event==="rules") { root.organizerBusy=false; return; }
        // status / auto / schedule / folders / config all answer with the status
        // shape, so one merge keeps the panel consistent
        if(message.folders !== undefined) {
            root.organizerStatus=message;
            root.organizerBusy=false;
            if(event!=="auto" && event!=="schedule" && event!=="folders" && event!=="config") return;
            if(message.ok===false) return;
            if(event==="folders" || event==="config") root.refreshOrganizer();
        }
    }
    // the shell calls this when the process exits, so a crash cannot leave the
    // panel spinning forever
    function organizerFinished(code) {
        root.organizerBusy=false;
        if(Number(code)!==0 && root.organizerError.length===0)
            root.organizerError="The file organizer exited with code "+code+".";
        root.organizerRing=-1;
    }
    function organizerRowsAt() { return root.organizerRows(); }
    function organizerFileCount() {
        var data=root.organizer || {};
        return Number(data.files) || 0;
    }
    function organizerCategories() { return (root.organizer && root.organizer.categories) || []; }
    function organizerCategoryByName(name) {
        var list=root.organizerCategories();
        for(var i=0;i<list.length;i++) if(list[i] && list[i].name===name) return list[i];
        return null;
    }
    function organizerAutoOn() { return !!(root.organizerStatus && root.organizerStatus.auto); }
    function organizerShortPath(path) {
        var text=String(path || "");
        var home=String(root.organizerStatus && root.organizerStatus.home || "");
        if(home.length>0 && text.indexOf(home)===0) return "~"+text.substring(home.length);
        return text;
    }
    function organizerDisplayFolder() {
        var status=root.organizerStatus || {};
        return String(status.display || root.organizerShortPath(status.folder) || "~/Downloads");
    }
    // "~/Downloads · 42 FILES · AUTO OFF"
    // The header keeps the shortest true thing ("AUTO OFF"), because the title
    // "FILE ORGANIZER" needs the room; the long form is the status line below it,
    // exactly as specified: "~/Downloads · 42 FILES · AUTO OFF".
    function organizerStateLine() {
        if(root.organizerBusy && root.organizerRing>=0)
            return "MOVING "+root.organizerMoved+"/"+root.organizerTotal;
        // "SCANNING" only while nothing is known yet: once a count is on screen
        // the pill underneath says what is being scanned, and the header keeps
        // the switch instead of throwing that line away.
        if(root.organizerBusy && root.organizerFileCount()===0) return "SCANNING";
        return root.organizerAutoOn() ? "AUTO ON" : "AUTO OFF";
    }
    // the sentence in the pill under the title: "~/Downloads · 42 FILES · AUTO OFF"
    function organizerStatusLine() {
        if(root.organizerError.length>0) return root.organizerError;
        var data=root.organizer || {};
        var count=root.organizerFileCount();
        if(root.organizerBusy && root.organizerRing>=0)
            return "MOVING FILES · "+root.organizerMoved+"/"+root.organizerTotal;
        if(data.event==="done" && Number(data.moved)>0)
            return "MOVED "+data.moved+" FILE"+(Number(data.moved)===1?"":"S")
                   +(data.undo_available?" · UNDO AVAILABLE":"");
        if(data.event==="undo") return String(data.message || "UNDONE").toUpperCase();
        // the specification's status line — kept whole while a scan is in flight,
        // because the count is still true and the sweep line already shows work.
        if(count>0 || !root.organizerBusy)
            return root.organizerDisplayFolder()+" · "+count+" FILE"+(count===1?"":"S")+" · "
                   +(root.organizerAutoOn() ? "AUTO ON" : "AUTO OFF");
        return root.organizerDisplayFolder()+" · SCANNING…";
    }
    function organizerMode() {
        if(root.organizerBusy && root.organizerRing>=0) return "value";
        if(root.organizerPrompt.length>0) return "list";
        if(root.organizerFileCount()===0
           && !(root.organizer && root.organizer.event==="done" && Number(root.organizer.moved)>0)) return "empty";
        return "list";
    }
    function organizerEmptyText() {
        if(root.organizerBusy) return "Scanning "+root.organizerDisplayFolder()+"…";
        if(root.organizerError.length>0) return root.organizerError;
        if(root.organizerFileCount()===0) return "ALL CLEAR";
        return "Nothing to organize";
    }
    function organizerEmptyHint() {
        if(root.organizerFileCount()===0)
            return "Every file in "+root.organizerDisplayFolder()+" already has a home. PREVIEW re-checks it.";
        return "PREVIEW scans, ORGANIZE NOW moves.";
    }
    function organizerRows() {
        var out=[], status=root.organizerStatus || {};
        if(root.organizerView==="files") {
            var category=root.organizerCategoryByName(root.organizerCategory);
            var files=(category && category.files) || [];
            out.push({ kind:"back", glyph:"back", title:"All categories",
                       subtitle:root.organizerCategory+" · "+files.length+" files",
                       tail:"‹", tone:"neutral" });
            for(var i=0;i<files.length;i++) {
                var file=files[i] || {};
                out.push({ kind:"file", glyph:"file", title:String(file.name || ""),
                           subtitle:root.organizerCategory+(file.renamed ? " · NAME TAKEN → RENAMED" : ""),
                           tail:String(file.size_h || ""),
                           tone:(file.renamed ? "warn" : "neutral") });
            }
            return out;
        }
        if(root.organizerView==="folders") {
            out.push({ kind:"back", glyph:"back", title:"File organizer",
                       subtitle:"Choose the folder to sort", tail:"‹" });
            var folders=(status.folders || []);
            for(var f=0;f<folders.length;f++) {
                out.push({ kind:"pickfolder", glyph:"folder", folder:String(folders[f]),
                           title:String(folders[f]), subtitle:(f===0 ? "sorting here" : "also available"),
                           tail:(f===0 ? "✓" : ""), inUse:(f===0), tone:"neutral" });
            }
            out.push({ kind:"quickfolder", glyph:"folder", folder:"~/Desktop",
                       title:"~/Desktop", subtitle:"quick pick", tail:"" });
            out.push({ kind:"quickfolder", glyph:"folder", folder:"~/Documents",
                       title:"~/Documents", subtitle:"quick pick", tail:"" });
            out.push({ kind:"addfolder", glyph:"plus", title:"Add a folder…",
                       subtitle:"Type an absolute path", tail:"+", tone:"neutral" });
            out.push({ kind:"togglesub", glyph:"folder",
                       title:"Include subfolders",
                       subtitle:(status.include_subfolders ? "On · nested files are sorted too" : "Off · top level only"),
                       tail:(status.include_subfolders ? "✓" : ""),
                       inUse:!!status.include_subfolders, tone:"neutral" });
            out.push({ kind:"central", glyph:"folder", title:"Central destination",
                       subtitle:(status.central && String(status.central).length>0
                                 ? String(status.central) : "Off · sort inside each folder"),
                       tail:(status.central && String(status.central).length>0 ? "✓" : ""),
                       inUse:!!(status.central && String(status.central).length>0), tone:"neutral" });
            out.push({ kind:"rules", glyph:"file", title:"Edit the rules…",
                       subtitle:"Categories, extensions, ignore list", tail:"›" });
            return out;
        }
        // categories: the folder row first, then one row per category, with the
        // share of the files as the bar under each
        out.push({ kind:"folder", glyph:"folder", title:root.organizerDisplayFolder(),
                   subtitle:"", dense:true, tail:"CHANGE", tone:"neutral" });
        var categories=root.organizerCategories();
        var total=Math.max(1, root.organizerFileCount());
        var ordered=categories.slice(0).sort(function(a,b){ return (b.count||0)-(a.count||0); });
        for(var c=0;c<ordered.length;c++) {
            var entry=ordered[c] || {};
            var count=Number(entry.count) || 0;
            out.push({ kind:"category", glyph:"file", category:String(entry.name || ""),
                       title:String(entry.name || "").toUpperCase(),
                       // dense: one line, the count as the tail, the share as the
                       // bar — ten categories have to fit, not two
                       subtitle:"", dense:true,
                       tail:count+" · "+String(entry.bytes_h || ""),
                       progress:count/total,
                       tone:(String(entry.name).toLowerCase()==="other" ? "warn" : "neutral") });
        }
        return out;
    }
    function organizerActions() {
        var data=root.organizer || {}, status=root.organizerStatus || {};
        var moving=root.organizerBusy && root.organizerRing>=0;
        // the done line already knows undo is possible; the status reply that
        // follows confirms it, so UNDO is live without waiting for that round trip
        var canUndo=!!(status.undo_available || data.undo_available);
        return [
            { label:"PREVIEW", labelShort:"SCAN", name:"preview", objectName:"organizerPreviewChip",
              disabled:root.organizerBusy },
            { label:"ORGANIZE NOW", labelShort:"SORT", name:"organize", objectName:"organizerRunChip",
              primary:true, disabled:root.organizerBusy || moving || root.organizerFileCount()===0 },
            { label:"UNDO", labelShort:"UNDO", name:"undo", objectName:"organizerUndoChip",
              disabled:root.organizerBusy || !canUndo },
            { label:(root.organizerAutoOn() ? "AUTO ON" : "AUTO OFF"), labelShort:"AUTO",
              name:"auto", objectName:"organizerAutoChip", active:root.organizerAutoOn() },
            { label:"RULES", labelShort:"RULES", name:"rules", objectName:"organizerRulesChip" }
        ];
    }
    // the panel title, from the frame's own measurement
    function organizerPanelTitle() {
        // the frame is addressed by its id inside its own file; from the widget we
        // read the same measurement it uses, so the title never guesses
        var side=root.orbRadius*0.70*Math.SQRT2*0.935;
        return side<150 ? "FILES" : "FILE ORGANIZER";
    }
    function organizerAction(name) {
        var status=root.organizerStatus || {};
        var folder=root.organizerFolderPath();
        if(name==="preview") { root.organizerBusy=true; root.organizerRequest("scan", [folder]); }
        else if(name==="organize") { root.organizerBusy=true; root.organizerMoved=0; root.organizerTotal=root.organizerFileCount();
                                     root.organizerRing=0; root.organizerRequest("run", [folder]); }
        else if(name==="undo") { root.organizerBusy=true; root.organizerRequest("undo", []); }
        else if(name==="auto") {
            var next=root.organizerAutoOn() ? "off" : "on";
            root.organizerRequest("auto", [next]);
        }
        else if(name==="rules") root.organizerRequest("rules", ["--open"]);
    }
    function organizerRow(item) {
        if(!item || !item.kind) return;
        var kind=String(item.kind);
        if(kind==="category") {
            root.organizerCategory=String(item.category || "");root.organizerView="files";return;
        }
        if(kind==="back") { root.organizerView="categories";root.organizerCategory="";return; }
        if(kind==="folder") { root.organizerView="folders";return; }
        if(kind==="pickfolder") {
            root.organizerRequest("folders", ["set", String(item.folder || "")]);
            root.organizerView="categories";return;
        }
        if(kind==="quickfolder") {
            root.organizerRequest("folders", ["add", String(item.folder || "")]);
            root.organizerView="categories";return;
        }
        if(kind==="addfolder") { root.organizerPrompt="folder";return; }
        if(kind==="central") { root.organizerPrompt="central";return; }
        if(kind==="togglesub") {
            var status=root.organizerStatus || {};
            root.organizerRequest("config", ["set","include_subfolders",
                (status.include_subfolders ? "false" : "true")]);
            return;
        }
        if(kind==="rules") root.organizerRequest("rules", ["--open"]);
    }
    function organizerPromptAccept(text) {
        var value=String(text || "").trim();
        var what=root.organizerPrompt;
        root.organizerPrompt="";
        if(value.length===0) return;
        if(what==="central") root.organizerRequest("config", ["set","central",value]);
        else if(what==="folder") root.organizerRequest("folders", ["add",value]);
    }
    readonly property rect wifiPanelRect: Qt.rect(wifiPanel.x, wifiPanel.y, wifiPanel.width, wifiPanel.height)
    readonly property rect bluetoothPanelRect: Qt.rect(bluetoothPanel.x, bluetoothPanel.y, bluetoothPanel.width, bluetoothPanel.height)
    readonly property rect batteryPanelRect: Qt.rect(batteryPanel.x, batteryPanel.y, batteryPanel.width, batteryPanel.height)
    readonly property rect resourcesPanelRect: Qt.rect(resourcesPanel.x, resourcesPanel.y, resourcesPanel.width, resourcesPanel.height)
    // The ring repaints only when its own clock moves.
    // ── the readings the rings carry ────────────────────────────────────────
    // CPU and RAM are sampled from /proc by SysStats on its own two-second beat;
    // shell.qml hands the bytes down (it owns the FileViews) and reloads them when
    // SysStats asks. Battery comes from the adapter's UPower reading, so the ring
    // and the battery panel can never disagree.
    property string procStat: ""
    property string procMem: ""
    signal statsPoll()
    SysStats {
        id: stats
        enabled: root.sphereVisible && !root.paused
        intervalMs: root.theme.statsPollMs
        smoothMs: root.theme.statsSmoothMs
        statText: root.procStat
        memText: root.procMem
        battery: root.batteryLevel >= 0 ? root.batteryLevel / 100 : 0
        batteryLive: root.batteryPresent && root.batteryLevel >= 0
        onPollRequested: root.statsPoll()
    }

    // ── the clock ───────────────────────────────────────────────────────────
    // shell.qml owns a Quickshell SystemClock at second precision, stopped while
    // the dashboard is hidden, and binds its date here once a second. Nothing in
    // this file polls a clock of its own — the core reads these three numbers.
    property var now: new Date()
    function dayNames() { return ["SUN","MON","TUE","WED","THU","FRI","SAT"]; }
    function monthNames() { return ["JAN","FEB","MAR","APR","MAY","JUN",
                                    "JUL","AUG","SEP","OCT","NOV","DEC"]; }
    // small caps, spelled here so the spelling does not follow the system locale
    // (the vocabulary is English: WI-FI, BLUETOOTH, BATTERY …)
    readonly property string dateText: root.dayNames()[root.now.getDay()] + " "
                                       + root.now.getDate() + " "
                                       + root.monthNames()[root.now.getMonth()]
    readonly property int clockHours: root.now.getHours()
    readonly property int clockMinutes: root.now.getMinutes()
    readonly property int clockSeconds: root.now.getSeconds()
    readonly property bool paused: snapshot.preferences.paused === true
    readonly property bool powerSave: snapshot.preferences.powerSave === true
    // LOW_POWER: static star, no shimmer, 30 fps. Forced by the preference, or
    // automatic when the machine is drawing under 30 % from its own cell.
    readonly property bool lowPower: powerSave
        || (lowPowerAuto && batteryPresent && String(battery.state || "") !== "charging"
            && String(battery.state || "") !== "full" && batteryLevel >= 0 && batteryLevel < 30)
    // PanelFrame's own spacing quantum is derived from orbRadius/200; `uiScale`
    // stays as the smallest-screen guard it always was (screen 900 px → 1.0).
    readonly property real uiScale: Math.max(.3, Math.min(width-40,height-140)/524)
    // ── the one measurement the centre is built from ─────────────────────────
    // Radius of the main orb's item. The glass sphere inside it is 70 % of this;
    // the aura, the hit regions and the Wi-Fi list are all derived from it, so
    // nothing at the centre can drift out of scale with the main orb.
    // The radius a panel is laid out for: the open disc. PanelFrame draws its
    // content circle inside this, so no type ever reflows while the rim grows.
    // (`shaders/` and `assets/sphere-artwork.png` are gone with the old glass.)
    readonly property real orbRadius: ringR * 0.70
    // Panels no longer carry their own type scale: PanelFrame derives one from
    // this same radius (u = orbRadius/200), so no panel can drift out of scale.
    // ── the orb's live palette, shared by the glass and everything inside it ─
    // mainOrb animates these two over 560 ms; every colour in the Wi-Fi list is
    // mixed from them, so the whole interior blends into the sphere and fades
    // with it (crimson → amber → emerald) instead of changing on its own.
    // The file organizer's one accent: the orb's body tint, rim and glow, the
    // folder-with-arrows glyph, and the panel the orb opens all come from here.
    readonly property color organizerAccent: "#ffb300"
    // the deep amber of the palette (the same tint the System orb uses when it
    // is in its amber state), so the ball is amber glass, not a colour of its own
    readonly property color organizerTint: "#59431C"
    // the palette a panel is painted in: its own gem's light, mixed in PanelFrame
    readonly property color listPaint: "#070b14"
    readonly property color listGlow: root.gemColorAt(root.gemIndexOf(root.activePanel))
    // semantic only — still mixed with the live accent where it is used
    readonly property color alertTint: "#ffd2c4"
    // ── THE CIRCLE ───────────────────────────────────────────────────────────
    // One measurement, R: 41 % of the smaller screen edge. The double ring is
    // drawn at R, the five gems orbit at 0.71 R, and the centre disc breathes
    // between 0.48 R (idle) and 0.70 R (a panel is showing). The band the
    // plates used to own (0.62–0.90 R) belongs to config/layout.json now.
    readonly property real ringR: Math.min(width, height) * 0.41
    readonly property real gemOrbit: ringR * geometry.gemOrbit
    readonly property real gemDiameter: ringR * geometry.gemDiameter
    readonly property int gemCount: gemSpecs.length
    // 0 = idle disc, 1 = expanded. The one animation the centre owns; the panels
    // crossfade inside it on their own clock (PanelFrame.switchMs).
    property real discOpen: activePanel === "" ? 0 : 1
    Behavior on discOpen { NumberAnimation { duration: 230; easing.type: Easing.OutCubic } }
    readonly property real discRadius: ringR * (0.48 + 0.22 * discOpen)
    // the open disc is what a panel is laid out for, so type never reflows while
    // the rim grows; PanelFrame draws its content circle inside this radius
    readonly property rect coreGeometry: Qt.rect(width/2-discRadius,height/2-discRadius,discRadius*2,discRadius*2)
    // Hit area of the centre: the disc plus its rim light. The shell reads this for
    // its own bookkeeping (`mainOrbRegion` for protocol compatibility).
    readonly property rect mainOrbRegion: Qt.rect(width/2-discRadius*1.06,height/2-discRadius*1.06,discRadius*2.12,discRadius*2.12)

    // ── the ring's geometry, in functions so nothing keeps a second copy ────
    function gemIndexOf(key) {
        for(var i=0;i<gemSpecs.length;i++) if(gemSpecs[i].panel===key) return i;
        return -1;
    }
    function gemKey(i) { return (i>=0 && i<gemSpecs.length) ? gemSpecs[i].panel : ""; }
    function gemColorAt(i) { return (i>=0 && i<gemSpecs.length) ? gemSpecs[i].color : "#F5B82E"; }
    // The centre is the Jarvis core now (JarvisCore.qml). The gem → centre
    // reflection that used to live in the old orb went with it, by request; the
    // the stones still light their own bridges and rays exactly as before.
    function gemGlyph(i) { return (i>=0 && i<gemSpecs.length) ? gemSpecs[i].glyph : "dot"; }
    // screen degrees: first gem at the top, clockwise. N gems, evenly spaced —
    // the same formula Geometry.qml derives config/layout.json's angles with.
    function gemAngle(i) { return -90 + 360*i/Math.max(1,gemCount); }
    function liveGemAngle(i) { return gemAngle(i) + root.orbitDeg; }
    function gemCenter(i) {
        var a=liveGemAngle(i)*Math.PI/180;
        return Qt.point(width/2+Math.cos(a)*gemOrbit, height/2+Math.sin(a)*gemOrbit);
    }
    // A gem's hit area is its bezel plus a little air: a plain rectangle centred
    // on the stone, computed from the geometry, never from the artwork.
    function gemRect(i) {
        var c=gemCenter(i), side=gemDiameter*1.18;
        return Qt.rect(c.x-side/2, c.y-side/2, side, side);
    }
    // The bridge from a gem to the disc: the pointer may travel one continuous
    // area from the stone to the centre, so a panel never closes on the way.
    function bridgeRect(i) {
        var c=gemCenter(i);
        return Qt.rect(Math.min(c.x,width/2), Math.min(c.y,height/2), Math.abs(c.x-width/2), Math.abs(c.y-height/2));
    }
    // is this point inside the disc (including the rim)? the centre is a hover
    // area of its own, and it must not steal the gems' area
    function insideDisc(x, y) {
        var dx=x-width/2, dy=y-height/2;
        return dx*dx+dy*dy <= discRadius*discRadius;
    }
    // ── colour helpers for anything that has to blend into the orb ───────────
    // Every colour inside the list is mixed from the orb's own *live* tint and
    // accent, so when the orb changes state (red → amber → emerald) the rows,
    // the text, the chips and the password field fade with it instead of
    // switching on their own.
    // An untyped QML function receives "#ffffff" as a *string*, so b.r is
    // undefined and the mix silently becomes NaN. `color` is not accepted as a
    // parameter type here, so literals are converted explicitly (QML hex order
    // is #AARRGGBB for eight digits).
    function toColor(v) {
        if (typeof v === "string") {
            var h = v.charAt(0) === "#" ? v.substr(1) : v;
            if (h.length === 6)
                return Qt.rgba(parseInt(h.substr(0,2),16)/255, parseInt(h.substr(2,2),16)/255,
                               parseInt(h.substr(4,2),16)/255, 1);
            if (h.length === 8)
                return Qt.rgba(parseInt(h.substr(2,2),16)/255, parseInt(h.substr(4,2),16)/255,
                               parseInt(h.substr(6,2),16)/255, parseInt(h.substr(0,2),16)/255);
        }
        return v;
    }
    function mixColor(a, b, t) {
        a = toColor(a); b = toColor(b);
        return Qt.rgba(a.r+(b.r-a.r)*t, a.g+(b.g-a.g)*t, a.b+(b.b-a.b)*t, a.a+(b.a-a.a)*t);
    }
    function withAlpha(c, alpha) { c = toColor(c); return Qt.rgba(c.r, c.g, c.b, alpha); }
    function emitRequest(message) {
        message.requestId=++serial;
        var pending=requests;pending[serial]=message.action;requests=pending;
        request(message);return serial;
    }
    function handleMessage(message) {
        if(message.type==="snapshot") { snapshot=message;connected=true;notice="Assignments saved locally · All workspaces";return; }
        if(message.type==="status") { nativeStatus=message;return; }
        if(message.type==="wifi") {
            // state pushes from `nmcli monitor` may omit the (expensive) network list:
            // merge them so the open list is never blanked by a background update.
            wifi=({ available:message.available!==false, radioOn:message.radioOn===true, active:message.active || null,
                    networks:message.networks!==undefined && message.networks!==null ? message.networks : (wifi.networks || []),
                    error:message.error || "", state:message.state || "", reason:message.reason || "",
                    scanning:message.scanning===true, problem:message.problem || "",
                    detail:message.detail || "", nm:message.nm || "" });
            wifiBusy=wifi.scanning;syncWifiStatus();
            if(message.error) wifiError=message.error;
            else if(message.connected) { wifiError="";notice="Connected to "+message.connected+"."; }
            else if(wifiOpen) wifiError="";
            return;
        }
        if(message.type==="battery") {
            battery=({ present:message.present===true && message.available!==false,
                       percent:message.percent===undefined ? null : message.percent,
                       state:message.state || "unknown",
                       timeToEmpty:message.timeToEmpty===undefined ? null : message.timeToEmpty,
                       timeToFull:message.timeToFull===undefined ? null : message.timeToFull,
                       watts:message.watts===undefined ? null : message.watts,
                       health:message.health || { full:null, design:null, percent:null },
                       cycles:message.cycles===undefined ? null : message.cycles,
                       voltage:message.voltage===undefined ? null : message.voltage,
                       profile:message.profile || "", profiles:message.profiles || [],
                       error:message.error || "" });
            batteryBusy=false;syncBatteryStatus();
            batteryError=(message.present===true) ? "" : (message.error || "No battery detected.");
            return;
        }
        if(message.type==="resources") {
            resources=({ available:message.available===true,
                         ram:message.ram || null, swap:message.swap || null,
                         disks:message.disks || [], diskPercent:message.diskPercent,
                         diskTarget:message.diskTarget || "",
                         processes:message.processes || [], error:message.error || "" });
            resourcesBusy=false;syncResourcesStatus();
            resourcesError=message.available===true ? (message.error || "") : (message.error || "System resources are unavailable.");
            return;
        }
        if(message.type==="bluetooth") {
            bluetooth=({ available:message.available!==false, powered:message.powered===true,
                          adapter:message.adapter || null, devices:message.devices || [],
                          blocked:message.blocked===true, blockedHard:message.blockedHard===true,
                          pending:message.pending===true,
                          scanning:message.scanning===true,
                          cli:message.cli || "",
                          error:message.error || "", detail:message.detail || "" });
            // The scan indicator follows the real process, and the poll below is
            // only there so a missed event can never leave "Scanning…" on screen.
            bluetoothScanning=bluetooth.scanning;
            bluetoothBusy=false;bluetoothBusyTimer.stop();
            if(bluetoothScanning) bluetoothScanPoll.restart(); else bluetoothScanPoll.stop();
            syncBluetoothStatus();
            if(message.error) bluetoothError=message.error;
            else if(bluetoothOpen) bluetoothError="";
            if(message.connectedTo) notice="Bluetooth: connected to "+message.connectedTo+".";
            return;
        }
        if(message.type!=="response") return;
        var action=requests[message.requestId];delete requests[message.requestId];
        if(!message.ok) {
            if(String(action||"").indexOf("wifi")===0) {
                wifiBusy=false;wifiPending=false;wifiPendingTimeout.stop();
                wifiError=message.error || "The Wi-Fi action failed.";
                // A refused action leaves us disconnected: say so in the glass too.
                if(wifiStatus==="connecting") wifiStatus=wifiConnected?"connected":"disconnected";
                return;
            }
            errorText=message.error || "The desktop action could not be completed.";
            notice=errorText;
            return;
        }
        var result=message.result || {};
        if(result.type==="wifi") {
            wifi=({ available:result.available!==false, radioOn:result.radioOn===true, active:result.active || null,
                    networks:result.networks!==undefined && result.networks!==null ? result.networks : (wifi.networks || []),
                    error:result.error || "", state:result.state || "", reason:result.reason || "",
                    scanning:result.scanning===true, problem:result.problem || "",
                    detail:result.detail || "", nm:result.nm || "" });
            wifiBusy=wifi.scanning;syncWifiStatus();
            if(result.connected) { wifiError="";notice="Connected to "+result.connected+"."; }
            return;
        }
        if(result.type==="snapshot") { snapshot=result;connected=true;notice="Saved locally. Workspace switching does not reset your orbs."; }
        if(result.launched) notice=result.focusedExisting?"Focused the existing application window.":"Application launch requested.";
    }
    function trackDiscHover(p) {
        // One question, asked of the pointer's own position: is it over the disc?
        if(insideDisc(p.x, p.y)) { if(!discHover.inside) { discHover.inside=true;hoverEnter("disc", "", -1); } }
        else leaveDiscHover();
    }
    function leaveDiscHover() {
        if(!discHover.inside) return;
        discHover.inside=false;
        hoverLeave("disc");
    }
    function backgroundClicked(x, y) {
        // Empty space absorbs the click: it releases the pin and clears the panel,
        // and otherwise keeps the dashboard up (Escape dismisses it). A click on
        // the disc itself is not empty space — it keeps what the disc is showing.
        if(typeof x==="number" && insideDisc(x, y)) { forceActiveFocus();return; }
        if(activePanel!=="") { clearPanel("background");return; }
    }
    function setInteraction(enabled) {
        // Kept so the manager's IPC calls keep working. Input is no longer opt-in:
        // nothing here closes a panel or disarms an orb any more.
        interactionEnabled=enabled;hoveredSlot=-1;
    }
    function setSphereVisible(visible) {
        sphereVisible=visible;
        if(!visible) { presence=0;dismissing=false;
                       clearPanel("hidden");wifiPasswordSsid="";hoveredAreas=({});hoveredSlot=-1;
                       notice="Sphere hidden. Press SUPER+A to bring it back."; }
    }
    // ── enter / leave, in the order that keeps input alive ────────────────────
    // Enter: the surface is mapped first (full-screen mask + exclusive keyboard
    // focus at once), then the glass fades in.
    function summon() {
        dismissing=false;dismissTimer.stop();
        if(!sphereVisible) setSphereVisible(true);
        presence=1;
        forceActiveFocus();
    }
    // Leave: the glass fades out while the surface still owns the pointer, and
    // only when the fade is over does the surface unmap — so nothing under it can
    // be clicked "through" a dashboard that is still on screen.
    function beginDismiss() {
        if(dismissing) return;
        dismissing=true;presence=0;
        dismissTimer.restart();
    }
    Timer {
        id:dismissTimer;interval:190;repeat:false
        onTriggered:{ root.sphereVisible=false;root.dismissing=false;root.dismissFinished(); }
    }
    // ── Wi-Fi actions ────────────────────────────────────────────────────────
    // A passphrase typed here is sent once to the local adapter, which hands it to
    // NetworkManager through a 0600 passwd-file; Sphere never stores or logs it.
    // ── Wi-Fi status ─────────────────────────────────────────────────────────
    function syncWifiStatus() {
        var reported = String(wifi.state || "");
        if(reported==="connected" || reported==="connecting" || reported==="disconnected") wifiStatus=reported;
        else wifiStatus=wifiConnected ? "connected" : "disconnected";
        if(wifiStatus!=="connecting") { wifiPending=false;wifiPendingTimeout.stop(); }
    }
    function beginWifiAction() {
        // Optimistic gold the moment the user asks, until NetworkManager answers.
        wifiPending=true;wifiStatus="connecting";wifiError="";wifiPendingTimeout.restart();
    }
    function syncBatteryStatus() {
        // The orb's palette: charging and full are emerald, a running read is
        // amber, everything else is the resting colour.
        batteryStatus = batteryBusy ? "connecting"
                      : (!batteryPresent) ? "disconnected"
                      : (battery.state==="charging" || battery.state==="full") ? "connected"
                      : "disconnected";
    }
    function openBattery() { root.showPanel("battery", "api", true); }
    function closeBattery() { if(root.batteryOpen) root.clearPanel("close"); }
    function toggleBattery() { if(batteryOpen) closeBattery(); else openBattery(); }
    function refreshBattery(silent) {
        // The watcher already pushes plug/unplug events; this is the periodic
        // read that keeps % and time estimates honest. `silent` keeps the header
        // from blinking "reading…" every few seconds.
        if(!connected) { if(!silent) batteryError="The local desktop adapter is not connected yet.";return; }
        if(!silent) batteryBusy=true;
        emitRequest({action:"battery"});
    }
    function syncResourcesStatus() {
        // "connecting" while a read is in flight is what makes the orb pulse; a
        // machine with no readable /proc/meminfo rests in the unavailable colour.
        resourcesStatus = resourcesBusy ? "connecting"
                        : (!resourcesAvailable) ? "disconnected"
                        : (systemPercent>85) ? "disconnected"
                        : "connected";
    }
    function openResources() { root.showPanel("resources", "api", true); }
    function closeResources() { if(root.resourcesOpen) root.clearPanel("close"); }
    function toggleResources() { if(resourcesOpen) closeResources(); else openResources(); }
    function refreshResources(silent) {
        if(!connected) { if(!silent) resourcesError="The local desktop adapter is not connected yet.";return; }
        if(!silent) { resourcesBusy=true;syncResourcesStatus(); }
        emitRequest({action:"resources"});
    }
    function setBatteryProfile(name) {
        if(!name || name.length===0) return;
        batteryBusy=true;batteryError="";
        syncBatteryStatus();
        emitRequest({action:"batteryProfile",profile:String(name)});
    }
    function openWifi() { root.showPanel("wifi", "api", true); }
    function closeWifi() { if(root.wifiOpen) root.clearPanel("close"); }
    function toggleWifi() { if(wifiOpen) closeWifi(); else openWifi(); }
    function syncBluetoothStatus() {
        // One place decides the orb's colour: any connected device is emerald,
        // a running action or scan is amber, everything else is crimson.
        if(bluetoothBusy || bluetoothScanning) bluetoothStatus="connecting";
        else bluetoothStatus=bluetoothConnectedDevice() ? "connected" : "disconnected";
    }
    function openBluetooth() { root.showPanel("bluetooth", "api", true); }
    function closeBluetooth() { if(root.bluetoothOpen) root.clearPanel("close"); }
    function toggleBluetooth() { if(bluetoothOpen) closeBluetooth(); else openBluetooth(); }
    function refreshBluetooth() {
        if(!connected) { bluetoothError="The local desktop adapter is not connected yet.";return; }
        bluetoothBusy=true;bluetoothError="";bluetoothBusyTimer.restart();
        emitRequest({action:"bluetooth"});
    }
    function scanBluetooth() {
        // The scan is a background process owned by the adapter; the panel shows
        // "working…" until the server confirms it is running, and only then
        // "Scanning…". Nothing here asserts that a scan started.
        if(!connected) { bluetoothError="The local desktop adapter is not connected yet.";return; }
        bluetoothBusy=true;bluetoothError="";
        bluetoothBusyTimer.restart();syncBluetoothStatus();
        emitRequest({action:"bluetoothScan"});
    }
    function connectBluetooth(device) {
        if(!device || !device.address) return;
        bluetoothBusy=true;bluetoothError="";bluetoothBusyTimer.restart();
        syncBluetoothStatus();
        emitRequest({action:"bluetoothConnect",address:String(device.address)});
    }
    function setBluetoothPower(enabled) {
        bluetoothBusy=true;bluetoothError="";bluetoothBusyTimer.restart();
        syncBluetoothStatus();
        emitRequest({action:"bluetoothPower",enabled:enabled===true});
    }
    function refreshWifi() {
        if(!connected) { wifiError="The local desktop adapter is not connected yet.";return; }
        // The scan is a process on the adapter's thread: this returns at once with
        // `scanning: true`, and the list arrives when the process has finished.
        wifiBusy=true;wifiError="";wifiScanTimeout.restart();
        emitRequest({action:"wifiScan"});
    }
    function chooseWifi(network) {
        if(!network) return;
        if(network.inUse) { wifiError="";notice="Already connected to "+network.ssid+".";return; }
        if(network.secure && !network.saved) {
            wifiPasswordSsid=network.ssid;wifiPasswordSecurity=network.label || "";
            wifiPanel.clearPrompt();wifiError="";
            // The frame's field only exists once the prompt is visible, so focus is
            // requested one event-loop turn later.
            Qt.callLater(function(){ wifiPanel.focusPrompt(); });
            return;
        }
        beginWifiAction();wifiBusy=true;
        emitRequest({action:"wifiConnect",ssid:network.ssid,security:network.label || ""});
    }
    function submitWifiPassword(text) {
        if(!wifiPasswordSsid) return;
        beginWifiAction();wifiBusy=true;
        emitRequest({action:"wifiConnect",ssid:wifiPasswordSsid,password:(text===undefined?wifiPanel.promptText:text),
                     security:wifiPasswordSecurity});
        wifiPanel.clearPrompt();wifiPasswordSsid="";wifiPasswordSecurity="";
    }
    function cancelWifiPassword() { wifiPanel.clearPrompt();wifiPasswordSsid="";wifiPasswordSecurity="";wifiError=""; }
    function setWifiRadio(enabled) { beginWifiAction();wifiBusy=true;emitRequest({action:"wifiRadio",enabled:enabled}); }
    function disconnectWifi() { beginWifiAction();wifiBusy=true;emitRequest({action:"wifiDisconnect"}); }
    function savePreference(key,value) { var values={};values[key]=value;emitRequest({action:"preferences",values:values}); }
    onPausedChanged: { lastTick=Date.now(); }

    Timer {
        // ── the one clock every animation reads ─────────────────────────────
        // 60 fps while the dashboard is up, 30 in low power, and fully stopped
        // while it is hidden: MagicRing, the gems and the disc glow are all a
        // function of `aliveTime`, so off-screen nothing is animated at all.
        id:frameClock
        interval: root.lowPower ? 33 : 16
        repeat: true
        running: root.sphereVisible && !root.paused
        onTriggered: {
            var now=Date.now(), dt=Math.min(0.1,(now-root.lastTick)/1000);
            root.lastTick=now;
            root.aliveTime+=dt;
            if(root.ufoMoving) {
                root.ufoMoveElapsed+=dt;
                var k=Math.min(1, root.ufoMoveElapsed/Math.max(0.05, root.ufoMoveDur));
                var e=k<0.5 ? 4*k*k*k : 1-Math.pow(-2*k+2,3)/2;
                root.orbitDeg=root.ufoFromDeg+(root.ufoToDeg-root.ufoFromDeg)*e;
                if(k>=1) {
                    root.orbitDeg=((root.ufoToDeg%360)+360)%360;
                    root.ufoMoving=false;
                    root.ufoLocked=true;
                    root.ufoLockTime=root.aliveTime;
                    root.ufoReveal=0;
                    root.ufoCascade=0;
                }
            } else if(root.theme.orbitRevolve && !root.lowPower && root.hoveredSlot<0 && root.activePanel==="" && root.ufoSlot<0) {
                root.orbitDeg=(root.orbitDeg + dt*root.theme.orbitRevolveDegPerSec) % 360;
            }
            var beamGoal = (root.ufoLocked && root.activePanel!=="") ? 1 : 0;
            root.ufoBeamLevel += (beamGoal - root.ufoBeamLevel) * Math.min(1, dt * (beamGoal ? 6.5 : 14.0));
            root.ufoReveal += (beamGoal - root.ufoReveal) * Math.min(1, dt * (beamGoal ? 3.2 : 12.0));
            if(root.ufoLocked && root.activePanel!=="") {
                if((root.aliveTime - root.ufoLockTime) > 0.24) {
                    root.ufoCascade = Math.min(1.5, root.ufoCascade + dt * 2.1);
                }
            }
        }
    }
    Timer {
        // Safety net only: the adapter pushes every NetworkManager state change
        // (`nmcli monitor`), so this is not a poll — it is the fallback for a watch
        // thread that died. Two minutes, state only, never a scan.
        interval:120000;repeat:true;running:root.connected && root.sphereVisible && !root.wifiOpen
        onTriggered:root.emitRequest({action:"wifi"})
    }
    Timer {
        // While the list is open, refresh signal strengths and the active network.
        interval:6000;repeat:true;running:root.wifiOpen && root.connected
        onTriggered:root.emitRequest({action:"wifi"})
    }
    onConnectedChanged: if(connected) emitRequest({action:"wifi"})

    Timer {
        // Belt and braces: if NetworkManager never answers an action, gold must not stick.
        id:wifiPendingTimeout;interval:15000;repeat:false
        onTriggered:{ root.wifiPending=false;root.syncWifiStatus(); }
    }
    Timer {
        // ── hover intent ─────────────────────────────────────────────────────
        // Restarted by every new area the pointer enters, so a fast sweep across
        // the ring ends on the orb it settled on and never opens the ones it
        // merely crossed. 70 ms: long enough to filter a sweep, short enough to
        // feel instant.
        id:hoverIntent;interval:root.hoverIntentMs;repeat:false
        onTriggered:hoverIntentFired()
    }
    Timer {
        // ── leave grace ──────────────────────────────────────────────────────
        // Started only when the pointer is in NO hover area. Coming back inside
        // the grace stops it, which is what makes returning cancel the fade
        // instead of restarting it.
        id:leaveTimer;interval:root.leaveGraceMs;repeat:false
        onTriggered:root.leaveGraceFired()
    }
    Timer {
        // A rescan is allowed 25 s + one 2 s retry. Past that the panel stops
        // claiming a scan is running, even if no event ever arrives.
        id:wifiScanTimeout;interval:34000;repeat:false
        onTriggered:{ root.wifiBusy=false; }
    }
    Timer {
        // A bluetoothctl that never answers must not leave the panel saying
        // "working…" forever: after 12 s it says so in words and offers Scan again.
        id:bluetoothBusyTimer;interval:12000;repeat:false
        onTriggered:{
            if(!root.bluetoothBusy) return;
            root.bluetoothBusy=false;root.bluetoothScanning=false;
            if(root.bluetoothOpen) root.bluetoothError="bluetoothctl did not answer in 12 s. Check `bluetoothctl list` in a terminal, then press Scan.";
            root.syncBluetoothStatus();
        }
    }
    Timer {
        // Only while the adapter says a scan process is running: this is what
        // clears "Scanning…" if the final event is ever missed.
        id:bluetoothScanPoll;interval:2000;repeat:true;running:false
        onTriggered:root.emitRequest({action:"bluetooth"})
    }
    HoverHandler {
        // ── the centre, as a hover area ──────────────────────────────────────
        // A MouseArea would be a square: its corners would reach into the gems'
        // orbit and steal their hover. So the disc's keep-alive area is computed
        // from the pointer's position against the disc's own radius — exact, and
        // invisible to clicks (a non-blocking handler consumes nothing).
        id:discHover;objectName:"discHover"
        blocking: false
        property bool inside: false
        onPointChanged: root.trackDiscHover(point.position)
        onHoveredChanged: if(!hovered) root.leaveDiscHover()
    }
    MouseArea {
        // ── the input catcher ────────────────────────────────────────────────
        // Full screen, every button, wheel included, and BELOW every orb (z:1).
        // It exists so that a click, a scroll or a middle-click on empty space is
        // absorbed by the dashboard instead of reaching the window underneath,
        // and it takes focus on press so Escape always lands on this widget.
        id:inputCatcher;objectName:"inputCatcher"
        anchors.fill:parent
        z:1
        hoverEnabled:true
        acceptedButtons:Qt.AllButtons
        cursorShape:Qt.ArrowCursor
        onPressed:mouse=>{ root.forceActiveFocus(); mouse.accepted=true; }
        onReleased:mouse=>{ mouse.accepted=true; }
        onClicked:mouse=>{ root.backgroundClicked(mouse.x, mouse.y); mouse.accepted=true; }
        onDoubleClicked:mouse=>{ mouse.accepted=true; }
        onWheel:wheel=>{ wheel.accepted=true; }
        onPositionChanged:mouse=>{ mouse.accepted=true; }
    }
    // ═══ THE SCENE ═══════════════════════════════════════════════════════════
    // Everything below is drawn in this order and nothing here takes a click
    // that belongs to something else:
    //
    //   veil      a near-black wash over the wallpaper, so the gold has something
    //             to sit on and the rays read as light rather than as colour
    //   ring      MagicRing: rays, dust and the pre-rendered gold sheets
    //   bridges   one transparent band per gem, gem → disc, hover only
    //   gems      five stones, each with its own hit area
    //   disc      the centre: rim, the orb, the mark (yours, or the orb alone)
    //   panels    five hosted PanelFrames, crossfading inside the disc
    Rectangle {
        // ── the veil ─────────────────────────────────────────────────────────
        // Not a blur and not a scrim over the whole screen: a radial wash that is
        // dense behind the circle and falls to nothing at the edges, so the
        // dashboard covers the desktop without hiding it.
        id:veil;objectName:"magicVeil"
        anchors.fill:parent;z:2
        color:"transparent"
        gradient: Gradient {
            GradientStop { position: 0.00; color: "#f4050811" }
            GradientStop { position: 0.55; color: "#e0050811" }
            GradientStop { position: 0.86; color: "#8c07060a" }
            GradientStop { position: 1.00; color: "#33040302" }
        }
        opacity: root.presence
    }
    MagicRing {
        // ── the circle ───────────────────────────────────────────────────────
        // Created once, never destroyed, never resized during a hover: its size is
        // a function of the screen alone.
        id:magicRing;objectName:"magicRing";z:5
        anchors.centerIn: parent
        radius: root.ringR
        orbitDeg: root.orbitDeg
        gemAngles: {
            var list=[];
            for(var i=0;i<root.gemCount;i++) list.push(root.liveGemAngle(i));
            return list;
        }
        gemColors: {
            var list=[];
            for(var i=0;i<root.gemCount;i++) list.push(root.gemColorAt(i));
            return list;
        }
        hoveredIndex: root.hoveredSlot>=0 && root.hoveredSlot<root.gemCount ? root.hoveredSlot : -1
        activeIndex: root.activePanel==="" ? -1 : root.gemIndexOf(root.activePanel)
        time: root.aliveTime
        activation: root.activation
        geometry: root.geometry
        animated: !root.paused && root.sphereVisible
        lowPower: root.lowPower
        theme: root.theme
        sparkSource: Qt.resolvedUrl("assets/spark.svg")
        atmosphereSource: Qt.resolvedUrl("assets/atmosphere.svg")
        gemRaySources: {
            // one pre-rendered cone per gem, named after the gem's key
            var list=[];
            for(var i=0;i<root.gemCount;i++)
                list.push(Qt.resolvedUrl("assets/ray-"+root.gemKey(i)+".svg"));
            return list;
        }
        opacity: root.presence
    }
    Repeater {
        // ── the bridges ──────────────────────────────────────────────────────
        // One transparent band per gem, from the stone to the disc. Crossing it
        // with the pointer keeps the same hover area alive, which is what makes
        // gem → centre → gem one continuous motion instead of two leaves. It
        // takes no clicks and sits under the gems and under the disc.
        model: root.gemCount
        delegate: Item {
            id:bridge;required property int index;objectName:"gemBridge"
            readonly property point c: root.gemCenter(bridge.index)
            readonly property real dx: root.width/2-bridge.c.x
            readonly property real dy: root.height/2-bridge.c.y
            readonly property real len: Math.max(1,Math.sqrt(bridge.dx*bridge.dx+bridge.dy*bridge.dy))
            x: bridge.c.x; y: bridge.c.y
            width: bridge.len; height: root.gemDiameter*0.86
            transformOrigin: Item.Left
            rotation: Math.atan2(bridge.dy,bridge.dx)*180/Math.PI
            z: 8
            Rectangle { anchors.fill: parent; color: "transparent" }
            HoverHandler {
                blocking: false
                onHoveredChanged: parent.HoverHandler.hovered
                    ? root.hoverEnter("bridge:"+bridge.index, root.panelKeyAt(bridge.index), bridge.index)
                    : root.hoverLeave("bridge:"+bridge.index)
            }
        }
    }
    Repeater {
        // ── the five gems ────────────────────────────────────────────────────
        // The stone is MagicGem; the hit area is a plain rectangle computed from
        // the ring's geometry (never from the artwork), one per gem, with no
        // full-screen area anywhere.
        model: root.gemCount
        delegate: Item {
            id:gemSlot;required property int index
            objectName: root.gemKey(gemSlot.index)+"Gem"
            readonly property rect area: root.gemRect(gemSlot.index)
            readonly property bool isUfoTop: root.ufoSlot===gemSlot.index && root.ufoLocked
            readonly property real ufoBob: (isUfoTop && !root.lowPower)
                ? (-root.ringR * 0.015 * root.ufoBeamLevel + Math.sin(root.aliveTime * 2.2) * root.ringR * 0.010 * root.ufoBeamLevel)
                : 0
            x: gemSlot.area.x; y: gemSlot.area.y + gemSlot.ufoBob
            width: gemSlot.area.width; height: gemSlot.area.height
            opacity: (root.ufoSlot>=0 && root.ufoSlot!==gemSlot.index) ? 0.44 : 1.0
            Behavior on opacity { NumberAnimation { duration: 300; easing.type: Easing.OutQuad } }
            z: 30
            MagicGem {
                anchors.centerIn: parent
                size: root.gemDiameter
                tint: root.gemColorAt(gemSlot.index)
                bezelSource: Qt.resolvedUrl("assets/magic-bezel.svg")
                glyphSource: Qt.resolvedUrl("assets/glyph-"+root.gemGlyph(gemSlot.index)+".svg")
                haloSource: Qt.resolvedUrl("assets/glow-"+root.gemKey(gemSlot.index)+".svg")
                hovered: gemArea.containsMouse || root.hoveredSlot===gemSlot.index
                active: root.activePanel===root.gemKey(gemSlot.index)
                dimmed: (root.hoveredSlot>=0 && root.hoveredSlot!==gemSlot.index)
                        || (root.hoveredSlot<0 && root.activePanel!=="" && root.activePanel!==root.gemKey(gemSlot.index))
                time: root.aliveTime
                animated: !root.paused
                lowPower: root.lowPower
                theme: root.theme
                sparkSource: Qt.resolvedUrl("assets/spark.svg")
            }
            MouseArea {
                id:gemArea;objectName:"gemArea";anchors.fill:parent;hoverEnabled:true
                acceptedButtons: Qt.LeftButton
                cursorShape: Qt.PointingHandCursor
                onEntered: { root.hoveredSlot=gemSlot.index;root.hoverEnter("gem:"+gemSlot.index, root.panelKeyAt(gemSlot.index), gemSlot.index); }
                onExited: { if(root.hoveredSlot===gemSlot.index) root.hoveredSlot=-1;root.hoverLeave("gem:"+gemSlot.index); }
                onClicked: root.gemActivated(gemSlot.index, "gem:"+gemSlot.index)
            }
        }
    }
    // ── UFO underside spinning chase lights under the 12 o'clock orb ─────────
    Item {
        id: ufoChaseRing
        objectName: "ufoChaseRing"
        enabled: false
        visible: root.sphereVisible && root.ufoBeamLevel > 0.01
        opacity: root.ufoBeamLevel * root.presence
        z: 31
        readonly property real topBob: (!root.lowPower && root.ufoLocked)
            ? (-root.ringR * 0.015 * root.ufoBeamLevel + Math.sin(root.aliveTime * 2.2) * root.ringR * 0.010 * root.ufoBeamLevel)
            : 0
        readonly property real rx: root.gemDiameter * 0.41
        readonly property real ry: root.gemDiameter * 0.095
        width: rx * 2.6
        height: ry * 3.6
        x: root.width / 2 - width / 2
        y: root.height / 2 - root.gemOrbit + root.gemDiameter * 0.30 + topBob - height / 2
        readonly property real cx: width / 2
        readonly property real cy: height / 2
        Shape {
            anchors.fill: parent
            ShapePath {
                strokeWidth: Math.max(1.0, root.ringR * 0.003)
                strokeColor: Qt.rgba(0.62, 0.95, 1.0, 0.36)
                fillColor: "transparent"
                startX: ufoChaseRing.cx + ufoChaseRing.rx
                startY: ufoChaseRing.cy
                PathAngleArc {
                    centerX: ufoChaseRing.cx; centerY: ufoChaseRing.cy
                    radiusX: ufoChaseRing.rx; radiusY: ufoChaseRing.ry
                    startAngle: 0; sweepAngle: 360
                }
            }
        }
        Repeater {
            model: 12
            delegate: Rectangle {
                required property int index
                readonly property real ang: root.aliveTime * 2.6 + index * Math.PI * 2 / 12
                readonly property real depth: (Math.sin(ang) + 1) * 0.5
                readonly property real dotR: Math.max(2.0, root.gemDiameter * 0.026) * (0.82 + 0.32 * depth)
                width: dotR * 2; height: width; radius: dotR
                x: ufoChaseRing.cx + Math.cos(ang) * ufoChaseRing.rx - dotR
                y: ufoChaseRing.cy + Math.sin(ang) * ufoChaseRing.ry - dotR
                color: index % 3 === 0 ? Qt.lighter(root.ufoAccentColor, 1.48) : "#dffcff"
                opacity: 0.24 + 0.76 * depth
            }
        }
    }
    Item {
        // ── the centre disc ──────────────────────────────────────────────────
        // A beveled gold rim, a near-black face, a faint inner glow and a vignette.
        // It is the panel's room: while a panel is showing it grows from 0.48 R to
        // 0.70 R in 230 ms and the content crossfades in inside it. It is also a
        // hover area (keep-alive) and it takes the click that closes an unpinned
        // preview, so buttons inside the panels keep working.
        id:disc;objectName:"centreDisc";z:20
        width: root.discRadius*2; height: width
        x: root.width/2-width/2; y: root.height/2-height/2
        visible: root.sphereVisible
        opacity: root.presence
        // a Shape only rebuilds when its geometry actually changes: during the
        // 230 ms expansion that is once per frame, and afterwards never
        readonly property real dr: root.discRadius

        // ── gradients, explained once ────────────────────────────────────────
        // A Qt radial gradient maps 0…1 onto the radius from `centerRadius` to the
        // shape's bounding-box CORNER (dr·√2 here), so a stop placed at the circle
        // itself is at 1/√2 ≈ 0.707 — not 1.0. These helpers do that arithmetic
        // once, so every stop below means "at this fraction of the disc".
        readonly property real corner: Math.SQRT2
        function faceStop(frac) { return frac / disc.corner; }
        Shape {
            visible: !root.theme.visionOsGlass
            anchors.fill: parent
            // the face: near-black, so every word inside it is readable over any
            // wallpaper
            ShapePath {
                strokeWidth: 0
                fillColor: "#ff080706"
                startX: disc.dr; startY: disc.dr
                PathAngleArc { centerX: disc.dr; centerY: disc.dr; radiusX: disc.dr*0.925; radiusY: disc.dr*0.925; startAngle: 0; sweepAngle: 360 }
            }
        }
        Shape {
            visible: !root.theme.visionOsGlass
            // the centre's own light: one slow gold breath under the logo, held
            // steady (and dimmer) in low power. Only this layer moves.
            anchors.fill: parent
            opacity: root.lowPower ? 0.55 : (0.70 + 0.30*Math.sin(root.aliveTime*0.9))
            ShapePath {
                strokeWidth: 0
                fillGradient: RadialGradient {
                    centerX: disc.dr; centerY: disc.dr; centerRadius: 0; focalRadius: 0
                    GradientStop { position: 0.00; color: "#40d8b45f" }
                    GradientStop { position: disc.faceStop(0.26); color: "#12d6b25f" }
                    GradientStop { position: disc.faceStop(0.60); color: "#00d6b25f" }
                }
                startX: disc.dr; startY: disc.dr
                PathAngleArc { centerX: disc.dr; centerY: disc.dr; radiusX: disc.dr*0.925; radiusY: disc.dr*0.925; startAngle: 0; sweepAngle: 360 }
            }
        }
        Shape {
            visible: !root.theme.visionOsGlass
            anchors.fill: parent
            // vignette: the face darkens towards its rim, so the content sits lit
            // in the middle of a dark lens
            ShapePath {
                strokeWidth: 0
                fillGradient: RadialGradient {
                    centerX: disc.dr; centerY: disc.dr; centerRadius: 0; focalRadius: 0
                    GradientStop { position: 0.00; color: "#00040302" }
                    GradientStop { position: disc.faceStop(0.42); color: "#00040302" }
                    GradientStop { position: disc.faceStop(0.925); color: "#b8040302" }
                }
                startX: disc.dr; startY: disc.dr
                PathAngleArc { centerX: disc.dr; centerY: disc.dr; radiusX: disc.dr*0.925; radiusY: disc.dr*0.925; startAngle: 0; sweepAngle: 360 }
            }
        }
        Shape {
            visible: !root.theme.visionOsGlass
            anchors.fill: parent
            // the rim: a bevel of stroked circles — bright lip, dark groove, inner
            // gold hairline. Strokes are exact, so the rim is the same weight at
            // every screen size and never blooms.
            ShapePath {
                strokeWidth: Math.max(1.2, disc.dr*0.012)
                strokeColor: theme.goldWhite; fillColor: "transparent"
                startX: disc.dr; startY: disc.dr - disc.dr*0.995
                PathAngleArc { centerX: disc.dr; centerY: disc.dr; radiusX: disc.dr*0.995; radiusY: disc.dr*0.995; startAngle: -90; sweepAngle: 360 }
            }
            ShapePath {
                strokeWidth: Math.max(1.6, disc.dr*0.020)
                strokeColor: theme.goldDeep; fillColor: "transparent"
                startX: disc.dr; startY: disc.dr - disc.dr*0.975
                PathAngleArc { centerX: disc.dr; centerY: disc.dr; radiusX: disc.dr*0.975; radiusY: disc.dr*0.975; startAngle: -90; sweepAngle: 360 }
            }
            ShapePath {
                strokeWidth: Math.max(1.0, disc.dr*0.008)
                strokeColor: theme.goldBright; fillColor: "transparent"
                startX: disc.dr; startY: disc.dr - disc.dr*0.952
                PathAngleArc { centerX: disc.dr; centerY: disc.dr; radiusX: disc.dr*0.952; radiusY: disc.dr*0.952; startAngle: -90; sweepAngle: 360 }
            }
            // the inner groove: a hairline just inside the rim
            ShapePath {
                strokeWidth: Math.max(0.8, disc.dr*0.006)
                strokeColor: theme.alpha(theme.gold, 0.33); fillColor: "transparent"
                startX: disc.dr; startY: disc.dr - disc.dr*0.918
                PathAngleArc { centerX: disc.dr; centerY: disc.dr; radiusX: disc.dr*0.918; radiusY: disc.dr*0.918; startAngle: -90; sweepAngle: 360 }
            }
        }
        // ── visionOS brushed silver-chrome collar & 3D bubble glass dome ─────
        Image {
            id: visionOsDomeCollar
            objectName: "visionOsDomeCollar"
            visible: root.theme.visionOsGlass
            anchors.fill: parent
            source: Qt.resolvedUrl("assets/visionos-dome-collar.svg")
            fillMode: Image.PreserveAspectFit
            smooth: true
            mipmap: true
        }
        // ── UFO light beam inside the glass dome (Point 3) ───────────────────
        Item {
            id: ufoBeamLayer
            objectName: "ufoBeamLayer"
            enabled: false
            visible: root.theme.visionOsGlass && root.ufoBeamLevel > 0.01
            anchors.fill: parent
            readonly property real sinceLock: Math.max(0, root.aliveTime - root.ufoLockTime)
            readonly property real flicker: (sinceLock < 0.35 && root.ufoLocked)
                ? (0.52 + 0.48 * Math.abs(Math.sin(sinceLock * 53.0) * Math.cos(sinceLock * 31.0)))
                : (0.92 + 0.08 * Math.sin(root.aliveTime * 9.0))
            opacity: root.ufoBeamLevel * flicker

            // Top-to-bottom downward reveal clip
            Item {
                id: ufoBeamClip
                x: 0; y: 0
                width: parent.width
                height: parent.height * Math.max(0, Math.min(1, root.ufoReveal))
                clip: true

                readonly property real y0: disc.height * 0.045
                readonly property real y1: disc.height * 0.895
                readonly property real w0: disc.dr * 0.078
                readonly property real w1: disc.dr * 0.59

                Image {
                    width: disc.width
                    height: disc.height
                    source: Qt.resolvedUrl("assets/visionos-ufo-cone.svg")
                    fillMode: Image.PreserveAspectFit
                    smooth: true
                    mipmap: true
                }

                // Left & Right beam edges in the active orb's own colour
                Shape {
                    width: disc.width
                    height: disc.height
                    ShapePath {
                        strokeWidth: 0
                        fillGradient: LinearGradient {
                            x1: 0; y1: ufoBeamClip.y0; x2: 0; y2: ufoBeamClip.y1
                            GradientStop { position: 0.0; color: Qt.rgba(root.ufoAccentColor.r, root.ufoAccentColor.g, root.ufoAccentColor.b, 0.56) }
                            GradientStop { position: 1.0; color: Qt.rgba(root.ufoAccentColor.r, root.ufoAccentColor.g, root.ufoAccentColor.b, 0.0) }
                        }
                        startX: disc.dr - ufoBeamClip.w0; startY: ufoBeamClip.y0
                        PathLine { x: disc.dr - ufoBeamClip.w0 + disc.dr * 0.032; y: ufoBeamClip.y0 }
                        PathLine { x: disc.dr - ufoBeamClip.w1 + disc.dr * 0.125; y: ufoBeamClip.y1 }
                        PathLine { x: disc.dr - ufoBeamClip.w1; y: ufoBeamClip.y1 }
                        PathLine { x: disc.dr - ufoBeamClip.w0; y: ufoBeamClip.y0 }
                    }
                    ShapePath {
                        strokeWidth: 0
                        fillGradient: LinearGradient {
                            x1: 0; y1: ufoBeamClip.y0; x2: 0; y2: ufoBeamClip.y1
                            GradientStop { position: 0.0; color: Qt.rgba(root.ufoAccentColor.r, root.ufoAccentColor.g, root.ufoAccentColor.b, 0.56) }
                            GradientStop { position: 1.0; color: Qt.rgba(root.ufoAccentColor.r, root.ufoAccentColor.g, root.ufoAccentColor.b, 0.0) }
                        }
                        startX: disc.dr + ufoBeamClip.w0 - disc.dr * 0.032; startY: ufoBeamClip.y0
                        PathLine { x: disc.dr + ufoBeamClip.w0; y: ufoBeamClip.y0 }
                        PathLine { x: disc.dr + ufoBeamClip.w1; y: ufoBeamClip.y1 }
                        PathLine { x: disc.dr + ufoBeamClip.w1 - disc.dr * 0.125; y: ufoBeamClip.y1 }
                        PathLine { x: disc.dr + ufoBeamClip.w0 - disc.dr * 0.032; y: ufoBeamClip.y0 }
                    }
                }

                // 3 rings of light traveling downward along the beam
                Repeater {
                    model: 3
                    delegate: Shape {
                        id: beamRing
                        required property int index
                        width: disc.width; height: disc.height
                        readonly property real p: (root.aliveTime * 0.45 + beamRing.index / 3.0) % 1.0
                        readonly property real ryCenter: ufoBeamClip.y0 + disc.dr * 0.08 + beamRing.p * (ufoBeamClip.y1 - ufoBeamClip.y0 - disc.dr * 0.08)
                        readonly property real rxRing: ufoBeamClip.w0 + beamRing.p * (ufoBeamClip.w1 - ufoBeamClip.w0)
                        readonly property real ryRing: beamRing.rxRing * 0.16
                        ShapePath {
                            strokeWidth: Math.max(1.0, disc.dr * 0.006)
                            strokeColor: Qt.rgba(0.67, 0.96, 1.0, Math.sin(beamRing.p * Math.PI) * 0.42)
                            fillColor: "transparent"
                            startX: disc.dr + beamRing.rxRing
                            startY: beamRing.ryCenter
                            PathAngleArc {
                                centerX: disc.dr; centerY: beamRing.ryCenter
                                radiusX: beamRing.rxRing; radiusY: beamRing.ryRing
                                startAngle: 0; sweepAngle: 360
                            }
                        }
                    }
                }

                // Small sparkles drifting UP into the orb
                Repeater {
                    model: 30
                    delegate: Rectangle {
                        required property int index
                        readonly property real sA: Math.sin(index * 12.9898 + 1.7) * 43758.5453
                        readonly property real fA: sA - Math.floor(sA)
                        readonly property real sB: Math.sin(index * 78.233 + 3.1) * 12345.6789
                        readonly property real fB: sB - Math.floor(sB)
                        readonly property real sp: 0.13 + fB * 0.18
                        readonly property real pt: (root.aliveTime * sp + fA) % 1.0
                        readonly property real py: ufoBeamClip.y1 - pt * (ufoBeamClip.y1 - ufoBeamClip.y0 - disc.dr * 0.03)
                        readonly property real curHw: ufoBeamClip.w0 + ((py - ufoBeamClip.y0) / Math.max(1, ufoBeamClip.y1 - ufoBeamClip.y0)) * (ufoBeamClip.w1 - ufoBeamClip.w0)
                        readonly property real lane: fA * 2.0 - 1.0
                        readonly property real px: disc.dr + lane * curHw * 0.78 + Math.sin(root.aliveTime * 2.1 + index * 1.9) * disc.dr * 0.012
                        readonly property real sr: Math.max(1.2, disc.dr * (0.004 + 0.006 * fB)) * (1.0 - pt * 0.45)
                        width: sr * 2; height: width; radius: sr
                        x: px - sr; y: py - sr
                        color: index % 4 === 0 ? Qt.lighter(root.ufoAccentColor, 1.55) : "#e6fdff"
                        opacity: Math.sin(pt * Math.PI) * 0.86
                    }
                }

                // Soft pool of light glowing at the bottom of the dome
                Item {
                    readonly property real poolW: disc.dr * (1.10 + 0.10 * Math.sin(root.aliveTime * 2.4))
                    readonly property real poolH: poolW * 0.20
                    x: disc.dr - poolW / 2
                    y: ufoBeamClip.y1 - poolH * 0.55
                    width: poolW; height: poolH
                    Image {
                        anchors.fill: parent
                        source: Qt.resolvedUrl("assets/visionos-ufo-pool.svg")
                        fillMode: Image.Stretch
                        smooth: true
                    }
                    Rectangle {
                        anchors.centerIn: parent
                        width: parent.width * 0.72
                        height: parent.height * 0.62
                        radius: height / 2
                        color: Qt.rgba(root.ufoAccentColor.r, root.ufoAccentColor.g, root.ufoAccentColor.b, 0.18)
                    }
                }
            }
        }
        // ── Thin glowing ring around the dome in the active orb's colour (Point 4)
        Shape {
            id: domeAccentRing
            objectName: "domeAccentRing"
            enabled: false
            visible: root.theme.visionOsGlass
            anchors.fill: parent
            property color ringTint: root.ufoAccentColor
            Behavior on ringTint { ColorAnimation { duration: 550; easing.type: Easing.OutCubic } }
            ShapePath {
                strokeWidth: Math.max(2.6, disc.dr * 0.022)
                strokeColor: Qt.rgba(domeAccentRing.ringTint.r, domeAccentRing.ringTint.g, domeAccentRing.ringTint.b, 0.28)
                fillColor: "transparent"
                startX: disc.dr; startY: disc.dr - disc.dr * 0.912
                PathAngleArc { centerX: disc.dr; centerY: disc.dr; radiusX: disc.dr * 0.912; radiusY: disc.dr * 0.912; startAngle: -90; sweepAngle: 360 }
            }
            ShapePath {
                strokeWidth: Math.max(1.5, disc.dr * 0.009)
                strokeColor: Qt.lighter(domeAccentRing.ringTint, 1.18)
                fillColor: "transparent"
                startX: disc.dr; startY: disc.dr - disc.dr * 0.912
                PathAngleArc { centerX: disc.dr; centerY: disc.dr; radiusX: disc.dr * 0.912; radiusY: disc.dr * 0.912; startAngle: -90; sweepAngle: 360 }
            }
        }
        // ── the holographic sphere: the room the mark floats in ──────────────
        // A child of the disc, so it grows and shrinks with it and fades out as a
        // panel opens; it never touches the ring container. It is static geometry
        // with a handful of moving transforms, so it costs one image draw and a
        // dozen binding updates per frame.
        JarvisCore {
            id:jarvisCore;objectName:"jarvisCore"
            anchors.centerIn: parent
            // inside the gold bevel: 0.92 of the disc's width, ≈ 0.47 R
            diameter: parent.width*root.theme.coreFit
            theme: root.theme
            // the readings, the clock, and one flag that decides whether the core
            // is alive or a still picture (the agent state arrives in step 5)
            cpu: stats.cpu
            ram: stats.ram
            battery: stats.battery
            cpuLive: stats.cpuLive
            ramLive: stats.ramLive
            batteryLive: stats.batteryLive
            // the idle motion runs only while the dashboard is up and awake: low
            // power drops the garnish exactly as it does everywhere else
            animated: !root.paused && root.sphereVisible && !root.lowPower
            // the clock: one SystemClock tick a second, from shell.qml
            hours: root.clockHours
            minutes: root.clockMinutes
            seconds: root.clockSeconds
            dateText: root.dateText
            serif: root.serifFamily
            // the idle centre gives way to a panel exactly as the mark does
            opacity: root.discOpen>0.02 ? 0 : 1
            Behavior on opacity { NumberAnimation { duration: 200; easing.type: Easing.OutQuad } }
        }

        // ── the idle centre: your mark, or the orb standing in for it
        Item {
            id:logoSlot;objectName:"logoSlot"
            anchors.centerIn: parent
            width: root.ringR*0.44; height: width
            opacity: root.discOpen>0.02 ? 0 : 1
            visible: opacity>0.01
            Behavior on opacity { NumberAnimation { duration: 200; easing.type: Easing.OutQuad } }
            Image {
                id:logoImage;objectName:"centreLogo"
                anchors.fill: parent
                // Qt caches an image by URL and the URL never changes when the
                // file on disk does, so the source is emptied and set again (see
                // reloadLogo). No "?v=" cache-buster: a file:// URL carrying a
                // query is a *different path*, and Qt then finds nothing at all.
                source: ""
                cache: false
                fillMode: Image.PreserveAspectFit
                // never an error in the UI: a missing or broken file simply leaves
                // the placeholder below on screen
                onStatusChanged: if(status===Image.Error) root.dbg("logo could not be read: "+source)
                visible: status===Image.Ready
            }
            // LOGO_TINT=false leaves the artwork exactly as it was drawn; when it
            // is true the mark is drawn into the ring's gold instead. This used to
            // be a colourising effect from the optional Qt Quick extras module —
            // which a bare Qt Quick install does not have and which is not in the
            // runtime package list, so its absence stopped the *whole* widget from
            // loading. The tint is now a one-shot Canvas: it paints once per mark,
            // never per frame, and needs nothing that is not already installed.
            Canvas {
                id:logoTint
                objectName:"logoTint"
                anchors.fill: parent
                visible: root.logoTint && logoImage.status===Image.Ready
                renderTarget: Canvas.FramebufferObject
                renderStrategy: Canvas.Cooperative
                onPaint: {
                    var ctx = getContext("2d");
                    ctx.clearRect(0, 0, width, height);
                    if (logoImage.status !== Image.Ready) return;
                    // preserve the mark's shape, then flood the gold through it
                    ctx.globalCompositeOperation = "source-over";
                    ctx.drawImage(logoImage.source, 0, 0, width, height);
                    ctx.globalCompositeOperation = "source-in";
                    ctx.fillStyle = "#e8c778";
                    ctx.fillRect(0, 0, width, height);
                    ctx.globalCompositeOperation = "source-over";
                }
                Connections {
                    target: logoImage
                    function onStatusChanged() { logoTint.requestPaint(); }
                }
                onWidthChanged: if (visible) requestPaint()
                onHeightChanged: if (visible) requestPaint()
            }
            // What stands in when there is no mark of your own: nothing is drawn
            // here. The centre is the Jarvis core, and this item is only the state
            // that says "no mark yet" — `logoFallback` is the name the tests and
            // the installer look for.
            Item {
                objectName:"logoFallback"
                anchors.fill: parent
                visible: !root.hasLogo || logoImage.status!==Image.Ready
            }
        }
        // ── the domed optical liquid-glass lens over the centre disc ───────
        Image {
            id:liquidLens;objectName:"liquidLens"
            anchors.fill: parent
            source: Qt.resolvedUrl("assets/liquid-lens.svg")
            fillMode: Image.PreserveAspectFit
            smooth: true
            mipmap: true
            visible: root.theme.liquidGlass
            opacity: root.discOpen>0.02 ? root.theme.liquidLensOpenAlpha : root.theme.liquidLensAlpha
            Behavior on opacity { NumberAnimation { duration: 200; easing.type: Easing.OutQuad } }
        }
    }

    Connections {
        // Two ways the mark can change: a different path (shell.qml found or lost
        // logo.svg / logo.png) or the same path with new contents (the revision
        // bumps). Both end in one re-read.
        target: root
        function onLogoSourceChanged() { root.reloadLogo(); }
        function onLogoRevisionChanged() { root.reloadLogo(); }
    }

    PanelFrame {
        // ── THE WI-FI PANEL ──────────────────────────────────────────────────
        // This block is *data only*: the frame owns the glass, the frosted slab,
        // the header, the clipping, the scrolling and the action row, so this
        // panel cannot differ from the other three in structure — and a fifth
        // panel would inherit the same layout for free.
        id:wifiPanel;objectName:"wifiPanel";key:"wifi"
        cascade:root.panelCascade
        // hosted: this frame IS the content of the one orb above it — no glass of
        // its own, no boot-in of its own, and its opacity crossfades when the
        // active panel changes. `active` is the single source of truth, read.
        hosted:true;active:root.wifiOpen;switchMs:root.switchFadeMs
        // the pointer on the panel is one more keep-alive hover area
        onHoverChanged:inside=>inside ? root.hoverEnter("panel:wifi", "", -1) : root.hoverLeave("panel:wifi")
        // proof for the hover test: each frame is built once and never rebuilt
        Component.onCompleted:root.dbg("frame wifi created")
        Component.onDestruction:root.dbg("frame wifi DESTROYED")
        x:root.width/2-width/2;y:root.height/2-height/2;z:45
        radius:root.orbRadius;uiScale:root.uiScale
        typeFamily:root.serifFamily
        // the frame is gold; this is the light of the gem that opened it
        accent:root.gemColorAt(root.gemIndexOf("wifi"))
        animated:!root.paused;time:root.aliveTime
        orbStatus:root.wifiStatus;orbAvailable:root.wifi.available!==false;orbReason:root.wifiReason
        orbTint:root.listPaint;orbAccent:root.listGlow

        icon:"wifi";title:"WI-FI"
        pulse:root.wifi.scanning===true
        tone:String(root.wifi.error || "").length>0 || String(root.wifi.problem || "").length>0 ? "bad"
            : root.wifiConnected ? "good"
            : root.wifi.radioOn ? "neutral" : "warn"
        // "Scanning…" only while the adapter says a scan process is running,
        // "on · N" from the list that scan produced, "off" from `nmcli radio wifi`.
        state:root.wifi.scanning ? "Scanning…"
            : !root.wifi.available ? "unavailable"
            : root.wifiConnected ? ("connected · "+root.wifiNetworkCount)
            : root.wifi.radioOn ? ("on · "+root.wifiNetworkCount) : "off"
        // The frame shows the status pill only when the orb is big enough; the
        // state line above is the fallback, so the same words are never lost.
        status:root.wifiStatusLine()
        statusWarn:String(root.wifi.error || "").length>0

        mode:(root.wifi.networks || []).length > 0 ? "list" : "empty"
        items:root.wifiRows()
        emptyIcon:"wifi"
        emptyText:root.wifiEmptyText()
        emptyHint:root.wifiEmptyHint()

        // the passphrase is asked by the frame, never stored by the widget
        promptVisible:root.wifiPasswordSsid.length>0
        promptLabel:"Password for "+root.wifiPasswordSsid
        promptPlaceholder:"Wi-Fi password"

        actions:root.wifiActions()

        onClose:root.closeWifi()
        onRowActivated:network => root.chooseWifi(network)
        onAction:(name) => root.wifiPanelAction(name)
        onPromptAccepted:text => root.submitWifiPassword(text)
        onPromptCancelled:root.cancelWifiPassword()
    }

    PanelFrame {
        // ── THE BLUETOOTH PANEL ──────────────────────────────────────────────
        // Same frame, different data: device rows instead of networks, the same
        // header/status/empty/action structure, the same clip and the same type.
        id:bluetoothPanel;objectName:"bluetoothPanel";key:"bluetooth"
        cascade:root.panelCascade
        // hosted: this frame IS the content of the one orb above it — no glass of
        // its own, no boot-in of its own, and its opacity crossfades when the
        // active panel changes. `active` is the single source of truth, read.
        hosted:true;active:root.bluetoothOpen;switchMs:root.switchFadeMs
        // the pointer on the panel is one more keep-alive hover area
        onHoverChanged:inside=>inside ? root.hoverEnter("panel:bluetooth", "", -1) : root.hoverLeave("panel:bluetooth")
        // proof for the hover test: each frame is built once and never rebuilt
        Component.onCompleted:root.dbg("frame bluetooth created")
        Component.onDestruction:root.dbg("frame bluetooth DESTROYED")
        x:root.width/2-width/2;y:root.height/2-height/2;z:45
        radius:root.orbRadius;uiScale:root.uiScale
        typeFamily:root.serifFamily
        // the frame is gold; this is the light of the gem that opened it
        accent:root.gemColorAt(root.gemIndexOf("bluetooth"))
        animated:!root.paused;time:root.aliveTime
        orbStatus:root.bluetoothStatus
        orbAvailable:root.bluetooth.available!==false && root.bluetooth.blocked!==true && root.bluetooth.adapter!==null
        orbTint:root.listPaint;orbAccent:root.listGlow

        icon:"bluetooth";title:"BLUETOOTH"
        pulse:root.bluetoothScanning===true || root.bluetoothStatus==="connecting"
        tone:(!root.bluetooth.available || root.bluetooth.blocked || root.bluetooth.adapter===null) ? "bad"
            : !root.bluetooth.powered ? "warn"
            : root.bluetoothConnectedDevice() ? "good" : "neutral"
        state:root.bluetoothBusy ? "working…"
            : root.bluetooth.scanning ? "Scanning…"
            : root.bluetooth.pending ? "checking…"
            : !root.bluetooth.available ? "unavailable"
            : root.bluetooth.blocked && root.bluetooth.blockedHard ? "blocked"
            : !root.bluetooth.adapter ? "no adapter"
            : !root.bluetooth.powered ? "off"
            : ("on · "+root.bluetoothDeviceCount())
        status:root.bluetoothStatusLine()
        statusWarn:!root.bluetooth.available || root.bluetooth.blocked || root.bluetooth.adapter===null

        mode:"list"
        items:root.bluetoothRows()
        emptyIcon:"bluetooth"
        emptyText:root.bluetoothEmptyText()
        emptyHint:String(root.bluetooth.detail || "")
        names:({ hint:"bluetoothDetail" })

        actions:root.bluetoothActions()

        onClose:root.closeBluetooth()
        onRowActivated:device => root.connectBluetooth(device)
        onAction:(name) => root.bluetoothPanelAction(name)
    }

    PanelFrame {
        // ── THE BATTERY PANEL ────────────────────────────────────────────────
        // A value dashboard in the same frame: big percentage with its ring, the
        // state line under it, a 2×2 grid of small cards and the power profiles
        // as a segmented control (the active one lit).
        id:batteryPanel;objectName:"batteryPanel";key:"battery"
        cascade:root.panelCascade
        // hosted: this frame IS the content of the one orb above it — no glass of
        // its own, no boot-in of its own, and its opacity crossfades when the
        // active panel changes. `active` is the single source of truth, read.
        hosted:true;active:root.batteryOpen;switchMs:root.switchFadeMs
        // the pointer on the panel is one more keep-alive hover area
        onHoverChanged:inside=>inside ? root.hoverEnter("panel:battery", "", -1) : root.hoverLeave("panel:battery")
        // proof for the hover test: each frame is built once and never rebuilt
        Component.onCompleted:root.dbg("frame battery created")
        Component.onDestruction:root.dbg("frame battery DESTROYED")
        x:root.width/2-width/2;y:root.height/2-height/2;z:45
        radius:root.orbRadius;uiScale:root.uiScale
        typeFamily:root.serifFamily
        // the frame is gold; this is the light of the gem that opened it
        accent:root.gemColorAt(root.gemIndexOf("battery"))
        animated:!root.paused;time:root.aliveTime
        orbStatus:root.batteryStatus;orbAvailable:root.batteryPresent
        orbTint:root.batteryTint;orbAccent:root.batteryAccent
        batteryLevel:root.batteryLevel;batteryState:String(root.battery.state || "")

        icon:"battery";title:"BATTERY"
        pulse:root.battery.state==="charging"
        tone:root.batteryTone()
        state:root.batteryBusy ? "reading…"
            : !root.batteryPresent ? "no battery"
            : ("on · "+root.batteryLevel+"%")
        status:root.batteryPresent ? root.batteryLine() : ""

        mode:root.batteryPresent ? "value" : "empty"
        value:root.batteryLevel>=0 ? root.batteryLevel+"%" : "—"
        valueSub:root.batteryValueSub()
        ring:root.batteryLevel>=0 ? root.batteryLevel/100 : -1
        stats:root.batteryStats()
        segments:root.batterySegments()
        emptyIcon:"battery"
        emptyText:String(root.batteryError || "").length>0 ? root.batteryError : "No battery detected"
        emptyHint:"A desktop or a virtual machine has no cell to report."
        names:({ ring:"batteryRing", value:"batteryReadout", stats:"batteryFacts", segments:"batteryProfiles" })

        actions:root.batteryActions()

        onClose:root.closeBattery()
        onAction:(name) => root.batteryPanelAction(name)
    }
    Timer {
        // Belt and braces: the bridge pushes every change, this re-reads on a
        // slow clock so the percentage never goes stale on a quiet machine.
        interval:5000;repeat:true;running:root.batteryOpen && root.connected && !root.paused
        onTriggered:root.refreshBattery(true)
    }

    PanelFrame {
        // ── THE SYSTEM PANEL ─────────────────────────────────────────────────
        // RAM is the ring and the big number, swap and every mounted filesystem
        // are thin bars with their sizes right-aligned, and the heaviest
        // processes are chips — all inside the same frame as the other three.
        id:resourcesPanel;objectName:"resourcesPanel";key:"system"
        cascade:root.panelCascade
        // hosted: this frame IS the content of the one orb above it — no glass of
        // its own, no boot-in of its own, and its opacity crossfades when the
        // active panel changes. `active` is the single source of truth, read.
        hosted:true;active:root.resourcesOpen;switchMs:root.switchFadeMs
        // the pointer on the panel is one more keep-alive hover area
        onHoverChanged:inside=>inside ? root.hoverEnter("panel:resources", "", -1) : root.hoverLeave("panel:resources")
        // proof for the hover test: each frame is built once and never rebuilt
        Component.onCompleted:root.dbg("frame resources created")
        Component.onDestruction:root.dbg("frame resources DESTROYED")
        x:root.width/2-width/2;y:root.height/2-height/2;z:45
        radius:root.orbRadius;uiScale:root.uiScale
        typeFamily:root.serifFamily
        // the frame is gold; this is the light of the gem that opened it
        accent:root.gemColorAt(root.gemIndexOf("resources"))
        animated:!root.paused;time:root.aliveTime
        orbStatus:root.resourcesStatus;orbAvailable:root.resourcesAvailable
        orbTint:root.resourcesTint;orbAccent:root.resourcesAccent

        icon:"system";title:"SYSTEM"
        pulse:root.resourcesBusy
        tone:root.ramPercent>90 ? "bad" : (root.ramPercent>75 ? "warn" : "good")
        // The header keeps the two numbers it has always shown; the ring and
        // the bars below are the detail, so there is no filler subtitle here.
        state:root.ramPercent>=0 ? ("RAM "+root.ramPercent+"% · Disk "+root.diskPercent+"%")
            : root.systemStatusText()
        status:""

        mode:root.resourcesAvailable ? "value" : "empty"
        value:root.ramPercent>=0 ? root.ramPercent+"%" : "—"
        valueSub:root.systemUsedText()
        ring:root.ramPercent>=0 ? root.ramPercent/100 : -1
        ringSecondary:root.diskPercent>=0 ? root.diskPercent/100 : -1
        bars:root.systemBars()
        tags:root.systemTags()
        emptyIcon:"system"
        emptyText:root.resourcesBusy ? "Reading system resources…"
            : (String(root.resourcesError || "").length>0 ? root.resourcesError : "System resources are unavailable")
        emptyHint:"Sphere reads /proc/meminfo, df and ps directly."
        names:({ ring:"resourcesRing", value:"resourcesReadout", stats:"resourcesFacts",
                 bars:"resourcesDisks", tags:"resourcesTop", state:"resourcesState" })

        actions:root.systemActions()

        onClose:root.closeResources()
        onAction:(name) => root.resourcesPanelAction(name)
    }
    PanelFrame {
        // ── THE FILE ORGANIZER PANEL ─────────────────────────────────────────
        // The same frame as every other orb — header, rule, status pill, clipped
        // body, action row — fed entirely by the JSON that jarvis-organize
        // prints. Amber is this orb's identity (`accent`), and the glass follows
        // it while the panel is open.
        id:organizerPanel;objectName:"organizerPanel";key:"organize"
        cascade:root.panelCascade
        // hosted: this frame IS the content of the one orb above it — no glass of
        // its own, no boot-in of its own, and its opacity crossfades when the
        // active panel changes. `active` is the single source of truth, read.
        hosted:true;active:root.organizerOpen;switchMs:root.switchFadeMs
        // the pointer on the panel is one more keep-alive hover area
        onHoverChanged:inside=>inside ? root.hoverEnter("panel:organize", "", -1) : root.hoverLeave("panel:organize")
        // proof for the hover test: each frame is built once and never rebuilt
        Component.onCompleted:root.dbg("frame organize created")
        Component.onDestruction:root.dbg("frame organize DESTROYED")
        x:root.width/2-width/2;y:root.height/2-height/2;z:45
        radius:root.orbRadius;uiScale:root.uiScale
        typeFamily:root.serifFamily
        // the frame is gold; this is the light of the gem that opened it
        accent:root.gemColorAt(root.gemIndexOf("organize"))
        animated:!root.paused;time:root.aliveTime
        orbStatus:"disconnected";orbAvailable:true
        orbTint:root.listPaint;orbAccent:root.gemColorAt(root.gemIndexOf("organize"))

        icon:root.organizerView==="folders" ? "folder" : "sort"
        // The smallest orb cannot fit "FILE ORGANIZER" beside a close disc; the
        // frame's own label rule cuts it sooner than two lines want. The orb is
        // named by its position, exactly like the other system orbs.
        title:root.organizerPanelTitle()
        pulse:root.organizerBusy
        state:root.organizerStateLine()
        status:root.organizerStatusLine()
        statusWarn:root.organizerError.length>0
        busy:root.organizerBusy

        mode:root.organizerMode()
        items:root.organizerRows()
        value:root.organizerMoved+"/"+root.organizerTotal
        valueSub:"files moved"
        ring:root.organizerRing
        emptyIcon:root.organizerError.length>0 ? "dot" : (root.organizerBusy ? "folder" : "folder")
        emptyText:root.organizerEmptyText()
        emptyHint:root.organizerEmptyHint()

        // the folder path is typed into the frame's own prompt field: same
        // component as the Wi-Fi passphrase, unmasked, with its own buttons
        promptVisible:root.organizerPrompt.length>0
        promptLabel:root.organizerPrompt==="central" ? "Central destination (empty = off)" : "Folder to add"
        promptPlaceholder:root.organizerPrompt==="central" ? "~/Documents/Sorted" : "~/Videos"
        promptAcceptLabel:"Save"
        promptMasked:false

        actions:root.organizerActions()
        names:({ list:"organizerList", empty:"organizerEmptyState", value:"organizerProgress",
                 hint:"organizerEmptyHint", status:"organizerStatusText" })

        onClose:root.closeOrganizer()
        onAction:(name) => root.organizerAction(name)
        onRowActivated:(item) => root.organizerRow(item)
        onPromptAccepted:(text) => root.organizerPromptAccept(text)
        onPromptCancelled:root.organizerPrompt=""
    }

    Timer {
        // Memory changes every second; the adapter caches storage for 30 s, so
        // this cheap tick is what keeps RAM honest without spinning df.
        interval:2500;repeat:true;running:root.resourcesOpen && root.connected && !root.paused
        onTriggered:root.refreshResources(true)
    }

}
