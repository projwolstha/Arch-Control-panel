import QtQuick

// ── SysStats — the three numbers the rings are told ─────────────────────────
//
// CPU, RAM and battery, each 0…1, each smoothed over 400 ms so a ring steps to a
// new value instead of jumping. Nothing here draws; JarvisCore only reads.
//
// WHERE THE NUMBERS COME FROM
//   battery  the adapter (UPower, through sphere_adapter/battery.py) already
//            reads it for the battery panel; it is handed in, so there is one
//            battery reading on screen and not two that can disagree.
//   CPU, RAM the kernel's own counters, sampled every two seconds:
//              /proc/stat      cpu user nice system idle iowait irq softirq …
//              /proc/meminfo   MemTotal, MemAvailable
//
// WHY A SIGNAL AND NOT A FILE READ
//   This file has no Quickshell import, so the widget — and every test harness —
//   loads it under plain Qt. `pollRequested` asks the caller to hand over fresh
//   bytes (shell.qml owns two FileViews and reloads them); the arithmetic happens
//   here, where it can be tested with fixed samples.
//
// ONE SAMPLE IS NOT A MEASUREMENT
//   /proc/stat holds totals since boot, so the first read only sets the baseline
//   and CPU keeps its previous value. The second read, two seconds later, is the
//   first real number: busy = 1 − Δidle / Δtotal.
//
// A MISSING SOURCE IS SAID OUT LOUD
//   No /proc/stat, no MemTotal, no battery: the value falls to 0 and the matching
//   `…Live` flag goes false. JarvisCore draws that ring's zero mark grey instead
//   of gold, so an empty ring never looks like a measurement of zero.
Item {
    id: stats

    // ── the beat ─────────────────────────────────────────────────────────────
    property bool enabled: true                 // false while the dashboard is hidden
    property int intervalMs: 2000               // Theme.statsPollMs
    property int smoothMs: 400                  // Theme.statsSmoothMs (0 = instant)
    signal pollRequested()

    Timer {
        interval: stats.intervalMs
        repeat: true
        running: stats.enabled
        triggeredOnStart: true                  // first baseline as soon as we appear
        onTriggered: stats.pollRequested()
    }

    // ── the samples, handed in ───────────────────────────────────────────────
    property string statText: ""
    property string memText: ""

    // ── the values, out ──────────────────────────────────────────────────────
    property real cpu: 0
    property real ram: 0
    property real battery: 0

    property bool cpuLive: false
    property bool ramLive: false
    property bool batteryLive: false

    // 400 ms, so a ring lights segment by segment rather than snapping
    Behavior on cpu { NumberAnimation { duration: stats.smoothMs; easing.type: Easing.OutCubic } }
    Behavior on ram { NumberAnimation { duration: stats.smoothMs; easing.type: Easing.OutCubic } }
    Behavior on battery { NumberAnimation { duration: stats.smoothMs; easing.type: Easing.OutCubic } }

    // ── the previous totals, for the delta ───────────────────────────────────
    property real prevTotal: 0
    property real prevIdle: 0

    onStatTextChanged: stats.ingest(stats.statText, stats.memText)
    onMemTextChanged: stats.ingest(stats.statText, stats.memText)

    function parseStat(text) {
        // the first line is the aggregate of every core
        var line = String(text || "").split("\n")[0];
        if (line.indexOf("cpu") !== 0) return null;
        var fields = line.split(/[ \t]+/);
        var parts = [];
        for (var i = 1; i < fields.length; i++) {
            if (fields[i].length === 0) continue;
            var v = Number(fields[i]);
            if (isNaN(v)) break;
            parts.push(v);
        }
        if (parts.length < 4) return null;             // user nice system idle
        var total = 0;
        for (var k = 0; k < parts.length; k++) total += parts[k];
        // idle + iowait: a disk wait is not the CPU working
        var idle = parts[3] + (parts.length > 4 ? parts[4] : 0);
        return { total: total, idle: idle };
    }

    function parseMem(text) {
        var body = String(text || "");
        var total = /MemTotal:\s+(\d+)/.exec(body);
        if (!total) return null;
        var t = Number(total[1]);
        if (!(t > 0)) return null;
        var avail = /MemAvailable:\s+(\d+)/.exec(body);
        var a = avail ? Number(avail[1]) : null;
        if (a === null) {
            // kernels before 3.14 have no MemAvailable; MemFree is the honest fallback
            var free = /MemFree:\s+(\d+)/.exec(body);
            if (!free) return null;
            a = Number(free[1]);
        }
        return Math.max(0, Math.min(1, (t - a) / t));
    }

    // One pass over a pair of samples. Public: the harnesses call it with fixed
    // text, and so could anything else that already has the bytes.
    function ingest(stat, mem) {
        var s = stats.parseStat(stat);
        if (s === null) {
            stats.cpu = 0;
            stats.cpuLive = false;
            stats.prevTotal = 0;
            stats.prevIdle = 0;
        } else {
            var dTotal = s.total - stats.prevTotal;
            var dIdle = s.idle - stats.prevIdle;
            if (stats.prevTotal > 0 && dTotal > 0 && dIdle >= 0 && dIdle <= dTotal) {
                stats.cpu = Math.max(0, Math.min(1, 1 - dIdle / dTotal));
                stats.cpuLive = true;
            }
            stats.prevTotal = s.total;
            stats.prevIdle = s.idle;
        }

        var m = stats.parseMem(mem);
        if (m === null) {
            stats.ram = 0;
            stats.ramLive = false;
        } else {
            stats.ram = m;
            stats.ramLive = true;
        }
    }
}
