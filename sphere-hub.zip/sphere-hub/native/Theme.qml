import QtQuick

// ── Theme — the one place a colour is written down ──────────────────────────
//
// Every line, gem, rune, particle and orb reads from here, so recolouring
// the whole interface is one edit. The values are the reference palette: engraved
// gold on near-black, cyan holographic light, and five gem hues that are *not*
// the four stock Qt colours — pink, gold, cyan, electric blue, violet.
//
// Three weights exist for every line, because a line is never one stroke (see
// EnergyLine.qml):
//   glow  — the wide atmospheric wash, very low alpha
//   mid   — the saturated stroke that carries the colour
//   core  — a thin near-white filament that reads as the light itself
//
// Instances are cheap (QtObject, no children). One is created by SphereWidget and
// handed down; the QA harnesses create their own.
QtObject {
    id: theme
    objectName: "theme"

    // ── gold: the engraved metal ─────────────────────────────────────────────
    readonly property color goldDeep: "#C98A12"
    readonly property color gold: "#F5B82E"
    readonly property color goldBright: "#FFD65A"
    readonly property color goldWhite: "#FFF0B8"
    // the cool alternative family for the tight outer rings (outerColor: silver)
    readonly property color silverDeep: "#5A6674"
    readonly property color silver: "#8C9AAB"
    readonly property color silverBright: "#C6D2DE"
    readonly property color silverWhite: "#F2F6FA"
    readonly property string outerColor: "gold"          // gold | silver
    readonly property color goldShadow: "#3a2a0d"

    // ── holographic light ────────────────────────────────────────────────────
    readonly property color cyan: "#4fe8ff"
    readonly property color cyanDeep: "#127a99"
    readonly property color cyanWhite: "#e8feff"
    readonly property color blue: "#1b5fd8"
    readonly property color blueDeep: "#0a2138"

    // ── the room ─────────────────────────────────────────────────────────────
    readonly property color white: "#ffffff"        // speculars and glass sheen
    readonly property color ink: "#05070c"          // the disc's face
    readonly property color bg: "#04060b"           // the atmosphere
    readonly property color bgDeep: "#020308"       // the far edge of the veil
    readonly property color shadow: "#000000"

    // ── the five gems ────────────────────────────────────────────────────────
    // Positions and panels are the widget's (SphereWidget.gemSpecs); only the
    // light belongs here.
    // the classic five: red, green, pink, blue, yellow. They are the gem's
    // identity — status colours inside a panel stay the panel's own business.
    readonly property color gemWifi: "#ff3b3b"      // top — red
    readonly property color gemBluetooth: "#3ddc84" // upper right — green
    readonly property color gemBattery: "#ff3bd4"   // lower right — pink
    readonly property color gemSystem: "#3b7bff"    // lower left — blue
    readonly property color gemFiles: "#ffd23b"     // upper left — yellow

    // ── the Jarvis core ──────────────────────────────────────────────────────
    // The centre. Every size here is a fraction of the core's own radius, so the
    // core scales with the disc and never needs a second set of constants. The
    // core is fitted to 0.92 of the disc's width, which puts it inside the gold
    // bevel at about 0.47 R.
    readonly property real coreFit: 0.92            // × the disc's width
    readonly property real coreOrbRadius: 0.362     // × core radius (≈ 0.16 R)
    readonly property real coreRingOuter: 0.88      // CPU
    readonly property real coreRingMiddle: 0.70     // RAM
    readonly property real coreRingInner: 0.52      // battery
    readonly property int coreCpuSegments: 48
    readonly property int coreRamSegments: 36
    readonly property int coreBatterySegments: 24
    readonly property real coreSegmentGap: 0.34     // share of the pitch left empty
    readonly property real coreRingStroke: 0.020    // × core radius
    readonly property real coreLitAlpha: 0.95
    readonly property real coreDimAlpha: 0.14
    readonly property real coreHaloScale: 1.40      // × the orb's diameter
    readonly property real coreHaloAlpha: 0.46
    readonly property color coreOrbCore: cyanWhite  // the orb's centre
    readonly property color coreOrbEdge: blue       // …and its edge
    readonly property color coreRingLit: cyan
    readonly property color coreRingDim: cyanDeep
    readonly property color coreAccent: white        // the segments that mark zero
    readonly property real coreMissingAlpha: 0.30   // that mark, when the source is absent

    // ── the clock over the orb ───────────────────────────────────────────────
    // Large thin time and a small-caps date, both in the plate serif, on a soft
    // dark scrim so cream type still reads against the orb's white-cyan centre.
    readonly property real coreClockTimeSize: 0.168     // × core radius
    readonly property real coreClockDateSize: 0.068
    readonly property real coreClockTimeSpacing: 0.012  // × core radius
    readonly property real coreClockDateSpacing: 0.028
    readonly property real coreClockGap: 0.020          // between the two lines
    readonly property int coreClockWeight: 500          // Font.Light: thin, not hairline
    readonly property color coreClockTime: white
    readonly property color coreClockDate: cyanWhite
    readonly property real coreClockDateAlpha: 0.80
    readonly property real coreScrimScale: 1.10         // × the orb's diameter
    readonly property real coreScrimAlpha: 0.34

    // ── the idle motion ──────────────────────────────────────────────────────
    // Four things move, and each one is a switch: set it false and that motion
    // stops where it is. All of them read the widget's `animated` flag, which is
    // false whenever the dashboard is hidden, paused or in low power.
    readonly property bool coreBreath: true
    readonly property real coreBreathScale: 0.028     // the orb's ± scale
    readonly property int coreBreathMs: 5200          // one full breath
    readonly property bool coreDrift: true
    readonly property real coreDriftDeg: 1.6          // the rings sway, they do not turn
    readonly property int coreDriftMsOuter: 21000
    readonly property int coreDriftMsMiddle: 27000
    readonly property int coreDriftMsInner: 17000
    readonly property bool coreSweep: true
    readonly property int coreSweepMs: 20000          // one turn of the radar
    // the wedge's width, radius and fade live in the asset (core-sweep.svg)
    // the time dials: 12 hour dots closest to the orb, then 60 minute dots,
    // then 60 second dots. A dot is never animated — it moves one place per
    // unit — so these are sizes and alphas, not durations.
    readonly property bool coreDials: true
    readonly property bool coreDialFill: true         // false: only the current dot is lit
    readonly property int coreDialHours: 12
    readonly property int coreDialMinutes: 60
    readonly property int coreDialSeconds: 60
    // radii, × the core's radius. They interleave with the three load rings on
    // purpose (0.52 / 0.70 / 0.88): the clock hugs the orb, the load sits out.
    readonly property real coreDialHoursRadius: 0.445
    readonly property real coreDialMinutesRadius: 0.630
    readonly property real coreDialSecondsRadius: 0.790
    // the dots' diameters, × core radius — dim, then the lit one
    readonly property real coreDialHourDot: 0.052
    readonly property real coreDialHourNow: 0.102
    readonly property real coreDialMinuteDot: 0.031
    readonly property real coreDialMinuteNow: 0.070
    readonly property real coreDialSecondDot: 0.035
    readonly property real coreDialSecondNow: 0.078
    readonly property color coreDialColor: cyan       // the dots of the hour and the minute
    readonly property color coreDialAccent: cyan      // …and of the second, which is the hand
    readonly property color coreDialNow: cyanWhite    // the current dot
    readonly property real coreDialDimAlpha: 0.24
    readonly property real coreDialPastAlpha: 0.52
    readonly property real coreDialNowAlpha: 1.00
    // a dark ring keeps the lit dot readable on top of a load ring's bar
    readonly property real coreDialNowRing: 0.005     // × core radius
    readonly property real coreDialRingAlpha: 0.85
    readonly property color coreDialRingColor: ink

    // ── the crest's line language ───────────────────────────────────────────
    // Mirrored from config/theme.json (test_config.py keeps them in step). All
    // widths are px at R = 500 — the drawing code scales by radius / 500 — and
    // every alpha is the line's own opacity. The gold STOPS of these lines are
    // goldGlow (0-1, default 0.6) scales every gold bloom layer below.
    readonly property real crestGoldGlow: 0.60
    readonly property var crestOuterEdgeWidths: [4.2, 4.2, 4.2, 5.5]
    readonly property var crestOuterEdgeAlphas: [0.80, 0.85, 0.92, 1.00]
    readonly property real crestRuneRingWidth: 1.2
    readonly property real crestRuneRingAlpha: 0.90
    readonly property real crestRuneGlyphAlpha: 0.85
    readonly property real crestDashedWidth: 1.0
    readonly property real crestDashedAlpha: 0.18
    readonly property real crestDashedOn: 2.0
    readonly property real crestDashedOff: 6.0
    readonly property real crestGuideWidth: 1.0
    readonly property real crestGuideAlpha: 0.20
    readonly property real crestSigilWidth: 1.3
    readonly property real crestSigilAlpha: 0.90
    readonly property real crestConnectorWidth: 0.9
    readonly property real crestConnectorAlpha: 0.45
    readonly property real crestSpokeGemWidth: 1.5
    readonly property real crestSpokeGemAlpha: 0.55
    readonly property real crestSpokeSegWidth: 1.0
    readonly property real crestSpokeSegAlpha: 0.35
    readonly property real crestStarWidth: 1.0
    readonly property real crestStarAlpha: 0.30
    readonly property real crestNodeAlpha: 0.95
    readonly property real crestCoreRingWidth: 1.2
    readonly property real crestCoreRingAlpha: 0.90

    // ── the readings ─────────────────────────────────────────────────────────
    // The three rings are live from step 3 on: /proc sampled on this beat, and a
    // value that steps to its new place over this long instead of snapping.
    readonly property int statsPollMs: 2000
    readonly property int statsSmoothMs: 400

    // ── the seconds arc, riding just outside the inner ring ──────────────────
    readonly property real coreArcRadius: 0.585         // × core radius
    readonly property real coreArcWidth: 0.011          // × core radius
    readonly property real coreArcAlpha: 0.95
    readonly property real coreArcHeadScale: 2.1        // × the arc's width
    readonly property color coreArcColor: cyan
    readonly property color coreArcHead: white

    // ── weights, so "make the lines glow more" is one number ────────────────
    readonly property real glowAlpha: 0.13          // the wide wash
    readonly property real midAlpha: 0.46           // the saturated stroke
    readonly property real coreAlpha: 0.92          // the near-white filament
    readonly property real glowScale: 5.0           // glow stroke width, × weight
    readonly property real midScale: 1.9
    readonly property real coreScale: 0.9
    readonly property real line: 1.0                // master stroke multiplier

    // ── glass, halos, particles ─────────────────────────────────────────────
    readonly property real glassOpacity: 0.92
    readonly property bool liquidGlass: true
    readonly property bool visionOsGlass: true
    readonly property bool orbitRevolve: true
    readonly property real orbitRevolveDegPerSec: 18.0
    readonly property bool coreOrbSwirl: true
    readonly property int coreOrbSwirlMs: 20000
    readonly property color smokedCore: "#162033"
    readonly property color chromeRim: "#dce6f5" 
    readonly property real liquidTorusAlpha: 0.96
    readonly property real liquidGlazeAlpha: 0.95
    readonly property real liquidGoldEmbedAlpha: 0.54
    readonly property real liquidLensAlpha: 0.95
    readonly property real liquidLensOpenAlpha: 0.34
    readonly property real gemDomeAlpha: 0.94
    readonly property real shellOpacity: 0.34
    readonly property real haloOpacity: 0.55
    readonly property real coreBrightness: 0.85
    readonly property real bloom: 1.0               // particle/glow master

    // ── helpers ──────────────────────────────────────────────────────────────
    function alpha(c, a) {
        var k = Qt.color(c);
        return Qt.rgba(k.r, k.g, k.b, Math.max(0, Math.min(1, a)));
    }
    // toward white: what the core of a glowing line is made of
    function light(c, t) {
        var k = Qt.color(c);
        return Qt.rgba(k.r + (1 - k.r) * t, k.g + (1 - k.g) * t, k.b + (1 - k.b) * t, k.a);
    }
    function dark(c, t) {
        var k = Qt.color(c);
        return Qt.rgba(k.r * (1 - t), k.g * (1 - t), k.b * (1 - t), k.a);
    }
}
