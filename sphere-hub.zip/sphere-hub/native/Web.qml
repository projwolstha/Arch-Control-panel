import QtQuick
import QtQuick.Shapes

// ── Web — the static radial web inside the ring ────────────────────────────
//
// Five gem spokes (the gem's inner edge to the core ring), five segment
// spokes (the inner band ring to the core ring), a tiny gold node wherever a
// spoke ends, the optional gemStar pentagram through the gems, and the
// optional guide circle on the inner band line. Everything is one quiet
// stroke language — theme px at R = 500, flat lines, no glow — and nothing
// here moves, ever: the web owns no transform (motion.json webRotation is
// false) and keeps no timer. `clock` and `animated` are the webPulse hook
// the motion step may use; the drawing itself is inert.
//
// The web is the ring's bottom layer: the core disc (SphereWidget z 20)
// covers the pentagram's middle and the gems their chord ends, so the star
// reads as running behind them — how the target's web reads. And no line may
// cross a sigil: the web's furthest reach is the gemStar radius, well inside
// the sigil ring — native/tests/test_config.py proves the invariant
// numerically, and nothing here may raise a reach without failing it.
Item {
    id: web
    objectName: "webLayer"

    property real radius: 300                  // R — every measurement is a fraction of it
    property real clock: 0                     // webPulse's hook (motion step)
    property bool animated: false
    property Motion motion: Motion {}
    property Geometry geometry: Geometry {}
    property Theme theme: Theme {}

    width: radius * 2
    height: width

    // one weight language: theme px at R = 500, scaled to this ring
    function weight(px) {
        return Math.max(0.6, radius / 500 * px);
    }

    // screen degrees (0 = straight up is -90, clockwise), y down — the same
    // convention as gemAnglesDeg
    function pt(frac, deg) {
        var a = deg * Math.PI / 180;
        return [radius + Math.cos(a) * frac * radius, radius + Math.sin(a) * frac * radius];
    }

    function segment(fracA, fracB, degA, degB) {
        var a = pt(fracA, degA), b = pt(fracB, degB);
        return "M " + a[0].toFixed(2) + " " + a[1].toFixed(2) + " L " + b[0].toFixed(2) + " " + b[1].toFixed(2) + " ";
    }

    function circlePath(fraction) {
        var rr = radius * fraction;
        return "M " + radius.toFixed(2) + " " + (radius - rr).toFixed(2) + " A " + rr.toFixed(2) + " " + rr.toFixed(2) + " 0 1 1 " + radius.toFixed(2) + " " + (radius + rr).toFixed(2) + " A " + rr.toFixed(2) + " " + rr.toFixed(2) + " 0 1 1 " + radius.toFixed(2) + " " + (radius - rr).toFixed(2) + " Z";
    }

    Shape {
        anchors.fill: parent

        // ── the guide circle (optional, default on) ───────────────────────
        ShapePath {
            strokeWidth: web.weight(web.theme.crestGuideWidth)
            strokeColor: web.theme.alpha(web.theme.gold, web.theme.crestGuideAlpha)
            fillColor: "transparent"
            PathSvg {
                path: web.geometry.guideEnabled ? web.circlePath(web.geometry.guideRadius) : ""
            }
        }

        // ── the gemStar pentagram (optional, default on) ──────────────────
        // gem i to gem i+2 — its middle hides behind the core disc, its
        // chord ends behind the gems
        ShapePath {
            strokeWidth: web.weight(web.theme.crestStarWidth)
            strokeColor: web.theme.alpha(web.theme.gold, web.theme.crestStarAlpha)
            strokeStyle: ShapePath.SolidLine
            fillColor: "transparent"
            PathSvg {
                path: {
                    if (!web.geometry.gemStarEnabled)
                        return "";
                    var d = "";
                    for (var i = 0; i < web.geometry.gemCount; i++)
                        d += web.segment(web.geometry.gemStarRadius, web.geometry.gemStarRadius, web.geometry.gemAngle(i, web.geometry.gemCount), web.geometry.gemAngle(i + 2, web.geometry.gemCount));
                    return d;
                }
            }
        }

        // ── the five gem spokes ───────────────────────────────────────────
        ShapePath {
            strokeWidth: web.weight(web.theme.crestSpokeGemWidth)
            strokeColor: web.theme.alpha(web.theme.gold, web.theme.crestSpokeGemAlpha)
            strokeStyle: ShapePath.SolidLine
            fillColor: "transparent"
            PathSvg {
                path: {
                    var d = "";
                    for (var i = 0; i < web.geometry.gemCount; i++)
                        d += web.segment(web.geometry.spokeGemFrom, web.geometry.spokeGemTo, web.geometry.gemAngle(i, web.geometry.gemCount), web.geometry.gemAngle(i, web.geometry.gemCount));
                    return d;
                }
            }
        }

        // ── the five segment spokes ───────────────────────────────────────
        ShapePath {
            strokeWidth: web.weight(web.theme.crestSpokeSegWidth)
            strokeColor: web.theme.alpha(web.theme.gold, web.theme.crestSpokeSegAlpha)
            strokeStyle: ShapePath.SolidLine
            fillColor: "transparent"
            PathSvg {
                path: {
                    var d = "";
                    for (var i = 0; i < web.geometry.gemCount; i++)
                        d += web.segment(web.geometry.spokeSegmentFrom, web.geometry.spokeSegmentTo, web.geometry.segmentAngle(i, web.geometry.gemCount), web.geometry.segmentAngle(i, web.geometry.gemCount));
                    return d;
                }
            }
        }
    }

    // ── webPulse: a faint light travels the spokes (motion, off by default) ─
    Shape {
        anchors.fill: parent
        visible: web.animated && web.motion.webPulse
        ShapePath {
            strokeWidth: web.weight(web.theme.crestSpokeGemWidth)
            strokeColor: web.theme.alpha(web.theme.goldWhite, 0.45)
            strokeStyle: ShapePath.DashLine
            dashPattern: [web.weight(16), web.weight(44)]
            dashOffset: -(web.clock * 30)
            fillColor: "transparent"
            PathSvg {
                path: {
                    if (!web.animated || !web.motion.webPulse)
                        return "";
                    var d = "";
                    for (var i = 0; i < web.geometry.gemCount; i++) {
                        d += web.segment(web.geometry.spokeGemFrom,
                                         web.geometry.spokeGemTo,
                                         web.geometry.gemAngle(i, web.geometry.gemCount),
                                         web.geometry.gemAngle(i, web.geometry.gemCount));
                        d += web.segment(web.geometry.spokeSegmentFrom,
                                         web.geometry.spokeSegmentTo,
                                         web.geometry.segmentAngle(i, web.geometry.gemCount),
                                         web.geometry.segmentAngle(i, web.geometry.gemCount));
                    }
                    return d;
                }
            }
        }
    }

    // ── the nodes: one wherever a spoke ends ──────────────────────────────
    Repeater {
        model: web.geometry.gemCount * 4
        delegate: Rectangle {
            required property int index
            readonly property int group: Math.floor(index / web.geometry.gemCount)
            readonly property int k: index % web.geometry.gemCount
            readonly property real deg: group < 2 ? web.geometry.gemAngle(k, web.geometry.gemCount) : web.geometry.segmentAngle(k, web.geometry.gemCount)
            readonly property real frac: [web.geometry.spokeGemFrom, web.geometry.spokeGemTo, web.geometry.spokeSegmentFrom, web.geometry.spokeSegmentTo][group]
            readonly property var at: web.pt(frac, deg)
            x: at[0] - width / 2
            y: at[1] - height / 2
            width: web.radius * web.geometry.nodeSize
            height: width
            radius: width / 2
            color: web.theme.alpha(web.theme.goldBright, web.theme.crestNodeAlpha)
        }
    }
}
