#!/bin/sh
# Launch Sphere's native Rust desktop adapter (`sphere-backend`) via `exec` so
# no intermediate shell or Python interpreter stays resident in memory. Falls
# back to `backend.py` only if no native binary is installed yet.
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if [ -n "${SPHERE_BACKEND_BIN:-}" ] && [ -x "${SPHERE_BACKEND_BIN}" ]; then
    exec "${SPHERE_BACKEND_BIN}" "$@"
fi

if [ -x "$HERE/sphere-backend" ]; then
    exec "$HERE/sphere-backend" "$@"
fi

if [ -x "${HOME}/.local/bin/sphere-backend" ]; then
    exec "${HOME}/.local/bin/sphere-backend" "$@"
fi

if [ -x "$HERE/../rust-backend/target/release/sphere-backend" ]; then
    exec "$HERE/../rust-backend/target/release/sphere-backend" "$@"
fi

exec python3 "$HERE/backend.py" "$@"
