#!/usr/bin/env python3
"""Sphere's local, stdio-only desktop adapter — executable entry point.

The implementation lives in the sibling ``sphere_adapter`` package, one concern
per module. This file only puts that directory on ``sys.path`` and re-exports the
public surface, so ``python3 backend.py serve`` (the command Quickshell runs) and
``import backend`` keep working exactly as before. No network server, no shell
evaluation; requests arrive on stdin and responses leave stdout.
"""
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from sphere_adapter import *  # noqa: E402,F401,F403
from sphere_adapter import __all__ as _ADAPTER_EXPORTS  # noqa: E402
from sphere_adapter.cli import main  # noqa: E402

__all__ = list(_ADAPTER_EXPORTS) + ["main"]

if __name__ == "__main__":
    raise SystemExit(main())
