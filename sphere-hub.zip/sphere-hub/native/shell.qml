import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Wayland

ShellRoot {
    id: root
    function chooseScreen() {
        var name=widget.snapshot.preferences.screenName || "";
        for(var i=0;i<Quickshell.screens.length;i++) if(Quickshell.screens[i].name===name) return Quickshell.screens[i];
        return Quickshell.screens[0] || null;
    }
    // ── the ring's geometry, asked of the widget ──────────────────────────────
    // `orbHit(i)` is the rect gem i is *drawn* and hit at, straight from the
    // widget's own gemRect() plus a little air. Geometry only: the IPC health
    // report and the doctor ask "where is that stone", and the input mask does
    // not use it — the mask is the whole surface (see PanelWindow below).
    function orbHit(index) {
        if(index<0 || index>=widget.gemCount) return Qt.rect(0,0,0,0);
        var r=widget.gemRect(index);
        var pad=r.width*0.06;
        return Qt.rect(r.x-pad, r.y-pad, r.width+pad*2, r.height+pad*2);
    }
    // Ring geometry, never gated: no panel, no focus and no flag can empty one.
    // The five indices are the gem table's order, first at the top.
    function orbRegion(index) { return root.orbHit(index); }
    function wifiOrbRegion() { return root.orbHit(0); }
    function bluetoothOrbRegion() { return root.orbHit(1); }
    function batteryOrbRegion() { return root.orbHit(2); }
    function resourcesOrbRegion() { return root.orbHit(3); }
    function organizerOrbRegion() { return root.orbHit(4); }
    function mainOrbRegion() { return widget.mainOrbRegion; }
    // ── the logo file ─────────────────────────────────────────────────────────
    // ~/.config/jarvis/logo.svg wins; logo.png is the fallback. Both are watched
    // (inotify — no polling), and every change bumps the widget's revision so the
    // Image reloads the same path instead of showing a cached copy. A missing
    // file is not an error: the widget keeps drawing its own arch glyph, and the
    // install summary prints the path to drop one at.
    readonly property string configDir: Quickshell.env("XDG_CONFIG_HOME") || (Quickshell.env("HOME")+"/.config")
    readonly property string logoDir: root.configDir+"/jarvis"
    property bool svgPresent:false
    property bool pngPresent:false
    function syncLogo() {
        root.svgPresent=logoSvg.loaded===true;
        root.pngPresent=logoPng.loaded===true;
        widget.logoSource=root.svgPresent ? logoSvg.path : (root.pngPresent ? logoPng.path : "");
        widget.logoRevision=widget.logoRevision+1;
    }
    FileView {
        id:logoSvg
        path:root.logoDir+"/logo.svg"
        watchChanges:true
        onFileChanged:{ reload(); root.syncLogo(); }
        onLoaded:root.syncLogo()
    }
    FileView {
        id:logoPng
        path:root.logoDir+"/logo.png"
        watchChanges:true
        onFileChanged:{ reload(); root.syncLogo(); }
        onLoaded:root.syncLogo()
    }
    IpcHandler {
        target: "sphere"
        function health(): string {
            var positions=[];
            for(var i=0;i<widget.gemCount;i++) {
                var c=widget.gemCenter(i);
                positions.push({gem:widget.gemKey(i),x:c.x,y:c.y});
            }
            return JSON.stringify({protocol:1,version:"sphere-native-6.18.0",native:true,webEngine:false,
                processId:Quickshell.processId,backendConnected:widget.connected,
                interactive:widget.sphereVisible,clickThrough:!widget.sphereVisible,
                inputRegion:({x:0,y:0,width:panel.width,height:panel.height}),
                sphereVisible:widget.sphereVisible,
                hyprland:widget.nativeStatus.hyprland,visible:panel.visible,
                screen:panel.screen?panel.screen.name:"",width:panel.width,height:panel.height,
                layer:"overlay",keyboardFocus:widget.sphereVisible?"exclusive":"none",
                namespace:"sphere-hub",gemCount:widget.gemCount,gem:widget.gemKey(0)+","+widget.gemKey(1),
                preferences:widget.snapshot.preferences,
                panel:widget.activePanel,pinned:widget.pinned,
                logo:({path:widget.logoPathLabel,present:widget.hasLogo}),
                wifi:({open:widget.wifiPanelOpen,available:widget.wifi.available===true,radioOn:widget.wifi.radioOn===true,
                    connected:widget.wifiConnected,ssid:widget.wifiConnected?widget.wifi.active.ssid:""}),
                system:({open:widget.resourcesPanelOpen,available:widget.resourcesAvailable,
                    ram:widget.ramPercent,disk:widget.diskPercent,slot:widget.resourcesSlot,
                    orb:({x:root.orbHit(3).x,y:root.orbHit(3).y,width:root.orbHit(3).width,height:root.orbHit(3).height}),
                    region:({x:root.resourcesOrbRegion().x,y:root.resourcesOrbRegion().y,
                             width:root.resourcesOrbRegion().width,height:root.resourcesOrbRegion().height})}),
                renderedFrames:widget.renderedFrames,
                savedTo:widget.snapshot.savedTo || "",orbs:positions});
        }
        function pause(value: bool): void { widget.savePreference("paused",value); }
        function lock(value: bool): void { widget.savePreference("orbitLocked",value); }
        function refresh(): void { widget.emitRequest({action:"refresh"}); }
        // SUPER+A model: dismiss hides the sphere AND ends the whole widget process
        // (Quickshell + adapter exit; state lives on disk) so hidden === 0 MB/0% CPU.
        // summon makes it visible and immediately usable. The manager wires the key.
        function summon(): string { widget.summon(); return "summoned"; }
        function dismiss(): string {
            // Fade first, unmap at the end of the fade, then exit cleanly so the
            // supervisor stands down. The quit fallback is belt and braces: a
            // dismissed dashboard must never linger with the pointer captured.
            widget.beginDismiss();
            quitFallback.restart();
            return "dismissed";
        }
        function wifi(): string { widget.openWifi(); return "wifi-opened"; }
        function wifiClose(): string { widget.closeWifi(); return "wifi-closed"; }
        function toggleWifi(): string { widget.toggleWifi(); return widget.wifiPanelOpen?"wifi-opened":"wifi-closed"; }
        // The System panel, openable and closable without a pointer. Handy when
        // the ring is locked or an input region is being investigated.
        function system(): string { widget.openResources(); return "system-opened"; }
        function systemClose(): string { widget.closeResources(); return "system-closed"; }
        function toggleSystem(): string { widget.toggleResources(); return widget.resourcesPanelOpen?"system-opened":"system-closed"; }
        // The file organizer, openable and closable without a pointer.
        function files(): string { widget.openOrganizer(); return "files-opened"; }
        function filesClose(): string { widget.closeOrganizer(); return "files-closed"; }
        function toggleFiles(): string { widget.toggleOrganizer(); return widget.organizerOpen?"files-opened":"files-closed"; }
        function toggle(): string {
            if(!widget.sphereVisible) return summon();
            return dismiss();
        }
    }
    // ── the file organizer's process bridge ───────────────────────────────────
    // The panel never moves a file: it asks for a command, this runs
    // `jarvis-organize`, and every JSON line the backend prints goes straight
    // into the widget. Two processes, because a `run` can take a while and a
    // status refresh must never kill a half-finished move.
    property string organizerBin: (Quickshell.env("JARVIS_ORGANIZE") || "")
                                  || (Quickshell.env("HOME") + "/.local/bin/jarvis-organize")
    property var organizerPending: []
    function organizerCommand(command, args) {
        return [root.organizerBin, command].concat(args || []);
    }
    function runOrganizer(command, arguments) {
        var isLong = (command === "run" || command === "watch" || command === "watch-all");
        var handler = isLong ? organizeRun : organizeInfo;
        handler.command = root.organizerCommand(command, arguments);
        handler.sawJson = false;
        handler.stderrText = "";
        handler.running = true;
    }
    Process {
        id:organizeInfo
        command:["true"]
        running:false
        property bool sawJson:false
        property string stderrText:""
        stdout:SplitParser {
            onRead:data=>{ organizeInfo.sawJson=true; widget.applyOrganizerLine(data); }
        }
        stderr:SplitParser { onRead:data=>{ organizeInfo.stderrText=String(data); } }
        onExited:(code,status)=>{
            if(code!==0 && !organizeInfo.sawJson && organizeInfo.stderrText.length>0)
                widget.applyOrganizerLine(JSON.stringify({ok:false,event:"error",error:organizeInfo.stderrText}));
            widget.organizerFinished(code);
        }
    }
    Process {
        id:organizeRun
        command:["true"]
        running:false
        property bool sawJson:false
        property string stderrText:""
        stdout:SplitParser {
            onRead:data=>{ organizeRun.sawJson=true; widget.applyOrganizerLine(data); }
        }
        stderr:SplitParser { onRead:data=>{ organizeRun.stderrText=String(data); } }
        onExited:(code,status)=>{
            if(code!==0 && !organizeRun.sawJson && organizeRun.stderrText.length>0)
                widget.applyOrganizerLine(JSON.stringify({ok:false,event:"error",error:organizeRun.stderrText}));
            widget.organizerFinished(code);
        }
    }
    Connections {
        target:widget
        function onOrganizerRequest(command, args) { root.runOrganizer(command, args); }
    }
    Process {
        id:backend
        command:[Quickshell.shellPath("backend-launch.sh"),"serve"]
        stdinEnabled:true
        running:false
        stdout:SplitParser {
            onRead:data=>{
                try {widget.handleMessage(JSON.parse(data));}
                catch(error) {console.warn("Sphere adapter returned invalid JSON:",String(error));}
            }
        }
        onExited:(exitCode,exitStatus)=>{
            widget.connected=false;
            widget.nativeStatus=({hyprland:false,activeDesktopId:"",runningDesktopIds:[]});
            widget.notice="Local adapter stopped ("+exitCode+"). Reconnecting…";
            reconnect.restart();
        }
    }
    Timer {id:reconnect;interval:3000;onTriggered:backend.running=true}
    // The widget asks to leave (Escape with nothing open). Same path as SUPER+A.
    Connections {
        target:widget
        function onDismissRequested() { widget.beginDismiss(); quitFallback.restart(); }
        function onDismissFinished() { Qt.quit(); }
    }
    Timer {id:quitFallback;interval:700;repeat:false;onTriggered:Qt.quit()}
    Timer {
        // The adapter is a separate process, but starting it during the first
        // frame still costs the UI thread the fork + JSON parse. Paint first,
        // accept input first, then connect: nothing here gates hit-testing.
        id:boot;interval:150;repeat:false
        onTriggered:backend.running=true
    }
    // One handler: a second Component.onCompleted on the same object is a
    // load-time error ("Property value set multiple times"), not a merge.
    Component.onCompleted:{ root.syncLogo(); boot.start(); }
    PanelWindow {
        id:panel
        // ── the surface IS the dashboard ─────────────────────────────────────
        // Full screen, Overlay layer, exclusion ignored: it covers every window
        // and, because its input region is the whole surface, every click, wheel
        // tick and hover inside the monitor belongs to the dashboard while it is
        // visible. `visible:false` unmaps it, so nothing is captured — and no
        // frame of an animation, no pose() rect and no flag can change that.
        visible:widget.sphereVisible
        screen:root.chooseScreen()
        anchors { top:true; bottom:true; left:true; right:true }
        implicitWidth:screen?screen.width:1920
        implicitHeight:screen?screen.height:1080
        color:"transparent"
        exclusionMode:ExclusionMode.Ignore
        WlrLayershell.namespace:"sphere-hub"
        // Overlay is the only layer that is above tiled, floating AND fullscreen
        // windows; Top leaves a fullscreen client above a dashboard that looks
        // visible but is not reachable.
        WlrLayershell.layer:WlrLayer.Overlay
        // Present but not focused (None) never receives Escape. Exclusive while
        // visible, None while hidden, so the window underneath keeps its keys the
        // moment the dashboard is gone.
        WlrLayershell.keyboardFocus:widget.sphereVisible?WlrKeyboardFocus.Exclusive:WlrKeyboardFocus.None
        // One rectangle, independent of animations and of the ring: this is what
        // guarantees "every orb is clickable from the first visible frame to the
        // last". It is computed from `visible` alone.
        mask:Region {
            x:0;y:0
            width:widget.sphereVisible?panel.width:0
            height:widget.sphereVisible?panel.height:0
        }
        // ── the kernel's counters, for the rings ────────────────────────
        // Two plain reads, no watching: SysStats asks for them on its own beat
        // (the widget's `statsPoll`), so the cost is two file reads every two
        // seconds while the dashboard is visible, and nothing at all while it is
        // not. printErrors is off: a missing file is a state the widget already
        // draws, not a line in the log.
        //
        // text() is a function in Quickshell (v0.3, "Functions"), and a binding on
        // it re-runs when the file loads or is reloaded — that is the whole
        // hand-over: bytes on disk → SysStats → the rings.
        FileView {
            id:procStatView
            path:"/proc/stat"
            watchChanges:false
            printErrors:false
        }
        FileView {
            id:procMemView
            path:"/proc/meminfo"
            watchChanges:false
            printErrors:false
        }
        // ── the clock ────────────────────────────────────────────────────
        // Quickshell's own SystemClock: it wakes within 50 ms of the system
        // second changing and costs nothing in between. `enabled` is what keeps
        // "hidden = frozen" true — while the surface is unmapped the clock stops,
        // so the widget's date/time stop with it.
        SystemClock {
            id:systemClock
            precision: SystemClock.Seconds
            enabled: widget.sphereVisible && !widget.paused
        }
        SphereWidget {
            id:widget;anchors.fill:parent
            now: systemClock.date
            procStat:procStatView.text()
            procMem:procMemView.text()
            // SysStats' two-second beat: hand it fresh bytes
            onStatsPoll:{ procStatView.reload(); procMemView.reload(); }
            screenNames:{var names=[];for(var i=0;i<Quickshell.screens.length;i++) names.push(Quickshell.screens[i].name);return names;}
            onRequest:message=>{if(backend.running) backend.write(JSON.stringify(message)+"\n");}
        }
    }
}
