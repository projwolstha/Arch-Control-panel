"""Sphere's stdio-only desktop adapter, split one concern per module.

``backend.py`` next to this package is a thin executable shim that re-exports
everything below, so ``python3 backend.py serve`` and the unit tests keep working.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys

from .bridge import Bridge, serve
from .catalog import DesktopCatalog
from .cli import main
from .config import ConfigStore
from .constants import HERE, MANAGERS, PACKAGE_RE, RECIPE_BY_ID, RECIPES, SLOT_COUNT, TERMINALS
from .hypr import desktop_environment, hypr_command
from . import wifi
from .install import install_plan, installer_cli
from .pathutil import data_dirs, default_config_path, executable, expand_exec, norm, socket_path
from .system import detect_terminal, os_release, system_info
from .terminal import terminal_argv

__all__ = [
    "Bridge", "ConfigStore", "DesktopCatalog", "HERE", "MANAGERS", "PACKAGE_RE", "RECIPE_BY_ID",
    "RECIPES", "SLOT_COUNT", "TERMINALS", "data_dirs", "default_config_path", "desktop_environment",
    "detect_terminal", "executable", "expand_exec", "hypr_command", "install_plan", "installer_cli",
    "main", "norm", "os", "os_release", "serve", "shutil", "socket_path", "subprocess", "sys",
    "system_info", "terminal_argv", "wifi",
]
