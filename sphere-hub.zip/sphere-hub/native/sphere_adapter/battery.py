"""Battery state for the orb panel, read from UPower and /sys.

The panel needs one flat state dict; everything else is this module's problem.

Source order
------------
1. **UPower** — the daemon Quickshell's ``SERVICE_UPOWER`` module would talk to.
   That module is compiled out of this build (see ``OFF_FEATURES``), so the same
   data is read through ``upower -e`` / ``upower -i``: one process, no polling
   loop of its own, and the numbers are already normalised to Wh/W.
2. **/sys/class/power_supply/BAT\\*** — used when ``upower`` is missing or answers
   nothing. Raw microwatt-hours / microvolts, converted here.
3. Nothing — ``present: False`` and one plain sentence; the panel shows
   "No battery detected" and desktops carry on.

Every field may be ``None``. The panel hides what it cannot show instead of
printing an error.
"""
from __future__ import annotations

import os
import re
import subprocess
import time

TIMEOUT = 6
CACHE_SECONDS = 1.5

PROFILES = ("power-saver", "balanced", "performance")

STATES = {
    "charging": "charging",
    "discharging": "discharging",
    "full": "full",
    "not charging": "not-charging",
    "unknown": "unknown",
}

_cache = {"at": 0.0, "value": None}


# ── plumbing ────────────────────────────────────────────────────────────────
def _run(argv, timeout=TIMEOUT):
    """Run an argument vector; never raise, never inherit a locale."""
    try:
        return subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                              env={**os.environ, "LC_ALL": "C"}, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        return subprocess.CompletedProcess(argv, 1, "", str(error))


def _has(tool):
    for directory in os.environ.get("PATH", "/usr/bin:/bin").split(":"):
        if directory and os.path.exists(os.path.join(directory, tool)):
            return True
    return False


def _supply_root():
    """Test hook: point the sysfs reader at a fake tree."""
    return os.environ.get("SPHERE_POWER_SUPPLY", "/sys/class/power_supply")


def _batteries():
    root = _supply_root()
    try:
        names = os.listdir(root)
    except OSError:
        return []
    return sorted(os.path.join(root, name) for name in names
                  if name.startswith("BAT") or _kind(name) == "Battery")


def _kind(name):
    root = _supply_root()
    try:
        with open(os.path.join(root, name, "type"), "r", encoding="utf-8") as handle:
            return handle.read().strip().lower()
    except OSError:
        return ""


def _read(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return handle.read().strip()
    except OSError:
        return None


def _float(text):
    if text is None:
        return None
    match = re.search(r"-?\d+(?:\.\d+)?", text.replace(",", "."))
    return float(match.group(0)) if match else None


def _int(text):
    value = _float(text)
    return int(round(value)) if value is not None else None


def _clamp_percent(value):
    if value is None:
        return None
    return max(0, min(100, int(round(value))))


def _state(text):
    return STATES.get((text or "").strip().lower(), "unknown")


# ── sysfs ───────────────────────────────────────────────────────────────────
def _sysfs_battery():
    for path in _batteries():
        percentage = _int(_read(os.path.join(path, "capacity")))
        status = _state(_read(os.path.join(path, "status")))
        if percentage is None and status == "unknown":
            continue

        # Energy (µWh) when the driver exposes it, charge (µAh) otherwise.
        energy_now = _float(_read(os.path.join(path, "energy_now")))
        energy_full = _float(_read(os.path.join(path, "energy_full")))
        energy_design = _float(_read(os.path.join(path, "energy_full_design")))
        charge_now = _float(_read(os.path.join(path, "charge_now")))
        charge_full = _float(_read(os.path.join(path, "charge_full")))
        charge_design = _float(_read(os.path.join(path, "charge_full_design")))
        voltage_uv = _float(_read(os.path.join(path, "voltage_now")))

        power_uw = _float(_read(os.path.join(path, "power_now")))
        if power_uw is None:
            current_ua = _float(_read(os.path.join(path, "current_now")))
            if current_ua is not None and voltage_uv:
                power_uw = abs(current_ua * voltage_uv / 1e6)   # µA · µV → µW

        # Normalise to Wh so the fields mean the same thing from both sources.
        to_wh = lambda value: (value / 1e6) if value is not None else None
        energy_now = to_wh(energy_now) if energy_now is not None else (
            (charge_now * voltage_uv / 1e12) if charge_now is not None and voltage_uv else None)
        energy_full = to_wh(energy_full) if energy_full is not None else (
            (charge_full * voltage_uv / 1e12) if charge_full is not None and voltage_uv else None)
        energy_design = to_wh(energy_design) if energy_design is not None else (
            (charge_design * voltage_uv / 1e12) if charge_design is not None and voltage_uv else None)

        return {
            "present": True,
            "percent": _clamp_percent(percentage),
            "state": status,
            "powerNow": (power_uw / 1e6) if power_uw is not None else None,
            "energyNow": energy_now,
            "energyFull": energy_full,
            "energyDesign": energy_design,
            "voltage": (voltage_uv / 1e6) if voltage_uv else None,
            "cycles": _int(_read(os.path.join(path, "cycle_count"))),
            "timeToEmpty": _int(_read(os.path.join(path, "time_to_empty_now"))),
            "timeToFull": _int(_read(os.path.join(path, "time_to_full_now"))),
            "source": "sysfs",
            "device": os.path.basename(path),
        }
    return None


# ── UPower ──────────────────────────────────────────────────────────────────
def _upower_device():
    if not _has("upower"):
        return None
    result = _run(["upower", "-e"])
    for line in (result.stdout or "").splitlines():
        if "battery" in line.lower() or "BAT" in line:
            return line.strip()
    return None


def _parse_seconds(text):
    """'2.5 hours' / '1 hour 12 minutes' / '48 minutes' → seconds."""
    if not text:
        return None
    hours = re.search(r"([\d.]+)\s*hour", text)
    minutes = re.search(r"([\d.]+)\s*minute", text)
    seconds = re.search(r"([\d.]+)\s*second", text)
    if hours is None and minutes is None and seconds is None:
        return None
    total = 0.0
    if hours:
        total += float(hours.group(1)) * 3600
    if minutes:
        total += float(minutes.group(1)) * 60
    if seconds:
        total += float(seconds.group(1))
    return int(total)


def _upower_battery(device):
    result = _run(["upower", "-i", device])
    if result.returncode != 0:
        return None
    fields = {}
    for line in (result.stdout or "").splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().lower()
        value = value.strip()
        if key and value:
            fields[key] = value
    if not fields:
        return None

    percent = _clamp_percent(_float(fields.get("percentage")))
    state = _state(fields.get("state"))
    if percent is None and state == "unknown":
        return None

    rate = _float(fields.get("energy-rate"))
    health_percent = _int(fields.get("capacity"))
    full = _float(fields.get("energy-full"))
    design = _float(fields.get("energy-full-design"))

    return {
        "present": True,
        "percent": percent,
        "state": state,
        "powerNow": rate,
        "energyNow": _float(fields.get("energy")),
        "energyFull": full,
        "energyDesign": design,
        "voltage": _float(fields.get("voltage")),
        "cycles": _int(fields.get("cycle count") or fields.get("charge cycles")),
        "timeToEmpty": _parse_seconds(fields.get("time to empty")),
        "timeToFull": _parse_seconds(fields.get("time to full")),
        "healthPercent": health_percent,
        "source": "upower",
        "device": fields.get("native-path") or device,
    }


# ── profiles ────────────────────────────────────────────────────────────────
def _profiles():
    if not _has("powerprofilesctl"):
        return "", []
    current = (_run(["powerprofilesctl", "get"]).stdout or "").strip()
    listing = (_run(["powerprofilesctl", "list"]).stdout or "")
    found = [p for p in PROFILES if re.search(r"(?m)^\W*" + re.escape(p) + r":", listing)]
    if not found:
        found = list(PROFILES)
    return (current if current in found else ""), found


def set_profile(name):
    """``powerprofilesctl set NAME``; an unknown name is refused, not guessed."""
    if name not in PROFILES:
        raise ValueError("Unknown power profile.")
    if not _has("powerprofilesctl"):
        raise RuntimeError("powerprofilesctl is not installed.")
    result = _run(["powerprofilesctl", "set", name])
    if result.returncode != 0:
        raise RuntimeError("power-profiles-daemon refused the profile change.")
    _cache["at"] = 0.0
    return status()


# ── assembly ────────────────────────────────────────────────────────────────
def _empty(error=""):
    return {
        "available": False,
        "present": False,
        "percent": None,
        "state": "unknown",
        "timeToEmpty": None,
        "timeToFull": None,
        "watts": None,
        "health": {"full": None, "design": None, "percent": None},
        "cycles": None,
        "voltage": None,
        "profile": "",
        "profiles": [],
        "source": "",
        "error": error,
    }


def status():
    """The whole panel state. Cheap enough to call on every refresh."""
    now = time.monotonic()
    if _cache["value"] is not None and now - _cache["at"] < CACHE_SECONDS:
        return _cache["value"]

    device = _upower_device()
    raw = _upower_battery(device) if device else None
    if raw is None:
        raw = _sysfs_battery()

    if raw is None:
        state = _empty("No battery detected.")
        state["profile"], state["profiles"] = _profiles()
        _cache.update(at=now, value=state)
        return state

    health_percent = raw.get("healthPercent")
    full, design = raw.get("energyFull"), raw.get("energyDesign")
    if health_percent is None and full and design:
        health_percent = _clamp_percent(full / design * 100)

    watts = raw.get("powerNow")
    if watts is not None:
        watts = abs(watts)

    # Time remaining: trust the driver first, compute it when it says nothing.
    state = raw["state"]
    seconds = None
    if state == "discharging":
        seconds = raw.get("timeToEmpty")
        if not seconds:
            now_wh, rate = raw.get("energyNow"), watts
            if now_wh is not None and rate:
                seconds = int(now_wh / rate * 3600)
    elif state == "charging":
        seconds = raw.get("timeToFull")
        if not seconds:
            now_wh, total, rate = raw.get("energyNow"), full, watts
            if now_wh is not None and total is not None and rate:
                seconds = int(max(0.0, total - now_wh) / rate * 3600)

    profile, profiles = _profiles()

    value = {
        "available": True,
        "present": True,
        "percent": raw.get("percent"),
        "state": state,
        "timeToEmpty": int(seconds) if state == "discharging" and seconds else None,
        "timeToFull": int(seconds) if state == "charging" and seconds else None,
        "watts": round(watts, 2) if watts is not None and watts > 0 else None,
        "health": {"full": full, "design": design, "percent": health_percent},
        "cycles": raw.get("cycles"),
        "voltage": round(raw["voltage"], 2) if raw.get("voltage") else None,
        "profile": profile,
        "profiles": profiles,
        "source": raw.get("source", ""),
        "error": "",
    }
    _cache.update(at=now, value=value)
    return value


def available():
    """True when a battery exists (the panel's empty state needs the answer)."""
    return bool(status().get("present"))
