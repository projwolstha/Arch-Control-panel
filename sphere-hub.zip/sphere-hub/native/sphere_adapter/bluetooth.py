"""Bluetooth control through ``bluetoothctl`` — tolerant, asynchronous, stdout-only.

Only argument vectors are handed to bluetoothctl — nothing is ever evaluated by
a shell, and every address is validated before it reaches the command line, so a
device name or a hand-edited state file can never turn into an argument.

Three rules decide whether the panel says "Bluetooth is not available", and they
are deliberately conservative:

1. **An adapter exists iff a ``Controller`` line appears on stdout.** That is the
   whole test. A powered-off adapter (``Powered: no``) is *available* and the
   panel offers a working power button; so is one that is soft-blocked by rfkill,
   because ``power on`` is exactly what clears that.
2. **Stdout is data, stderr is a note.** bluetoothctl prints progress such as
   ``Waiting to connect to bluetoothd...`` on stderr and still exits non-zero on
   perfectly healthy machines, so neither the exit code nor stderr may ever
   decide availability. Parsing reads stdout only; the text of a *failure* is
   taken from whichever stream has it and is shown verbatim in the panel.
3. **A slow first answer is retried, never believed.** bluetoothd can take a
   second to answer the very first call after login, so an empty answer is
   retried once (1 s) before anything is reported. A definitive negative
   (``No default controller available``) is an answer and is not retried.

Everything the panel sees comes from :class:`Monitor`, which runs bluetoothctl
on its own thread and hands out the last known state. No caller — and therefore
no QML frame — ever waits for a subprocess.

There is no Quickshell/BlueZ service in this path: Sphere talks to the daemon
through bluetoothctl only (Quickshell ships without QtBluetooth). The two-stage
read in :func:`_detect` is the fallback the panel relies on: ``list`` first, then
``show`` when ``list`` names no default controller.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path

TIMEOUT = 20              # a normal bluetoothctl action
DETECT_TIMEOUT = 6        # list/show answer in milliseconds when the daemon is up
DETECT_RETRIES = 1        # one retry …
DETECT_RETRY_DELAY = 1.0  # … one second later
SCAN_SECONDS = 8          # bluetoothctl --timeout N scan on
SCAN_GRACE = 15           # seconds past the timeout before the process is killed
PAIR_TIMEOUT = 60
MONITOR_INTERVAL = 4.0    # idle refresh of the cached state
MONITOR_SCAN_INTERVAL = 1.0
MAX_DETAIL = 240          # characters of raw bluetoothctl text kept for the panel

CLI_NAME = "bluetoothctl"
# A session started without /usr/bin on PATH must still find the tool. These are
# absolute, so `available()` cannot be fooled by an incomplete environment.
CLI_FALLBACKS = ("/usr/bin/bluetoothctl", "/bin/bluetoothctl",
                 "/usr/local/bin/bluetoothctl", "/usr/sbin/bluetoothctl",
                 "/sbin/bluetoothctl")

# AA:BB:CC:DD:EE:FF — the only thing ever accepted as a device identifier.
ADDRESS = re.compile(r"^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$")

# bluez's Icon: field → the small drawn glyph the panel shows for a device.
ICON_KIND = {
    "audio-card": "audio", "audio-headset": "audio", "audio-headphones": "audio",
    "audio-speakers": "audio", "audio-input-microphone": "audio",
    "input-keyboard": "keyboard", "input-mouse": "mouse",
    "input-tablet": "tablet", "input-gaming": "gamepad",
    "phone": "phone", "smartphone": "phone",
    "computer": "computer", "laptop": "computer",
    "watch": "watch", "printer": "printer", "camera-photo": "camera",
}

MAX_DEVICES = 24          # a runaway adapter cannot turn one request into hundreds

# Answers that mean "there really is no adapter" — retrying them just wastes a
# second. Anything else that comes back empty is treated as a slow/hiccup answer.
DEFINITIVE = ("no default controller available", "no controller available")


class BluetoothError(ValueError):
    """A Bluetooth request that cannot be honoured; the message is shown in the panel."""

    def __init__(self, message, detail=""):
        super().__init__(message)
        self.detail = (detail or "")[:MAX_DETAIL]


# ── environment and the binary ───────────────────────────────────────────────
def cli_environment(base=None):
    """The environment bluetoothctl is given: the user's, completed where broken.

    A widget launched from an unusual session (a systemd unit, a bare `exec-once`
    without a login shell, a terminal multiplexer started by hand) can lack the
    variables D-Bus needs. `bluetoothctl` then fails with "Failed to connect to
    bus" even though `bluetoothd` is fine. Completing them here means the panel
    behaves the same however Quickshell happened to be started.
    """
    env = dict(os.environ if base is None else base)
    parts = [piece for piece in (env.get("PATH") or "").split(os.pathsep) if piece]
    for extra in ("/usr/local/sbin", "/usr/local/bin", "/usr/bin", "/usr/sbin",
                  "/bin", "/sbin"):
        if extra not in parts:
            parts.append(extra)
    env["PATH"] = os.pathsep.join(parts) or os.defpath
    try:
        uid = os.getuid()
    except (AttributeError, OSError):
        uid = None
    runtime = env.get("XDG_RUNTIME_DIR") or ""
    if not runtime or not Path(runtime).is_dir():
        candidate = f"/run/user/{uid}" if uid is not None else ""
        if candidate and Path(candidate).is_dir():
            runtime = candidate
    if runtime:
        env["XDG_RUNTIME_DIR"] = runtime
    if not env.get("DBUS_SESSION_BUS_ADDRESS") and runtime:
        bus = Path(runtime) / "bus"
        if bus.exists():
            env["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=" + str(bus)
    # BlueZ lives on the *system* bus; spell it out when the socket is there.
    if not env.get("DBUS_SYSTEM_BUS_ADDRESS"):
        socket = Path("/run/dbus/system_bus_socket")
        if socket.exists():
            env["DBUS_SYSTEM_BUS_ADDRESS"] = "unix:path=" + str(socket)
    # Stable, ASCII parsing of the key/value output; Python still decodes UTF-8.
    env.setdefault("LC_ALL", "C")
    return env


def cli_path():
    """Absolute path of bluetoothctl, from PATH and then from the known locations."""
    found = shutil.which(CLI_NAME)
    if found:
        return found
    for candidate in CLI_FALLBACKS:
        try:
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                return candidate
        except OSError:
            continue
    return None


def available():
    """True when bluetoothctl can be executed (an adapter is a separate question)."""
    return cli_path() is not None


# ── running bluetoothctl ────────────────────────────────────────────────────
def _run(args, timeout=TIMEOUT):
    """Run bluetoothctl with an argument vector. Raises BluetoothError, never OSError.

    The result is returned whatever the exit code says: callers read stdout and
    decide for themselves. Only a timeout or an impossible spawn is an error.
    """
    cli = cli_path()
    if cli is None:
        raise BluetoothError(
            "bluetoothctl is not installed. On Arch: sudo pacman -S bluez bluez-utils")
    try:
        return subprocess.run([cli, *args], capture_output=True, text=True,
                              encoding="utf-8", errors="replace",
                              timeout=timeout, env=cli_environment(), check=False)
    except subprocess.TimeoutExpired as error:
        raise BluetoothError(
            f"bluetoothctl {' '.join(str(a) for a in args)} did not answer in {int(timeout)}s.",
            _as_text(error.stdout) or _as_text(error.stderr)) from None
    except OSError as error:
        raise BluetoothError(f"bluetoothctl could not be started: {error}" +
                             (f" ({cli})" if cli else "")) from None


def _as_text(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return str(value)


def _stdout(result):
    """The only stream that is ever parsed."""
    return _as_text(getattr(result, "stdout", "")) if result is not None else ""


def _stderr(result):
    return _as_text(getattr(result, "stderr", "")) if result is not None else ""


def _clean_lines(text):
    return [line.strip() for line in (text or "").splitlines() if line.strip()]


def _detail(result, limit=MAX_DETAIL):
    """The first meaningful line of a result, for the panel's error line."""
    for line in _clean_lines(_stdout(result)) + _clean_lines(_stderr(result)):
        return line[:limit]
    return ""


def _message(result):
    """Text of a failure: stdout if it said anything, otherwise stderr."""
    said = "\n".join(_clean_lines(_stdout(result)))
    return said or "\n".join(_clean_lines(_stderr(result)))


FRIENDLY = (
    ("No default controller available",
     "No Bluetooth adapter was found. Check that it is plugged in and not disabled in firmware."),
    ("Failed to connect to bus",
     "The Bluetooth service (bluetoothd) is not running. Start it with: sudo systemctl start bluetooth"),
    ("Blocked through rfkill",
     "Bluetooth is blocked by rfkill. The power button unblocks it; or run: sudo rfkill unblock bluetooth"),
    ("org.bluez.Error.AuthenticationFailed", "The device rejected the pairing."),
    ("org.bluez.Error.AuthenticationRejected", "The device rejected the pairing."),
    ("org.bluez.Error.AuthenticationTimeout", "Pairing timed out. Put the device in pairing mode and try again."),
    ("org.bluez.Error.Failed", "The device refused the request. Make sure it is in range and awake."),
    ("org.bluez.Error.Blocked", "The adapter is blocked. The power button unblocks it first."),
    ("le-connection-abort-by-local", "The connection attempt was dropped. Try again."),
    ("a2dp-sink", ""),          # profile chatter is not an error
)


def _humanize(text, fallback):
    for needle, friendly in FRIENDLY:
        if needle.lower() in (text or "").lower() and friendly:
            return friendly
    return fallback


# ── parsing (stdout only) ───────────────────────────────────────────────────
_CONTROLLER_QUALIFIER = re.compile(r"^\((?:public|le|bredr|dual)\)\s*", re.I)


def _controller_from(text):
    """The first ``Controller <mac> …`` line of a listing, or None."""
    lines = _clean_lines(text)
    for position, line in enumerate(lines):
        if not line.lower().startswith("controller "):
            continue
        parts = line.split(None, 2)
        address = parts[1].strip().strip("()") if len(parts) > 1 else ""
        if not ADDRESS.match(address):
            continue
        rest = parts[2] if len(parts) > 2 else ""
        rest = _CONTROLLER_QUALIFIER.sub("", rest).replace("[default]", "").strip()
        if not rest:                      # `bluetoothctl show` puts Name: on its own line
            for follow in lines[position + 1:position + 12]:
                if follow.lower().startswith("name:"):
                    rest = follow.split(":", 1)[1].strip()
                    break
                if follow.lower().startswith("controller "):
                    break
        return {"address": address.upper(), "name": rest, "default": "[default]" in line}
    return None


def _power_from(text):
    """True/False from a ``Powered:`` line, None when the output does not say."""
    for line in _clean_lines(text):
        lowered = line.lower()
        if lowered.startswith("powered:"):
            value = lowered.split(":", 1)[1].strip()
            if value in ("yes", "on", "true"):
                return True
            if value in ("no", "off", "false"):
                return False
    return None


def _addresses(text):
    found = set()
    for line in _clean_lines(text):
        parts = line.split()
        if len(parts) >= 2 and parts[0] == "Device" and ADDRESS.match(parts[1]):
            found.add(parts[1].upper())
    return found


def _clean_address(address):
    if not isinstance(address, str) or not ADDRESS.match(address.strip()):
        raise BluetoothError("That is not a Bluetooth address.")
    return address.strip().upper()


# ── rfkill ──────────────────────────────────────────────────────────────────
def _blocked():
    """(blocked, hard) from rfkill; (False, False) when rfkill is not installed."""
    rfkill = shutil.which("rfkill")
    if not rfkill:
        return False, False
    try:
        out = subprocess.run([rfkill, "list", "bluetooth"], capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=6,
                             env=cli_environment(), check=False).stdout or ""
    except (OSError, subprocess.TimeoutExpired):
        return False, False
    lines = [line.lower() for line in out.splitlines()]
    soft = any("soft blocked: yes" in line for line in lines)
    hard = any("hard blocked: yes" in line for line in lines)
    return (soft or hard), hard


def _unblock():
    """Best effort `rfkill unblock bluetooth`; returns True when it ran."""
    rfkill = shutil.which("rfkill")
    if not rfkill:
        return False
    try:
        subprocess.run([rfkill, "unblock", "bluetooth"], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=6,
                       env=cli_environment(), check=False)
        return True
    except (OSError, subprocess.TimeoutExpired):
        return False


# ── adapter detection ───────────────────────────────────────────────────────
def _transient(result):
    """True when an empty answer looks like a hiccup rather than a verdict."""
    if result is None:
        return True
    said = (_stderr(result) + "\n" + _stdout(result)).lower()
    if any(token in said for token in DEFINITIVE):
        return False                       # a real answer: there is no controller
    if _clean_lines(_stdout(result)):
        return False                       # it did answer, just not with a controller
    return True                            # nothing at all: could be a slow daemon


def _detect():
    """(adapter, powered, notes) — list, retry once, then show.

    `list` is the primary source; `show` is the fallback that names the default
    controller even when the listing is unavailable. A failure in one stage never
    ends the detection: the next one is still tried, and every note is kept so
    the panel can print what bluetoothctl actually said.
    """
    notes = []
    for attempt in range(DETECT_RETRIES + 1):
        result = None
        try:
            result = _run(["list"], timeout=DETECT_TIMEOUT)
            adapter = _controller_from(_stdout(result))
            if adapter:
                return adapter, None, notes
            note = _detail(result)
            if note:
                notes.append(note)
            if not _transient(result):
                break
        except BluetoothError as error:
            notes.append(str(error) + ((": " + error.detail) if error.detail else ""))
        if attempt < DETECT_RETRIES:
            time.sleep(DETECT_RETRY_DELAY)      # the first call after login is slow
    # `bluetoothctl show` answers with the same `Controller <mac> <name>` header,
    # and carries the Powered: line — one call for both.
    try:
        result = _run(["show"], timeout=DETECT_TIMEOUT)
        adapter = _controller_from(_stdout(result))
        powered = _power_from(_stdout(result))
        if adapter:
            return adapter, powered, notes
        note = _detail(result)
        if note:
            notes.append(note)
    except BluetoothError as error:
        notes.append(str(error) + ((": " + error.detail) if error.detail else ""))
    unique = []
    for note in notes:
        if note and note not in unique:
            unique.append(note)
    return None, None, unique


# ── a scan that is a real process ───────────────────────────────────────────
_SCAN = {"process": None, "started": 0.0, "seconds": 0.0, "output": ""}
_SCAN_LOCK = threading.Lock()


def scanning():
    """True only while the `scan on` process is actually alive."""
    with _SCAN_LOCK:
        process = _SCAN["process"]
    return bool(process is not None and process.poll() is None)


def stop_scan():
    """Stop a running scan (used when the panel closes). Returns True if one ran."""
    with _SCAN_LOCK:
        process = _SCAN["process"]
        _SCAN["process"] = None
    if process is None or process.poll() is not None:
        return False
    try:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
    except OSError:
        pass
    return True


def start_scan(seconds=SCAN_SECONDS, on_done=None):
    """Start `bluetoothctl --timeout N scan on` in the background; never blocks.

    Returns immediately with the current state. `scanning` is true only while
    that process is alive, so the panel's "Scanning…" cannot outlive it: the
    supervisor thread waits for the process, kills it after the timeout plus a
    grace period, and calls `on_done` for a fresh reading.
    """
    cli = cli_path()
    if cli is None:
        return status(include_devices=False)
    if scanning():
        state = status(include_devices=False)
        state["scanning"] = True
        return state
    state = status(include_devices=False)
    if state["adapter"] is None:
        return state
    if not state["powered"]:
        state["scanning"] = False
        state["error"] = state["error"] or "Bluetooth is off. Switch it on to scan for devices."
        return state
    try:
        process = subprocess.Popen([cli, "--timeout", str(int(seconds)), "scan", "on"],
                                   stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, text=True, encoding="utf-8",
                                   errors="replace", env=cli_environment(),
                                   start_new_session=True)
    except OSError as error:
        state["error"] = f"bluetoothctl could not start a scan: {error}"
        return state
    with _SCAN_LOCK:
        _SCAN.update(process=process, started=time.monotonic(), seconds=float(seconds), output="")

    def supervise():
        try:
            out, err = process.communicate(timeout=float(seconds) + SCAN_GRACE)
        except subprocess.TimeoutExpired:
            process.kill()
            try:
                out, err = process.communicate(timeout=5)
            except (subprocess.TimeoutExpired, OSError, ValueError):
                out, err = "", ""
        with _SCAN_LOCK:
            if _SCAN["process"] is process:
                _SCAN["process"] = None
            _SCAN["output"] = (out or "") + (err or "")
        if on_done:
            try:
                on_done()
            except Exception:              # a broken callback must not kill the thread
                pass

    thread = threading.Thread(target=supervise, daemon=True,
                              name="sphere-bt-scan")
    thread.start()
    state["scanning"] = True
    state["error"] = ""
    return state


# ── devices ─────────────────────────────────────────────────────────────────
def _details(address):
    """Paired/Connected/Trusted/Icon/name for one address (one short call)."""
    detail = {"paired": False, "connected": False, "trusted": False, "icon": "", "alias": ""}
    try:
        result = _run(["info", address], timeout=8)
    except BluetoothError:
        return detail
    for line in _clean_lines(_stdout(result)):
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key, value = key.strip().lower(), value.strip()
        if key == "paired":
            detail["paired"] = value.lower() == "yes"
        elif key == "connected":
            detail["connected"] = value.lower() == "yes"
        elif key == "trusted":
            detail["trusted"] = value.lower() == "yes"
        elif key == "icon":
            detail["icon"] = value
        elif key == "alias":
            detail["alias"] = value
    return detail


def devices():
    """Every known device, de-duplicated by address, with its state and kind.

    ``bluetoothctl devices`` gives the name; the paired/connected/trusted flags
    and the bluez ``Icon`` need ``info``, so it is asked once per device — capped,
    and a failing device never fails the list.
    """
    known = _run(["devices"], timeout=12)
    seen = {}
    for line in _clean_lines(_stdout(known)):
        parts = line.split(None, 2)
        if len(parts) < 2 or parts[0] != "Device" or not ADDRESS.match(parts[1]):
            continue
        address = parts[1].upper()                       # duplicates differ in case
        name = (parts[2] if len(parts) > 2 else "").strip()
        if address in seen:
            if not seen[address]["name"] and name:       # keep the first, fill the name
                seen[address]["name"] = name
            continue
        seen[address] = {"address": address, "name": name}

    ordered = list(seen.values())[:MAX_DEVICES]
    for device in ordered:
        detail = _details(device["address"])
        if not device["name"]:
            device["name"] = detail["alias"] or ""       # unnamed stays unnamed; panel shows the MAC
        device.update(paired=detail["paired"], connected=detail["connected"],
                      trusted=detail["trusted"], icon=detail["icon"],
                      kind=ICON_KIND.get(detail["icon"], "other"),
                      label=device["name"] or device["address"])
    ordered.sort(key=lambda d: (not d["connected"], not d["paired"], d["label"].lower()))
    return ordered


# ── state ───────────────────────────────────────────────────────────────────
def blank_state():
    """The shape every caller (and the panel) can rely on."""
    return {"available": False, "powered": False, "adapter": None, "devices": [],
            "scanning": scanning(), "blocked": False, "blockedHard": False,
            "pending": False, "cli": "", "error": "", "detail": ""}


def status(include_devices=True):
    """Everything the dashboard needs to paint the Bluetooth orb and its list."""
    started = time.monotonic()
    state = blank_state()
    cli = cli_path()
    if cli is None:
        state["error"] = ("bluez-utils (bluetoothctl) is not installed, so Bluetooth cannot be "
                          "controlled from Sphere. On Arch: sudo pacman -S bluez bluez-utils")
        return state
    state["cli"] = cli
    state["available"] = True                 # the integration works; an adapter is separate

    blocked, hard = _blocked()
    state["blocked"], state["blockedHard"] = blocked, hard

    adapter, powered, notes = _detect()
    if adapter is None:
        state["available"] = True             # bluetoothctl answered; nothing to drive though
        state["detail"] = " · ".join(note for note in notes if note)[:MAX_DETAIL]
        state["error"] = _humanize(state["detail"],
                                   "No Bluetooth adapter was found on this system.")
        if hard:
            state["error"] = ("The Bluetooth adapter is hard-blocked (firmware or hardware switch). "
                              "Enable it in the BIOS or with the hardware switch.")
        return state
    state["adapter"] = adapter
    if powered is None:
        try:
            powered = _powered()
        except BluetoothError as error:
            # The adapter exists, so it is available; not knowing the power state
            # is not a reason to say it is missing.
            state["detail"] = str(error)[:MAX_DETAIL]
            powered = False
    state["powered"] = bool(powered)
    if blocked and not hard:
        state["error"] = ("Bluetooth is blocked by rfkill. Press Power on to unblock and switch "
                          "it on, or run: sudo rfkill unblock bluetooth")
    elif hard and not state["powered"]:
        state["error"] = ("The adapter is hard-blocked (firmware or hardware switch). Enable it in "
                          "the BIOS or with the hardware switch.")
    if include_devices and state["powered"]:
        try:
            state["devices"] = devices()
        except BluetoothError as error:
            state["error"] = state["error"] or str(error)
            state["detail"] = state["detail"] or error.detail
    state["scanning"] = scanning()
    state["took"] = round(time.monotonic() - started, 3)
    return state


def _powered():
    result = _run(["show"], timeout=DETECT_TIMEOUT)
    powered = _power_from(_stdout(result))
    if powered is None:
        raise BluetoothError("bluetoothctl did not report the adapter's power state.",
                             _detail(result))
    return powered


# ── actions ─────────────────────────────────────────────────────────────────
def connect(address):
    """Pair (and trust) if needed, then connect. Returns the refreshed state."""
    target = _clean_address(address)
    if cli_path() is None:
        return status()
    try:
        if not _powered():
            raise BluetoothError("Bluetooth is switched off. Switch it on, then choose the device again.")
        detail = _details(target)
        if not detail["paired"]:
            try:
                pair = _run(["pair", target], timeout=PAIR_TIMEOUT)
            except BluetoothError as error:
                raise BluetoothError(str(error), error.detail) from None
            said = _message(pair)
            lowered = said.lower()
            if ("failed" in lowered or "error" in lowered) and "alreadyexists" not in lowered:
                raise BluetoothError(_humanize(said, "Pairing with that device failed."), said)
            # Trust it so it may reconnect on its own later; a refusal is not fatal.
            try:
                _run(["trust", target], timeout=PAIR_TIMEOUT)
            except BluetoothError:
                pass
        try:
            result = _run(["connect", target], timeout=PAIR_TIMEOUT)
        except BluetoothError as error:
            raise BluetoothError(str(error), error.detail) from None
        said = _message(result)
        lowered = said.lower()
        delivered = ("connection successful" in lowered or "alreadyconnected" in lowered
                     or "already connected" in lowered)
        # The exit code is not the answer: a connected device reports
        # "AlreadyConnected" with a failure status. Ask the device instead.
        if not delivered and not _details(target)["connected"]:
            raise BluetoothError(_humanize(said, "The device did not accept the connection."), said)
    except BluetoothError as error:
        state = status(include_devices=False)
        state["error"] = str(error)
        state["detail"] = error.detail or state["detail"]
        state["connectedTo"] = ""
        return state
    state = status()
    state["connectedTo"] = next((d["label"] for d in state["devices"]
                                 if d["address"] == target and d["connected"]), "")
    return state


def disconnect(address):
    """`bluetoothctl disconnect <mac>` — kept for completeness of the protocol."""
    target = _clean_address(address)
    try:
        _run(["disconnect", target], timeout=PAIR_TIMEOUT)
    except BluetoothError:
        pass
    return status()


def power(enabled):
    """``bluetoothctl power on|off``, unblocking rfkill first when switching on."""
    if cli_path() is None:
        return status()
    enabled = enabled is True
    said = ""
    try:
        if enabled:
            blocked, hard = _blocked()
            if blocked and not hard and _unblock():
                # Give bluetoothd a moment to notice the unblock before asking.
                time.sleep(.3)
        try:
            result = _run(["power", "on" if enabled else "off"], timeout=15)
        except BluetoothError as error:
            raise BluetoothError(str(error), error.detail) from None
        said = _message(result)
        powered = _powered()
        if powered != enabled:
            # The real sentence, not a paraphrase of the exit code.
            raise BluetoothError(
                _humanize(said, "The adapter did not change its power state."),
                said or f"Powered: {'yes' if powered else 'no'}")
    except BluetoothError as error:
        state = status(include_devices=False)
        state["error"] = str(error)
        state["detail"] = error.detail or state["detail"]
        return state
    state = status()
    if state["error"]:
        state["detail"] = state["detail"] or said[:MAX_DETAIL]
    return state


# ── the cache the panel reads ───────────────────────────────────────────────
def _copy_state(state):
    """A shallow copy whose lists/objects are fresh, so a caller cannot edit the cache."""
    copied = dict(state)
    copied["devices"] = [dict(device) for device in state.get("devices") or []]
    copied["adapter"] = dict(state["adapter"]) if state.get("adapter") else None
    return copied


class Monitor:
    """A cached, self-refreshing view of the adapter.

    QML must never wait for bluetoothctl: `current()` is a dictionary lookup, and
    a background thread keeps it fresh (4 s idle, 1 s while a scan runs), pushing
    every change through `on_change`. `start_scan()` is likewise non-blocking.
    """

    def __init__(self, on_change=None, interval=MONITOR_INTERVAL):
        self.on_change = on_change or (lambda state: None)
        self.interval = max(.5, float(interval))
        self._lock = threading.Lock()
        self._state = None
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread = None
        self._include_devices = True

    # ── reading ─────────────────────────────────────────────────────────
    def pending_state(self):
        """What the panel gets before the first read has finished: no verdicts."""
        state = blank_state()
        state.update(available=cli_path() is not None, pending=True,
                     cli=cli_path() or "")
        return state

    def current(self):
        """The last known state. Never runs a subprocess."""
        with self._lock:
            state = self._state
        if state is None:
            state = self.pending_state()
            self.wake()
        return _copy_state(state)

    def refresh(self, include_devices=True):
        """Ask the worker for a fresh reading now (returns immediately)."""
        self._include_devices = include_devices
        self.wake()

    def wake(self):
        self._wake.set()

    # ── lifecycle ───────────────────────────────────────────────────────
    def start(self):
        if self._thread and self._thread.is_alive():
            return self
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="sphere-bt-monitor")
        self._thread.start()
        return self

    def stop(self):
        self._stop.set()
        self._wake.set()
        stop_scan()

    def _loop(self):
        while not self._stop.is_set():
            try:
                state = status(include_devices=self._include_devices)
            except Exception as error:                 # never let the thread die
                state = dict(self.pending_state())
                state.update(pending=False, error=f"Bluetooth could not be read: {error}")
            self._publish(state)
            wait = MONITOR_SCAN_INTERVAL if state.get("scanning") else self.interval
            self._wake.wait(wait)
            self._wake.clear()

    def _publish(self, state):
        with self._lock:
            previous = self._state
            self._state = dict(state)
        if state != previous:
            try:
                self.on_change(dict(state))
            except Exception:
                pass

    # ── actions (run on the worker) ─────────────────────────────────────
    def set_power(self, enabled):
        self._run_action(lambda: power(enabled is True))

    def connect(self, address):
        self._run_action(lambda: connect(address))

    def start_scan(self, seconds=SCAN_SECONDS):
        def work():
            try:
                start_scan(seconds, on_done=self.wake)
            except Exception:
                pass
        threading.Thread(target=work, daemon=True, name="sphere-bt-scan-start").start()

    def stop_scan(self):
        if stop_scan():
            self.wake()

    def _run_action(self, action):
        def work():
            try:
                state = action()
                if isinstance(state, dict):
                    self._publish(state)
            except Exception as error:
                state = self.current()
                state.update(pending=False, error=str(error))
                self._publish(state)
            finally:
                self.wake()
        threading.Thread(target=work, daemon=True, name="sphere-bt-action").start()
