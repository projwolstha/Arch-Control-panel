"""The stdio JSON protocol: requests in, events/responses out."""
from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
from pathlib import Path

from .catalog import DesktopCatalog
from .config import ConfigStore
from .constants import HERE, RECIPES, RECIPE_BY_ID, SLOT_COUNT
from .hypr import desktop_environment, hypr_command
from .install import install_plan
from .pathutil import expand_exec, socket_path
from .system import system_info
from .terminal import terminal_argv
from . import battery as battery_control
from . import bluetooth as bluetooth_control
from . import resources as resources_control
from . import wifi as wifi_control


def render_capability():
    """How the dashboard is drawn.

    The old orb chose between a GLSL glass shader and a Canvas fallback; both are
    gone with it. The ring is pre-rendered SVG loaded as images plus a few QML
    shapes, so there is no GPU feature to probe and no software-mode fallback to
    select. The key stays in the snapshot because `sphere-setup status` and
    older readers of the protocol parse it.
    """
    return {"renderer": "svg-shapes", "shader": False, "reason": "not-used"}


class Bridge:
    def __init__(self, catalog=None, store=None, emit=None, popen=None):
        self.catalog = catalog or DesktopCatalog()
        self.store = store or ConfigStore()
        self.emit = emit or (lambda message: None)
        self.popen = popen or subprocess.Popen
        self.clients = []
        self.stop = threading.Event()
        self.dirty = threading.Event()
        self.dirty.set()
        self.catalog.refresh()
        self.last_status = None
        # Bluetooth is read on its own thread: a slow bluetoothd must never delay
        # a snapshot, a Wi-Fi action or a repaint. The panel reads the cache.
        self.bluetooth = bluetooth_control.Monitor(
            on_change=lambda state: self.emit({"type": "bluetooth", **state}))
        # Wi-Fi too: a scan is a process on its own thread, never a request that
        # blocks the UI thread, and the list it produced is pushed when it ends.
        self.wifi = wifi_control.Monitor(
            on_change=lambda state: self.emit({"type": "wifi", **state}))

    def resolved_slot(self, target):
        if not target:
            return None
        if target["kind"] == "desktop":
            entry = self.catalog.entries.get(target["id"])
            return self.catalog.public(entry) if entry else {"id":target["id"], "name":target["id"].removesuffix(".desktop"), "description":"Desktop entry is no longer installed. Right-click to replace it.", "icon":"", "installed":False}
        recipe = RECIPE_BY_ID.get(target["id"])
        if not recipe:
            return {"id":target["id"], "name":"Unknown app", "description":"Please choose an application again.", "icon":"", "installed":False}
        entry = self.catalog.recipe_entry(recipe)
        if entry:
            result = self.catalog.public(entry)
            result["recipeId"] = recipe["id"]
            return result
        return {"id":"recipe:"+recipe["id"], "recipeId":recipe["id"], "name":recipe["name"], "description":recipe["description"], "icon":"", "installed":False}

    def snapshot(self, refresh=False):
        if refresh:
            self.catalog.refresh()
        recipes = []
        for recipe in RECIPES:
            resolved = self.resolved_slot({"kind":"recipe", "id":recipe["id"]})
            recipes.append({**resolved, "recipeId":recipe["id"], "managers":list(recipe["packages"])})
        scan = dict(self.catalog.scan_report)
        scan["listed"] = len(self.catalog.entries)
        return {"type":"snapshot", "apps":self.catalog.public_entries(), "recipes":recipes, "slots":self.store.data["slots"], "slotApps":[self.resolved_slot(v) for v in self.store.data["slots"]], "preferences":self.store.data["preferences"], "system":system_info(), "scan":scan, "savedTo":str(self.store.path), "render":render_capability()}

    def status(self):
        try:
            clients = json.loads(hypr_command("j/clients"))
            active = json.loads(hypr_command("j/activewindow"))
            if not isinstance(clients, list) or not isinstance(active, dict):
                raise ValueError("Invalid compositor response")
            self.clients = clients
            running = sorted({entry for c in clients if (entry := self.catalog.match_client(c))})
            return {"type":"status", "hyprland":True, "activeDesktopId":self.catalog.match_client(active) if active.get("address") else "", "runningDesktopIds":running}
        except (OSError, ValueError, TypeError, KeyError):
            self.clients = []
            return {"type":"status", "hyprland":False, "activeDesktopId":"", "runningDesktopIds":[]}

    def launch_entry(self, entry):
        self.status()
        matching = [c for c in self.clients if self.catalog.match_client(c)==entry["id"]]
        if matching:
            matching.sort(key=lambda c:c.get("focusHistoryID", 99999))
            address = matching[0].get("address", "")
            if re.fullmatch(r"0x[0-9a-fA-F]+", address):
                reply = hypr_command("dispatch focuswindow address:"+address)
                if reply.strip().lower() != "ok":
                    # Hyprland 0.55+ accepts Lua dispatcher expressions. Never interpolate
                    # a window title/class here: the address has already passed a hex whitelist.
                    reply = hypr_command("dispatch hl.dsp.focus({ window = "+json.dumps("address:"+address)+" })")
                if reply.strip().lower() != "ok":
                    raise ValueError("Hyprland could not focus the existing app window.")
                return {"launched":True, "focusedExisting":True}
        if entry["terminal"]:
            command = terminal_argv(expand_exec(entry), "Sphere — "+entry["name"])
        elif shutil.which("gio"):
            command = ["gio", "launch", entry["path"]]
        else:
            command = expand_exec(entry)
        cwd = entry.get("workingDirectory")
        if not cwd or not Path(cwd).is_dir():
            cwd = None
        self.popen(command, cwd=cwd, env=desktop_environment(), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        self.dirty.set()
        return {"launched":True, "focusedExisting":False}

    def wifi_state(self, rescan=False, include_networks=True):
        """The cached Wi-Fi state; `rescan` starts a scan and returns at once.

        A rescan takes 3-5 s on a cold adapter, so it cannot run here: the answer
        is the current cache with `scanning: true`, and the finished list arrives
        as a `{"type":"wifi"}` event. That is what keeps the panel's "Scanning…"
        tied to a process that really exists.
        """
        if rescan:
            self.wifi.scan()
        else:
            self.wifi.refresh()
        state = self.wifi.current()
        state.setdefault("scanning", False)
        return {"type": "wifi", **state}

    def battery_state(self):
        """Charge, state, time remaining, health and the power profile."""
        return {"type": "battery", **battery_control.status()}

    def resources_state(self):
        """RAM, swap, mounted filesystems and the heaviest processes."""
        return {"type": "resources", **resources_control.status()}

    def bluetooth_state(self, scan=False):
        """The cached adapter state; `scan` starts a scan process and returns at once.

        Nothing here waits for bluetoothctl: a scan is a background process whose
        lifetime the adapter owns, and every change is pushed to the widget as a
        separate `{"type":"bluetooth"}` event.
        """
        if scan:
            self.bluetooth.start_scan()
        else:
            self.bluetooth.refresh()
        return {"type": "bluetooth", **self.bluetooth.current()}

    def watch_wifi(self, emit):
        """Push Wi-Fi state changes as NetworkManager reports them.

        Event driven: ``nmcli monitor`` prints a line for every device/connectivity
        change, and only then do we ask the monitor for a fresh state (coalescing
        bursts). The monitor thread itself refreshes every 20 s while the panel is
        closed and every 2 s while it is open, so this watcher can die without
        taking the panel's accuracy with it.
        """
        if not wifi_control.available():
            return
        last = None

        def publish():
            nonlocal last
            self.wifi.refresh()
            try:
                state = self.wifi.current()
            except Exception:
                return
            if state != last:
                last = state
                emit({"type": "wifi", **state})

        while not self.stop.is_set():
            try:
                process = subprocess.Popen(["nmcli", "monitor"], stdin=subprocess.DEVNULL,
                                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                           text=True, bufsize=1)
            except OSError:
                process = None
            if process is None or process.stdout is None:
                # nmcli too old for `monitor`: cheap state-only poll, still not a scan.
                while not self.stop.wait(20):
                    publish()
                return
            try:
                publish()                       # tell the widget where we start
                for _line in process.stdout:
                    if self.stop.is_set():
                        break
                    self.stop.wait(0.35)        # one connect burst -> one read
                    publish()
            except (OSError, ValueError):
                pass
            finally:
                with contextlib.suppress(Exception):
                    process.terminate()
                    process.wait(timeout=2)
            if self.stop.wait(5):
                break                           # monitor died; retry unless we are shutting down

    def request(self, message):
        if not isinstance(message, dict):
            raise ValueError("Request must be a JSON object.")
        action = message.get("action")
        if action in ("wifi", "wifiScan"):
            if action == "wifiScan":
                self.wifi.set_open(True)          # the panel is open: scan + poll
            return self.wifi_state(rescan=action == "wifiScan")
        if action == "wifiPanel":
            # Opening or closing the panel: scan on open, and poll faster while open.
            opened = message.get("open") is True
            self.wifi.set_open(opened)
            if opened:
                self.wifi.scan()
            return self.wifi_state()
        if action == "wifiConnect":
            # Runs on the monitor's thread; the outcome arrives as an event.
            self.wifi.connect(message.get("ssid"), message.get("password"),
                              message.get("security") or "")
            state = self.wifi_state()
            state["connected"] = message.get("ssid") or ""
            return state
        if action == "wifiDisconnect":
            self.wifi.disconnect()
            return self.wifi_state()
        if action == "wifiRadio":
            self.wifi.set_radio(message.get("enabled") is True)
            return self.wifi_state()
        if action == "wifiScanStop":
            wifi_control.stop_scan()
            return self.wifi_state()
        if action == "resources":
            return self.resources_state()
        if action == "battery":
            return self.battery_state()
        if action == "batteryProfile":
            name = message.get("profile")
            try:
                battery_control.set_profile(name)
            except (ValueError, RuntimeError) as error:
                return {"type": "battery", **battery_control.status(), "error": str(error)}
            return self.battery_state()
        if action in ("bluetooth", "bluetoothScan"):
            return self.bluetooth_state(scan=action == "bluetoothScan")
        if action == "bluetoothConnect":
            # The action runs on the monitor thread; its result arrives as an event.
            self.bluetooth.connect(message.get("address"))
            return {"type": "bluetooth", **self.bluetooth.current()}
        if action == "bluetoothPower":
            self.bluetooth.set_power(message.get("enabled") is True)
            return {"type": "bluetooth", **self.bluetooth.current()}
        if action == "bluetoothScanStop":
            self.bluetooth.stop_scan()
            return {"type": "bluetooth", **self.bluetooth.current()}
        if action == "bluetoothRefresh":
            self.bluetooth.refresh()
            return {"type": "bluetooth", **self.bluetooth.current()}
        if action in ("snapshot", "refresh"):
            result = self.snapshot(refresh=True)
            self.dirty.set()
            return result
        if action in ("assign", "clear", "launch"):
            index = message.get("slot")
            if type(index) is not int or not 0 <= index < SLOT_COUNT:
                raise ValueError("Choose an orb from 1 to 8.")
        if action == "assign":
            target = message.get("target")
            if not isinstance(target, dict) or target.get("kind") not in ("desktop", "recipe"):
                raise ValueError("Choose an installed app or a listed install recipe.")
            target = {"kind":target["kind"], "id":target.get("id")}
            if target["kind"] == "desktop" and target["id"] not in self.catalog.entries:
                raise ValueError("This desktop entry is not installed. Refresh the list or choose an install recipe.")
            if target["kind"] == "recipe" and target["id"] not in RECIPE_BY_ID:
                raise ValueError("Unknown install recipe.")
            new_slots = list(self.store.data["slots"])
            previous = new_slots[index]
            resolved = self.resolved_slot(target)
            for i, other in enumerate(new_slots):
                existing = self.resolved_slot(other)
                if i != index and (other == target or (resolved and existing and resolved["id"]==existing["id"])):
                    new_slots[i] = previous
                    break
            new_slots[index] = target
            self.store.replace_values(slots=new_slots)
            return self.snapshot()
        if action == "clear":
            new_slots = list(self.store.data["slots"])
            new_slots[index] = None
            self.store.replace_values(slots=new_slots)
            return self.snapshot()
        if action == "launch":
            resolved = self.resolved_slot(self.store.data["slots"][index])
            if not resolved or not resolved["installed"]:
                raise ValueError("This app is not installed. Choose Install in terminal, then refresh the application list.")
            entry = self.catalog.entries.get(resolved["id"])
            if not entry:
                raise ValueError("Refresh the application list before launching.")
            return self.launch_entry(entry)
        if action in ("previewInstall", "install"):
            plan = install_plan(message.get("recipeId"), message.get("package"), message.get("manager"))
            if action == "previewInstall":
                return {"type":"installPlan", **plan}
            if message.get("confirmed") is not True:
                raise ValueError("Explicit confirmation is required before opening an installer terminal.")
            command = [sys.executable, str(HERE/"backend.py"), "install", "--manager", plan["manager"], "--package", plan["package"]]
            argv = terminal_argv(command)
            self.popen(argv, env=desktop_environment(), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            return {"openedTerminal":True, "command":plan["command"], "installed":False, "note":"Terminal opened. Installation has not been reported as successful. Confirm there, then use Refresh apps."}
        if action == "preferences":
            values = message.get("values", {})
            if not isinstance(values, dict):
                raise ValueError("Preferences must be an object.")
            preferences = dict(self.store.data["preferences"])
            for k, value in values.items():
                if k not in preferences or type(value) is not type(preferences[k]):
                    raise ValueError("Unsupported preference.")
                if k == "rotationSeconds":
                    value = max(20, min(180, value))
                if k == "screenName":
                    value = value[:128]
                preferences[k] = value
            self.store.replace_values(preferences=preferences)
            return self.snapshot()
        raise ValueError("Unknown action. Arbitrary shell commands are not supported.")

    def event_listener(self):
        interesting = {"activewindow", "activewindowv2", "openwindow", "closewindow", "workspace", "workspacev2", "movewindow", "movewindowv2"}
        while not self.stop.is_set():
            path = socket_path(".socket2.sock")
            if not path:
                self.stop.wait(3)
                continue
            try:
                with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                    client.settimeout(1)
                    client.connect(str(path))
                    pending = b""
                    self.dirty.set()
                    while not self.stop.is_set():
                        try:
                            chunk = client.recv(65536)
                        except socket.timeout:
                            continue
                        if not chunk:
                            break
                        pending += chunk
                        while b"\n" in pending:
                            line, pending = pending.split(b"\n", 1)
                            if line.split(b">>", 1)[0].decode("ascii", "ignore") in interesting:
                                self.dirty.set()
                        if len(pending) > 1024*1024:
                            pending = b""
            except OSError:
                self.stop.wait(3)

    def status_worker(self):
        while not self.stop.is_set():
            self.dirty.wait(5)
            if self.stop.is_set():
                break
            if self.dirty.is_set():
                self.stop.wait(.08)  # Coalesce workspace + activewindow event bursts.
                self.dirty.clear()
            state = self.status()
            if state != self.last_status:
                self.last_status = state
                self.emit(state)


def watch_battery(bridge, emit):
    """Push battery changes: instantly on plug/unplug, and every few seconds.

    ``upower --monitor`` prints a line whenever a device changes (plug, unplug,
    charge state), so the panel reacts the moment the cable moves. The 4 s poll
    keeps the percentage and the time estimates fresh between those events, and
    is the whole mechanism when upower is absent (sysfs-only machines).
    """
    last = [None]

    def publish():
        try:
            state = bridge.battery_state()
        except Exception:
            return
        if state != last[0]:
            last[0] = state
            emit(state)

    thread = None
    try:
        process = subprocess.Popen(["upower", "--monitor"], stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                   text=True, bufsize=1)
        thread = threading.Thread(target=_drain, args=(process, bridge.stop, publish), daemon=True)
        thread.start()
    except OSError:
        process = None

    while not bridge.stop.wait(4):
        publish()


def watch_resources(bridge, emit):
    """Push resources every 2.5 s, but only when something the panel shows moved.

    Memory is read from /proc/meminfo (cheap, cached a second); storage is cached
    for 30 s inside the adapter, so this loop never runs ``df`` more often than
    that even though it ticks every 2.5 s.
    """
    last = [None]

    def signature(state):
        ram = state.get("ram") or {}
        swap = state.get("swap") or {}
        return (ram.get("percent"), swap.get("percent"),
                tuple((disk.get("target"), disk.get("percent")) for disk in state.get("disks", [])),
                tuple(process.get("name") for process in state.get("processes", [])))

    while not bridge.stop.is_set():
        try:
            state = bridge.resources_state()
        except Exception:
            state = None
        if state is not None:
            current = signature(state)
            if current != last[0]:
                last[0] = current
                emit(state)
        if bridge.stop.wait(2.5):
            break


def _drain(process, stop, publish):
    """Read upower --monitor; publish once per burst, stop with the bridge."""
    try:
        for _line in process.stdout:
            if stop.is_set():
                break
            stop.wait(.25)
            publish()
    finally:
        try:
            process.terminate()
        except OSError:
            pass


def serve(config_path=None):
    lock = threading.Lock()
    def emit(message):
        try:
            with lock:
                print(json.dumps(message, ensure_ascii=False), flush=True)
        except (BrokenPipeError, OSError):
            pass
    bridge = Bridge(store=ConfigStore(config_path), emit=emit)
    emit(bridge.snapshot())
    bridge.bluetooth.start()
    bridge.wifi.start()
    for target in (bridge.event_listener, bridge.status_worker):
        threading.Thread(target=target, daemon=True).start()
    threading.Thread(target=bridge.watch_wifi, args=(emit,), daemon=True).start()
    threading.Thread(target=watch_battery, args=(bridge, emit), daemon=True).start()
    threading.Thread(target=watch_resources, args=(bridge, emit), daemon=True).start()
    try:
        while True:
            line = sys.stdin.readline(65537)
            if not line:
                break
            if len(line) > 65536:
                emit({"type":"response", "ok":False, "error":"Request too large."})
                break
            request = None
            try:
                request = json.loads(line)
                response = bridge.request(request)
                emit({"type":"response", "requestId":request.get("requestId"), "ok":True, "result":response})
            except (ValueError, TypeError, KeyError, OSError) as error:
                emit({"type":"response", "requestId":request.get("requestId") if isinstance(request,dict) else None, "ok":False, "error":str(error)})
    finally:
        bridge.stop.set()
        bridge.dirty.set()
        bridge.bluetooth.stop()
        bridge.wifi.stop()
