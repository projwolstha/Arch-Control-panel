"""Discovery of installed XDG/Flatpak/Snap desktop entries and theme icons."""
from __future__ import annotations

import configparser
import os
import shlex
from pathlib import Path

from .pathutil import data_dirs, executable, norm


class DesktopCatalog:
    def __init__(self, dirs=None):
        self.dirs = list(dirs) if dirs is not None else data_dirs()
        self.entries = {}
        self.icon_cache = {}
        self._icon_index = None
        self.scan_report = {"dirs": 0, "files": 0}

    def icon_index(self):
        # One bounded pass over the icon roots, then O(1) lookups. The old
        # per-app scatter search cost thousands of stat calls per application and
        # could stall the first snapshot for so long that the picker stayed empty
        # on slower disks/theme stacks.
        if self._icon_index is not None:
            return self._icon_index
        index = {}
        roots = []
        for base in self.dirs:
            roots += [base/"pixmaps", base/"icons"]
        roots.append(Path.home()/".icons")
        for root in roots:
            try:
                if not root.is_dir():
                    continue
                for path in root.rglob("*"):
                    if not path.is_file() or path.suffix.lower() not in (".svg", ".png", ".xpm"):
                        continue
                    try:
                        uri = path.resolve().as_uri()
                    except OSError:
                        continue
                    index.setdefault(path.name, uri)   # exact file name
                    index.setdefault(path.stem, uri)   # theme-name form
            except OSError:
                continue
        self._icon_index = index
        return index

    def icon_url(self, name):
        if not name:
            return ""
        if name in self.icon_cache:
            return self.icon_cache[name]
        try:
            path = Path(name)
            result = ""
            if path.is_absolute():
                result = path.resolve().as_uri() if path.is_file() else ""
            else:
                index = self.icon_index()
                result = index.get(name) or index.get(Path(name).stem) or ""
        except OSError:
            result = ""
        self.icon_cache[name] = result
        return result

    def refresh(self):
        self.icon_cache.clear()
        self._icon_index = None
        self.scan_report = {"dirs": sum(1 for base in self.dirs if (base/"applications").is_dir()), "files": 0}
        result, seen = {}, set()
        desktop_names = {s.casefold() for s in os.environ.get("XDG_CURRENT_DESKTOP", "Hyprland").split(":") if s}
        lang = (os.environ.get("LC_ALL") or os.environ.get("LANG") or "en").split(".")[0]
        for base in self.dirs:
            folder = base/"applications"
            if not folder.is_dir():
                continue
            for path in sorted(folder.rglob("*.desktop")):
                self.scan_report["files"] += 1
                desktop_id = "-".join(path.relative_to(folder).parts)
                if desktop_id in seen:
                    continue
                seen.add(desktop_id)  # Hidden user entries must mask system entries.
                try:
                    parser = configparser.ConfigParser(interpolation=None, strict=False)
                    parser.optionxform = str
                    parser.read(path, encoding="utf-8")
                    d = parser["Desktop Entry"]
                    if d.get("Type", "Application") != "Application" or d.get("Hidden", "false").lower() == "true" or d.get("NoDisplay", "false").lower() == "true":
                        continue
                    only = {v.casefold() for v in d.get("OnlyShowIn", "").split(";") if v}
                    never = {v.casefold() for v in d.get("NotShowIn", "").split(";") if v}
                    if (only and not desktop_names.intersection(only)) or desktop_names.intersection(never):
                        continue
                    if d.get("TryExec") and not executable(d["TryExec"]):
                        continue
                    argv = shlex.split(d.get("Exec", ""))
                    if not argv and d.get("DBusActivatable", "false").lower() != "true":
                        continue
                    name = d.get("Name["+lang+"]", d.get("Name["+lang.split("_")[0]+"]", d.get("Name", desktop_id)))
                    classes = {norm(desktop_id), norm(desktop_id).rsplit(".", 1)[-1], norm(d.get("StartupWMClass", ""))}
                    if argv:
                        first = Path(argv[0]).name
                        if first == "env":
                            first = next((Path(v).name for v in argv[1:] if "=" not in v and not v.startswith("-")), "")
                        if first not in ("env", "sh", "bash", "flatpak", "snap", "python", "python3", "java"):
                            classes.add(norm(first))
                    classes.discard("")
                    result[desktop_id] = {"id":desktop_id, "name":name, "description":d.get("Comment", d.get("GenericName", "")), "icon":self.icon_url(d.get("Icon", "")), "installed":True, "path":str(path.resolve()), "exec":d.get("Exec", ""), "argv":argv, "terminal":d.get("Terminal", "false").lower()=="true", "workingDirectory":d.get("Path", ""), "classes":classes}
                except (OSError, ValueError, configparser.Error, KeyError):
                    continue
        self.entries = result
        return self.public_entries()

    def public(self, entry):
        return {k:entry[k] for k in ("id", "name", "description", "icon", "installed")}

    def public_entries(self):
        return sorted((self.public(e) for e in self.entries.values()), key=lambda x:x["name"].casefold())

    def recipe_entry(self, recipe):
        for desktop_id in recipe["desktopIds"]:
            if desktop_id in self.entries:
                return self.entries[desktop_id]
        commands = {norm(c) for c in recipe["commands"]}
        return next((e for e in self.entries.values() if e["classes"].intersection(commands)), None)

    def match_client(self, client):
        values = {norm(client.get("class", "")), norm(client.get("initialClass", ""))}
        values.discard("")
        # Strongest match first: the window class IS a desktop id (foot → foot.desktop);
        # without this, exec-token collisions (foot-server.desktop also carries the
        # class "foot") could resolve to the wrong app, killing active tracking.
        for v in sorted(values):
            direct = self.entries.get(v + ".desktop")
            if direct:
                return direct["id"]
        exact = next((e["id"] for e in self.entries.values() if values.intersection(e["classes"])), None)
        if exact:
            return exact
        # Flatpak / reverse-DNS classes sometimes include a fully qualified prefix.
        short = {v.rsplit(".", 1)[-1] for v in values}
        return next((e["id"] for e in self.entries.values() if short.intersection(e["classes"])), None)
