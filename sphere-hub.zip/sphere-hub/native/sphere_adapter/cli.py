"""Command line entry point for the adapter process."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .bridge import serve
from .catalog import DesktopCatalog
from .constants import MANAGERS
from .install import installer_cli
from .system import system_info


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    host = sub.add_parser("serve");host.add_argument("--config", type=Path)
    sub.add_parser("diagnose")
    install = sub.add_parser("install");install.add_argument("--manager", required=True, choices=MANAGERS);install.add_argument("--package", required=True)
    args = parser.parse_args()
    if args.action == "serve":
        serve(args.config)
        return 0
    if args.action == "diagnose":
        catalog = DesktopCatalog();catalog.refresh()
        print(json.dumps({**system_info(), "installedDesktopEntries":len(catalog.entries)}, indent=2))
        return 0
    return installer_cli(args)
