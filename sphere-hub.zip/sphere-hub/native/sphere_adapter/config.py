"""The eight-slot state file (atomic, validated, corruption-safe)."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

from .constants import SLOT_COUNT
from .pathutil import default_config_path


class ConfigStore:
    def __init__(self, path=None):
        self.path = Path(path) if path is not None else default_config_path()
        self.data = {"version":1, "slots":[None]*SLOT_COUNT, "preferences":{"orbitLocked":False, "paused":False, "powerSave":False, "aboveWindows":True, "screenName":"", "rotationSeconds":90}}
        try:
            saved = json.loads(self.path.read_text())
            if isinstance(saved.get("slots"), list):
                self.data["slots"] = (saved["slots"]+[None]*SLOT_COUNT)[:SLOT_COUNT]
            for k, default in self.data["preferences"].items():
                value = saved.get("preferences", {}).get(k)
                if type(value) is type(default):
                    self.data["preferences"][k] = value
            self.data["preferences"]["rotationSeconds"] = max(20, min(180, self.data["preferences"]["rotationSeconds"]))
        except (OSError, ValueError, TypeError, AttributeError):
            pass
        self.data["slots"] = [v if isinstance(v,dict) and v.get("kind") in ("desktop", "recipe") and isinstance(v.get("id"), str) and len(v["id"])<=256 else None for v in self.data["slots"]]

    def replace_values(self, **updates):
        previous = self.data
        self.data = {**previous, **updates}
        try:
            self.save()
        except Exception:
            self.data = previous
            raise

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd, tmp = tempfile.mkstemp(prefix=".sphere-", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w") as out:
                json.dump(self.data, out, indent=2)
                out.write("\n")
                out.flush()
                os.fsync(out.fileno())
            os.replace(tmp, self.path)
        finally:
            try:
                os.unlink(tmp)
            except FileNotFoundError:
                pass
