"""Fixed table of install recipes, slot count, terminals and package-name rules."""
from __future__ import annotations

import re
from pathlib import Path


HERE = Path(__file__).resolve().parent.parent  # the deployed native/ directory.parent  # the deployed native/ directory


SLOT_COUNT = 8


PACKAGE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9+._:-]{0,127}$")


RECIPES = [
    {"id":"firefox", "name":"Firefox", "description":"Web browser", "desktopIds":["firefox.desktop","firefox-esr.desktop","org.mozilla.firefox.desktop"], "commands":["firefox","firefox-esr"], "packages":{"pacman":"firefox","apt":"firefox-esr","dnf":"firefox","zypper":"MozillaFirefox","apk":"firefox","flatpak":"org.mozilla.firefox"}},
    {"id":"chromium", "name":"Chromium", "description":"Web browser", "desktopIds":["chromium.desktop","chromium-browser.desktop","org.chromium.Chromium.desktop"], "commands":["chromium","chromium-browser"], "packages":{"pacman":"chromium","apt":"chromium","dnf":"chromium","zypper":"chromium","apk":"chromium","flatpak":"org.chromium.Chromium"}},
    {"id":"kitty", "name":"Kitty", "description":"Terminal emulator", "desktopIds":["kitty.desktop"], "commands":["kitty"], "packages":{"pacman":"kitty","apt":"kitty","dnf":"kitty","zypper":"kitty","apk":"kitty"}},
    {"id":"alacritty", "name":"Alacritty", "description":"Terminal emulator", "desktopIds":["Alacritty.desktop","alacritty.desktop"], "commands":["alacritty"], "packages":{"pacman":"alacritty","apt":"alacritty","dnf":"alacritty","zypper":"alacritty","apk":"alacritty"}},
    {"id":"foot", "name":"Foot", "description":"Wayland terminal", "desktopIds":["foot.desktop"], "commands":["foot"], "packages":{"pacman":"foot","apt":"foot","dnf":"foot","apk":"foot"}},
    {"id":"thunar", "name":"Thunar", "description":"File manager", "desktopIds":["thunar.desktop","Thunar.desktop"], "commands":["thunar"], "packages":{"pacman":"thunar","apt":"thunar","dnf":"Thunar","zypper":"thunar","apk":"thunar"}},
    {"id":"dolphin", "name":"Dolphin", "description":"File manager", "desktopIds":["org.kde.dolphin.desktop"], "commands":["dolphin"], "packages":{"pacman":"dolphin","apt":"dolphin","dnf":"dolphin","zypper":"dolphin","apk":"dolphin"}},
    {"id":"code", "name":"VS Code / Code OSS", "description":"Code editor (system repository or Flatpak)", "desktopIds":["code.desktop","code-oss.desktop","code_code.desktop","com.visualstudio.code.desktop"], "commands":["code","code-oss"], "packages":{"pacman":"code","flatpak":"com.visualstudio.code"}},
    {"id":"vlc", "name":"VLC", "description":"Media player", "desktopIds":["vlc.desktop","org.videolan.VLC.desktop"], "commands":["vlc"], "packages":{"pacman":"vlc","apt":"vlc","dnf":"vlc","zypper":"vlc","apk":"vlc","flatpak":"org.videolan.VLC"}},
    {"id":"gimp", "name":"GIMP", "description":"Image editor", "desktopIds":["gimp.desktop","org.gimp.GIMP.desktop"], "commands":["gimp"], "packages":{"pacman":"gimp","apt":"gimp","dnf":"gimp","zypper":"gimp","apk":"gimp","flatpak":"org.gimp.GIMP"}},
    {"id":"krita", "name":"Krita", "description":"Painting and illustration", "desktopIds":["org.kde.krita.desktop","krita.desktop"], "commands":["krita"], "packages":{"pacman":"krita","apt":"krita","dnf":"krita","zypper":"krita","apk":"krita","flatpak":"org.kde.krita"}},
    {"id":"obs", "name":"OBS Studio", "description":"Recording and broadcasting", "desktopIds":["com.obsproject.Studio.desktop","obs.desktop"], "commands":["obs"], "packages":{"pacman":"obs-studio","apt":"obs-studio","dnf":"obs-studio","zypper":"obs-studio","apk":"obs-studio","flatpak":"com.obsproject.Studio"}},
    {"id":"libreoffice", "name":"LibreOffice Writer", "description":"Documents", "desktopIds":["libreoffice-writer.desktop","org.libreoffice.LibreOffice.writer.desktop"], "commands":["libreoffice"], "packages":{"pacman":"libreoffice-fresh","apt":"libreoffice-writer","dnf":"libreoffice-writer","zypper":"libreoffice-writer","apk":"libreoffice","flatpak":"org.libreoffice.LibreOffice"}},
    {"id":"qalculate", "name":"Qalculate!", "description":"Calculator", "desktopIds":["qalculate-gtk.desktop","qalculate-qt.desktop"], "commands":["qalculate-gtk","qalculate-qt"], "packages":{"pacman":"qalculate-gtk","apt":"qalculate-gtk","dnf":"qalculate-gtk","zypper":"qalculate-gtk","apk":"qalculate-gtk"}},
    {"id":"pavucontrol", "name":"Volume control", "description":"Audio settings", "desktopIds":["pavucontrol.desktop"], "commands":["pavucontrol"], "packages":{"pacman":"pavucontrol","apt":"pavucontrol","dnf":"pavucontrol","zypper":"pavucontrol","apk":"pavucontrol"}},
]


RECIPE_BY_ID = {r["id"]: r for r in RECIPES}


MANAGERS = ("pacman", "apt", "dnf", "zypper", "apk", "flatpak")


TERMINALS = ("kitty", "ghostty", "foot", "alacritty", "wezterm", "konsole", "gnome-terminal", "xfce4-terminal", "xterm")
