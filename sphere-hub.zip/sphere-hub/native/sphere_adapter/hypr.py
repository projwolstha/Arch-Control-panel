"""Hyprland IPC over its unix socket and the child environment for launched apps."""
from __future__ import annotations

import os
import socket

from .pathutil import socket_path


def hypr_command(command):
    path = socket_path(".socket.sock")
    if not path:
        raise OSError("Hyprland IPC is not available in this session.")
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.settimeout(.8)
        client.connect(str(path))
        client.sendall(command.encode())
        chunks, total = [], 0
        while True:
            part = client.recv(65536)
            if not part:
                break
            total += len(part)
            if total > 4*1024*1024:
                raise ValueError("Hyprland IPC reply was too large.")
            chunks.append(part)
    return b"".join(chunks).decode("utf-8", "replace")


def desktop_environment():
    """Keep widget-only Qt overrides out of launched applications/terminals."""
    env = os.environ.copy()
    for key in ("QT_QPA_PLATFORM", "QT_QUICK_CONTROLS_STYLE", "QT_QUICK_BACKEND"):
        marker = "SPHERE_SAVED_"+key
        if marker in env:
            saved = env.pop(marker)
            if saved == "__SPHERE_UNSET__":
                env.pop(key, None)
            else:
                env[key] = saved
    return env
