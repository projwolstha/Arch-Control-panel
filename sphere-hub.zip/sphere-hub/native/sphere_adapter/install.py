"""Reviewable install plans and the terminal-only installer."""
from __future__ import annotations

import shlex
import subprocess
import sys

from .constants import MANAGERS, PACKAGE_RE, RECIPE_BY_ID
from .system import system_info


def install_plan(recipe_id=None, package=None, manager=None, info=None):
    info = info or system_info()
    manager = manager or info["preferredManager"]
    if manager not in info["managers"] or manager not in MANAGERS:
        raise ValueError("Select an available package manager. No installation command was run.")
    if recipe_id:
        recipe = RECIPE_BY_ID.get(recipe_id)
        if not recipe:
            raise ValueError("Unknown application recipe.")
        package = recipe["packages"].get(manager)
        if manager == "apt" and recipe_id == "firefox" and info.get("distributionId") in ("ubuntu", "linuxmint", "pop", "neon"):
            package = "firefox"
        if not package:
            raise ValueError("No verified package mapping for this app with "+manager+". Try another available manager, or enter a package name you have checked. No repository will be added automatically.")
    if not isinstance(package, str) or not PACKAGE_RE.fullmatch(package):
        raise ValueError("Use a single package name (letters, numbers, +, ., _, :, or -). URLs, paths, flags and shell commands are not accepted.")
    base = {
        "pacman":["pacman", "-S", "--needed", package],
        "apt":["apt", "install", package],
        "dnf":["dnf", "install", package],
        "zypper":["zypper", "install", package],
        "apk":["apk", "add", package],
        "flatpak":["flatpak", "install", "--user", "flathub", package],
    }[manager]
    argv = base if manager == "flatpak" else ["sudo"]+base
    return {"manager":manager, "package":package, "argv":argv, "command":shlex.join(argv), "terminalAvailable":bool(info["terminal"]), "terminal":info["terminal"], "note":"You must confirm again inside the terminal. Your package manager may ask for your password. No -y flags or repository setup are used."}


def installer_cli(args):
    try:
        plan = install_plan(package=args.package, manager=args.manager)
    except ValueError as error:
        print("Sphere: "+str(error))
        return 2
    print("\nSPHERE / install an application\n")
    print("Command:\n  "+plan["command"]+"\n")
    print("No repositories are added, and nothing has been installed yet.")
    print("The package manager may request your password and confirmation.\n")
    if not sys.stdin.isatty():
        print("Refusing non-interactive installation. Open this action in a terminal.")
        return 2
    try:
        answer = input("Type INSTALL to run this command, or press Enter to cancel: ")
        if answer != "INSTALL":
            print("Cancelled. No installation was attempted.")
            return 0
        result = subprocess.run(plan["argv"], shell=False, check=False).returncode
        print("\n"+("Package manager exited successfully. Use Refresh apps in Sphere, then choose/launch the app." if result == 0 else "The package manager did not complete successfully. Review its output above; Sphere has not marked the app installed."))
        input("\nPress Enter to close this terminal.")
        return result
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled.")
        return 130
    except OSError as error:
        print("Could not run the package manager: "+str(error))
        return 2
