"""XDG data roots, desktop-entry argv expansion and socket path helpers."""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path


def data_dirs():
    home = Path(os.environ.get("XDG_DATA_HOME", str(Path.home()/".local/share")))
    dirs = [home] + [Path(p) for p in os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":") if p]
    # Flatpak exports are desktop entries, not shell commands. NixOS/Guix keep
    # applications outside the classic XDG roots — cover them or the picker
    # shows nothing on those systems.
    for p in (home/"flatpak/exports/share",
              Path("/var/lib/flatpak/exports/share"), Path("/var/lib/snapd/desktop"),
              Path.home()/".nix-profile/share", Path("/etc/profiles/per-user")/os.environ.get("USER","")/"share" if os.environ.get("USER") else Path("/nonexistent"),
              Path("/run/current-system/sw/share"), Path.home()/".guix-profile/share",
              Path.home()/".local/state/nix/profile/share" if hasattr(Path, "home") else Path("/nonexistent")):
        try:
            if p not in dirs and p.is_dir():
                dirs.append(p)
        except OSError:
            continue
    return dirs


def executable(value):
    return bool(value and (os.access(value, os.X_OK) if "/" in value else shutil.which(value)))


def norm(value):
    return str(value).casefold().removesuffix(".desktop")


def default_config_path():
    return Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home()/".config")))/"sphere-hub"/"state.json"


def socket_path(name):
    signature = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE", "")
    runtime = os.environ.get("XDG_RUNTIME_DIR", "")
    if not signature or not runtime or "/" in signature:
        return None
    return Path(runtime)/"hypr"/signature/name


def expand_exec(entry):
    argv = []
    for token in entry["argv"]:
        if token in ("%f", "%F", "%u", "%U", "%d", "%D", "%n", "%N", "%v", "%m"):
            continue
        if token == "%i":
            continue
        token = token.replace("%%", "\0").replace("%c", entry["name"]).replace("%k", entry["path"])
        if re.search(r"%[A-Za-z]", token):
            raise ValueError("This desktop entry needs gio to expand its launch arguments.")
        argv.append(token.replace("\0", "%"))
    if not argv:
        raise ValueError("Install gio / GLib desktop utilities to launch this DBus-only desktop entry.")
    return argv
