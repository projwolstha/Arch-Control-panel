"""System resources for the orb panel: memory, swap, storage and the heaviest
processes.

The panel wants one flat dict; everything else is this module's problem.

Sources
-------
1. **/proc/meminfo** — ``MemTotal``, ``MemAvailable``, ``Cached``, ``Buffers``,
   ``SwapTotal``, ``SwapFree``. ``used`` is ``total - available``, the number
   ``free`` and ``htop`` show, not ``total - free`` (page cache is not "in use").
2. **``df -B1 --output=source,fstype,size,used,avail,pcent,target``** — one row
   per mounted filesystem. Pseudo filesystems (tmpfs, devtmpfs, squashfs,
   overlay, …) and loop devices are dropped here, not in the UI.
3. **``ps``** — the three largest RSS values, best effort; no ``ps`` means no
   process list, never an error.

Storage is expensive compared with memory, so it is cached for 30 s while the
memory figures are cached for a second: the bridge can poll the cheap one often.
Every field may be ``None``; the panel hides what it cannot show.
"""
from __future__ import annotations

import os
import subprocess
import time

TIMEOUT = 6
CACHE_SECONDS = 1.0
STORAGE_SECONDS = 30.0

MEMINFO = "/proc/meminfo"
DF_ARGV = ("df", "-B1", "--output=source,fstype,size,used,avail,pcent,target")

# Pseudo and in-memory filesystems: not "storage" in the sense the panel means.
EXCLUDED_FSTYPES = {
    "tmpfs", "devtmpfs", "squashfs", "overlay", "ramfs", "efivarfs", "proc", "sysfs",
    "cgroup", "cgroup2", "devpts", "fusectl", "mqueue", "debugfs", "tracefs",
    "securityfs", "pstore", "bpf", "autofs", "binfmt_misc", "configfs", "hugetlbfs",
    "nsfs", "rpc_pipefs", "selinuxfs", "fuse.gvfsd-fuse", "fuse.etcfs", "tmp", "dev",
}

# Bedrock Linux composes distributions under /bedrock/strata: those directories
# are the layer plumbing, not a disk the user stores anything on.
BEDROCK_PREFIX = "/bedrock/"

# Never deduplicated away, even when they share a device with another mount.
ALWAYS_SHOW = ("/", "/home", "/boot", "/boot/efi", "/var", "/usr")

GIB = 1024.0 ** 3

_cache = {"mem": (0.0, None), "disk": (0.0, None), "proc": (0.0, None)}


# ── plumbing ────────────────────────────────────────────────────────────────
def _run(argv, timeout=TIMEOUT):
    """Run an argument vector; never raise, never inherit a locale."""
    try:
        return subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                              env={**os.environ, "LC_ALL": "C"}, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        return subprocess.CompletedProcess(argv, 1, "", str(error))


def _has(tool):
    for directory in os.environ.get("PATH", "/usr/bin:/bin").split(":"):
        if directory and os.path.exists(os.path.join(directory, tool)):
            return True
    return False


def _read(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read()
    except OSError:
        return None


def _meminfo_path():
    """Test hook: point the reader at a fake /proc/meminfo."""
    return os.environ.get("SPHERE_MEMINFO", MEMINFO)


def _clamp(value):
    return max(0, min(100, int(round(value)))) if value is not None else None


def _gib(kib):
    return None if kib is None else round(kib / 1048576.0, 1)


def _pct(used, total):
    if not total or used is None:
        return None
    return _clamp(100.0 * used / total)


# ── memory ──────────────────────────────────────────────────────────────────
def _parse_meminfo(text):
    """'MemTotal: 32768 kB' lines → {'MemTotal': 32768, …} (kB)."""
    fields = {}
    for line in (text or "").splitlines():
        if ":" not in line:
            continue
        key, _, rest = line.partition(":")
        number = rest.strip().split(" ")[0] if rest.strip() else ""
        try:
            fields[key.strip()] = int(number)
        except ValueError:
            continue
    return fields


def memory():
    """RAM and swap, in GiB, with the percentages the panel paints."""
    stamp, cached = _cache["mem"]
    now = time.monotonic()
    if cached is not None and now - stamp < CACHE_SECONDS:
        return cached

    fields = _parse_meminfo(_read(_meminfo_path()))
    if not fields.get("MemTotal"):
        _cache["mem"] = (now, None)
        return None

    total = fields["MemTotal"]
    available = fields.get("MemAvailable")
    if available is None:                      # very old kernels
        available = fields.get("MemFree", 0) + fields.get("Cached", 0) + fields.get("Buffers", 0)
    used = max(0, total - available)
    cached_kib = fields.get("Cached", 0) + fields.get("SReclaimable", 0)
    buffers = fields.get("Buffers", 0)

    swap_total = fields.get("SwapTotal", 0) or 0
    swap_free = fields.get("SwapFree", 0) or 0
    swap_used = max(0, swap_total - swap_free)
    swap = None
    if swap_total > 0:
        swap = {"total": _gib(swap_total), "used": _gib(swap_used),
                "free": _gib(swap_free), "percent": _pct(swap_used, swap_total)}

    value = {
        "total": _gib(total), "used": _gib(used), "available": _gib(available),
        "free": _gib(fields.get("MemFree", 0)),
        "cached": _gib(cached_kib), "buffers": _gib(buffers),
        "percent": _pct(used, total),
        "totalBytes": total * 1024, "usedBytes": used * 1024,
    }
    result = {"ram": value, "swap": swap}
    _cache["mem"] = (now, result)
    return result


# ── storage ─────────────────────────────────────────────────────────────────
def _df_rows(text):
    """Parse the --output table; never raise on a short or odd line."""
    rows = []
    lines = (text or "").splitlines()
    for line in lines[1:]:                     # first line is the header
        parts = line.split()
        if len(parts) < 7:
            continue
        source, fstype = parts[0], parts[1]
        try:
            size, used, avail = int(parts[2]), int(parts[3]), int(parts[4])
        except ValueError:
            continue                           # df prints "-" for some mounts
        target = " ".join(parts[6:]) or "/"
        if fstype in EXCLUDED_FSTYPES:
            continue
        if source.startswith("/dev/loop") or source == "none":
            continue
        if target == BEDROCK_PREFIX.rstrip("/") or target.startswith(BEDROCK_PREFIX):
            continue
        if size <= 0:
            continue
        rows.append({"source": source, "fstype": fstype, "target": target,
                     "size": size, "used": used, "avail": avail,
                     "percent": _pct(used, used + avail)})
    return rows


def _pick_disks(rows):
    """One row per mount worth showing, biggest and most standard first."""
    kept, seen = [], set()
    for row in rows:
        key = (row["source"], row["size"], row["used"])
        if row["target"] not in ALWAYS_SHOW and key in seen:
            continue                           # a bind mount repeating a device
        seen.add(key)
        kept.append(row)

    # A mount that lives on the same volume as / is not a second disk: the
    # panel prints it as a sub-line under / instead of a row with the same bar.
    root = next((row for row in kept if row["target"] == "/"), None)
    if root is not None:
        root_key = (root["source"], root["size"], root["used"])
        for row in kept:
            row["shared"] = (row is not root
                             and (row["source"], row["size"], row["used"]) == root_key)

    order = {target: index for index, target in enumerate(ALWAYS_SHOW)}

    def rank(row):
        target = row["target"]
        exact = order.get(target, len(order))
        if target.startswith("/home/"):
            exact = len(order) + 1
        return (exact, -row["size"])

    return sorted(kept, key=rank)


def storage():
    """Mounted filesystems, cached for 30 s (df is the expensive one)."""
    stamp, cached = _cache["disk"]
    now = time.monotonic()
    if cached is not None and now - stamp < STORAGE_SECONDS:
        return cached

    result = _run(DF_ARGV)
    rows = _pick_disks(_df_rows(result.stdout or "")) if result.returncode == 0 else []

    disks = []
    for row in rows:
        disks.append({
            "target": row["target"], "source": row["source"], "fstype": row["fstype"],
            "total": round(row["size"] / GIB, 1), "used": round(row["used"] / GIB, 1),
            "free": round(row["avail"] / GIB, 1), "percent": row["percent"],
            "shared": bool(row.get("shared")),
        })
    _cache["disk"] = (now, disks)
    return disks


# ── the heaviest three, best effort ─────────────────────────────────────────
def processes(limit=3):
    stamp, cached = _cache["proc"]
    now = time.monotonic()
    if cached is not None and now - stamp < CACHE_SECONDS:
        return cached
    if not _has("ps"):
        _cache["proc"] = (now, [])
        return []

    result = _run(["ps", "-eo", "rss=,comm=", "--sort=-rss"], timeout=4)
    out = []
    for line in (result.stdout or "").splitlines():
        text = line.strip()
        if not text:
            continue
        parts = text.split(None, 1)
        if len(parts) != 2:
            continue
        try:
            rss_kib = int(parts[0])
        except ValueError:
            continue
        name = parts[1].strip()
        if name in ("ps", "df") or rss_kib <= 0:
            continue
        out.append({"name": name, "rss": round(rss_kib / 1048576.0, 2)})
        if len(out) >= limit:
            break
    _cache["proc"] = (now, out)
    return out


# ── the one flat state the panel reads ──────────────────────────────────────
def status(include_processes=True):
    memory_state = memory()
    disks = storage() or []
    # The header speaks about the system disk: "/" when it is mounted, otherwise
    # the fullest filesystem there is.
    root = next((d for d in disks if d["target"] == "/"), None)
    if root is not None:
        disk_percent, disk_target = root.get("percent"), "/"
    elif disks:
        fullest = max(disks, key=lambda d: d.get("percent") or 0)
        disk_percent, disk_target = fullest.get("percent"), fullest["target"]
    else:
        disk_percent, disk_target = None, ""

    if memory_state is None and not disks:
        return {"available": False, "now": round(time.time()),
                "error": "Could not read /proc/meminfo or df.", "ram": None, "swap": None,
                "disks": [], "diskPercent": None, "processes": []}

    return {
        "available": True,
        "now": round(time.time()),
        "error": "" if memory_state is not None else "Memory information is unavailable.",
        "ram": (memory_state or {}).get("ram"),
        "swap": (memory_state or {}).get("swap"),
        "disks": disks,
        "diskPercent": disk_percent,
        "diskTarget": disk_target,
        "processes": processes() if include_processes else [],
    }
