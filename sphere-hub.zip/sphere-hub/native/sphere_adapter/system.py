"""Host probes: os-release, package managers, terminals, Hyprland window state."""
from __future__ import annotations

import os
import shlex
import shutil
from pathlib import Path

from .constants import MANAGERS, TERMINALS
from .pathutil import default_config_path, executable


def os_release():
    result = {}
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                parsed = shlex.split(v)
                result[k] = parsed[0] if parsed else ""
    except OSError:
        pass
    return result


# The file each distribution writes into its own root. These outrank the text
# of /etc/os-release: on Bedrock one distribution supplies the release file while
# another supplies the package manager, and a stale apt shim outlives the base
# image it came from. Arch is checked first because this desktop targets it.
DISTRO_MARKERS = (("/etc/arch-release", "pacman"),
                  ("/etc/debian_version", "apt"),
                  ("/etc/fedora-release", "dnf"),
                  ("/etc/alpine-release", "apk"))


def preferred_manager(release, available):
    """The package manager that owns this root, or "" when none is installed."""
    for marker, manager in DISTRO_MARKERS:
        if Path(marker).exists():
            return manager if manager in available else (available[0] if available else "")
    ident = release.get("ID", "")+" "+release.get("ID_LIKE", "")
    preferred = "pacman" if "arch" in ident else "apt" if any(v in ident for v in ("debian", "ubuntu")) else "dnf" if any(v in ident for v in ("fedora", "rhel")) else "zypper" if "suse" in ident else "apk" if "alpine" in ident else ""
    if preferred not in available:
        preferred = available[0] if available else ""
    return preferred


def system_info():
    release = os_release()
    available = [m for m in MANAGERS if shutil.which(m)]
    preferred = preferred_manager(release, available)
    terminal = detect_terminal()
    return {"distribution":release.get("PRETTY_NAME", "Linux"), "distributionId":release.get("ID", ""), "managers":available, "preferredManager":preferred, "terminal":terminal[0] if terminal else "", "hyprlandSession":bool(os.environ.get("HYPRLAND_INSTANCE_SIGNATURE")), "configPath":str(default_config_path())}


def detect_terminal():
    preferred = []
    if os.environ.get("TERMINAL"):
        try:
            command = shlex.split(os.environ["TERMINAL"])
            if command and Path(command[0]).name in TERMINALS and executable(command[0]):
                preferred.append(command)
        except ValueError:
            pass
    preferred.extend([[t] for t in TERMINALS if shutil.which(t)])
    return preferred[0] if preferred else []
