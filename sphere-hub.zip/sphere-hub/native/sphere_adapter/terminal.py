"""Building the argument vector for a real terminal window."""
from __future__ import annotations

from pathlib import Path

from .system import detect_terminal


def terminal_argv(command, title="Sphere — install"):
    terminal = detect_terminal()
    if not terminal:
        raise ValueError("No supported terminal was found. Open your own terminal and use the displayed command.")
    kind = Path(terminal[0]).name
    if kind == "kitty":
        return terminal+["--title", title]+list(command)
    if kind == "ghostty":
        return terminal+["--title="+title, "-e"]+list(command)
    if kind == "foot":
        return terminal+["--title="+title]+list(command)
    if kind == "alacritty":
        return terminal+["--title", title, "-e"]+list(command)
    if kind == "wezterm":
        return terminal+["start", "--"]+list(command)
    if kind == "konsole":
        return terminal+["--separate", "-e"]+list(command)
    if kind == "gnome-terminal":
        return terminal+["--title="+title, "--"]+list(command)
    if kind == "xfce4-terminal":
        return terminal+["--title="+title, "--execute"]+list(command)
    return terminal+["-T", title, "-e"]+list(command)
