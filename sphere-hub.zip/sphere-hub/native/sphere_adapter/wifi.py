"""Wi-Fi listing and connection control through NetworkManager's ``nmcli``.

Three invariants, learned the hard way:

* **stdout is data, stderr is a note.** nmcli writes "Error: Device 'wlan0'
  request failed: …" to stderr and still exits 0 on some paths; conversely it can
  exit 1 with the answer on stdout. Parsing reads stdout only; the *text* of an
  error is taken from whichever stream has it and is shown verbatim.
* **A scan is a process, not a flag.** ``nmcli ... device wifi list --rescan yes``
  runs on its own thread; the panel says "Scanning…" only while that thread lives,
  and the list is filled from its result. The first rescan after login can take
  3-5 s, so a completely empty answer is retried once, two seconds later.
* **Four different problems, four different sentences.** NetworkManager not
  running, no Wi-Fi device, a device NetworkManager refuses to manage, and a
  switched-off radio each produce their own message — never a generic
  "No networks visible yet".

Only argument vectors are handed to nmcli — nothing is ever evaluated by a shell.
A WPA passphrase never appears on a command line: it is written to a 0600
``passwd-file`` in the private temporary directory, passed to
``nmcli connection up … passwd-file``, and unlinked in a ``finally`` block.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
from pathlib import Path

TIMEOUT = 25
SCAN_TIMEOUT = 25          # one --rescan yes; the first one after login is slow
SCAN_RETRY_DELAY = 2.0     # an empty answer is retried once, two seconds later
CONNECT_TIMEOUT = 60
MAX_SSID_BYTES = 32
MAX_DETAIL = 240
HEX_PSK = re.compile(r"[0-9a-fA-F]{64}")

# Exactly the field list the panel needs, in the documented terse format.
LIST_FIELDS = "IN-USE,SSID,SIGNAL,SECURITY"
LIST_ARGS = ["-t", "-f", LIST_FIELDS, "device", "wifi", "list"]

CLI_NAME = "nmcli"
CLI_FALLBACKS = ("/usr/bin/nmcli", "/bin/nmcli", "/usr/local/bin/nmcli",
                 "/usr/sbin/nmcli", "/sbin/nmcli")


class WifiError(ValueError):
    """A Wi-Fi request that cannot be honoured; the message is shown in the widget."""

    def __init__(self, message, detail=""):
        super().__init__(message)
        self.detail = (detail or "")[:MAX_DETAIL]


# ── environment and the binary ───────────────────────────────────────────────
def cli_environment(base=None):
    """The environment nmcli is given: the user's, completed where broken.

    A widget started from a bare ``exec-once``, a systemd unit or a multiplexer
    can lack the variables D-Bus needs; nmcli then says "Error: Could not create
    NMClient object: Could not connect: No such file or directory" while
    NetworkManager is perfectly healthy.
    """
    env = dict(os.environ if base is None else base)
    parts = [piece for piece in (env.get("PATH") or "").split(os.pathsep) if piece]
    for extra in ("/usr/local/sbin", "/usr/local/bin", "/usr/bin", "/usr/sbin",
                  "/bin", "/sbin"):
        if extra not in parts:
            parts.append(extra)
    env["PATH"] = os.pathsep.join(parts) or os.defpath
    try:
        uid = os.getuid()
    except (AttributeError, OSError):
        uid = None
    runtime = env.get("XDG_RUNTIME_DIR") or ""
    if not runtime or not Path(runtime).is_dir():
        candidate = f"/run/user/{uid}" if uid is not None else ""
        if candidate and Path(candidate).is_dir():
            runtime = candidate
    if runtime:
        env["XDG_RUNTIME_DIR"] = runtime
    if not env.get("DBUS_SESSION_BUS_ADDRESS") and runtime:
        bus = Path(runtime) / "bus"
        if bus.exists():
            env["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=" + str(bus)
    if not env.get("DBUS_SYSTEM_BUS_ADDRESS"):
        socket = Path("/run/dbus/system_bus_socket")
        if socket.exists():
            env["DBUS_SYSTEM_BUS_ADDRESS"] = "unix:path=" + str(socket)
    env.setdefault("LC_ALL", "C")
    return env


def cli_path():
    """Absolute path of nmcli, from PATH and then from the known locations."""
    found = shutil.which(CLI_NAME)
    if found:
        return found
    for candidate in CLI_FALLBACKS:
        try:
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                return candidate
        except OSError:
            continue
    return None


def available():
    """True when NetworkManager's command line client can be executed."""
    return cli_path() is not None


def _run(args, timeout=TIMEOUT):
    """Run nmcli with an argument vector. Raises WifiError, never a bare OSError."""
    cli = cli_path()
    if cli is None:
        raise WifiError("NetworkManager (nmcli) is not installed, so Wi-Fi cannot be controlled from Sphere.")
    try:
        return subprocess.run([cli, *args], capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=timeout,
                              env=cli_environment(), check=False)
    except subprocess.TimeoutExpired as error:
        raise WifiError(f"nmcli {' '.join(str(a) for a in args)} did not answer in {int(timeout)}s.",
                        _as_text(error.stdout) or _as_text(error.stderr)) from None
    except OSError as error:
        raise WifiError("nmcli could not be started: " + str(error) +
                        (f" ({cli})" if cli else "")) from None


def _as_text(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return str(value)


def _out(result):
    return _as_text(getattr(result, "stdout", "")) if result is not None else ""


def _err(result):
    return _as_text(getattr(result, "stderr", "")) if result is not None else ""


def _lines(text):
    return [line for line in (text or "").splitlines() if line.strip()]


def _detail(result, limit=MAX_DETAIL):
    """The first meaningful line of an nmcli result — its own words."""
    for line in _lines(_out(result)) + _lines(_err(result)):
        return line.strip()[:limit]
    return ""


def _message(result):
    """Text of a failure: stdout if it said anything, otherwise stderr."""
    said = "\n".join(line.strip() for line in _lines(_out(result)))
    return said or "\n".join(line.strip() for line in _lines(_err(result)))


# The most common nmcli failures, in words a non-root desktop user can act on.
FRIENDLY = (
    ("NetworkManager is not running", "NetworkManager is not running. Start it, then press Scan again."),
    ("Could not create NMClient object", "NetworkManager is not reachable. Start it, then press Scan again."),
    ("No Wi-Fi device found", "No Wi-Fi adapter was found on this system."),
    ("not authorized", "NetworkManager refused the change for this user (PolicyKit)."),
    ("Secrets were required", "The saved password was rejected. Choose the network again and type the password."),
    ("no network with SSID", "That network is no longer in range. Press Scan and try again."),
    ("Connection activation failed", "NetworkManager could not activate this connection."),
    ("Device or resource busy", "The Wi-Fi adapter is busy (another connection is being set up)."),
)


def _humanize(text, fallback=""):
    """Translate a known nmcli failure, or fall back to the text nmcli printed."""
    text = (text or "").strip()
    for needle, friendly in FRIENDLY:
        if needle.lower() in text.lower():
            return friendly
    return text or fallback


def _reply(process, action):
    if process.returncode == 0:
        return _out(process)
    detail = " ".join(_message(process).split())[:300]
    if not detail:
        raise WifiError("nmcli could not " + action + ".")
    friendly = _humanize(detail)
    if friendly == detail:
        raise WifiError("nmcli could not " + action + ": " + detail, detail)
    raise WifiError(friendly, detail)


def _unquote(field):
    """Undo nmcli's terse-mode escaping (backslash before ':' and '\\')."""
    out, index = [], 0
    while index < len(field):
        char = field[index]
        if char == "\\" and index + 1 < len(field):
            index += 1
            out.append(field[index])
        else:
            out.append(char)
        index += 1
    return "".join(out)


def split_terse(line):
    """Split one ``nmcli -t`` line on **unescaped** colons.

    An SSID containing a colon is printed as ``My\\:Net``; splitting naively
    shifts SIGNAL and SECURITY one field over and the list comes back empty —
    which is exactly the bug this function exists to prevent.
    """
    fields, current, index = [], [], 0
    while index < len(line):
        char = line[index]
        if char == "\\" and index + 1 < len(line):
            current.append(line[index:index + 2])
            index += 2
            continue
        if char == ":":
            fields.append(_unquote("".join(current)))
            current = []
        else:
            current.append(char)
        index += 1
    fields.append(_unquote("".join(current)))
    return fields


def check_ssid(value):
    """Validate an SSID before it reaches nmcli."""
    if not isinstance(value, str) or not value:
        raise WifiError("Choose a Wi-Fi network first.")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise WifiError("That network name contains control characters; it was not used.")
    if value.startswith("-"):
        raise WifiError("That network name would be read as an option by nmcli; it was not used.")
    if len(value.encode("utf-8")) > MAX_SSID_BYTES:
        raise WifiError("A Wi-Fi network name is at most 32 bytes long.")
    return value


def check_passphrase(value):
    """Validate a WPA passphrase. None/empty means "use the saved key or no key"."""
    if value in (None, ""):
        return None
    if not isinstance(value, str):
        raise WifiError("The passphrase must be text.")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise WifiError("That passphrase contains control characters; it was not used.")
    if HEX_PSK.fullmatch(value):
        return value
    if not 8 <= len(value) <= 63:
        raise WifiError("A WPA passphrase is 8 to 63 characters (or 64 hexadecimal digits).")
    return value


# ── radio ───────────────────────────────────────────────────────────────────
def radio_on():
    """True/False for the Wi-Fi radio, or None when nmcli cannot tell.

    ``nmcli radio wifi`` prints exactly ``enabled`` or ``disabled``; anything else
    (an error, a missing client) is "unknown", never a guess.
    """
    try:
        result = _run(["-t", "radio", "wifi"], timeout=10)
    except WifiError:
        return None
    if result.returncode != 0:
        return None
    text = _out(result).strip().lower()
    if text.startswith("enabled") or text == "on":
        return True
    if text.startswith("disabled") or text == "off":
        return False
    return None


def radio(enabled):
    if type(enabled) is not bool:
        raise WifiError("The Wi-Fi radio switch expects true or false.")
    _reply(_run(["radio", "wifi", "on" if enabled else "off"], timeout=15), "switch the Wi-Fi radio")
    return radio_on()


# ── network manager health ──────────────────────────────────────────────────
NM_RUNNING = "running"
NM_STOPPED = "stopped"
NM_UNKNOWN = "unknown"


def network_manager_running():
    """(state, detail) — is NetworkManager itself up? Its own words on failure."""
    try:
        result = _run(["-t", "-f", "RUNNING", "general", "status"], timeout=10)
    except WifiError as error:
        return NM_UNKNOWN, str(error)
    said = (_out(result) or "").strip().lower()
    if result.returncode == 0:
        if said in ("running", "yes", "true") or said.startswith("running"):
            return NM_RUNNING, ""
        if said in ("not running", "no", "false", "stopped") or "not running" in said:
            return NM_STOPPED, "NetworkManager is not running"
    detail = _detail(result)
    if "could not create nmclient" in detail.lower() or "not running" in detail.lower():
        return NM_STOPPED, detail
    return NM_UNKNOWN, detail


def wifi_devices():
    """[(device, state, managed)] for every Wi-Fi interface.

    ``nmcli -t -f DEVICE,TYPE,STATE,CONNECTION device status`` is the cheap read;
    "unmanaged"/"unavailable" is what a device looks like when NetworkManager
    refuses to drive it (``/etc/NetworkManager/conf.d/unmanaged.conf``,
    ``netctl``, or ``managed=0`` in ``iwd``).
    """
    result = _run(["-t", "-f", "DEVICE,TYPE,STATE", "device", "status"], timeout=12)
    devices = []
    for line in _lines(_out(result)):
        fields = split_terse(line)
        if len(fields) >= 3 and fields[1] == "wifi":
            state = fields[2].strip().lower()
            devices.append((fields[0], state, state not in ("unmanaged", "unavailable")))
    return devices


# ── networks ────────────────────────────────────────────────────────────────
def profiles():
    """Saved connection profile names, used to tell 'saved' from 'new' networks."""
    try:
        text = _reply(_run(["-t", "-f", "NAME,TYPE", "connection", "show"]), "list saved connections")
    except WifiError:
        return set()
    names = set()
    for line in _lines(text):
        fields = split_terse(line)
        if len(fields) >= 2 and fields[1] in ("802-11-wireless", "wifi"):
            names.add(fields[0])
    return names


def _security(security):
    text = (security or "").strip()
    label = "" if text in ("", "--") else text
    return {
        "label": label,
        "secure": bool(label),
        "wep": "WEP" in label.upper() and "WPA" not in label.upper(),
        "enterprise": "802.1X" in label or "802.1x" in label,
        "sae": "WPA3" in label.upper() or "SAE" in label.upper(),
    }


def parse_networks(text, saved=None):
    """Turn ``nmcli -t -f IN-USE,SSID,SIGNAL,SECURITY …`` output into rows.

    * fields are split on **unescaped** colons (an SSID may contain ``:``);
    * lines without a name (hidden access points) are skipped;
    * duplicates are collapsed to the strongest signal — a 2.4 GHz and a 5 GHz
      radio of the same network are one row;
    * the result is sorted by signal, connected first.
    """
    saved = profiles() if saved is None else saved
    found = {}
    for line in _lines(text):
        fields = split_terse(line)
        if len(fields) < 4:
            continue
        in_use, ssid, signal, security = fields[0], fields[1], fields[2], fields[3]
        ssid = ssid.strip("\x00").strip()
        if not ssid:
            continue
        try:
            quality = max(0, min(100, int(float(signal))))
        except (TypeError, ValueError):
            quality = 0
        entry = {
            "ssid": ssid,
            "signal": quality,
            "inUse": in_use.strip() == "*",
            "saved": ssid in saved,
            **_security(security),
        }
        previous = found.get(ssid)
        if previous is None or (entry["inUse"], entry["signal"]) > (previous["inUse"], previous["signal"]):
            found[ssid] = entry
    return sorted(found.values(),
                  key=lambda item: (not item["inUse"], not item["saved"], -item["signal"], item["ssid"].lower()))


def networks(rescan=False):
    """Visible access points, de-duplicated by SSID and sorted for display."""
    args = list(LIST_ARGS)
    if rescan:
        args += ["--rescan", "yes"]
    result = _run(args, timeout=SCAN_TIMEOUT if rescan else TIMEOUT)
    text = _out(result)
    if result.returncode != 0 and not _lines(text):
        # Never a bare "no networks": nmcli's own sentence, translated when it is
        # one of the known failures and quoted verbatim when it is not.
        detail = _detail(result)
        friendly = _humanize(detail)
        if not friendly:
            friendly = "nmcli could not list Wi-Fi networks."
        elif detail and friendly == detail:
            friendly = "nmcli could not list Wi-Fi networks: " + detail
        raise WifiError(friendly, detail)
    return parse_networks(text)


def scan_networks(seconds=SCAN_TIMEOUT):
    """One rescan; retried once when the answer is completely empty.

    The retry exists because the first ``--rescan yes`` after login regularly
    comes back empty while the adapter is still waking up — that is the "on · 0"
    the panel used to show. Two seconds later the same call returns the list.
    """
    first = networks(rescan=True)
    if first:
        return first, False, ""
    time.sleep(SCAN_RETRY_DELAY)
    second = networks(rescan=True)
    return second, True, ""


# ── connection state ────────────────────────────────────────────────────────
DEVICE_CONNECTED = {"connected", "activated"}
DEVICE_CONNECTING = {"connecting", "prepare", "config", "need-auth", "ip-config", "ip-check",
                     "secondaries", "activating", "deactivating"}
DEVICE_FAILED = {"failed"}
CONNECTION_ACTIVE = {"activated", "activating"}


def device_states():
    """{device: state} for every Wi-Fi interface NetworkManager knows."""
    text = _reply(_run(["-t", "-f", "DEVICE,TYPE,STATE", "device", "status"]), "read device states")
    devices = {}
    for line in _lines(text):
        fields = split_terse(line)
        if len(fields) >= 3 and fields[1] == "wifi":
            devices[fields[0]] = fields[2].strip().lower()
    return devices


def active_connections():
    """[(name, state)] for active Wi-Fi connection profiles (activating = auth/IP phase)."""
    text = _reply(_run(["-t", "-f", "NAME,TYPE,STATE", "connection", "show", "--active"]),
                  "read active connections")
    result = []
    for line in _lines(text):
        fields = split_terse(line)
        if len(fields) >= 3 and fields[1] in ("802-11-wireless", "wifi"):
            result.append((fields[0], fields[2].strip().lower()))
    return result


def visual_state(available_=None, radio=None, devices=None, connections=None):
    """Map raw NetworkManager facts to the widget's three states."""
    if available_ is False:
        return {"state": "disconnected", "reason": "no-networkmanager"}
    if radio is False:
        return {"state": "disconnected", "reason": "radio-off"}
    devices = devices or {}
    connections = connections or []
    states = set(devices.values())
    pending = [name for name, state in connections if state == "activating"]
    if states & DEVICE_CONNECTED:
        if pending:
            return {"state": "connecting", "reason": "auth-pending"}
        return {"state": "connected", "reason": "connected"}
    if states & DEVICE_FAILED:
        return {"state": "disconnected", "reason": "failed"}
    if states & DEVICE_CONNECTING or pending:
        return {"state": "connecting", "reason": "auth-pending" if pending else "activating"}
    if not devices:
        return {"state": "disconnected", "reason": "no-device"}
    if states == {"unmanaged"} or "unmanaged" in states:
        return {"state": "disconnected", "reason": "unmanaged"}
    return {"state": "disconnected", "reason": "disconnected"}


def read_state():
    """The three-state verdict plus the raw facts it came from."""
    if not available():
        return {"state": "disconnected", "reason": "no-networkmanager", "radioOn": False,
                "devices": {}, "connections": [], "nm": NM_UNKNOWN, "error": "",
                "detail": "NetworkManager (nmcli) is not installed"}
    nm_state, nm_detail = network_manager_running()
    on = radio_on()
    try:
        devices = device_states()
    except WifiError as error:
        devices = {}
        nm_detail = nm_detail or str(error)
    try:
        connections = active_connections()
    except WifiError:
        connections = []
    verdict = visual_state(available_=True, radio=on, devices=devices, connections=connections)
    return {**verdict, "radioOn": bool(on), "devices": devices,
            "connections": [{"name": name, "state": state} for name, state in connections],
            "nm": nm_state, "error": "", "detail": nm_detail}


def active_ssid(devices=None):
    """SSID of the connection that is actually up ('' when nothing is connected)."""
    devices = device_states() if devices is None else devices
    if not any(state in DEVICE_CONNECTED for state in devices.values()):
        return ""
    try:
        text = _reply(_run(["-t", "-f", "GENERAL.CONNECTION", "device", "show"]), "read the active connection")
    except WifiError:
        return ""
    for line in _lines(text):
        fields = split_terse(line)
        if len(fields) >= 2 and fields[0].startswith("GENERAL.CONNECTION") and fields[1] not in ("", "--"):
            return fields[1]
    return ""


def problem(facts, devices=None):
    """The one sentence the panel shows when there is nothing to list.

    Empty means "no problem, the list is simply empty (no networks in range)".
    Four distinct causes, because they need four different actions.
    """
    if not available():
        return ("NetworkManager (nmcli) is not installed, so Wi-Fi cannot be controlled "
                "from Sphere. On Arch: sudo pacman -S networkmanager")
    nm_state = facts.get("nm", NM_UNKNOWN)
    detail = (facts.get("detail") or "").strip()
    if nm_state == NM_STOPPED:
        return ("NetworkManager is not running. Start it with: sudo systemctl start "
                "NetworkManager" + (f" — nmcli said: {detail}" if detail else ""))
    if not facts.get("radioOn"):
        return ("Wi-Fi is switched off. Press Wi-Fi on to enable the radio "
                "(nmcli radio wifi on)" + (f" — nmcli said: {detail}" if detail else ""))
    states = set((devices if devices is not None else facts.get("devices") or {}).values())
    if not states:
        return ("No Wi-Fi device was found. Check that the adapter is present "
                "(lspci -nn | grep -i network) and not blocked by rfkill."
                + (f" — nmcli said: {detail}" if detail else ""))
    if states == {"unmanaged"} or states == {"unavailable"} or (states & {"unmanaged", "unavailable"}
                                                               and not states & (DEVICE_CONNECTED | DEVICE_CONNECTING)):
        return ("The Wi-Fi device is not managed by NetworkManager, so it cannot scan. "
                "Check /etc/NetworkManager/conf.d for an [unmanaged-devices] rule "
                "(and that another tool such as netctl or iwd is not driving it)."
                + (f" — nmcli said: {detail}" if detail else ""))
    if nm_state == NM_UNKNOWN and detail:
        return "NetworkManager could not be queried: " + detail
    return ""


def status(rescan=False, include_networks=True, networks_override=None):
    """Everything the widget needs to paint the orb (and, optionally, the list).

    ``include_networks=False`` skips the (comparatively expensive) scan and the
    saved-profile lookup: the orb only needs state, so state-change pushes stay cheap.
    ``networks_override`` lets the scan worker hand its finished list in without a
    second nmcli call.
    """
    if not available():
        return {"available": False, "radioOn": False, "active": None, "networks": [],
                "state": "disconnected", "reason": "no-networkmanager", "devices": {},
                "connections": [], "nm": NM_UNKNOWN, "scanning": scanning(),
                "problem": problem({}), "error": problem({}), "detail": ""}
    try:
        facts = read_state()
        listed = []
        active = None
        if include_networks and facts["radioOn"]:
            listed = networks_override if networks_override is not None else networks(rescan=rescan)
            active = next((item for item in listed if item["inUse"]), None)
        elif facts["state"] == "connected":
            ssid = active_ssid(facts["devices"])
            active = {"ssid": ssid, "inUse": True} if ssid else None
        found_problem = problem(facts) if facts["radioOn"] else problem(facts)
        return {"available": True, "radioOn": facts["radioOn"], "active": active, "networks": listed,
                "state": facts["state"], "reason": facts["reason"],
                "devices": facts["devices"], "connections": facts["connections"],
                "nm": facts["nm"], "scanning": scanning(),
                "problem": found_problem, "error": "", "detail": facts.get("detail", "")}
    except WifiError as error:
        return {"available": True, "radioOn": bool(radio_on()), "active": None, "networks": [],
                "state": "disconnected", "reason": "error", "devices": {}, "connections": [],
                "nm": NM_UNKNOWN, "scanning": scanning(),
                "problem": str(error), "error": str(error), "detail": error.detail}


# ── the scan process ────────────────────────────────────────────────────────
_SCAN_LOCK = threading.Lock()
_SCAN = {"thread": None, "started": 0.0, "result": None, "callback": None, "finished": None}


def scanning():
    """True only while a rescan is actually running."""
    with _SCAN_LOCK:
        thread = _SCAN["thread"]
    return bool(thread is not None and thread.is_alive())


def last_scan():
    """(networks, retried, detail) of the last finished scan, or None."""
    with _SCAN_LOCK:
        return _SCAN["result"]


def start_scan(on_done=None, seconds=SCAN_TIMEOUT):
    """Start a rescan on its own thread and return immediately.

    The caller (the bridge) publishes `scanning: true` at once, then calls
    `on_done(listed, retried, detail)` from the scanning thread when the list is
    ready — or when the scan failed, with `listed` empty and the real text in
    `detail`. Pressing Scan twice reuses the running scan instead of stacking a
    second nmcli on top of it.
    """
    if scanning():
        state = status(include_networks=False)
        state["scanning"] = True
        return True
    with _SCAN_LOCK:
        _SCAN.update(started=time.monotonic(), result=None, callback=on_done)

    def work():
        listed, retried, detail = [], False, ""
        try:
            listed, retried, detail = scan_networks(seconds=seconds)
        except WifiError as error:
            detail = str(error) + ((": " + error.detail) if error.detail else "")
        except Exception as error:                 # never let the thread die silently
            detail = f"the scan thread failed: {error}"
        finished = time.monotonic()
        with _SCAN_LOCK:
            _SCAN.update(thread=None, result=([dict(row) for row in listed], retried, detail),
                         finished=finished)
            callback = _SCAN["callback"]
            _SCAN["callback"] = None
        if callback:
            try:
                callback(listed, retried, detail)
            except Exception:
                pass

    thread = threading.Thread(target=work, daemon=True, name="sphere-wifi-scan")
    with _SCAN_LOCK:
        _SCAN["thread"] = thread
    thread.start()
    return True


def stop_scan():
    """Mark the scan abandoned (the nmcli call itself is bounded by its timeout)."""
    with _SCAN_LOCK:
        _SCAN.update(callback=None)


# ── connecting ──────────────────────────────────────────────────────────────
def _profile_added(ssid, key_mgmt):
    _reply(_run(["connection", "add", "type", "wifi", "con-name", ssid, "ssid", ssid,
                 "wifi-sec.key-mgmt", key_mgmt]), "create a connection profile")


def _activate_with_secret(ssid, passphrase, key_mgmt):
    """Hand the passphrase to NetworkManager through a 0600 file, never argv."""
    handle, path = tempfile.mkstemp(prefix="sphere-wifi-", suffix=".passwd")
    try:
        os.fchmod(handle, 0o600)
        with os.fdopen(handle, "w") as stream:
            stream.write("802-11-wireless-security.psk:" + passphrase + "\n")
        return _reply(_run(["--wait", "30", "connection", "up", "id", ssid, "passwd-file", path],
                           timeout=CONNECT_TIMEOUT), "activate " + ssid)
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def connect(ssid, passphrase=None, security=""):
    """Join a network. Returns the SSID on success; raises WifiError otherwise."""
    ssid = check_ssid(ssid)
    passphrase = check_passphrase(passphrase)
    details = _security(security)
    if details["enterprise"]:
        raise WifiError("Enterprise (802.1X) networks need certificates and an identity; join this one with your system tools.")
    if details["wep"]:
        raise WifiError("WEP networks are not supported here; join this one with your system tools.")
    if not passphrase:
        _reply(_run(["--wait", "30", "device", "wifi", "connect", ssid], timeout=CONNECT_TIMEOUT),
               "connect to " + ssid)
        return ssid
    key_mgmt = "sae" if details["sae"] else "wpa-psk"
    if ssid not in profiles():
        _profile_added(ssid, key_mgmt)
    try:
        _activate_with_secret(ssid, passphrase, key_mgmt)
    except WifiError:
        _reply(_run(["connection", "modify", "id", ssid, "wifi-sec.key-mgmt", key_mgmt]), "update " + ssid)
        _activate_with_secret(ssid, passphrase, key_mgmt)
    return ssid


def wifi_device():
    """The connected Wi-Fi interface name, or '' when none is up."""
    try:
        for device, state, _managed in wifi_devices():
            if state in DEVICE_CONNECTED:
                return device
    except WifiError:
        return ""
    return ""


def disconnect():
    device = wifi_device()
    if not device:
        raise WifiError("No Wi-Fi interface is currently connected.")
    _reply(_run(["device", "disconnect", device]), "disconnect " + device)
    return device


# ── the cache the widget reads ──────────────────────────────────────────────
class Monitor:
    """A cached, self-refreshing view of the radio and the list.

    QML must never wait for nmcli: `current()` is a dictionary lookup, and a
    background thread keeps it fresh (2 s while the panel is open, 20 s while it
    is closed). A scan is started by `scan()` and its result is published through
    the same channel, so "Scanning…" is tied to a real thread.
    """

    def __init__(self, on_change=None, interval=20.0, open_interval=2.0):
        self.on_change = on_change or (lambda state: None)
        self.interval = max(1.0, float(interval))
        self.open_interval = max(1.0, float(open_interval))
        self._lock = threading.Lock()
        self._state = None
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread = None
        self._open = False

    # ── reading ─────────────────────────────────────────────────────────
    def current(self):
        with self._lock:
            state = self._state
        if state is None:
            state = {"available": available(), "radioOn": False, "active": None, "networks": [],
                     "state": "disconnected", "reason": "", "devices": {}, "connections": [],
                     "nm": NM_UNKNOWN, "scanning": scanning(),
                     "problem": "", "error": "", "detail": ""}
            self.wake()
        copied = dict(state)
        copied["networks"] = [dict(row) for row in state.get("networks") or []]
        copied["active"] = dict(state["active"]) if state.get("active") else None
        return copied

    def set_open(self, is_open):
        """The panel opened: refresh now, and refresh often while it stays open."""
        self._open = bool(is_open)
        self.wake()

    def refresh(self):
        self.wake()

    def wake(self):
        self._wake.set()

    # ── lifecycle ───────────────────────────────────────────────────────
    def start(self):
        if self._thread and self._thread.is_alive():
            return self
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="sphere-wifi-monitor")
        self._thread.start()
        return self

    def stop(self):
        self._stop.set()
        self._wake.set()
        stop_scan()

    def _loop(self):
        while not self._stop.is_set():
            try:
                state = status(include_networks=self._open)
            except Exception as error:
                state = self.current()
                state.update(state="disconnected", reason="error", error=str(error),
                             problem=f"Wi-Fi could not be read: {error}")
            self._publish(state)
            self._wake.wait(self.open_interval if self._open else self.interval)
            self._wake.clear()

    def _publish(self, state):
        with self._lock:
            previous = self._state
            self._state = dict(state)
        if state != previous:
            try:
                self.on_change(dict(state))
            except Exception:
                pass

    # ── scanning ────────────────────────────────────────────────────────
    def scan(self):
        """Start a scan in the background; the panel flips to "Scanning…" now."""
        if scanning():
            return
        state = self.current()
        state["scanning"] = True
        state["problem"] = ""
        self._publish(state)

        def done(listed, retried, detail):
            # Scan finished: fill the list from its own result, no second call.
            state = status(include_networks=True, networks_override=listed)
            if not listed and detail:
                state["problem"] = _humanize(detail, detail)
                if state["problem"] == detail and detail:
                    state["problem"] = "The scan failed: " + detail
                state["detail"] = detail[:MAX_DETAIL]
            elif not listed:
                state["problem"] = problem(read_state())
            state["scanning"] = False
            state["retried"] = retried
            self._publish(state)

        start_scan(on_done=done)

    # ── actions ─────────────────────────────────────────────────────────
    def set_radio(self, enabled):
        def work():
            try:
                radio(enabled is True)
            except WifiError as error:
                state = self.current()
                state.update(problem=str(error), error=str(error), detail=error.detail)
                self._publish(state)
            finally:
                self.wake()
        threading.Thread(target=work, daemon=True, name="sphere-wifi-radio").start()

    def connect(self, ssid, passphrase=None, security=""):
        def work():
            try:
                connect(ssid, passphrase, security)
            except WifiError as error:
                state = self.current()
                state.update(problem=str(error), error=str(error), detail=error.detail)
                self._publish(state)
            finally:
                self.wake()
        threading.Thread(target=work, daemon=True, name="sphere-wifi-connect").start()

    def disconnect(self):
        def work():
            try:
                disconnect()
            except WifiError as error:
                state = self.current()
                state.update(problem=str(error), error=str(error), detail=error.detail)
                self._publish(state)
            finally:
                self.wake()
        threading.Thread(target=work, daemon=True, name="sphere-wifi-disconnect").start()
