#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if ! command -v python3 >/dev/null 2>&1 || ! python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
  printf '%s\n' 'Sphere needs Python 3.10 or newer. Install it with your distribution package manager.' >&2
  exit 1
fi
# A session that was started without these (a bare exec-once, a systemd unit, a
# multiplexer) breaks every D-Bus client — bluetoothctl included — while
# everything else looks fine. Complete them here, once, for Quickshell and every
# process it spawns; the panel does the same again for its own children.
if [ -z "${XDG_RUNTIME_DIR:-}" ] && [ -d "/run/user/$(id -u)" ]; then
  XDG_RUNTIME_DIR="/run/user/$(id -u)"; export XDG_RUNTIME_DIR
fi
if [ -z "${DBUS_SESSION_BUS_ADDRESS:-}" ] && [ -S "${XDG_RUNTIME_DIR:-/nonexistent}/bus" ]; then
  DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"; export DBUS_SESSION_BUS_ADDRESS
fi

if command -v qs >/dev/null 2>&1; then
  exec qs -p "$HERE"
elif command -v quickshell >/dev/null 2>&1; then
  exec quickshell -p "$HERE"
else
  printf '%s\n' 'Quickshell was not found. Install Quickshell using its official distribution instructions, then run this script again.' >&2
  printf '%s\n' 'https://quickshell.org/docs/guide/install-setup/' >&2
  exit 1
fi
