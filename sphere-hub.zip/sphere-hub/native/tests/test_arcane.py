"""The living arcane layer: tokens, energy strokes, runes, the orb, the spell.

6.18.0 rebuilt the *look* of the ring — glowing lines, generated runes, a
holographic centre and a coordinated ignition — without touching a single piece
of behaviour. These tests are the contract that keeps it that way:

  * one theme object owns every colour (no hex literals in the drawing files),
  * a line is three layers (bloom, colour, white core) and never a shader,
  * the rune rings are individual generated glyphs, not a baked band,
  * the core sits inside the bevel and cannot resize the ring,
  * the spell ramps 0 → 1 once, and low power skips it,
  * the memory guarantee (no per-item Canvas, no shadowBlur, no full-screen blur)
    still holds, and the five gems/panels/hover model are untouched.
"""
import re
import unittest
from pathlib import Path

NATIVE = Path(__file__).resolve().parents[1]
REPO = NATIVE.parent
WIDGET = (NATIVE / "SphereWidget.qml").read_text()
RING = (NATIVE / "MagicRing.qml").read_text()
GEM = (NATIVE / "MagicGem.qml").read_text()
CORE = (NATIVE / "JarvisCore.qml").read_text()
LINE = (NATIVE / "EnergyLine.qml").read_text()
RUNES = (NATIVE / "RuneRing.qml").read_text()
OUTER = (NATIVE / "OuterRings.qml").read_text()
SIGILS = (NATIVE / "Sigil.qml").read_text()
WEB = (NATIVE / "Web.qml").read_text()
THEME = (NATIVE / "Theme.qml").read_text()
ARTWORK = (REPO / "tools" / "artwork.py").read_text()

HEX = re.compile(r'"#[0-9a-fA-F]{3,8}"')


class ThemeTests(unittest.TestCase):
    def test_every_token_the_brief_asks_for_exists(self):
        for token in ("gold", "goldBright", "cyan", "blue", "gemWifi", "gemBattery",
                      "glassOpacity", "glowAlpha", "coreAlpha", "bg"):
            self.assertIn("readonly property", THEME, token)
            self.assertRegex(THEME, r"readonly property (color|real) %s:" % re.escape(token))

    def test_the_drawing_files_do_not_hardcode_colours(self):
        # a hex literal in the drawing code is a colour that cannot be recoloured
        for name, text in (("MagicRing.qml", RING), ("MagicGem.qml", GEM),
                           ("JarvisCore.qml", CORE), ("EnergyLine.qml", LINE),
                           ("RuneRing.qml", RUNES)):
            literals = [h for h in HEX.findall(text) if h != '"#000000"']
            self.assertEqual(literals, [], f"{name} hardcodes {literals}")

    def test_the_five_gems_read_their_light_from_the_theme(self):
        for token in ("gemWifi", "gemBluetooth", "gemBattery", "gemSystem", "gemFiles"):
            self.assertIn("color:theme.%s" % token, WIDGET)
        self.assertEqual(WIDGET.count("theme.gem"), 5)

    def test_helpers_exist_for_the_two_things_every_layer_needs(self):
        self.assertIn("function alpha(c, a)", THEME)
        self.assertIn("function light(c, t)", THEME)     # toward white: the core


class EnergyLineTests(unittest.TestCase):
    def test_a_line_is_three_layers(self):
        # bloom, saturated middle, white core — in that order, in one Shape
        self.assertEqual(LINE.count("ShapePath {"), 3)
        self.assertLess(LINE.index("line.theme.glowAlpha"), LINE.index("line.theme.midAlpha"))
        self.assertLess(LINE.index("line.theme.midAlpha"), LINE.index("line.theme.coreAlpha"))

    def test_the_flow_is_a_dash_offset_not_new_geometry(self):
        self.assertIn("strokeStyle: line.flow ? ShapePath.DashLine : ShapePath.SolidLine", LINE)
        self.assertIn("dashOffset: line.flow ? -(line.clock * line.flowSpeed) : 0", LINE)
        # the path itself never depends on the clock
        self.assertNotIn("PathSvg { path: line.clock", LINE)

    def test_the_core_is_not_white_white(self):
        # a pure-white filament eats the colour of a long line: the tint survives
        self.assertIn("line.theme.light(line.tint, 0.46)", LINE)
        self.assertNotIn("light(line.tint, 1.0)", LINE)

    def test_the_tight_outer_rings_replace_the_old_double_ring(self):
        # the bold edge is four packed rings from OuterRings.qml; the old
        # EnergyLine double ring and its circlePath are deleted, not commented
        self.assertIn("OuterRings {", RING)
        self.assertNotIn("circlePath", RING)
        for gone in ("polygonPath", "starPoint", "starAngle", "innerAngle"):
            self.assertNotIn(gone, RING, gone)
        # 2 ignition arcs + the bridge delegate (3 at run time)
        self.assertGreaterEqual(RING.count("EnergyLine {"), 3)

    def test_the_edge_rings_are_computed_and_packed(self):
        # 3-4 thin rings at the very edge: radii from Geometry, weights from
        # Theme, the outermost brightest; gold (default) or silver family
        self.assertIn("geometry.outerRadii", OUTER)
        self.assertIn("crestOuterEdgeWidths", OUTER)
        self.assertIn("crestOuterEdgeAlphas", OUTER)
        self.assertIn("familyColor", OUTER)
        self.assertIn('theme.outerColor === "silver"', OUTER)
        for gone in ("tickAnchor", "tickShortEveryDeg", "crestTickLongWidth"):
            self.assertNotIn(gone, OUTER, gone)

    def test_the_plates_labels_and_old_web_are_gone(self):
        # the spell-circle pass removed them; nothing may quietly return
        for gone in ("plateSource", "gemLabels", "plateGlowPath", "plateAngle",
                     "plateGain", "textRadius", "typeFamily"):
            self.assertNotIn(gone, RING, gone)
        for gone in ("plateBox", "plateInner", "plateOuter", "gemLabel(",
                     'objectName: "plate'):
            self.assertNotIn(gone, WIDGET, gone)


class RuneTests(unittest.TestCase):
    def test_one_rune_ring_draws_the_structure_not_two_spinning_rings(self):
        # the counter-rotating glyph rings and their spin are retired: one
        # RuneRing owns the crest's ring structure now — its frame is fixed
        self.assertEqual(RING.count("RuneRing {"), 1)
        self.assertNotIn("spin:", RING)
        self.assertNotIn("spin:", RUNES)
        self.assertIn("geometry: ring.geometry", RING)
        self.assertIn("highlight: ring.litIndex", RING)

    def test_the_ring_structure_is_computed_geometry(self):
        # band rings and the dashed ring — every radius from Geometry.qml,
        # every stroke from Theme.qml, nothing hand-placed; the dense tick
        # comb is deleted and its tokens must not come back
        for token in ("runeBandOuter", "runeBandInner", "dashedRadius"):
            self.assertIn("runeRing.geometry.%s" % token, RUNES, token)
        for token in ("crestRuneRingWidth", "crestDashedWidth"):
            self.assertIn("runeRing.theme.%s" % token, RUNES, token)
        for gone in ("tickAnchor", "tickLongEveryDeg", "tickShortEveryDeg",
                     "crestTickLongWidth", "crestTickShortWidth"):
            self.assertNotIn(gone, RUNES, gone)
        self.assertNotIn("model: 72", RING)                # the old comb is gone
        self.assertNotIn("frameSource", RING)              # the sheets with it

    def test_the_glyph_ring_is_five_segments_with_gaps_and_diamonds(self):
        # 60 glyphs in five segments of twelve, every station angle derived
        # from the segment centre, a gap at each gem angle and one diamond
        # boundary node in each gap — no hand-placed position anywhere
        for token in ("runeCount", "runeRadius", "runeSize", "segmentGapDeg",
                      "boundaryNodeSize"):
            self.assertIn("runeRing.geometry.%s" % token, RUNES, token)
        self.assertIn("runeRing.geometry.segmentAngle(", RUNES)
        self.assertIn("runeRing.geometry.gemAngle(", RUNES)      # the diamonds
        self.assertIn("runeRing.geometry.runeBandOuter", RUNES)  # on the ring, visible
        self.assertIn('Qt.resolvedUrl("assets/rune-"', RUNES)
        self.assertIn("model: runeRing.geometry.runeCount", RUNES)
        self.assertIn("model: runeRing.geometry.gemCount", RUNES)
        # upright outward: the glyph turns with its radius (0 = up)
        self.assertIn("rotation: angleDeg + 90", RUNES)

    def test_the_runes_turn_in_place_one_lap_per_ten_minutes(self):
        # motion runeRotation: each glyph turns slowly on its own spot — one
        # lap per 600 s — and the BAND never moves: the delivered
        # composition (gaps at the gems) stands still
        self.assertIn("property Motion motion", RUNES)
        self.assertIn("runeRing.motion.runeRotation", RUNES)
        self.assertIn("runeRing.clock % 600", RUNES)
        self.assertIn("rotation: turn", RUNES)          # the rune's own turn
        self.assertNotIn("glyphWheel", RUNES)           # no wandering band
        # hover lighting is the delivered slot rule
        self.assertIn("slot === 0 && runeRing.highlight === segment", RUNES)

    def test_the_ring_motions_are_all_toggleable_and_pause_with_the_clock(self):
        # every crest motion reads its own flag; nothing owns a timer, so
        # everything stops with the widget's paused clock (hidden ↔ unhidden)
        self.assertIn("runeRing.motion.runeFlicker", RUNES)
        self.assertIn("runeRing.motion.goldShimmer", RUNES)
        self.assertIn("sigils.motion.sigilPulse", SIGILS)
        self.assertIn("web.motion.webPulse", WEB)
        for text in (RUNES, SIGILS, WEB):
            self.assertIn("property Motion motion", text)
            self.assertNotIn("Timer {", text)

    def test_the_glyphs_are_generated_files_and_there_are_enough(self):
        assets = NATIVE / "assets"
        runes = sorted(assets.glob("rune-*.svg"))
        sigils = sorted(assets.glob("sigils/sigil-*.svg"))
        # one glyph per band slot: the asset set follows the config count
        want = int(re.search(r"readonly property int runeCount: (\d+)",
                             (NATIVE / "Geometry.qml").read_text()).group(1))
        self.assertEqual(len(runes), want)
        self.assertGreaterEqual(len(sigils), 5)
        # all distinct, and all drawn from strokes rather than typed
        bodies = {(p.read_text()) for p in runes + sigils}
        self.assertEqual(len(bodies), len(runes) + len(sigils))
        for p in runes[:3] + sigils[:3]:
            text = p.read_text()
            self.assertIn("<path d=", text)
            self.assertNotIn("font", text)

    def test_the_glyph_ring_keeps_its_hooks_and_has_no_timer(self):
        # the motion step drives the drift and flicker from these hooks; the
        # ring itself must never keep a timer of its own
        self.assertIn("clock", RUNES)
        self.assertIn("highlight", RUNES)               # the hovered gem's station
        self.assertIn("property bool animated", RUNES)
        self.assertIn("runeRing.highlight", RUNES)      # and the hooks are used
        self.assertNotIn("Timer {", RUNES)

    def test_the_artwork_generator_owns_the_runes(self):
        self.assertIn("RUNE_SEEDS", ARTWORK)
        self.assertNotIn("SIGIL_SEEDS", ARTWORK)        # studies retired
        self.assertIn("SIGIL_STATION_SEEDS", ARTWORK)
        self.assertIn("def rune_glyph_svg", ARTWORK)


class SigilTests(unittest.TestCase):
    """The five sigil stations: emblems, inscriptions, diamond end nodes."""

    def test_the_sigil_layer_hides_behind_the_flag(self):
        # "sigils": false (layout.json → Geometry.sigilsEnabled) hides the
        # whole layer — the code stays, the crest does not draw it
        self.assertIn("visible: ring.geometry.sigilsEnabled", RING)

    def test_one_station_per_segment_from_panels_json(self):
        # the emblem each segment carries is ASSIGNED in panels.json — the
        # drawing code never names a sigil file of its own
        self.assertIn('objectName: "sigilLayer"', SIGILS)
        self.assertIn("model: sigils.panels.segments.length", SIGILS)
        self.assertIn("property Panels panels", SIGILS)
        self.assertIn("Qt.resolvedUrl(segment.sigil)", SIGILS)
        self.assertIn("highlight: ring.litIndex", RING)     # wired like the ring

    def test_every_station_is_computed_geometry(self):
        for token in ("sigilRadius", "sigilSize", "gemHaloRadius", "connectorArc",
                      "nodeSize", "boundaryNodeSize"):
            self.assertIn("geometry.%s" % token, SIGILS, token)
        self.assertIn("geometry.segmentAngle(", SIGILS)     # the station
        self.assertIn("geometry.gemAngle(", SIGILS)         # the halo endpoints
        # upright outward, like the glyph ring
        self.assertIn("rotation: stationDeg + 90", SIGILS)
        # the inscriptions read the connector language, the studs the node one
        self.assertIn("theme.crestConnectorWidth", SIGILS)
        self.assertIn("theme.crestConnectorAlpha", SIGILS)
        self.assertIn("theme.crestSigilAlpha", SIGILS)

    def test_the_stations_have_their_hooks_and_no_timer(self):
        self.assertIn("clock", SIGILS)
        self.assertIn("property bool animated", SIGILS)
        self.assertIn("sigils.highlight", SIGILS)
        self.assertNotIn("Timer {", SIGILS)

    def test_the_web_is_one_quiet_static_layer(self):
        # spokes, nodes, the optional star and the optional guide circle —
        # flat lines at the token weights, and the web owns no transform and
        # no timer (motion.json webRotation is false; webPulse is the only
        # hook, and the drawing does not read it yet)
        self.assertIn('objectName: "webLayer"', WEB)
        self.assertIn("property real clock", WEB)          # webPulse's hook
        self.assertIn("property bool animated", WEB)
        self.assertNotIn("Timer {", WEB)
        self.assertNotIn("RotationAnimator", WEB)
        self.assertNotIn("Rotation {", WEB)

    def test_the_web_is_computed_geometry(self):
        for token in ("spokeGemFrom", "spokeGemTo", "spokeSegmentFrom",
                      "spokeSegmentTo", "nodeSize", "gemStarRadius",
                      "gemStarEnabled", "guideRadius", "guideEnabled"):
            self.assertIn("web.geometry.%s" % token, WEB, token)
        self.assertIn("web.geometry.gemAngle(", WEB)
        self.assertIn("web.geometry.segmentAngle(", WEB)
        for token in ("crestSpokeGemWidth", "crestSpokeSegWidth", "crestStarWidth",
                      "crestGuideWidth", "crestNodeAlpha"):
            self.assertIn("web.theme.%s" % token, WEB, token)
        # the star and the guide circle are optional — empty path when off
        self.assertIn("web.geometry.gemStarEnabled", WEB)
        self.assertIn("web.geometry.guideEnabled", WEB)

    def test_the_sigil_art_is_assigned_files_not_type(self):
        assets = NATIVE / "assets" / "sigils"
        files = sorted(assets.glob("sigil-*.svg"))
        self.assertEqual(len(files), 5)
        for f in files:
            text = f.read_text()
            self.assertIn("<path d=", text)
            self.assertNotIn("font", text)


class CoreTests(unittest.TestCase):
    """The Jarvis core: what sits in the middle of the disc now."""

    def test_the_core_is_a_child_of_the_disc_not_the_ring(self):
        # a child of the disc grows with it; the ring container is never touched
        disc = WIDGET.split('id:disc;objectName:"centreDisc"', 1)[1]
        self.assertIn("JarvisCore {", disc)
        self.assertLess(disc.index("JarvisCore {"), disc.index('id:logoSlot'))

    def test_the_core_fits_inside_the_bevel_and_is_drawn_from_tokens(self):
        # coreFit is a share of the disc, and it must stay inside the gold bevel
        self.assertIn("diameter: parent.width*root.theme.coreFit", WIDGET)
        self.assertRegex(THEME, r"coreFit: 0\.9[0-9]*")
        # the orb is ≈0.16 R: a fifth of the way out from the centre
        self.assertRegex(THEME, r"coreOrbRadius: 0\.3[0-9]+")
        # the three rings, outside in, and their segment counts
        self.assertRegex(THEME, r"coreRingOuter: 0\.[0-9]+")
        self.assertRegex(THEME, r"coreRingMiddle: 0\.[0-9]+")
        self.assertRegex(THEME, r"coreRingInner: 0\.[0-9]+")
        self.assertIn("coreCpuSegments: 48", THEME)
        self.assertIn("coreRamSegments: 36", THEME)
        self.assertIn("coreBatterySegments: 24", THEME)

    def test_the_rings_are_one_repeated_bar_each_not_a_rebuilt_path(self):
        # a segment lights by changing its colour; no path is rebuilt per value
        self.assertIn("component Ring: Item {", CORE)
        self.assertEqual(CORE.count("Ring {"), 3)          # one per ring, no more
        self.assertIn("model: ring.segments", CORE)
        self.assertIn("rotation: index * (360 / Math.max(1, ring.segments))", CORE)
        self.assertIn("index < ring.value * ring.segments", CORE)

    def test_the_rings_are_fed_by_sysstats(self):
        # the core still defaults to an empty ring, but the widget hands it values
        for prop in ("cpu", "ram", "battery"):
            self.assertRegex(CORE, r"property real %s: 0" % prop)
        self.assertIn("animated: !root.paused && root.sphereVisible && !root.lowPower",
                      WIDGET)
        self.assertIn("SysStats {", WIDGET)
        self.assertIn("cpu: stats.cpu", WIDGET)
        self.assertIn("ram: stats.ram", WIDGET)
        self.assertIn("battery: stats.battery", WIDGET)
        # a missing source is a state the ring shows, not a number it invents
        for flag in ("cpuLive", "ramLive", "batteryLive"):
            self.assertIn("property bool %s: false" % flag, CORE)
            self.assertIn("%s: stats.%s" % (flag, flag), WIDGET)
        # and the core keeps no timer: the beat lives in the data file
        self.assertNotIn("Timer {", CORE)

    def test_the_orb_and_its_halo_are_generated_artwork(self):
        # SVG radial gradients: a RadialGradient inside a Shape paints a sliver
        # in this Qt, so the light is an asset, not a shape fill
        self.assertIn("def core_orb_svg", ARTWORK)
        self.assertIn("def core_halo_svg", ARTWORK)
        for name in ("core-orb.svg", "core-halo.svg"):
            self.assertTrue((NATIVE / "assets" / name).is_file(), name)
        self.assertIn('source: Qt.resolvedUrl("assets/core-orb.svg")', CORE)
        self.assertIn('source: Qt.resolvedUrl("assets/core-halo.svg")', CORE)

    def test_the_core_takes_a_clock_and_formats_it_itself(self):
        # three numbers in, "hh:mm" out — the zero-padding is the core's own job
        for prop in ("hours", "minutes", "seconds"):
            self.assertRegex(CORE, r"property int %s: 0" % prop)
        self.assertIn("property string dateText", CORE)
        self.assertIn('(hours < 10 ? "0" : "") + hours', CORE)
        # the date is spelled elsewhere, so this file never guesses a locale
        self.assertIn("property string serif", CORE)
        self.assertIn("font.family: core.serif", CORE)

    def test_the_seconds_are_one_arc_rebuilt_once_a_second(self):
        self.assertIn("PathAngleArc {", CORE)
        self.assertIn("startAngle: -90", CORE)              # twelve o'clock
        self.assertIn("sweepAngle: 6 * core.seconds", CORE)  # 6° a second
        self.assertIn("ShapePath.RoundCap", CORE)
        self.assertIn('objectName: "coreSecondsArc"', CORE)
        # and a bead at its head, on the same angle
        self.assertIn("Math.sin(a) * core.r * core.theme.coreArcRadius", CORE)

    def test_the_type_sits_on_a_generated_scrim_not_a_shader(self):
        self.assertIn("def core_scrim_svg", ARTWORK)
        self.assertTrue((NATIVE / "assets" / "core-scrim.svg").is_file())
        self.assertIn('source: Qt.resolvedUrl("assets/core-scrim.svg")', CORE)
        # every size and colour is a token
        for token in ("coreClockTimeSize", "coreClockDateSize", "coreClockTimeSpacing",
                      "coreClockDateSpacing", "coreClockGap", "coreClockWeight",
                      "coreClockTime", "coreClockDate", "coreClockDateAlpha",
                      "coreScrimScale", "coreScrimAlpha", "coreArcRadius",
                      "coreArcWidth", "coreArcAlpha", "coreArcHeadScale",
                      "coreArcColor", "coreArcHead"):
            self.assertIn(token, THEME, token)
        for token in ("coreClockTime", "coreClockDate", "coreScrimAlpha",
                      "coreArcRadius", "coreArcWidth", "coreArcHeadScale"):
            self.assertIn("core.theme.%s" % token, CORE, token)

    def test_the_widget_no_longer_keeps_a_clock_of_its_own(self):
        # one source: Quickshell's SystemClock in shell.qml, at second precision
        shell = (NATIVE / "shell.qml").read_text()
        self.assertIn("SystemClock {", shell)
        self.assertIn("precision: SystemClock.Seconds", shell)
        self.assertIn("enabled: widget.sphereVisible && !widget.paused", shell)
        self.assertIn("now: systemClock.date", shell)
        # and the widget only formats what it is handed
        self.assertNotIn("interval:1000;repeat:true;running:true", WIDGET)
        self.assertNotIn("showClockWhenIdle", WIDGET)

    def test_the_date_is_spelled_in_the_plates_language(self):
        # the dashboard says WI-FI, not the system's translated names: the day and
        # month come from fixed tables, so the date cannot change language
        self.assertIn('["SUN","MON","TUE","WED","THU","FRI","SAT"]', WIDGET)
        self.assertIn('"NOV"', WIDGET)
        self.assertIn("root.dayNames()[root.now.getDay()]", WIDGET)

    def test_the_data_file_polls_proc_on_a_two_second_beat(self):
        stats = (NATIVE / "SysStats.qml").read_text()
        self.assertIn("interval: stats.intervalMs", stats)
        self.assertIn("signal pollRequested()", stats)
        self.assertIn("/proc/stat", stats) or self.assertIn("parseStat", stats)
        self.assertIn("MemTotal", stats)
        self.assertIn("MemAvailable", stats)
        # CPU is a delta between two samples, never a single read
        self.assertIn("1 - dIdle / dTotal", stats)
        # and it is smoothed, not snapped
        self.assertIn("Behavior on cpu { NumberAnimation { duration: stats.smoothMs", stats)
        # the beat and the blend are tokens
        self.assertIn("statsPollMs: 2000", THEME)
        self.assertIn("statsSmoothMs: 400", THEME)
        self.assertIn("intervalMs: root.theme.statsPollMs", WIDGET)
        self.assertIn("smoothMs: root.theme.statsSmoothMs", WIDGET)

    def test_the_shell_reads_proc_and_hands_it_down(self):
        shell = (NATIVE / "shell.qml").read_text()
        self.assertIn('path:"/proc/stat"', shell)
        self.assertIn('path:"/proc/meminfo"', shell)
        self.assertIn("procStat:procStatView.text()", shell)
        self.assertIn("procMem:procMemView.text()", shell)
        self.assertIn("onStatsPoll:{ procStatView.reload(); procMemView.reload(); }", shell)
        # a missing file is not an error to log: the ring already says it
        self.assertEqual(shell.count("printErrors:false"), 2)
        # and the beat stops with the dashboard
        self.assertIn("enabled: root.sphereVisible && !root.paused", WIDGET)

    def test_a_missing_ring_says_so_instead_of_showing_zero(self):
        self.assertIn("property bool live: true", CORE)
        self.assertIn("ring.live && index < ring.value * ring.segments", CORE)
        self.assertIn("coreMissingAlpha", THEME)
        # the grey mark: the zero segment is drawn from the missing colour, not gold
        self.assertIn("core.theme.coreMissingAlpha", CORE)

    def test_the_standing_mark_is_the_core(self):
        # the arch glyph is gone on request: the centre is the core, and the
        # fallback keeps its object name (the "no mark yet" state) but draws nothing
        self.assertIn('objectName:"logoFallback"', WIDGET)
        self.assertNotIn("arch-mark.svg", WIDGET)
        self.assertNotIn("arch_mark_svg", ARTWORK)
        # the 3-D sprite it replaced is gone from the payload, not just unused
        self.assertNotIn("centre-orb.png", WIDGET)
        self.assertFalse((NATIVE / "ArcaneOrb.qml").is_file())


class SpellTests(unittest.TestCase):
    def test_the_spell_ramps_once_from_zero_to_one(self):
        self.assertIn("property real activation: 0", WIDGET)
        self.assertIn('NumberAnimation { target:root; property:"activation"; from:0; to:1', WIDGET)
        self.assertIn("function castSpell()", WIDGET)

    def test_low_power_skips_the_ceremony(self):
        self.assertIn("if(root.lowPower) { ignition.stop();root.activation=1;return; }", WIDGET)

    def test_hiding_the_dashboard_resets_and_freezes_it(self):
        self.assertIn("else { ignition.stop();root.activation=0; }", WIDGET)
        self.assertIn("activation: root.activation", WIDGET)
        self.assertIn("animated: !root.paused && root.sphereVisible", WIDGET)

    def test_the_ring_has_all_five_phases(self):
        # dormant, ignition, formation, activated, interaction
        self.assertIn("readonly property real charge", RING)
        self.assertIn("arcPath(1.0", RING)                    # the ignition head
        self.assertIn("rayGain", RING)                        # per-gem light
        self.assertIn("gemGain", RING)                        # hover reach

    def test_hover_reaches_the_geometry(self):
        # the lit gem brightens its bridge and its rune station
        self.assertIn("glow: (0.35 + 0.65 * ring.gemGain(bridge.index)) * ring.charge", RING)
        self.assertIn("highlight:", RING)
        self.assertIn("ring.litIndex", RING)


class PerformanceTests(unittest.TestCase):
    def test_no_shaders_no_canvas_no_blur(self):
        # Flat rectangles, SVG assets and bindings: none of these are needed.
        for name in ("MagicRing.qml", "MagicGem.qml", "JarvisCore.qml", "EnergyLine.qml",
                     "RuneRing.qml", "Spark.qml", "Theme.qml"):
            text = (NATIVE / name).read_text()
            for banned in ("Canvas", "ShaderEffect", "shadowBlur", "FastBlur", "GaussianBlur",
                           "layer.enabled: true"):
                self.assertNotIn(banned, text, f"{name} uses {banned}")

    def test_the_one_canvas_left_paints_once_per_mark_not_per_frame(self):
        # LOGO_TINT used to be a MultiEffect — an import of QtQuick.Effects, which a
        # bare Qt Quick install does not have; its absence stopped the whole widget
        # from loading. The replacement may not reintroduce a per-frame canvas.
        self.assertNotIn("QtQuick.Effects", WIDGET)
        self.assertNotIn("MultiEffect {", WIDGET)
        self.assertIn('objectName:"logoTint"', WIDGET)
        block = WIDGET.split('objectName:"logoTint"', 1)[1].split("\n            }", 2)[0]
        self.assertIn("renderTarget: Canvas.FramebufferObject", block)
        self.assertIn("renderStrategy: Canvas.Cooperative", block)
        tail = WIDGET.split('objectName:"logoTint"', 1)[1][:1200]
        self.assertIn("requestPaint", tail)             # repaint only on a new mark
        self.assertNotIn("Timer", tail)

    def test_everything_moving_reads_the_one_clock(self):
        for name, text in (("MagicRing.qml", RING), ("JarvisCore.qml", CORE),
                           ("MagicGem.qml", GEM), ("RuneRing.qml", RUNES)):
            self.assertNotIn("Timer {", text, f"{name} has a timer of its own")
            self.assertTrue("time" in text or "clock" in text, name)
        # and every animation there is bound to that clock, not to a running state
        for text in (RING, RUNES):
            self.assertIn("clock", text)
        # the core keeps no clock of its own in any step: its life is QML
        # animation, switched on and off by the one `animated` flag
        self.assertNotIn("Timer {", CORE)
        self.assertNotIn("aliveTime", CORE)

    def test_the_ring_never_rebuilds_a_gradient_per_frame(self):
        # the only per-frame geometry is the two short ignition arcs, and they
        # stop existing the moment the spell is fully cast
        self.assertEqual(RING.count("arcPath(1.0"), 2)
        self.assertGreaterEqual(RING.count("ring.charge < 0.999"), 2)


class MotionTests(unittest.TestCase):
    """Step four: the idle life of the core, and the one switch that stops it."""

    def test_every_motion_has_a_toggle_and_a_period(self):
        # no motion without a token to switch it off: the brief asks for all four
        for token in ("coreBreath", "coreBreathScale", "coreBreathMs",
                      "coreDrift", "coreDriftDeg", "coreDriftMsOuter",
                      "coreDriftMsMiddle", "coreDriftMsInner",
                      "coreSweep", "coreSweepMs"):
            self.assertIn(token, THEME, token)

    def test_nothing_moves_unless_the_widget_says_it_is_on_screen(self):
        self.assertIn("property bool animated: false", CORE)
        self.assertIn("animated: !root.paused && root.sphereVisible && !root.lowPower",
                      WIDGET)
        # three motions animate; the time dials are the fourth thing on the
        # core but they do not move — see test_the_time_dials_are_not_an_animation
        for toggle in ("coreBreath", "coreDrift", "coreSweep"):
            self.assertIn("running: core.animated && core.theme.%s" % toggle, CORE,
                          "%s is not gated" % toggle)

    def test_the_motion_is_qml_animation_not_a_frame_loop(self):
        for forbidden in ("Timer {", "onTriggered", "requestPaint", "aliveTime",
                          "Canvas {", "createObject"):
            self.assertNotIn(forbidden, CORE, forbidden)

    def test_the_sweep_is_a_generated_asset_not_a_gradient(self):
        # a conical gradient describes a radar sweep exactly and paints nothing
        # in this Qt (measured), so the cone is baked into an SVG
        self.assertIn("def core_sweep_svg", ARTWORK)
        self.assertTrue((NATIVE / "assets" / "core-sweep.svg").is_file())
        self.assertIn('source: Qt.resolvedUrl("assets/core-sweep.svg")', CORE)
        self.assertIn('objectName: "coreSweep"', CORE)
        self.assertIn("duration: core.theme.coreSweepMs", CORE)
        self.assertIn("from: 0; to: 360", CORE)
        self.assertNotIn("ConicalGradient {", CORE)
        sweep = (NATIVE / "assets" / "core-sweep.svg").read_text()
        self.assertIn('mask="url(#m)"', sweep)                    # the radial half
        self.assertEqual(sweep.count('stroke="#7ff0ff"'), 3)      # the rim, in three fades

    def test_the_breath_moves_the_orb_and_its_halo_together(self):
        holder = CORE.index('objectName: "coreOrbHolder"')
        halo = CORE.index('assets/core-halo.svg')
        orb = CORE.index('assets/core-orb.svg')
        scrim = CORE.index('objectName: "coreScrim"')
        self.assertLess(holder, halo)
        self.assertLess(halo, orb)              # the halo is behind the orb
        self.assertLess(orb, scrim)             # and the type sits over both
        self.assertIn("from: 1.0; to: 1.0 + core.theme.coreBreathScale", CORE)
        self.assertIn("duration: core.theme.coreBreathMs / 2", CORE)

    def test_the_three_rings_sway_on_three_clocks(self):
        for token in ("coreDriftMsOuter", "coreDriftMsMiddle", "coreDriftMsInner"):
            self.assertIn("swayMs: core.theme.%s" % token, CORE, token)
        self.assertIn("from: 0; to: core.theme.coreDriftDeg", CORE)
        self.assertIn("from: core.theme.coreDriftDeg; to: -core.theme.coreDriftDeg", CORE)

    # ── the time dials: 12 / 60 / 60 dots, one per unit ────────────────────
    def test_three_dials_with_twelve_sixty_and_sixty_dots(self):
        # every count, radius, size and alpha is a Theme token
        for token in ("coreDials", "coreDialFill", "coreDialHours", "coreDialMinutes",
                      "coreDialSeconds", "coreDialHoursRadius", "coreDialMinutesRadius",
                      "coreDialSecondsRadius", "coreDialHourDot", "coreDialHourNow",
                      "coreDialMinuteDot", "coreDialMinuteNow", "coreDialSecondDot",
                      "coreDialSecondNow", "coreDialColor", "coreDialAccent",
                      "coreDialNow", "coreDialDimAlpha", "coreDialPastAlpha",
                      "coreDialNowAlpha", "coreDialNowRing", "coreDialRingColor"):
            self.assertIn(token, THEME, token)
        for name in ("dialHours", "dialMinutes", "dialSeconds"):
            self.assertIn('objectName: "%s"' % name, CORE, name)
        self.assertIn("count: core.theme.coreDialHours", CORE)
        self.assertIn("count: core.theme.coreDialMinutes", CORE)
        self.assertIn("count: core.theme.coreDialSeconds", CORE)

    def test_hours_sit_closest_to_the_orb_and_seconds_outside(self):
        # the order is the brief: hour innermost, then minute, then second
        import re
        theme = THEME
        radius = lambda name: float(re.search(
            r"coreDial%sRadius: ([\d.]+)" % name, theme).group(1))
        self.assertLess(radius("Hours"), radius("Minutes"))
        self.assertLess(radius("Minutes"), radius("Seconds"))
        self.assertGreater(radius("Hours"), 0.36)      # outside the orb itself

    def test_each_hand_is_driven_by_its_own_number(self):
        import re
        body = CORE[CORE.index("Dial {"):]
        self.assertIn("current: core.hours % core.theme.coreDialHours", body)
        self.assertIn("current: core.minutes", body)
        self.assertIn("current: core.seconds", body)

    def test_the_lit_dot_is_the_hand_and_the_rest_are_dim(self):
        box = CORE[CORE.index("    component Dial:"):]
        self.assertIn("readonly property bool lit: index === dial.current", box)
        self.assertIn("readonly property bool past: !lit && index < dial.current", box)
        self.assertIn("core.theme.coreDialFill", box)          # fill vs marker
        self.assertIn("border.width: lit ?", box)               # the dark ring
        # a dot is a Rectangle; there is no path geometry to rebuild
        self.assertNotIn("ShapePath", box)

    def test_the_time_dials_are_not_an_animation(self):
        # a dot jumps one place per unit, so nothing has to be paused, and the
        # core keeps its "no timer, no frame loop" guarantee
        box = CORE[CORE.index("    component Dial:"):CORE.index("    component Ring:")]
        for forbidden in ("RotationAnimation", "NumberAnimation", "Timer {",
                          "Behavior on", "requestPaint"):
            self.assertNotIn(forbidden, box, forbidden)

    def test_the_dials_can_be_switched_off(self):
        self.assertIn("visible: core.theme.coreDials",
                      CORE[CORE.index("    component Dial:"):])


class PreservedTests(unittest.TestCase):
    """Nothing about behaviour moved. If one of these fails, the upgrade broke it."""

    def test_five_gems_five_panels_and_the_same_hover_model(self):
        self.assertIn('property string activePanel: ""', WIDGET)
        self.assertIn("readonly property int hoverIntentMs: 70", WIDGET)
        self.assertIn("readonly property int leaveGraceMs: 280", WIDGET)
        self.assertIn("readonly property bool pinOnClick: true", WIDGET)
        self.assertEqual(WIDGET.count('{ panel:"'), 5)

    def test_the_ring_container_is_still_created_once_and_never_resized(self):
        self.assertEqual(WIDGET.count("MagicRing {"), 1)
        self.assertIn("radius: root.ringR", WIDGET)

    def test_the_shared_frame_is_still_the_only_panel_shell(self):
        self.assertEqual(WIDGET.count("PanelFrame {"), 5)
        self.assertIn("hosted:true", WIDGET.replace(" ", ""))

    def test_the_installer_ships_the_new_files(self):
        import sys
        sys.path.insert(0, str(REPO))
        from installer.constants import NATIVE_FILES
        for name in ("Theme.qml", "EnergyLine.qml", "RuneRing.qml", "Spark.qml",
                     "JarvisCore.qml", "SysStats.qml",
                     "assets/core-orb.svg", "assets/core-halo.svg", "assets/core-scrim.svg",
                     "assets/core-sweep.svg",
                     "assets/spark.svg", "assets/atmosphere.svg",
                     "assets/liquid-torus-body.svg", "assets/liquid-torus-glaze.svg",
                     "assets/liquid-lens.svg", "assets/gem-liquid-dome.svg", "assets/visionos-dial-scale.svg", "assets/visionos-astro-web.svg", "assets/visionos-dome-collar.svg", "assets/visionos-ufo-cone.svg", "assets/visionos-ufo-pool.svg", "assets/gem-aurora-swirl.svg", "assets/core-orb-swirl.svg"):
            self.assertIn(name, NATIVE_FILES)
        self.assertIn("assets/rune-31.svg", NATIVE_FILES)
        self.assertIn("assets/sigils/sigil-05.svg", NATIVE_FILES)
        # and what the core replaced is no longer shipped
        for gone in ("ArcaneOrb.qml", "assets/centre-orb.png"):
            self.assertNotIn(gone, NATIVE_FILES)


if __name__ == "__main__":
    unittest.main()
