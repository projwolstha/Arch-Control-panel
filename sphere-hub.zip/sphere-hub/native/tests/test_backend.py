"""Dependency-free tests. No real desktop programs, terminals or installers run."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("sphere_backend", ROOT/"backend.py")
b = importlib.util.module_from_spec(spec);spec.loader.exec_module(b)

# backend.py is a shim; the implementation lives in the adapter package, and each
# module looks helpers up in its own namespace. Stub them where they are used.
import sphere_adapter.bridge as adapter_bridge
import sphere_adapter.install as adapter_install
import sphere_adapter.system as adapter_system
import sphere_adapter.terminal as adapter_terminal
ADAPTER_MODULES = (adapter_bridge, adapter_install, adapter_system, adapter_terminal)


def patch_adapter(name, **kwargs):
    """Patch a helper in every adapter module that imported it (like the old monolith)."""
    stack = contextlib.ExitStack()
    for module in ADAPTER_MODULES:
        if hasattr(module, name):
            stack.enter_context(patch.object(module, name, **kwargs))
    return stack


def desktop(folder, name, text):
    path=folder/"applications"/name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text("[Desktop Entry]\nType=Application\n"+text)
    return path


class UpgradePruneTests(unittest.TestCase):
    """An upgrade must not leave the previous dashboard's files behind.

    6.16.0 shipped MainOrb.qml, SphereFlow.js, a baked glass shader and the sphere
    artwork into the same directory 6.17.0 deploys into. The deploy merges into
    that directory, so without an explicit prune those files survive the swap —
    and the shipped tests, which assert they are gone, then fail the install and
    roll it back. That is exactly what happened the first time this build was run
    over a 6.16 install.
    """

    def setUp(self):
        self.deploy = ROOT.parent / "installer" / "ops" / "deploy.py"
        if not self.deploy.is_file():
            self.skipTest("installer sources are repo-only")

    def test_the_retired_files_are_named(self):
        source = self.deploy.read_text()
        for name in ("MainOrb.qml", "SphereFlow.js", "shaders/glass.frag",
                     "shaders/glass.frag.qsb", "assets/sphere-artwork.png"):
            self.assertIn('"'+name+'"', source, name)

    def test_the_prune_is_the_previous_manifest_plus_the_legacy_list(self):
        source = self.deploy.read_text()
        self.assertIn("stale = (previous | set(LEGACY_NATIVE_FILES)) - set(NATIVE_FILES)", source)
        # …and a directory that only held removed files goes too, or the empty
        # `shaders/` would still make `(ROOT/"shaders").exists()` true.
        self.assertIn("parent.rmdir()", source)
        # the previous inventory is read from the manifest this directory carries
        self.assertIn('manifest = self.p.config/"sphere-package.json"', source)


class RenderCapabilityTests(unittest.TestCase):
    """What the adapter tells the UI about how it is drawn.

    The glass shader and its Canvas fallback went with the old orb. The ring is
    pre-rendered SVG plus QML shapes, so the report is a constant — but it stays
    in the snapshot, because `sphere-setup status` and older readers parse it.
    """

    def test_the_report_describes_the_ring_not_a_shader(self):
        self.assertEqual(adapter_bridge.render_capability(),
                         {"renderer": "svg-shapes", "shader": False, "reason": "not-used"})

    def test_no_shader_binary_is_shipped_any_more(self):
        self.assertFalse((ROOT / "shaders").exists())
        self.assertFalse((ROOT / "MainOrb.qml").exists())
        self.assertFalse((ROOT / "SphereFlow.js").exists())

    def test_the_snapshot_still_carries_the_key(self):
        import inspect
        source = inspect.getsource(adapter_bridge)
        self.assertIn('"render":render_capability()', source)


class NativeBackendTests(unittest.TestCase):
    def test_window_class_matches_its_exact_desktop_entry_first(self):
        c = b.DesktopCatalog()
        c.entries = {
            "foot-server.desktop": {"id": "foot-server.desktop", "classes": {"foot-server", "foot"}},
            "foot.desktop": {"id": "foot.desktop", "classes": {"foot"}},
        }
        self.assertEqual(c.match_client({"class": "foot"}), "foot.desktop")
        self.assertEqual(c.match_client({"class": "foot-server"}), "foot-server.desktop")
        self.assertEqual(c.match_client({"class": ""}), None)

    def test_broken_desktop_file_never_hides_good_apps(self):
        # A malformed/corrupt .desktop file must never empty the whole picker.
        (self.user/"applications"/"broken.desktop").write_text("this is not ini at all\n[no section header above\n")
        (self.user/"applications"/"trailing-junk.desktop").write_text("Name=NoSection\n")
        self.catalog.refresh()
        ids = set(self.catalog.entries)
        self.assertIn("firefox.desktop", ids)
        self.assertIn("kitty.desktop", ids)
        self.assertGreaterEqual(self.catalog.scan_report["files"], 4)

    def test_icon_index_resolves_theme_icons_in_one_pass(self):
        icon = self.system/"icons"/"hicolor"/"scalable"/"apps"
        icon.mkdir(parents=True, exist_ok=True)
        (icon/"firefox.svg").write_text("<svg/>")
        self.catalog = b.DesktopCatalog([self.user, self.system])
        uri = self.catalog.icon_url("firefox")
        self.assertTrue(uri.startswith("file://") and uri.endswith("firefox.svg"), uri)
        self.assertEqual(self.catalog.icon_url("firefox.svg"), uri)
        self.assertEqual(self.catalog.icon_url(""), "")

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.user=self.root/"user";self.system=self.root/"system"
        desktop(self.user,"firefox.desktop","Name=Firefox\nExec=firefox %U\nStartupWMClass=firefox\n")
        desktop(self.system,"kitty.desktop","Name=Kitty\nExec=kitty\nStartupWMClass=kitty\n")
        self.env=patch.dict(os.environ,{"LANG":"en_US.UTF-8","XDG_CURRENT_DESKTOP":"Hyprland"});self.env.start();self.addCleanup(self.env.stop)
        self.catalog=b.DesktopCatalog([self.user,self.system])
        self.spawn=Mock()
        self.bridge=b.Bridge(self.catalog,b.ConfigStore(self.root/"settings"/"state.json"),popen=self.spawn)
        self.info={"managers":["apt","flatpak","pacman","dnf","zypper","apk"],"preferredManager":"apt","terminal":"kitty","distribution":"Test Linux","distributionId":"debian"}

    def assign(self,slot,app):
        return self.bridge.request({"action":"assign","slot":slot,"target":{"kind":"desktop","id":app}})

    def test_eight_empty_native_slots(self):
        snap=self.bridge.snapshot();self.assertEqual(snap["slots"],[None]*8)
        self.assertEqual({a["id"] for a in snap["apps"]},{"firefox.desktop","kitty.desktop"})

    def test_fixed_slot_persistence(self):
        self.assign(5,"firefox.desktop");self.assign(1,"kitty.desktop")
        saved=b.ConfigStore(self.bridge.store.path)
        self.assertEqual(saved.data["slots"],self.bridge.store.data["slots"])
        self.assertIsNone(saved.data["slots"][0]);self.assertEqual(saved.data["slots"][5]["id"],"firefox.desktop")
        self.assertEqual(self.bridge.store.path.stat().st_mode & 0o777,0o600)
        before=json.loads(json.dumps(self.bridge.store.data))
        with patch.object(self.bridge.store,"save",side_effect=PermissionError("Test read-only config")):
            with self.assertRaises(PermissionError):self.assign(2,"kitty.desktop")
        self.assertEqual(self.bridge.store.data,before)

    def test_assigning_existing_app_swaps_only_those_two_slots(self):
        self.assign(0,"firefox.desktop");self.assign(6,"kitty.desktop")
        self.assign(0,"kitty.desktop")
        slots=self.bridge.store.data["slots"]
        self.assertEqual(slots[6]["id"],"firefox.desktop");self.assertEqual(slots[0]["id"],"kitty.desktop")
        self.assertTrue(all(slots[i] is None for i in (1,2,3,4,5,7)))

    def test_clear_only_one_slot(self):
        self.assign(1,"kitty.desktop");self.assign(2,"firefox.desktop")
        self.bridge.request({"action":"clear","slot":1})
        self.assertIsNone(self.bridge.store.data["slots"][1]);self.assertEqual(self.bridge.store.data["slots"][2]["id"],"firefox.desktop")

    def test_invalid_slot_and_arbitrary_shell_rejected(self):
        for value in (-1,8,True,"0"):
            with self.assertRaises(ValueError):self.bridge.request({"action":"clear","slot":value})
        for action in ("shell","exec","eval","installSilent"):
            with self.assertRaises(ValueError):self.bridge.request({"action":action,"command":"touch /tmp/should-not-exist"})
        self.spawn.assert_not_called()

    def test_uninstalled_id_cannot_be_launched_or_assigned_as_installed(self):
        with self.assertRaises(ValueError):self.assign(0,"missing.desktop")
        self.bridge.request({"action":"assign","slot":0,"target":{"kind":"recipe","id":"vlc"}})
        with self.assertRaises(ValueError):self.bridge.request({"action":"launch","slot":0})
        self.spawn.assert_not_called()

    def test_recipe_becomes_installed_only_after_desktop_discovery(self):
        self.bridge.request({"action":"assign","slot":4,"target":{"kind":"recipe","id":"vlc"}})
        self.assertFalse(self.bridge.snapshot()["slotApps"][4]["installed"])
        desktop(self.user,"vlc.desktop","Name=VLC media player\nExec=vlc %U\n")
        result=self.bridge.snapshot(refresh=True)
        self.assertTrue(result["slotApps"][4]["installed"]);self.assertEqual(result["slots"][4],{"kind":"recipe","id":"vlc"})
        (self.user/"applications/firefox.desktop").unlink()
        desktop(self.user,"firefox-esr.desktop","Name=Firefox ESR\nExec=firefox-esr %U\n")
        self.bridge.snapshot(refresh=True)
        result=self.bridge.request({"action":"assign","slot":5,"target":{"kind":"recipe","id":"firefox"}})
        self.assertTrue(result["slotApps"][5]["installed"]);self.assertEqual(result["slotApps"][5]["id"],"firefox-esr.desktop")

    def test_hidden_override_no_display_and_desktop_filters(self):
        desktop(self.user,"kitty.desktop","Name=Hidden user override\nHidden=true\nExec=kitty\n")
        desktop(self.system,"hidden.desktop","Name=Hidden\nNoDisplay=true\nExec=hidden\n")
        desktop(self.system,"kde-only.desktop","Name=KDE only\nOnlyShowIn=KDE;\nExec=true\n")
        desktop(self.system,"not-hypr.desktop","Name=Not here\nNotShowIn=Hyprland;\nExec=true\n")
        self.catalog.refresh();self.assertEqual(list(self.catalog.entries),["firefox.desktop"])

    def test_try_exec_and_localized_name(self):
        desktop(self.system,"missing.desktop","Name=Missing\nExec=missing\nTryExec=/not/a/real/binary\n")
        desktop(self.user,"localized.desktop","Name=Default\nName[en_US]=Localized\nExec=true\n")
        self.catalog.refresh();self.assertNotIn("missing.desktop",self.catalog.entries);self.assertEqual(self.catalog.entries["localized.desktop"]["name"],"Localized")

    def test_theme_icon_local_url(self):
        path=self.user/"icons/hicolor/scalable/apps/test-icon.svg";path.parent.mkdir(parents=True);path.write_text('<svg xmlns="http://www.w3.org/2000/svg"/>')
        self.assertEqual(self.catalog.icon_url("test-icon"),path.resolve().as_uri())

    def test_matching_desktop_ids_and_wm_classes(self):
        self.assertEqual(self.catalog.match_client({"class":"firefox"}),"firefox.desktop")
        self.assertEqual(self.catalog.match_client({"class":"org.mozilla.firefox"}),"firefox.desktop")
        self.assertEqual(self.catalog.match_client({"initialClass":"kitty"}),"kitty.desktop")
        self.assertIsNone(self.catalog.match_client({"class":"not-an-assigned-app"}))

    def test_gio_launch_uses_argv_not_shell(self):
        self.assign(0,"firefox.desktop")
        with patch_adapter("hypr_command",side_effect=OSError),patch.object(b.shutil,"which",return_value="/usr/bin/gio"):
            result=self.bridge.request({"action":"launch","slot":0})
        self.assertTrue(result["launched"]);args,kw=self.spawn.call_args
        self.assertEqual(args[0],["gio","launch",self.catalog.entries["firefox.desktop"]["path"]]);self.assertNotIn("shell",kw)

    def test_existing_window_focused_without_second_launch(self):
        self.assign(0,"firefox.desktop");seen=[]
        def ipc(command):
            seen.append(command)
            if command=="j/clients":return json.dumps([{"class":"firefox","address":"0x123abc","focusHistoryID":0}])
            if command=="j/activewindow":return "{}"
            return "ok"
        with patch_adapter("hypr_command",side_effect=ipc):result=self.bridge.request({"action":"launch","slot":0})
        self.assertTrue(result["focusedExisting"]);self.assertIn("dispatch focuswindow address:0x123abc",seen);self.spawn.assert_not_called()

    def test_hyprland_055_lua_dispatcher_fallback_is_safe(self):
        self.assign(0,"firefox.desktop");seen=[]
        def ipc(command):
            seen.append(command)
            if command=="j/clients":return json.dumps([{"class":"firefox","address":"0x123abc"}])
            if command=="j/activewindow":return "{}"
            if command.startswith("dispatch focuswindow"):return "Invalid dispatcher"
            return "ok"
        with patch_adapter("hypr_command",side_effect=ipc):result=self.bridge.request({"action":"launch","slot":0})
        self.assertTrue(result["focusedExisting"])
        self.assertIn('dispatch hl.dsp.focus({ window = "address:0x123abc" })',seen)
        self.spawn.assert_not_called()

    def test_widget_qt_overrides_are_not_leaked_to_desktop_apps(self):
        with patch.dict(b.os.environ,{"QT_QPA_PLATFORM":"wayland","SPHERE_SAVED_QT_QPA_PLATFORM":"xcb","QT_QUICK_CONTROLS_STYLE":"Basic","SPHERE_SAVED_QT_QUICK_CONTROLS_STYLE":"__SPHERE_UNSET__"}):
            result=b.desktop_environment()
        self.assertEqual(result["QT_QPA_PLATFORM"],"xcb")
        self.assertNotIn("QT_QUICK_CONTROLS_STYLE",result)
        self.assertNotIn("SPHERE_SAVED_QT_QPA_PLATFORM",result)

    def test_workspace_focus_updates_never_write_or_reorder_slots(self):
        self.assign(3,"firefox.desktop");before=self.bridge.store.path.read_bytes()
        with patch_adapter("hypr_command",side_effect=[json.dumps([{"class":"firefox","address":"0x12"}]),json.dumps({"class":"firefox","address":"0x12"}),"[]","{}"]):
            first=self.bridge.status();second=self.bridge.status()
        self.assertEqual(first["activeDesktopId"],"firefox.desktop");self.assertFalse(second["activeDesktopId"])
        self.assertEqual(self.bridge.store.path.read_bytes(),before)

    def test_safe_exec_expansion_preserves_quoted_argument(self):
        entry={"argv":["program","literal ; $(touch nope)","%U","%c","%k","100%%"],"name":"Test app","path":"/tmp/Test app.desktop"}
        self.assertEqual(b.expand_exec(entry),["program","literal ; $(touch nope)","Test app","/tmp/Test app.desktop","100%"])

    def test_package_plans_are_reviewable_and_never_unattended(self):
        for manager in self.info["managers"]:
            plan=b.install_plan(package="safe-package",manager=manager,info=self.info)
            self.assertNotIn("-y",plan["argv"]);self.assertNotIn("--noconfirm",plan["argv"])
            self.assertNotIn("sh",plan["argv"]);self.assertIn("safe-package",plan["argv"])
        self.assertEqual(b.install_plan("vlc",manager="apt",info=self.info)["argv"],["sudo","apt","install","vlc"])
        self.assertEqual(b.install_plan("firefox",manager="flatpak",info=self.info)["package"],"org.mozilla.firefox")
        self.assertEqual(b.install_plan("firefox",manager="apt",info={**self.info,"distributionId":"ubuntu"})["package"],"firefox")
        self.assertEqual(b.install_plan("firefox",manager="apt",info=self.info)["package"],"firefox-esr")

    def test_malicious_package_inputs_rejected(self):
        for value in ("-y","pkg;reboot","pkg && echo hi","$(reboot)","a b","/tmp/script","https://example.org/x","",None):
            with self.assertRaises(ValueError,msg=repr(value)):b.install_plan(package=value,manager="apt",info=self.info)
        with self.assertRaises(ValueError):b.install_plan(package="test",manager="bash",info=self.info)

    def test_recipe_without_mapping_does_not_add_repository(self):
        with self.assertRaisesRegex(ValueError,"No verified package mapping"):b.install_plan("code",manager="apt",info=self.info)
        self.spawn.assert_not_called()

    def test_install_requires_ui_confirmation_then_only_opens_terminal(self):
        request={"action":"install","recipeId":"vlc","manager":"apt"}
        with patch_adapter("system_info",return_value=self.info),patch_adapter("detect_terminal",return_value=["kitty"]):
            with self.assertRaises(ValueError):self.bridge.request(request)
            self.spawn.assert_not_called()
            result=self.bridge.request({**request,"confirmed":True})
        command=self.spawn.call_args.args[0]
        self.assertEqual(command[0],"kitty");self.assertIn("install",command);self.assertIn("--package",command);self.assertNotIn("sudo",command)
        self.assertFalse(result["installed"])

    def test_no_terminal_cannot_claim_an_install_happened(self):
        with patch_adapter("system_info",return_value={**self.info,"terminal":""}),patch_adapter("detect_terminal",return_value=[]):
            result=self.bridge.request({"action":"previewInstall","recipeId":"vlc","manager":"apt"})
            self.assertFalse(result["terminalAvailable"])
            with self.assertRaises(ValueError):self.bridge.request({"action":"install","recipeId":"vlc","manager":"apt","confirmed":True})
        self.spawn.assert_not_called()

    def test_terminal_argv_supports_multiple_emulators_without_shell(self):
        for terminal in b.TERMINALS:
            with patch_adapter("detect_terminal",return_value=[terminal]):
                argv=b.terminal_argv(["python3","/space in path/backend.py","install"])
                self.assertEqual(argv[0],terminal);self.assertIn("/space in path/backend.py",argv);self.assertNotIn("sh",argv)

    def test_non_tty_installer_refuses_to_run(self):
        args=type("Args",(),{"package":"vlc","manager":"apt"})()
        with patch_adapter("system_info",return_value=self.info),patch.object(b.sys.stdin,"isatty",return_value=False),patch.object(b.subprocess,"run") as run,contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(b.installer_cli(args),2);run.assert_not_called()

    def test_terminal_cancel_and_exact_typed_confirmation(self):
        args=type("Args",(),{"package":"vlc","manager":"apt"})()
        for answer in ("","yes","install","INSTALL "):
            with patch_adapter("system_info",return_value=self.info),patch.object(b.sys.stdin,"isatty",return_value=True),patch("builtins.input",return_value=answer),patch.object(b.subprocess,"run") as run,contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(b.installer_cli(args),0);run.assert_not_called()
        with patch_adapter("system_info",return_value=self.info),patch.object(b.sys.stdin,"isatty",return_value=True),patch("builtins.input",side_effect=["INSTALL",""]),patch.object(b.subprocess,"run",return_value=Mock(returncode=0)) as run,contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(b.installer_cli(args),0);self.assertEqual(run.call_args.args[0],["sudo","apt","install","vlc"]);self.assertFalse(run.call_args.kwargs["shell"])

    def test_preferences_saved_and_clamped(self):
        result=self.bridge.request({"action":"preferences","values":{"screenName":"DP-1","orbitLocked":True,"rotationSeconds":999}})
        self.assertTrue(result["preferences"]["orbitLocked"]);self.assertEqual(result["preferences"]["rotationSeconds"],180)
        self.assertEqual(b.ConfigStore(self.bridge.store.path).data["preferences"]["screenName"],"DP-1")

    def test_corrupt_config_falls_back_to_safe_eight_slots(self):
        path=self.root/"corrupt.json";path.write_text("not JSON")
        self.assertEqual(b.ConfigStore(path).data["slots"],[None]*8)
        path.write_text(json.dumps({"slots":[{"kind":"desktop","id":[]},"oops",None]*4}))
        self.assertEqual(b.ConfigStore(path).data["slots"],[None]*8)

    def test_real_unix_socket_transport_with_fake_compositor(self):
        runtime=self.root/"run";folder=runtime/"hypr/test-instance";folder.mkdir(parents=True)
        server=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);server.bind(str(folder/".socket.sock"));server.listen(1)
        received=[]
        def respond():
            connection,_=server.accept()
            with connection:received.append(connection.recv(1024));connection.sendall(b'{"class":"firefox"}')
            server.close()
        thread=threading.Thread(target=respond,daemon=True);thread.start()
        with patch.dict(os.environ,{"XDG_RUNTIME_DIR":str(runtime),"HYPRLAND_INSTANCE_SIGNATURE":"test-instance"}):
            self.assertEqual(json.loads(b.hypr_command("j/activewindow"))["class"],"firefox")
        thread.join(2);self.assertFalse(thread.is_alive());self.assertEqual(received,[b"j/activewindow"])

    def test_stdio_protocol_eof_and_error_handling(self):
        environment={**os.environ,"XDG_DATA_HOME":str(self.user),"XDG_DATA_DIRS":str(self.system),"HYPRLAND_INSTANCE_SIGNATURE":""}
        payload='\n'.join((json.dumps({"action":"snapshot","requestId":1}),json.dumps({"action":"exec","requestId":2}),"not-json"))+"\n"
        result=subprocess.run([sys.executable,str(ROOT/"backend.py"),"serve","--config",str(self.root/"stdio.json")],input=payload,capture_output=True,text=True,env=environment,timeout=5)
        self.assertEqual(result.returncode,0,result.stderr)
        messages=[json.loads(line) for line in result.stdout.splitlines()]
        self.assertEqual(messages[0]["type"],"snapshot")
        responses=[m for m in messages if m["type"]=="response"]
        self.assertTrue(responses[0]["ok"]);self.assertFalse(responses[1]["ok"]);self.assertFalse(responses[2]["ok"])


if __name__=="__main__":unittest.main(verbosity=2)
