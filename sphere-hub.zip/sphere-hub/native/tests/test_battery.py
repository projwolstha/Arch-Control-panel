"""Battery: the adapter's two sources, the bridge's actions, the panel and the
Arch preparation script.

Both data sources are exercised against fakes — a temporary /sys tree and a stub
`upower` — so these run on any machine, including one with no battery at all.
"""
import importlib
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

NATIVE = Path(__file__).resolve().parents[1]
WIDGET = (NATIVE / "SphereWidget.qml").read_text()
PANEL_FRAME = (NATIVE / "PanelFrame.qml").read_text()
SHELL = (NATIVE / "shell.qml").read_text()
ADAPTER = (NATIVE / "sphere_adapter" / "battery.py").read_text()
BRIDGE = (NATIVE / "sphere_adapter" / "bridge.py").read_text()
REPO = NATIVE.parent
PREP = REPO / "shell" / "battery-prep.sh"
# The installer source and shell/ live in the repo, not in the deployed payload:
# the config directory is copied by NATIVE_FILES alone. Checks that need them
# skip there instead of failing the install.
REPO_ONLY_TREE = (REPO / "installer").is_dir()

sys.path.insert(0, str(NATIVE))

UPOWER_STUB = textwrap.dedent('''\
    #!/bin/sh
    if [ "$1" = "-e" ]; then
        [ "${UP_MODE:-normal}" = "none" ] && exit 0
        echo "/org/freedesktop/UPower/devices/DisplayDevice"
        echo "/org/freedesktop/UPower/devices/battery_BAT0"
        exit 0
    fi
    if [ "$1" = "-i" ]; then
        cat <<INFO
      native-path:          BAT0
        state:               ${UP_STATE:-charging}
        energy:              31.2 Wh
        energy-full:         50.1 Wh
        energy-full-design:  60 Wh
        energy-rate:         20.4 W
        voltage:             12.1 V
        charge cycles:       214
        time to full:        1.1 hours
        percentage:          62%
        capacity:            83.5%
    INFO
        exit 0
    fi
    exit 0
''')

PROFILES_STUB = textwrap.dedent('''\
    #!/bin/sh
    case "$1" in
      get) echo "${PPD_CURRENT:-balanced}";;
      list) printf '  performance:\\n\\n* balanced:\\n\\n  power-saver:\\n';;
      set) echo "$2" > "${PPD_FILE}/set";;
    esac
    exit 0
''')

SYSFS = {
    "capacity": "85\n",
    "status": "Discharging\n",
    "energy_now": "25000000\n",
    "energy_full": "50000000\n",
    "energy_full_design": "60000000\n",
    "power_now": "8500000\n",
    "voltage_now": "11800000\n",
    "cycle_count": "214\n",
    "type": "Battery\n",
}


def battery_adapter():
    from sphere_adapter import battery
    return importlib.reload(battery)


class FakePower:
    """A temporary power-supply tree plus PATH stubs for upower/powerprofilesctl."""

    def __init__(self, sysfs=True, upower=True, mode="normal", state="charging"):
        self.sysfs, self.upower, self.mode, self.state = sysfs, upower, mode, state

    def __enter__(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.supply = root / "power_supply"
        self.supply.mkdir()
        self.bin = root / "bin"
        self.bin.mkdir()
        if self.sysfs:
            bat = self.supply / "BAT0"
            bat.mkdir()
            for name, body in SYSFS.items():
                (bat / name).write_text(body)
        if self.upower:
            path = self.bin / "upower"
            path.write_text(UPOWER_STUB)
            path.chmod(path.stat().st_mode | stat.S_IEXEC)
            profiles = self.bin / "powerprofilesctl"
            profiles.write_text(PROFILES_STUB)
            profiles.chmod(profiles.stat().st_mode | stat.S_IEXEC)
        self.saved = {key: os.environ.get(key) for key in ("PATH", "SPHERE_POWER_SUPPLY", "UP_MODE", "UP_STATE", "PPD_FILE")}
        os.environ["PATH"] = f"{self.bin}:{self.saved['PATH'] or '/usr/bin:/bin'}"
        os.environ["SPHERE_POWER_SUPPLY"] = str(self.supply)
        os.environ["UP_MODE"] = self.mode
        os.environ["UP_STATE"] = self.state
        os.environ["PPD_FILE"] = str(root)
        return self

    def __exit__(self, *exc):
        for key, value in self.saved.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        self.tmp.cleanup()
        return False


class AdapterTests(unittest.TestCase):
    def test_upower_is_the_preferred_source(self):
        with FakePower(upower=True):
            state = battery_adapter().status()
        self.assertEqual(state["source"], "upower")
        self.assertEqual(state["percent"], 62)
        self.assertEqual(state["state"], "charging")
        self.assertEqual(state["timeToFull"], 3960)     # "1.1 hours"
        self.assertAlmostEqual(state["watts"], 20.4)
        self.assertEqual(state["cycles"], 214)
        self.assertAlmostEqual(state["voltage"], 12.1)
        self.assertEqual(state["health"]["percent"], 84)   # capacity: 83.5 %
        self.assertTrue(state["present"])

    def test_sysfs_is_the_fallback_when_upower_is_missing(self):
        with FakePower(upower=False, sysfs=True):
            state = battery_adapter().status()
        self.assertEqual(state["source"], "sysfs")
        self.assertEqual(state["percent"], 85)
        self.assertEqual(state["state"], "discharging")
        self.assertAlmostEqual(state["watts"], 8.5)        # 8 500 000 µW
        self.assertAlmostEqual(state["voltage"], 11.8)     # 11 800 000 µV
        self.assertEqual(state["health"]["percent"], 83)   # 50 / 60 Wh
        self.assertGreater(state["timeToEmpty"], 0)

    def test_time_remaining_is_computed_when_the_driver_has_none(self):
        with FakePower(upower=False):
            state = battery_adapter().status()
        # 25 Wh left at 8.5 W ≈ 2.94 h
        self.assertAlmostEqual(state["timeToEmpty"] / 3600, 2.94, places=1)
        self.assertIsNone(state["timeToFull"])

    def test_no_battery_at_all_is_one_plain_sentence(self):
        with FakePower(sysfs=False, upower=True, mode="none"):
            state = battery_adapter().status()
        self.assertFalse(state["present"])
        self.assertFalse(state["available"])
        self.assertEqual(state["error"], "No battery detected.")
        self.assertIsNone(state["percent"])

    def test_missing_sysfs_tree_does_not_raise(self):
        with FakePower(sysfs=False, upower=False):
            state = battery_adapter().status()
        self.assertFalse(state["present"])
        self.assertEqual(state["error"], "No battery detected.")

    def test_every_field_may_be_null(self):
        with FakePower(sysfs=False, upower=False):
            # a battery that reports a percentage and nothing else
            tmp = tempfile.TemporaryDirectory()
            root = Path(tmp.name)
            bat = root / "BAT1"
            bat.mkdir()
            (bat / "capacity").write_text("44\n")
            (bat / "status").write_text("Discharging\n")
            os.environ["SPHERE_POWER_SUPPLY"] = str(root)
            state = battery_adapter().status()
            tmp.cleanup()
        self.assertEqual(state["percent"], 44)
        for key in ("cycles", "voltage"):
            self.assertIsNone(state[key])
        self.assertIsNone(state["health"]["percent"])

    def test_profiles_are_reported_and_settable(self):
        with FakePower():
            module = battery_adapter()
            state = module.status()
            self.assertEqual(state["profile"], "balanced")
            self.assertEqual(state["profiles"], ["power-saver", "balanced", "performance"])
            with self.assertRaises(ValueError):
                module.set_profile("turbo")
            module.set_profile("performance")

    def test_watts_are_never_negative(self):
        with FakePower(upower=True):
            state = battery_adapter().status()
        self.assertGreaterEqual(state["watts"], 0)


class BridgeSyncTests(unittest.TestCase):
    def test_the_qml_request_names_match_the_bridge(self):
        self.assertIn('action:"battery"', WIDGET)
        self.assertIn('action:"batteryProfile"', WIDGET)
        self.assertIn('"battery"', BRIDGE)
        self.assertIn('"batteryProfile"', BRIDGE)

    def test_the_bridge_answers_with_one_shape(self):
        from sphere_adapter.bridge import Bridge
        self.assertTrue(hasattr(Bridge, "battery_state"))
        self.assertRegex(BRIDGE, r'"type":\s*"battery"')

    def test_plug_and_unplug_are_pushed(self):
        self.assertIn("def watch_battery", BRIDGE)
        self.assertIn("upower\", \"--monitor", BRIDGE)
        self.assertIn("watch_battery", BRIDGE.split("def serve", 1)[1])
        # and a slow poll for machines where upower is absent
        self.assertIn("bridge.stop.wait(4)", BRIDGE)


class PanelTests(unittest.TestCase):
    """The battery panel is data on the shared frame (see test_panelframe.py)."""

    def panel(self):
        return WIDGET.split('key:"battery"', 1)[1].split("\n    }\n", 1)[0]

    def test_it_has_the_same_layers_as_the_other_two(self):
        # One frame, one set of layers — the parts keep their historical names
        # through the frame's `names` map, so health, doctor and every drill-down
        # that looked for them still find them.
        self.assertIn('id:batteryPanel;objectName:"batteryPanel";key:"battery"', WIDGET)
        self.assertIn('names:({ ring:"batteryRing", value:"batteryReadout", '
                      'stats:"batteryFacts", segments:"batteryProfiles" })', WIDGET)
        self.assertIn("PanelFrame {", WIDGET)
        panel = self.panel()
        for token in ("radius:root.orbRadius", "ring:root.batteryLevel>=0 ? root.batteryLevel/100 : -1",
                      "stats:root.batteryStats()", "segments:root.batterySegments()"):
            self.assertIn(token, panel)

    def test_every_size_is_derived_from_orbRadius(self):
        panel = self.panel()
        self.assertIn("radius:root.orbRadius", panel)
        self.assertNotRegex(panel, r"\b\d+(?:\.\d+)?\s*\*\s*root\.uiScale")
        # a panel carries no sizes at all any more: the frame's spacing and type
        # scales are the only ones in existence, and both are fractions of radius
        # (x/y/z say *where the panel sits*, which is the widget's business; the
        #  panel itself brings no size, no anchor, no spacing and no type size)
        layout = "\n".join(line for line in panel.splitlines()
                            if not line.strip().startswith("x:root.width/2"))
        for token in ("width:", "height:", "anchors.", "spacing:", "pixelSize:"):
            self.assertNotIn(token, layout)

    def test_the_copy_that_was_asked_for(self):
        for text in ('title:"BATTERY"', "No battery detected", '"on · "+root.batteryLevel+"%"',
                     'status:root.batteryPresent ? root.batteryLine() : ""'):
            self.assertIn(text, WIDGET)

    def test_the_status_line_is_on_percent(self):
        self.assertIn('("on · "+root.batteryLevel+"%")', WIDGET)
        # and the same number is the ring, the big readout and the ring's sweep
        self.assertIn('value:root.batteryLevel>=0 ? root.batteryLevel+"%" : "—"', WIDGET)
        self.assertIn("ring:root.batteryLevel>=0 ? root.batteryLevel/100 : -1", WIDGET)

    def test_the_ring_and_the_readout_exist(self):
        self.assertIn('ring:"batteryRing"', WIDGET)
        self.assertIn('value:"batteryReadout"', WIDGET)
        self.assertIn('ctx.beginPath(); ctx.arc(cx, cy, w / 2 - lw, -Math.PI / 2, '
                      '-Math.PI / 2 + Math.PI * 2 * shownRing);', PANEL_FRAME)

    def test_missing_numbers_are_hidden_not_printed(self):
        # A card exists only for a number the driver actually reported.
        stats = WIDGET.split("function batteryStats()", 1)[1].split("function ", 1)[0]
        for line in ("if(draw.length>0) out.push", "if(health.length>0) out.push",
                     "if(cycles.length>0) out.push", "if(volts.length>0 && !batteryPanel.compact)"):
            self.assertIn(line, stats)
        for text in (self.panel(), PANEL_FRAME):
            code = "\n".join(line.split("//", 1)[0] for line in text.splitlines())
            self.assertNotIn('"N/A"', code)
            self.assertNotIn('"?"', code)

    def test_the_state_colours_follow_the_charge(self):
        self.assertIn("batteryLevel<15", WIDGET)
        self.assertIn("batteryLevel<30", WIDGET)
        self.assertIn('"#FF7777"', WIDGET)
        self.assertIn('"#FFD36A"', WIDGET)
        self.assertIn('"#55F49A"', WIDGET)

    def test_the_gem_sits_third_on_the_ring_and_opens_the_panel(self):
        # third entry of the one ring table: WI-FI, BLUETOOTH, BATTERY, …
        spec = WIDGET.split("{ panel:\"battery\"", 1)[1].split("}", 1)[0]
        self.assertIn('label:"BATTERY"', spec)
        self.assertIn("color:theme.gemBattery", spec)   # the token, not a copy
        self.assertIn('glyph:"battery"', spec)
        self.assertIn('key:"battery"', WIDGET)          # the panel frame it opens

    def test_only_one_system_list_can_be_open(self):
        # There is exactly one panel state, so "close the others" is structural:
        # every opener sets the one key, and showPanel() retires whatever was there.
        for opener, key in (("function openWifi(", "wifi"),
                            ("function openBluetooth(", "bluetooth"),
                            ("function openBattery(", "battery")):
            body = WIDGET.split(opener, 1)[1].split("function ", 1)[0]
            self.assertIn('root.showPanel("%s", "api", true)' % key, body,
                          f"{opener} does not go through the one state machine")
        show = WIDGET.split("function showPanel(", 1)[1].split("function ", 1)[0]
        self.assertIn("root.retirePanel(previous);", show)
        clear = WIDGET.split("function clearPanel(", 1)[1].split("function ", 1)[0]
        # Exactly one writer each way, in the state machine and nowhere else.
        self.assertEqual(WIDGET.count("root.activePanel=key;"), 1)
        self.assertEqual(WIDGET.count('root.activePanel="";'), 1)
        self.assertIn('root.activePanel="";', clear)

    def test_escape_closes_the_power_panel(self):
        keys = WIDGET.split("Keys.onEscapePressed", 1)[1].split("signal dismissRequested", 1)[0]
        self.assertIn('else if(activePanel!=="") { clearPanel("escape")', keys)
        self.assertIn('readonly property bool batteryOpen: activePanel==="battery"', WIDGET)

    def test_there_is_no_picker_left_to_assign_it_from(self):
        # the app picker went with the orbs; nothing in the dashboard can
        # reassign a gem, so the battery panel cannot be overwritten by one
        self.assertNotIn("openEditor", WIDGET)
        self.assertNotIn("Assign app", WIDGET)

    def test_the_battery_never_reads_as_a_missing_panel(self):
        # present:false must fall through to the empty state, not to an error
        self.assertIn('emptyText:String(root.batteryError || "").length>0 ? root.batteryError '
                      ': "No battery detected"', WIDGET)
        self.assertIn('mode:root.batteryPresent ? "value" : "empty"', WIDGET)


@unittest.skipUnless(REPO_ONLY_TREE, "installer source is not part of the deployed payload")
class DeployInventoryTests(unittest.TestCase):
    """The payload carries every file, but deploy_native() copies NATIVE_FILES only."""

    def test_every_adapter_module_is_in_the_deploy_inventory(self):
        sys.path.insert(0, str(REPO))
        from installer.constants import ADAPTER_FILES
        adapter = NATIVE
        for path in sorted((adapter / "sphere_adapter").glob("*.py")):
            self.assertIn(path.name, ADAPTER_FILES,
                          f"{path.name} is imported by bridge.py but never deployed")

    def test_the_native_inventory_covers_what_the_shell_needs(self):
        sys.path.insert(0, str(REPO))
        from installer.constants import NATIVE_FILES
        for name in ("SphereWidget.qml", "MagicRing.qml", "MagicGem.qml", "shell.qml",
                     "sphere_adapter/battery.py"):
            self.assertIn(name, NATIVE_FILES)

    def test_the_arch_package_list_carries_the_power_stack(self):
        sys.path.insert(0, str(REPO))
        from installer.constants import RUNTIME_PACKAGES
        pacman = RUNTIME_PACKAGES["pacman"]
        self.assertIn("upower", pacman)
        self.assertIn("power-profiles-daemon", pacman)

    def test_the_doctor_reports_the_power_supply_without_failing(self):
        # A desktop with no battery must read as a fact, not a failure.
        sys.path.insert(0, str(REPO))
        from installer.ops.diagnose import DiagnoseMixin
        report = DiagnoseMixin.power_report()
        self.assertIn("detail", report)
        self.assertIsInstance(report["batteries"], list)
        self.assertTrue(report["detail"])


class TwinTests(unittest.TestCase):
    """The browser twin must show the same panel, with the same colour language.

    The twin is generated (``tools/preview.py``) from the same SVG sheets the
    widget ships, so these tests read the generated file — no duplication of
    the panel in two places by hand.
    """

    def twin(self):
        path = REPO.parent / "sphere-preview.html"
        if not path.is_file():
            self.skipTest("sphere-preview.html is not present next to the checkout")
        return path.read_text()

    def test_the_twin_is_generated_not_hand_edited(self):
        html = self.twin()
        self.assertIn('<meta name="generator" content="tools/preview.py">', html)
        self.assertIn("Sphere Hub 6.18.0", html)     # the twin tracks the widget

    def test_the_twin_carries_the_living_layer(self):
        # the 6.18 layers: energy rings, both rune circles, the core, the mark.
        # The layer ids are assigned in JS (energyHost.id = "energy"), so the file
        # carries the assignments and the CSS rules, not static attributes.
        html = self.twin()
        for marker in ('energyHost.id = "energy"', 'buildRuneRing("runeRingOuter"',
                       'buildRuneRing("runeRingInner"', 'core.id = "jarvisCore"'):
            self.assertIn(marker, html, marker)
        self.assertIn(".mid { stroke-opacity: .62; }", html)     # bloom/mid/core
        self.assertIn("@keyframes spinRev", html)                # counter-rotation
        self.assertIn('id="logoFallback"', html)                 # the standing mark
        # the core: the orb, its halo, and the three segmented rings
        self.assertIn('coreOrb.id = "coreOrb"', html)
        self.assertIn('coreHalo.id = "coreHalo"', html)
        self.assertIn('"coreOrb":', html)
        self.assertIn('"coreHalo":', html)
        for segments in ('segments: 48', 'segments: 36', 'segments: 24'):
            self.assertIn(segments, html)
        # the clock the widget draws on the orb, and its seconds arc
        self.assertIn('coreClock.id = "coreClock"', html)
        self.assertIn('coreSeconds.id = "coreSeconds"', html)
        self.assertIn('"coreScrim":', html)
        # and what it replaced is gone, not merely unused
        for gone in ('orbReflect.id', "centreOrb", '"refl":', "paintReflection"):
            self.assertNotIn(gone, html, gone)

    def test_the_twin_carries_the_same_gem_and_panel(self):
        html = self.twin()
        self.assertIn('panel: "battery"', html)
        self.assertIn('label: "BATTERY"', html)
        self.assertIn('color: "#ff3bd4"', html)          # the pink gem
        self.assertIn("function renderBattery", html)
        for profile in ("power-saver", "balanced", "performance"):
            self.assertIn(profile, html)

    def test_the_twin_uses_the_same_charge_colours(self):
        html = self.twin()
        for hex_code in ("#55F49A", "#FFD36A", "#FF7777", "#8496a8"):
            self.assertIn(hex_code, html)
        self.assertIn('b.state === "charging" || b.state === "full"', html)
        # crimson below 15, amber below 30 — the same two cuts as the widget
        self.assertIn("b.percent < 15", html)
        self.assertIn("b.percent < 30", html)

    def test_the_twin_deep_links_open_the_power_panel(self):
        html = self.twin()
        self.assertIn("panel=([a-z]+)", html)           # the #panel= parser
        self.assertIn('title: "BATTERY"', html)
        for state in ("charging", "low", "critical", "empty"):
            self.assertIn('"%s"' % state, html)

    def test_the_twin_never_prints_a_missing_number(self):
        # the panel formats through chargeAccent/percent, and an unknown read is
        # "empty" (the slate colour), never the string N/A
        html = self.twin()
        self.assertIn('"#8496a8"', html)
        self.assertIn("b.percent === null", html)
        self.assertNotIn('"N/A"', html)


@unittest.skipUnless(PREP.is_file(), "shell/battery-prep.sh is not part of the deployed payload")
class PreparationScriptTests(unittest.TestCase):
    text = PREP.read_text() if PREP.is_file() else ""

    def test_it_is_valid_posix_shell(self):
        result = subprocess.run(["sh", "-n"], input=self.text, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_it_installs_only_missing_packages(self):
        self.assertIn('pacman -Q "$1"', self.text)
        self.assertIn('"${BAT_ELEVATOR}" pacman -S --needed --noconfirm', self.text)
        self.assertNotIn("sudo pacman", self.text)
        self.assertIn("upower", self.text)
        self.assertIn("power-profiles-daemon", self.text)

    def test_it_starts_both_services(self):
        self.assertIn("systemctl enable --now", self.text)
        self.assertIn('bat_enable_service "$_svc"', self.text)
        self.assertIn('BAT_SERVICES_WANTED="upower power-profiles-daemon"', self.text)

    def test_a_missing_unit_is_reported_as_missing_not_as_a_failure(self):
        # Layered roots (Bedrock) can install upower without the running systemd
        # seeing its unit file; the script must say so and carry on.
        self.assertIn("bat_unit_known", self.text)
        self.assertIn("systemctl list-unit-files", self.text)
        self.assertIn("is not installed for the running systemd", self.text)
        self.assertIn("unit not installed (optional", self.text)

    def test_upower_not_answering_is_told_apart_from_no_battery(self):
        self.assertIn("the daemon is not answering", self.text)
        self.assertIn("sysfs has${BAT_DEVICES}", self.text)

    def test_it_checks_for_a_battery_and_continues_without_one(self):
        self.assertIn("/sys/class/power_supply", self.text)
        self.assertIn("No battery detected", self.text)
        self.assertNotIn("exit 1", self.text)

    def test_the_standalone_up3_script_embeds_this_preparation(self):
        up3 = REPO.parent / "up3.sh"
        if not up3.is_file():
            self.skipTest("up3.sh is not present next to the checkout")
        text = up3.read_text()
        self.assertIn("battery-prep", text.lower())
        # up3.sh is a shipped snapshot of an earlier build: once the payload
        # moves on it keeps the old bytes on purpose, because reissuing it under
        # the same name would hand a user who already ran it a different script.
        # Only a standalone that embeds today's source is checked for today's rules.
        if (REPO / "shell" / "battery-prep.sh").read_text() not in text:
            self.skipTest("up3.sh predates the current battery-prep.sh; not a freshness test")
        self.assertIn('"${BAT_ELEVATOR}" pacman -S --needed --noconfirm', text)
        self.assertNotIn("sudo pacman", text)
        self.assertIn("systemctl enable --now", text)

if __name__ == "__main__":
    unittest.main()
