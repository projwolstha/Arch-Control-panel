"""Bluetooth: the adapter's parsing, the bridge's action names, the panel's
geometry, and the Arch preparation script.

The adapter talks to bluetoothctl; here it talks to a stub with canned bluez
output, so these run on any machine (no adapter, no bluez, no root).
"""
import os
import re
import stat
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

NATIVE = Path(__file__).resolve().parents[1]
WIDGET = (NATIVE / "SphereWidget.qml").read_text()
PANEL_FRAME = (NATIVE / "PanelFrame.qml").read_text()
SHELL = (NATIVE / "shell.qml").read_text()
ADAPTER = (NATIVE / "sphere_adapter" / "bluetooth.py").read_text()
BRIDGE = (NATIVE / "sphere_adapter" / "bridge.py").read_text()
REPO = NATIVE.parent
PREP_PATH = REPO / "shell" / "bluetooth-prep.sh"
# Read lazily: deployed to ~/.config/quickshell the repo tree is not there, and a
# module-level read would abort the whole discovery run instead of that one test.
PREP = PREP_PATH.read_text() if PREP_PATH.is_file() else ""

sys.path.insert(0, str(NATIVE))

STUB = textwrap.dedent('''\
    #!/bin/sh
    # A canned bluez: BT_MODE=normal|noadapter|off|dup|noisy|slow|stderronly
    mode="${BT_MODE:-normal}"
    # power survives between calls so a toggle can be observed
    state="${BT_STATE:-/tmp/bt-stub-power}"
    [ -f "$state" ] && powered="$(cat "$state")" || powered="yes"
    # A scan is a real, slow process: that is what the panel's "Scanning…" tracks.
    if [ "$1" = "--timeout" ]; then
        sleep "${2:-1}"
        echo "Device DD:DD:DD:DD:DD:04 Speaker"
        exit 0
    fi
    # noisy: a healthy adapter that talks on stderr and exits non-zero.
    if [ "$mode" = "noisy" ]; then
        case "$1 $2" in
            "list "*) echo "Waiting to connect to bluetoothd..." >&2
                      echo "Controller 11:22:33:44:55:66 archbox [default]"
                      echo "Controller 99:99:99:99:99:99 ghost" >&2
                      exit 1;;
            "show "*) echo "Controller 11:22:33:44:55:66 archbox [default]"
                      printf '\\tPowered: %s\\n' "$powered"; exit 1;;
            "devices "*) exit 0;;
        esac
    fi
    # slow: the very first answer is empty (bluetoothd is still starting).
    if [ "$mode" = "slow" ]; then
        count="${state}.calls"
        n="$(cat "$count" 2>/dev/null || echo 0)"
        echo "$((n + 1))" > "$count"
        case "$1 $2" in
            "list "*)
                if [ "$n" -lt 1 ]; then exit 3; fi
                echo "Controller 11:22:33:44:55:66 archbox [default]"; exit 0;;
        esac
    fi
    # stderronly: nothing on stdout, everything on stderr, failure status.
    if [ "$mode" = "stderronly" ]; then
        case "$1 $2" in
            "list "*) echo "No default controller available" >&2; exit 1;;
            "show "*) echo "No default controller available" >&2; exit 1;;
        esac
    fi
    if [ "$mode" = "noadapter" ]; then
        # What a machine without an adapter really prints, for every verb.
        echo "No default controller available" >&2
        exit 1
    fi
    if [ "$mode" = "off" ]; then
        # starts switched off; `power on` writes the state file, so the button is
        # observable exactly like on a real adapter
        [ -f "$state" ] && off_power="$(cat "$state")" || off_power="no"
        case "$1 $2" in
            "show "*) printf 'Controller 11:22:33:44:55:66 archbox\\n\\tPowered: %s\\n' "$off_power"; exit 0;;
            "devices "*) exit 0;;
        esac
    fi
    case "$1 $2" in
        "list "*) echo "Controller 11:22:33:44:55:66 archbox [default]";;
        "show "*) printf 'Controller 11:22:33:44:55:66 archbox [default]\\n\\tPowered: %s\\n' "$powered";;
        "power "*) case "$2" in on) echo yes > "$state";; off) echo no > "$state";; esac
                   echo "Succeeded";;
        "devices ") if [ "$mode" = "dup" ]; then
                       printf 'Device AA:AA:AA:AA:AA:01 Headphones\\n'
                       printf 'Device AA:AA:AA:AA:AA:01 Headphones\\n'
                       printf 'Device BB:BB:BB:BB:BB:02 \\n'
                   else
                       printf 'Device AA:AA:AA:AA:AA:01 Headphones\\n'
                       printf 'Device BB:BB:BB:BB:BB:02 \\n'
                       printf 'Device CC:CC:CC:CC:CC:03 Keyboard\\n'
                   fi;;
        "connect "*) echo "$2" > "${BT_STATE:-/tmp/bt-stub-power}.conn"; echo "Connection successful";;
        "info "*) conn="$(cat "${BT_STATE:-/tmp/bt-stub-power}.conn" 2>/dev/null || true)"
                  case "$2" in
                    AA:*) printf 'Device AA:AA:AA:AA:AA:01\\n\\tName: Headphones\\n\\tIcon: audio-card\\n\\tPaired: yes\\n\\tTrusted: yes\\n\\tConnected: yes\\n';;
                    BB:*) printf 'Device BB:BB:BB:BB:BB:02\\n\\tIcon: phone\\n\\tPaired: no\\n\\tConnected: %s\\n' \
                              "$([ "$conn" = "BB:BB:BB:BB:BB:02" ] && echo yes || echo no)";;
                    CC:*) printf 'Device CC:CC:CC:CC:CC:03\\n\\tIcon: input-keyboard\\n\\tPaired: yes\\n\\tConnected: no\\n';;
                  esac;;
        "pair "*) echo "Pairing successful";;
        "trust "*) echo "trust succeeded";;
        "disconnect "*) echo "Successful disconnected";;
        *) exit 0;;
    esac
    exit 0
''')


class StubBluetoothctl:
    """Puts a fake bluetoothctl first on PATH for the duration of a with-block."""

    def __init__(self, mode="normal"):
        self.mode = mode

    def __enter__(self):
        self.dir = tempfile.TemporaryDirectory()
        path = Path(self.dir.name) / "bluetoothctl"
        path.write_text(STUB)
        path.chmod(path.stat().st_mode | stat.S_IEXEC)
        self.saved = os.environ.get("PATH", "")
        os.environ["PATH"] = f"{self.dir.name}:{self.saved}"
        os.environ["BT_MODE"] = self.mode
        # per-test power/connection state, so a toggle never leaks between tests
        os.environ["BT_STATE"] = str(Path(self.dir.name) / "power")
        # keep a quiet rfkill out of the picture
        return self

    def __exit__(self, *exc):
        os.environ["PATH"] = self.saved
        os.environ.pop("BT_MODE", None)
        os.environ.pop("BT_STATE", None)
        self.dir.cleanup()
        return False


def adapter():
    import importlib
    from sphere_adapter import bluetooth
    return importlib.reload(bluetooth)


class AdapterShapeTests(unittest.TestCase):
    def test_status_has_every_key_the_panel_reads(self):
        with StubBluetoothctl():
            state = adapter().status()
        for key in ("available", "powered", "adapter", "devices", "scanning",
                    "blocked", "error"):
            self.assertIn(key, state)
        self.assertTrue(state["available"])
        self.assertTrue(state["powered"])
        self.assertEqual(state["adapter"]["address"], "11:22:33:44:55:66")
        # bluez appends [default]; the panel must never show it
        self.assertEqual(state["adapter"]["name"], "archbox")
        self.assertEqual(state["error"], "")

    def test_devices_are_deduped_and_unnamed_ones_show_their_mac(self):
        with StubBluetoothctl("dup"):
            state = adapter().status()
        addresses = [d["address"] for d in state["devices"]]
        self.assertEqual(len(addresses), len(set(addresses)), "duplicate device listed twice")
        unnamed = [d for d in state["devices"] if d["address"] == "BB:BB:BB:BB:BB:02"][0]
        self.assertEqual(unnamed["name"], "")
        self.assertEqual(unnamed["label"], "BB:BB:BB:BB:BB:02")

    def test_kind_comes_from_the_bluez_icon(self):
        with StubBluetoothctl():
            devices = {d["address"]: d for d in adapter().status()["devices"]}
        self.assertEqual(devices["AA:AA:AA:AA:AA:01"]["kind"], "audio")
        self.assertEqual(devices["BB:BB:BB:BB:BB:02"]["kind"], "phone")
        self.assertEqual(devices["CC:CC:CC:CC:CC:03"]["kind"], "keyboard")
        self.assertTrue(devices["AA:AA:AA:AA:AA:01"]["connected"])
        self.assertTrue(devices["CC:CC:CC:CC:CC:03"]["paired"])

    def test_connected_devices_sort_first(self):
        with StubBluetoothctl():
            devices = adapter().status()["devices"]
        self.assertTrue(devices[0]["connected"])

    def test_powered_off_reports_no_devices_and_no_error(self):
        with StubBluetoothctl("off"):
            state = adapter().status()
        self.assertFalse(state["powered"])
        self.assertEqual(state["devices"], [])
        self.assertEqual(state["error"], "")

    def test_missing_adapter_is_explained_in_words(self):
        with StubBluetoothctl("noadapter"):
            state = adapter().status()
        self.assertIsNone(state["adapter"])
        self.assertTrue(state["error"])
        self.assertIn("adapter", state["error"].lower())

    def test_connect_rejects_anything_that_is_not_an_address(self):
        with StubBluetoothctl():
            with self.assertRaises(ValueError):
                adapter().connect("nonsense")
            with self.assertRaises(ValueError):
                adapter().connect("11:22:33:44:55")

    def test_connect_pairs_before_connecting_an_unpaired_device(self):
        calls = []
        with StubBluetoothctl():
            mod = adapter()
            real = mod._run

            def spy(argv, timeout=10):
                calls.append(list(argv))
                return real(argv, timeout)
            mod._run = spy
            state = mod.connect("BB:BB:BB:BB:BB:02")
        verbs = [c[0] for c in calls if c]
        self.assertIn("pair", verbs)
        self.assertLess(verbs.index("pair"), verbs.index("connect"))
        self.assertEqual(state["connectedTo"], "BB:BB:BB:BB:BB:02")
        # the adapter returns the bare state; the bridge adds the message type
        self.assertIn("devices", state)

    def test_power_toggles_the_controller(self):
        with StubBluetoothctl():
            mod = adapter()
            self.assertTrue(mod.power(True)["powered"])
            self.assertFalse(mod.power(False)["powered"])

    def test_missing_bluez_is_reported_not_raised(self):
        saved = os.environ.get("PATH", "")
        os.environ["PATH"] = "/nonexistent"
        mod = adapter()
        saved_fallbacks = mod.CLI_FALLBACKS
        mod.CLI_FALLBACKS = ()            # a machine that really has no bluetoothctl
        try:
            state = mod.status()
        finally:
            os.environ["PATH"] = saved
            mod.CLI_FALLBACKS = saved_fallbacks
        self.assertFalse(state["available"])
        self.assertIn("bluez-utils", state["error"])

    def test_a_broken_path_cannot_hide_an_installed_bluetoothctl(self):
        # A session without /usr/bin on PATH used to make the panel say
        # "not available" on a machine where bluetoothctl works perfectly.
        saved = os.environ.get("PATH", "")
        os.environ["PATH"] = "/nonexistent"
        mod = adapter()
        try:
            mod.CLI_FALLBACKS = ("/nonexistent/bluetoothctl",)
            self.assertIsNone(mod.cli_path())
            with StubBluetoothctl():
                mod = adapter()
                # the stub lives in a temp dir, so it is found through PATH …
                self.assertTrue(mod.cli_path().endswith("/bluetoothctl"))
                # … and the absolute fallbacks are consulted when PATH is broken
                self.assertIn("/usr/bin/bluetoothctl", mod.CLI_FALLBACKS)
                self.assertIn("/usr/local/bin/bluetoothctl", mod.CLI_FALLBACKS)
        finally:
            os.environ["PATH"] = saved


class DetectionRulesTests(unittest.TestCase):
    """The rules that decide "Bluetooth is not available" — and when it is not said.

    Each one exists because the old detection produced that sentence on a machine
    where bluetoothctl worked perfectly.
    """

    def test_stderr_noise_and_a_failed_exit_code_do_not_hide_the_adapter(self):
        # bluetoothctl prints "Waiting to connect to bluetoothd..." on stderr and
        # exits 1 on healthy machines; stdout still carries the Controller line.
        with StubBluetoothctl("noisy"):
            state = adapter().status()
        self.assertTrue(state["available"])
        self.assertIsNotNone(state["adapter"])
        self.assertEqual(state["adapter"]["address"], "11:22:33:44:55:66")
        self.assertTrue(state["powered"])
        self.assertEqual(state["error"], "")

    def test_only_stdout_is_parsed(self):
        # The stub prints a second, bogus "Controller 99:..." line on stderr.
        with StubBluetoothctl("noisy"):
            state = adapter().status()
        self.assertEqual(state["adapter"]["address"], "11:22:33:44:55:66")

    def test_powered_off_is_available_with_a_power_button(self):
        with StubBluetoothctl("off"):
            state = adapter().status()
        self.assertTrue(state["available"], "a switched-off adapter is still an adapter")
        self.assertIsNotNone(state["adapter"])
        self.assertFalse(state["powered"])
        self.assertEqual(state["error"], "", "being off is a state, not an error")
        self.assertEqual(state["devices"], [])

    def test_power_on_works_from_the_off_state(self):
        with StubBluetoothctl("off"):
            mod = adapter()
            self.assertFalse(mod.status()["powered"])
            state = mod.power(True)
        self.assertTrue(state["powered"])
        self.assertEqual(state["error"], "")

    def test_a_slow_first_answer_is_retried_once(self):
        import time as clock
        with StubBluetoothctl("slow"):
            mod = adapter()
            started = clock.monotonic()
            state = mod.status()
            elapsed = clock.monotonic() - started
        self.assertTrue(state["available"], "the retry should have found the adapter")
        self.assertIsNotNone(state["adapter"])
        self.assertGreaterEqual(elapsed, 1.0, "the retry must wait a second, not spin")

    def test_a_definitive_negative_is_not_retried(self):
        import time as clock
        with StubBluetoothctl("stderronly"):
            mod = adapter()
            started = clock.monotonic()
            state = mod.status()
            elapsed = clock.monotonic() - started
        self.assertIsNone(state["adapter"])
        self.assertLess(elapsed, .95, "a real 'no controller' answer needs no retry")
        self.assertIn("adapter", state["error"].lower())
        # …and the panel gets bluetoothctl's own sentence to show.
        self.assertIn("no default controller", state["detail"].lower())

    def test_the_environment_is_completed_before_bluetoothctl_runs(self):
        env = adapter().cli_environment({"PATH": "/broken", "HOME": "/home/x"})
        parts = env["PATH"].split(":")
        for wanted in ("/usr/bin", "/bin", "/usr/local/bin", "/broken"):
            self.assertIn(wanted, parts)
        self.assertEqual(env["LC_ALL"], "C")
        self.assertEqual(env["HOME"], "/home/x")
        # Set only when the sockets exist, never invented.
        if Path("/run/dbus/system_bus_socket").exists():
            self.assertTrue(env["DBUS_SYSTEM_BUS_ADDRESS"].startswith("unix:path="))

    def test_a_scan_is_a_process_the_panel_can_see(self):
        import time as clock
        with StubBluetoothctl():
            mod = adapter()
            started = clock.monotonic()
            state = mod.start_scan(2)
            elapsed = clock.monotonic() - started
            self.assertLess(elapsed, 1.0, "starting a scan must not wait for it")
            self.assertTrue(state["scanning"])
            self.assertTrue(mod.scanning())
            self.assertTrue(mod.status(include_devices=False)["scanning"])
            mod.stop_scan()
            clock.sleep(.2)
            self.assertFalse(mod.scanning(), "the scan process must really be gone")
            self.assertFalse(mod.status(include_devices=False)["scanning"])

    def test_a_scan_is_not_started_on_a_powered_off_adapter(self):
        with StubBluetoothctl("off"):
            mod = adapter()
            state = mod.start_scan(2)
            self.assertFalse(state["scanning"])
            self.assertIn("off", state["error"].lower())
            self.assertFalse(mod.scanning())

    def test_the_monitor_hands_out_a_copy_and_never_blocks(self):
        import time as clock
        with StubBluetoothctl():
            mod = adapter()
            seen = []
            monitor = mod.Monitor(on_change=seen.append, interval=.2)
            first = monitor.current()          # before the thread has read anything
            self.assertTrue(first["pending"])
            monitor.start()
            try:
                deadline = clock.monotonic() + 5
                while clock.monotonic() < deadline and not seen:
                    clock.sleep(.05)
            finally:
                monitor.stop()
            self.assertTrue(seen, "the monitor must publish its first reading")
            state = monitor.current()
            self.assertFalse(state["pending"])
            self.assertTrue(state["available"])
            self.assertEqual(state["adapter"]["address"], "11:22:33:44:55:66")
            before = monitor.current()["devices"]
            state["devices"].append("not real")     # a caller cannot corrupt the cache
            state["adapter"]["address"] = "bogus"
            self.assertEqual(monitor.current()["devices"], before)
            self.assertEqual(monitor.current()["adapter"]["address"], "11:22:33:44:55:66")


class BridgeSyncTests(unittest.TestCase):
    """The QML action strings and the bridge's request() must agree exactly."""

    ACTIONS = ("bluetooth", "bluetoothScan", "bluetoothConnect", "bluetoothPower")

    def test_every_action_the_qml_sends_is_handled(self):
        for action in self.ACTIONS:
            self.assertIn(f'"{action}"', BRIDGE, f"bridge does not handle {action}")
            self.assertIn(f'action:"{action}"', WIDGET, f"QML never requests {action}")

    def test_the_bridge_answers_with_one_state_shape(self):
        from sphere_adapter.bridge import Bridge
        self.assertTrue(hasattr(Bridge, "bluetooth_state"))
        self.assertRegex(BRIDGE, r'"type":\s*"bluetooth"')

    def test_the_bridge_reads_the_cache_instead_of_a_subprocess(self):
        # bluetooth_state() must not call bluetoothctl on the request path; the
        # monitor thread owns every call and pushes changes as events.
        self.assertIn("bluetooth_control.Monitor(", BRIDGE)
        self.assertIn("bridge.bluetooth.start()", BRIDGE)
        self.assertIn("bridge.bluetooth.stop()", BRIDGE)
        state = BRIDGE.split("def bluetooth_state", 1)[1].split("def ", 1)[0]
        self.assertNotIn("bluetooth_control.status(", state)
        self.assertNotIn("bluetooth_control.scan(", state)
        self.assertIn("self.bluetooth.current()", state)

    def test_the_scan_can_be_stopped_from_the_widget(self):
        self.assertIn('"bluetoothScanStop"', BRIDGE)
        self.assertIn("bluetoothScanStop", WIDGET)

    def test_a_bridge_bluetooth_request_answers_immediately(self):
        from sphere_adapter.bridge import Bridge
        from sphere_adapter.config import ConfigStore
        with tempfile.TemporaryDirectory() as temporary:
            store = ConfigStore(Path(temporary) / "state.json")
            bridge = Bridge(store=store)
            state = bridge.request({"action": "bluetooth"})
            self.assertEqual(state["type"], "bluetooth")
            # Without bluetoothctl this is the honest answer, not an exception.
            for key in ("available", "powered", "adapter", "devices", "scanning",
                        "blocked", "pending", "error", "detail"):
                self.assertIn(key, state)
            self.assertEqual(bridge.request({"action": "bluetoothScanStop"})["type"], "bluetooth")

    def test_scan_is_the_documented_timeout(self):
        self.assertIn('SCAN_SECONDS', ADAPTER)
        self.assertIn('"--timeout"', ADAPTER)
        self.assertIn('"scan", "on"', ADAPTER)

    def test_only_bluetoothctl_is_shelled_out_to(self):
        # Quickshell ships without the Qt Bluetooth module, so this is the whole
        # integration surface: no D-Bus client, no extra process.
        self.assertIn('"bluetoothctl"', ADAPTER)
        for name in ("SphereWidget.qml", "MagicRing.qml", "MagicGem.qml", "shell.qml"):
            self.assertNotIn("import QtBluetooth", (NATIVE / name).read_text(), name)


class SessionEnvironmentTests(unittest.TestCase):
    """The variables bluetoothctl needs, completed at both ends of the chain."""

    def test_the_launcher_completes_the_session(self):
        start = (NATIVE / "start.sh").read_text()
        self.assertIn("XDG_RUNTIME_DIR", start)
        self.assertIn("DBUS_SESSION_BUS_ADDRESS", start)
        self.assertIn('"/run/user/$(id -u)"', start)
        # It must only fill gaps, never overwrite a working session.
        self.assertIn('[ -z "${XDG_RUNTIME_DIR:-}" ]', start)
        self.assertIn('[ -z "${DBUS_SESSION_BUS_ADDRESS:-}" ]', start)

    def test_the_adapter_completes_them_again_for_its_children(self):
        self.assertIn("def cli_environment(", ADAPTER)
        for key in ("XDG_RUNTIME_DIR", "DBUS_SESSION_BUS_ADDRESS", "DBUS_SYSTEM_BUS_ADDRESS", "PATH"):
            self.assertIn(key, ADAPTER)
        # Every spawn site goes through it.
        self.assertEqual(ADAPTER.count("env=cli_environment()"), 4)

    def test_the_start_script_is_still_valid_posix_shell(self):
        result = subprocess.run(["sh", "-n", str(NATIVE / "start.sh")],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)


class PanelTests(unittest.TestCase):
    def test_panel_exists_with_the_same_structure_as_wifi(self):
        self.assertIn('id:bluetoothPanel;objectName:"bluetoothPanel";key:"bluetooth"', WIDGET)
        # Same frame, so the structure is the same by construction — the frame is
        # the only thing that draws a header, a body, a list or a button row.
        for token in ("ListView", "Text.ElideRight", "ScrollBar"):
            self.assertIn(token, PANEL_FRAME)
        wifi = self.panel_block("wifi")
        bt = self.panel_block("bluetooth")
        for token in ("radius:root.orbRadius", "actions:root.", "items:root."):
            self.assertIn(token, wifi, token)
            self.assertIn(token, bt, token)

    def panel_block(self, key):
        start = WIDGET.index('key:"%s"' % key)
        return WIDGET[start:WIDGET.index("\n    }\n", start)]

    def test_every_size_is_derived_from_orbRadius(self):
        panel = self.panel_block("bluetooth")
        self.assertIn("radius:root.orbRadius", panel)
        self.assertNotRegex(panel, r"\b\d+(?:\.\d+)?\s*\*\s*root\.uiScale")
        # A bare 1 (hairline border, 1-pixel separator) is the only literal the
        # frame may carry; every other dimension comes from the orb's radius.
        # property *defaults* (radius: 150, uiScale: 1) are the component's API;
        # what must never carry a pixel literal is the layout tree itself.
        tree = PANEL_FRAME.split("width: radius * 2", 1)[1]
        tree = "\n".join(line.split("//", 1)[0] for line in tree.splitlines())
        # spacing: 0 is a legitimate zero gap (label over value inside one card)
        hairlines_removed = re.sub(r"(?<![\d.])1(?![\d.])", "", tree)
        hairlines_removed = hairline_removed = re.sub(r"spacing:\s*0\b", "", hairlines_removed)
        self.assertNotRegex(hairlines_removed,
                            r"(?:width|height|radius|spacing|pixelSize)\s*:\s*\d+(?:\.\d+)?\b")

    def test_it_is_built_exactly_like_the_wifi_panel(self):
        wifi = self.panel_block("wifi")
        bt = self.panel_block("bluetooth")
        # Both are the *same* component with different data, so the guarantee is
        # structural: no panel may declare a layer, a list or a button of its own.
        for block in (wifi, bt):
            self.assertNotIn("ListView", block)
            self.assertNotIn("Rectangle", block)
            self.assertNotIn("MouseArea", block)
        # …and both feed the same frame properties.
        for token in ("mode:", "items:", "actions:", "tone:", "state:", "status:", "icon:", "title:"):
            self.assertIn(token, wifi, token)
            self.assertIn(token, bt, token)

    def test_bluetooth_gem_sits_second_on_the_ring(self):
        # second entry of the one ring table, at gemIndex(1) = -90 + 72°
        self.assertIn('{ panel:"bluetooth", label:"BLUETOOTH", color:theme.gemBluetooth, glyph:"bluetooth" }', WIDGET)
        self.assertIn("function gemAngle(i) { return -90 + 360*i/Math.max(1,gemCount); }", WIDGET)
        self.assertIn("readonly property int bluetoothSlot: 1", WIDGET)

    def test_only_one_system_list_can_be_open(self):
        # One panel, one truth. The six open flags are read-only views of
        # `activePanel`, and every opener routes through showPanel(), which retires
        # the previous panel before it sets the new key — so two lists cannot
        # coexist, and no opener has to remember to close the others.
        self.assertIn("systemListOpen", WIDGET)
        self.assertIn('property string activePanel: ""', WIDGET)
        self.assertIn('readonly property bool bluetoothOpen: activePanel==="bluetooth"', WIDGET)
        self.assertIn('readonly property bool wifiOpen: activePanel==="wifi"', WIDGET)
        for opener, key in (("function openWifi(", "wifi"), ("function openBluetooth(", "bluetooth")):
            body = WIDGET.split(opener, 1)[1].split("function ", 1)[0]
            self.assertIn('root.showPanel("%s", "api", true)' % key, body)
        show = WIDGET.split("function showPanel(", 1)[1].split("function ", 1)[0]
        self.assertIn("if(previous.length>0) root.retirePanel(previous);", show)
        self.assertIn("root.activePanel=key;", show)

    def test_escape_closes_the_bluetooth_list(self):
        keys = WIDGET.split("Keys.onEscapePressed", 1)[1].split("signal dismissRequested", 1)[0]
        # The device list is the active panel, and an active panel is one Escape
        # away — the same line closes the Wi-Fi list, the battery dashboard and
        # everything else, because there is only one panel to close.
        self.assertIn('else if(activePanel!=="") { clearPanel("escape")', keys)
        self.assertIn("property string activePanel", WIDGET)

    def test_every_gem_appears_on_the_ring_and_nowhere_else(self):
        # Five stones from one table, five panels from one frame, no orb declared
        # twice, and no panel carrying glass of its own.
        self.assertEqual(WIDGET.count("MagicGem {"), 1)     # one delegate, five stones
        self.assertEqual(WIDGET.count("PanelFrame {"), 5)   # wifi, bt, battery, system, files
        self.assertEqual(SHELL.count("function bluetoothOrbRegion"), 1)
        self.assertEqual(SHELL.count("function batteryOrbRegion"), 1)
        # the geometry helper stays pinned so health and doctor keep answering
        self.assertIn("function bluetoothOrbRegion() { return root.orbHit(1); }", SHELL)

    def test_the_bluetooth_rune_is_its_own_asset(self):
        # the glyph is a drawn silhouette in native/assets, one per gem, not a
        # font character and not a branch inside a Canvas
        self.assertIn('glyph:"bluetooth"', WIDGET)
        self.assertIn('glyphSource: Qt.resolvedUrl("assets/glyph-"+root.gemGlyph(gemSlot.index)+".svg")',
                      WIDGET)
        asset = NATIVE / "assets" / "glyph-bluetooth.svg"
        self.assertTrue(asset.is_file())
        text = asset.read_text()
        self.assertIn("<svg", text)
        self.assertIn("path", text)

    def test_the_gem_owns_its_panel_and_nothing_can_reassign_it(self):
        self.assertIn('{ panel:"bluetooth", label:"BLUETOOTH", color:theme.gemBluetooth, glyph:"bluetooth" }', WIDGET)
        self.assertIn("function panelKeyAt(index) { return root.gemKey(index); }", WIDGET)
        # the picker went with the app orbs, so a gem's panel cannot be replaced
        self.assertNotIn("openEditor", WIDGET)

    def test_panel_has_the_required_copy(self):
        for text in ('title:"BLUETOOTH"', '"Choose a device"', '"No devices visible yet. Press Scan."',
                     '"Scan"', '"Power off"', '"Power on"', '"Scanning…"', '"Bluetooth is off"',
                     '"Reading the adapter…"'):
            self.assertIn(text, WIDGET)

    def test_scanning_is_never_claimed_without_a_running_scan(self):
        # The panel may only say "Scanning…" when the adapter reports a live
        # `bluetoothctl scan on` process — never because a button was pressed.
        self.assertIn("bluetoothScanning=bluetooth.scanning;", WIDGET)
        scan = WIDGET.split("function scanBluetooth()", 1)[1].split("function ", 1)[0]
        self.assertNotIn("bluetoothScanning=true", scan)
        self.assertIn("root.bluetooth.scanning ? \"Scanning…\"", WIDGET)
        # …and the scan is stopped when the list closes, and polled while it runs.
        # Closing is now one place for every panel: retirePanel().
        close = WIDGET.split("function retirePanel(", 1)[1].split("function ", 1)[0]
        self.assertIn('emitRequest({action:"bluetoothScanStop"})', close)
        self.assertIn("id:bluetoothScanPoll", WIDGET)

    def test_the_panel_shows_the_real_error_text(self):
        # The frame's hint slot carries bluetoothctl's own words, under the same
        # objectName every drill-down already knew.
        self.assertIn('names:({ hint:"bluetoothDetail" })', WIDGET)
        self.assertIn('emptyHint:String(root.bluetooth.detail || "")', WIDGET)
        self.assertIn('objectName: frame.n("hint", "EmptyHint")', PANEL_FRAME)
        self.assertIn("bluetooth.pending", WIDGET)

    def test_a_silent_adapter_cannot_leave_the_panel_working(self):
        self.assertIn("id:bluetoothBusyTimer", WIDGET)
        self.assertIn("bluetoothctl did not answer in 12 s", WIDGET)

    def test_the_alert_tint_is_derived_not_hand_picked(self):
        # State is a *tone*, and every colour the panel shows is mixed from it
        # and the orb's own palette — never a hand-picked hex per panel.
        self.assertIn('statusWarn:!root.bluetooth.available', WIDGET)
        # the semantic tone chain, plus the per-orb identity accent that the
        # organizer uses (an override, not a second palette)
        self.assertIn('readonly property color cAccent: accent.length > 0 ? c(accent)', PANEL_FRAME)
        self.assertIn('tone === "good" ? "#55f49a"', PANEL_FRAME)
        self.assertIn("readonly property color cText: mix(cAccent, \"#ffffff\", 0.94)", PANEL_FRAME)
        self.assertIn("statusWarn ? \"#ff7777\" : frame.cAccent", PANEL_FRAME)


@unittest.skipUnless(PREP_PATH.is_file(), "shell/bluetooth-prep.sh is not part of the deployed payload")
class PreparationScriptTests(unittest.TestCase):
    def test_it_is_valid_posix_shell(self):
        result = subprocess.run(["sh", "-n"], input=PREP, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_it_installs_only_the_missing_packages(self):
        self.assertIn('pacman -Q "$1"', PREP)
        self.assertIn('"${BT_ELEVATOR}" pacman -S --needed --noconfirm', PREP)
        self.assertNotIn("sudo pacman", PREP)

    def test_it_starts_and_enables_both_services(self):
        self.assertIn("systemctl enable --now \"$_name\"", PREP)
        self.assertIn("bluetooth NetworkManager", PREP)

    def test_it_unblocks_rfkill_and_verifies_the_adapter(self):
        self.assertIn("rfkill unblock bluetooth", PREP)
        self.assertIn("bluetoothctl list", PREP)
        self.assertIn("^Controller ", PREP)

    def test_failures_are_reported_and_the_run_continues(self):
        self.assertIn("continuing without it", PREP)
        self.assertNotIn("exit 1", PREP)

    def test_the_standalone_up2_script_embeds_this_preparation(self):
        up2 = REPO.parent / "up2.sh"
        if not up2.is_file():
            self.skipTest("up2.sh is not present next to the checkout")
        text = up2.read_text()
        self.assertIn("bt_prepare || SPHERE_DEGRADED=1", text)
        self.assertIn("rfkill unblock bluetooth", text)
        self.assertIn("sudo pacman -S --needed --noconfirm", text)
        # --dry-run has to reach the embedded installer, not be swallowed here
        self.assertIn('case "$arg" in --no-deps) ;;', text)

    def test_dry_run_changes_nothing(self):
        result = subprocess.run(
            ["sh", "-c", '. "$1"; SPHERE_BT_DRY_RUN=1; bt_prepare', "sh",
             str(REPO / "shell" / "bluetooth-prep.sh")],
            text=True, capture_output=True, env={**os.environ, "PATH": "/usr/bin:/bin:/usr/sbin:/sbin"})
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Summary:", result.stdout)
        self.assertIn("service:", result.stdout)


if __name__ == "__main__":
    unittest.main()
