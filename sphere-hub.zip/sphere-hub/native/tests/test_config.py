"""The configs and the QML are one truth, enforced.

config/layout.json, config/theme.json, config/panels.json and config/motion.json
are the sources; native/Geometry.qml, the crest tokens in native/Theme.qml,
native/Panels.qml and native/Motion.qml mirror them for the QML side (browsers
cannot read the JSON at run time and the QA harnesses run without Quickshell's
FileView). This module fails the moment a mirror drifts — nothing may hand-edit
a number in a ui file.
"""
import json
import pathlib
import re
import unittest

REPO = pathlib.Path(__file__).resolve().parents[2]
CONFIG = REPO / "config"
NATIVE = REPO / "native"

LAYOUT = json.loads((CONFIG / "layout.json").read_text())
THEME_JSON = json.loads((CONFIG / "theme.json").read_text())
PANELS = json.loads((CONFIG / "panels.json").read_text())
MOTION = json.loads((CONFIG / "motion.json").read_text())

GEOMETRY = (NATIVE / "Geometry.qml").read_text()
THEME = (NATIVE / "Theme.qml").read_text()
PANELS_QML = (NATIVE / "Panels.qml").read_text()
MOTION_QML = (NATIVE / "Motion.qml").read_text()
WIDGET = (NATIVE / "SphereWidget.qml").read_text()

TOKEN = re.compile(r"readonly property (real|int|bool|var|color|string) (\w+): (.+)")


def qml_tokens(text):
    """name → python value for every `readonly property` in a token file."""
    out = {}
    for kind, name, raw in TOKEN.findall(text):
        raw = raw.split("//")[0].strip()
        if kind == "real":
            out[name] = float(raw)
        elif kind == "int":
            out[name] = int(raw)
        elif kind == "bool":
            out[name] = raw == "true"
        elif kind == "var":
            out[name] = json.loads(raw)
        else:
            out[name] = raw.strip('"')
    return out


GEO = qml_tokens(GEOMETRY)
TOK = qml_tokens(THEME)
MOT = qml_tokens(MOTION_QML)


class LayoutMirrorTests(unittest.TestCase):
    """config/layout.json ↔ native/Geometry.qml."""

    MAP = {
        "ringScreenShare": "ringScreenShare", "gemOrbit": "gemOrbit",
        "gemDiameter": "gemDiameter", "gemCount": "gemCount",
        "gemAnglesDeg": "gemAnglesDeg", "coreRingRadius": "coreRingRadius",
        "sigilSize": "sigilSize", "sigilRadius": "sigilRadius",
        "gemHaloRadius": "gemHaloRadius",
    }

    def test_flat_values_match(self):
        for key, token in self.MAP.items():
            self.assertEqual(LAYOUT[key], GEO[token], key)

    def test_nested_values_match(self):
        pairs = [
            (LAYOUT["runeBand"]["outerRing"], GEO["runeBandOuter"]),
            (LAYOUT["runeBand"]["innerRing"], GEO["runeBandInner"]),
            (LAYOUT["runeBand"]["runeRadius"], GEO["runeRadius"]),
            (LAYOUT["runeBand"]["runeCount"], GEO["runeCount"]),
            (LAYOUT["runeBand"]["runeSize"], GEO["runeSize"]),
            (LAYOUT["runeBand"]["segmentGapDeg"], GEO["segmentGapDeg"]),
            (LAYOUT["runeBand"]["boundaryNodeSize"], GEO["boundaryNodeSize"]),
            (LAYOUT["outerRings"]["radii"], GEO["outerRadii"]),
            (LAYOUT["outerRings"]["style"], GEO["outerStyle"]),
            (LAYOUT["dashedRing"]["radius"], GEO["dashedRadius"]),
            (LAYOUT["guideCircle"]["radius"], GEO["guideRadius"]),
            (LAYOUT["guideCircle"]["enabled"], GEO["guideEnabled"]),
            (LAYOUT["sigils"], GEO["sigilsEnabled"]),
            (LAYOUT["spokes"]["gem"]["from"], GEO["spokeGemFrom"]),
            (LAYOUT["spokes"]["gem"]["to"], GEO["spokeGemTo"]),
            (LAYOUT["spokes"]["segment"]["from"], GEO["spokeSegmentFrom"]),
            (LAYOUT["spokes"]["segment"]["to"], GEO["spokeSegmentTo"]),
            (LAYOUT["spokes"]["nodeSize"], GEO["nodeSize"]),
            (LAYOUT["spokes"]["connectorArc"], GEO["connectorArc"]),
            (LAYOUT["gemStar"]["enabled"], GEO["gemStarEnabled"]),
            (LAYOUT["gemStar"]["radius"], GEO["gemStarRadius"]),
        ]
        for want, got in pairs:
            self.assertEqual(want, got)

    def test_generated_glyph_assets_match_the_config(self):
        # the artwork generator must produce exactly the glyphs the band draws
        runes = sorted((NATIVE / "assets").glob("rune-*.svg"))
        self.assertEqual(len(runes), LAYOUT["runeBand"]["runeCount"])
        self.assertEqual(len({p.read_text() for p in runes}), len(runes),
                         "every glyph unique")
        sigils = sorted((NATIVE / "assets").glob("sigils/sigil-*.svg"))
        self.assertEqual(len(sigils), 5)                  # five stations

    def test_the_installer_manifest_ships_every_glyph(self):
        # installer/constants.py enumerates what the manager installs — if it
        # ever under-counts the generated glyph set, the widget comes up with
        # missing runes (the reason this test exists)
        text = (REPO / "installer" / "constants.py").read_text()
        n = int(re.search(r'rune-%02d\.svg" % i for i in range\((\d+)\)',
                          text).group(1))
        self.assertEqual(n, LAYOUT["runeBand"]["runeCount"])
        self.assertNotIn('"assets/sigil-%02d.svg"', text)  # studies retired

    def test_no_web_line_may_cross_a_sigil(self):
        # the web's furthest reach is the gemStar radius; the sigils sit at
        # sigilRadius and nothing may raise a web reach past their inner edge
        sigil_inner = LAYOUT["sigilRadius"] - LAYOUT["sigilSize"] / 2
        for reach in (LAYOUT["gemStar"]["radius"], LAYOUT["guideCircle"]["radius"],
                      LAYOUT["spokes"]["gem"]["from"], LAYOUT["spokes"]["segment"]["from"]):
            self.assertLess(reach, sigil_inner, reach)

    def test_the_installer_manifest_ships_every_native_file(self):
        # NATIVE_FILES is what deploy_native() copies — every component in
        # native/ must be listed or the widget loads without it (this exact
        # gap shipped b30 without Sigil.qml)
        text = (REPO / "installer" / "constants.py").read_text()
        body = text.split("NATIVE_FILES = (", 1)[1].split(")", 1)[0]
        listed = set(re.findall(r'"([^"]+)"', body))
        have = {p.name for p in NATIVE.glob("*.qml")}
        self.assertTrue(have <= listed, sorted(have - listed))
        for name in listed:
            if name.endswith(".qml"):
                self.assertTrue((NATIVE / name).is_file(), name)

    def test_the_gold_palette_is_the_locked_bright_gold(self):
        # the spell-circle palette: brightest at the gradient's upper left;
        # gem colours and the core blues are not gold and are not covered here
        gold = json.loads((REPO / "config" / "theme.json").read_text())["gold"]
        self.assertEqual(gold["highlight"], "#FFF0B8")
        self.assertEqual(gold["bright"], "#FFD65A")
        self.assertEqual(gold["mid"], "#F5B82E")
        self.assertEqual(gold["deep"], "#C98A12")

    def test_gold_glow_is_the_zero_to_one_knob_defaulting_to_six(self):
        theme = json.loads((REPO / "config" / "theme.json").read_text())
        self.assertEqual(theme["goldGlow"], 0.6)
        self.assertGreaterEqual(theme["goldGlow"], 0.0)
        self.assertLessEqual(theme["goldGlow"], 1.0)

    def test_the_sigils_flag_defaults_to_off(self):
        # section A: the sigil code stays, hidden behind "sigils": false
        self.assertIs(LAYOUT["sigils"], False)

    def test_gem_angles_are_the_computed_schedule(self):
        # first gem at the top, evenly spaced — stored and computed must agree
        n = LAYOUT["gemCount"]
        computed = [-90 + 360 * i / n for i in range(n)]
        self.assertEqual(computed, LAYOUT["gemAnglesDeg"])

    def test_segment_angles_are_derived_not_stored(self):
        # the sigil station between gem i and gem i+1 is midway — a second
        # stored list is exactly the drift this file exists to prevent
        self.assertNotIn("segmentAnglesDeg", LAYOUT)
        n = LAYOUT["gemCount"]
        for i in range(n):
            self.assertEqual(LAYOUT["gemAnglesDeg"][i] + 180 / n,
                             -90 + 360 * i / n + 180 / n)

    def test_the_tight_rings_pack_with_small_gaps(self):
        # "gap only 2-3px" at R = 500: the white between two strokes is the
        # radius step minus the two half-widths; the outermost is brightest
        radii = LAYOUT["outerRings"]["radii"]
        edge = THEME_JSON["lines"]["outerEdge"]
        self.assertEqual(radii, sorted(radii))
        self.assertLessEqual(radii[-1], 1.0)
        self.assertEqual(len(edge["widths"]), len(radii))
        self.assertEqual(len(edge["alphas"]), len(radii))
        for i in range(len(radii) - 1):
            gap = (radii[i + 1] - radii[i]) * 500 - (edge["widths"][i] + edge["widths"][i + 1]) / 2
            self.assertGreaterEqual(gap, 2.0, i)
            self.assertLessEqual(gap, 4.0, i)
        self.assertEqual(edge["alphas"][-1], 1.0)
        self.assertEqual(max(edge["alphas"]), edge["alphas"][-1])
        self.assertIn(LAYOUT["outerRings"]["style"], ("classic", "current"))

    def test_the_outer_color_flag_has_a_silver_family(self):
        self.assertIn(THEME_JSON["outerColor"], ("gold", "silver"))
        self.assertEqual(THEME_JSON["outerColor"], "gold")   # default
        self.assertEqual(set(THEME_JSON["silverPalette"]) & {"highlight", "bright", "mid", "deep"},
                         {"highlight", "bright", "mid", "deep"})
        for name in ("highlight", "bright", "mid", "deep"):
            self.assertRegex(THEME_JSON["silverPalette"][name], r"^#[0-9A-F]{6}$")


class ThemeMirrorTests(unittest.TestCase):
    """config/theme.json's line language ↔ the crest tokens in native/Theme.qml."""

    def test_gold_palette_is_recorded(self):
        for name in ("highlight", "bright", "mid", "deep"):
            self.assertIn(name, THEME_JSON["gold"])
            self.assertRegex(THEME_JSON["gold"][name], r"^#[0-9A-F]{6}$")

    def test_gold_glow_matches(self):
        self.assertEqual(THEME_JSON["goldGlow"], TOK["crestGoldGlow"])

    def test_every_line_style_matches(self):
        want = {
            "runeRing": ("crestRuneRingWidth", "crestRuneRingAlpha"),
            "dashedRing": ("crestDashedWidth", "crestDashedAlpha"),
            "guideCircle": ("crestGuideWidth", "crestGuideAlpha"),
            "sigil": ("crestSigilWidth", "crestSigilAlpha"),
            "connector": ("crestConnectorWidth", "crestConnectorAlpha"),
            "gemSpoke": ("crestSpokeGemWidth", "crestSpokeGemAlpha"),
            "segmentSpoke": ("crestSpokeSegWidth", "crestSpokeSegAlpha"),
            "gemStar": ("crestStarWidth", "crestStarAlpha"),
            "coreRing": ("crestCoreRingWidth", "crestCoreRingAlpha"),
        }
        lines = THEME_JSON["lines"]
        for key, (w, a) in want.items():
            self.assertEqual(lines[key]["width"], TOK[w], key)
            self.assertEqual(lines[key]["opacity"], TOK[a], key)
        self.assertEqual(lines["runeGlyph"]["opacity"], TOK["crestRuneGlyphAlpha"])
        self.assertEqual(lines["node"]["opacity"], TOK["crestNodeAlpha"])
        dash = [float(x) for x in lines["dashedRing"]["dash"].split()]
        self.assertEqual(dash[0], TOK["crestDashedOn"])
        self.assertEqual(dash[1], TOK["crestDashedOff"])
        self.assertEqual(lines["outerEdge"]["widths"], TOK["crestOuterEdgeWidths"])
        self.assertEqual(lines["outerEdge"]["alphas"], TOK["crestOuterEdgeAlphas"])
        self.assertEqual(THEME_JSON["outerColor"], TOK["outerColor"])


class PanelsMirrorTests(unittest.TestCase):
    """config/panels.json ↔ native/Panels.qml ↔ the widget's gemSpecs."""

    def parse_segments(self):
        body = PANELS_QML.split("segments: [", 1)[1].rsplit("]", 1)[0]
        return json.loads("[" + body + "]")

    def parse_gem_specs(self):
        out = []
        for m in re.finditer(
                r'\{ panel:"(\w+)",\s*label:"([^"]+)",\s*color:theme\.(\w+),\s*glyph:"(\w+)" \}',
                WIDGET):
            out.append(m.groups())
        return out

    def test_every_assigned_sigil_exists_and_ships(self):
        # panels.json assigns each segment its emblem; the file must exist and
        # the installer manifest must cover it, or the station draws nothing
        text = (REPO / "installer" / "constants.py").read_text()
        m = re.search(r'sigils/sigil-%02d\.svg" % i for i in range\((\d+), (\d+)\)',
                      text)
        lo, hi = int(m.group(1)), int(m.group(2))
        shipped = {"assets/sigils/sigil-%02d.svg" % i for i in range(lo, hi)}
        assigned = {seg["sigil"] for seg in PANELS["segments"]}
        self.assertTrue(assigned <= shipped, sorted(assigned - shipped))
        for rel in assigned:
            self.assertTrue((NATIVE / rel).is_file(), rel)

    def test_show_labels_is_off_everywhere(self):
        self.assertIs(PANELS["showLabels"], False)
        self.assertIn("readonly property bool showLabels: false", PANELS_QML)

    def test_the_segments_match_the_json(self):
        self.assertEqual(PANELS["segments"], self.parse_segments())

    def test_the_segments_match_the_gem_specs(self):
        specs = self.parse_gem_specs()
        self.assertEqual(len(specs), 5)
        theme_colors = {m.group(1): m.group(2) for m in
                        re.finditer(r'readonly property color (\w+): "(#[0-9a-fA-F]{6})"',
                                    THEME)}
        for seg, (panel, label, color_token, _glyph) in zip(PANELS["segments"], specs):
            self.assertEqual(seg["id"], panel)
            self.assertEqual(seg["label"], label)
            self.assertEqual(seg["gemColor"], theme_colors[color_token], panel)

    def test_every_segment_assigns_a_sigil_file(self):
        for seg in PANELS["segments"]:
            self.assertRegex(seg["sigil"], r"^assets/sigils/sigil-0[1-5]\.svg$")


class MotionMirrorTests(unittest.TestCase):
    """config/motion.json ↔ native/Motion.qml, and the static promises."""

    def test_every_flag_matches(self):
        for key, val in MOTION.items():
            if key == "notes":
                continue
            self.assertEqual(val, MOT[key], key)

    def test_the_web_never_rotates(self):
        self.assertIs(MOTION["webRotation"], False)
        self.assertIn("readonly property bool webRotation: false", MOTION_QML)


if __name__ == "__main__":
    unittest.main()
