"""The hover-preview interaction model: one panel state, two timers, no flicker.

The dashboard used to answer only to clicks, and each panel carried its own open
flag, its own glass and its own opening animation. That is what made the orb flash
when you moved between orbs, why a panel could outlive the thing that opened it,
and why the old fixes (hide the orb, unload the frame, re-run an animation from 0)
kept trading one flicker for another.

Now there is one state — ``activePanel`` plus ``pinned`` — and one orb container
that is never destroyed, never hidden for a panel and never resized. Hover intent
and the leave grace are one timer each. These tests pin the whole model: the three
settings, the single writer, the aliases that keep every other binding honest, the
non-blocking hover areas, the guard that stops a prompt being cleared from under
the user, and the rule that decorative layers never take a click.
"""
import re
import unittest
from pathlib import Path

NATIVE = Path(__file__).resolve().parents[1]
WIDGET = (NATIVE/"SphereWidget.qml").read_text()
FRAME = (NATIVE/"PanelFrame.qml").read_text()
RING = (NATIVE/"MagicRing.qml").read_text()

# the five gems and the five panels they own — one table, no other layout
PANEL_KEYS = ("wifi", "bluetooth", "battery", "resources", "organize")
ALIASES = {
    "wifi": "wifiOpen", "bluetooth": "bluetoothOpen", "battery": "batteryOpen",
    "resources": "resourcesOpen", "organize": "organizerOpen",
}


def function_body(name):
    body = WIDGET.split("function %s(" % name, 1)[1]
    return body.split("\n    function ", 1)[0]


class SettingsTests(unittest.TestCase):
    def test_the_three_numbers_are_at_the_top_of_the_file(self):
        head = WIDGET.split("SETTINGS — everything below reads these", 1)[1].split("signal request", 1)[0]
        self.assertIn("hoverIntentMs: 70", head)
        self.assertIn("leaveGraceMs: 280", head)
        self.assertIn("pinOnClick: true", head)
        # …and the top means the top: above the first panel declaration.
        top = WIDGET.index("hoverIntentMs: 70")
        for marker in ('key:"wifi"', 'key:"organize"', "function openWifi("):
            self.assertLess(top, WIDGET.index(marker), marker)

    def test_the_fades_are_the_ones_the_brief_asked_for(self):
        self.assertIn("switchFadeMs: 140", WIDGET)       # 120–160 ms crossfade
        self.assertIn("clearFadeMs: 150", WIDGET)        # ~150 ms content fade-out
        self.assertTrue(120 <= 140 <= 160)

    def test_the_debug_log_is_off_in_the_shipped_build(self):
        self.assertIn("property bool debugHover: false", WIDGET)
        self.assertIn("function dbg(message) { if(root.debugHover) console.log(", WIDGET)
        # nothing logs unconditionally
        self.assertNotIn("\n    console.log(", WIDGET)


class OneStateTests(unittest.TestCase):
    def test_there_is_exactly_one_panel_state(self):
        self.assertIn('property string activePanel: ""', WIDGET)
        self.assertIn("property bool pinned: false", WIDGET)
        # one writer each way, in the state machine and nowhere else
        self.assertEqual(WIDGET.count("root.activePanel=key;"), 1)
        self.assertEqual(WIDGET.count('root.activePanel="";'), 1)
        self.assertIn("root.activePanel=key;", function_body("showPanel"))
        self.assertIn('root.activePanel="";', function_body("clearPanel"))

    def test_the_five_open_flags_are_views_not_copies(self):
        for key, flag in ALIASES.items():
            self.assertIn("readonly property bool %s: activePanel===\"%s\"" % (flag, key), WIDGET)
            # …and nothing can write them any more
            self.assertNotIn("%s=true" % flag, WIDGET, flag)
            self.assertNotIn("%s=false" % flag, WIDGET, flag)

    def test_system_list_open_still_answers_every_question_asked_of_it(self):
        self.assertIn("readonly property bool systemListOpen: wifiOpen || bluetoothOpen", WIDGET)
        self.assertIn("|| organizerOpen", WIDGET)
        self.assertNotIn("slotOpen", WIDGET)

    def test_showing_a_panel_retires_the_previous_one_first(self):
        show = function_body("showPanel")
        self.assertIn("if(previous.length>0) root.retirePanel(previous);", show)
        self.assertIn("root.enterPanel(key);", show)
        self.assertLess(show.index("retirePanel(previous)"), show.index("enterPanel(key)"))

    def test_every_panel_gets_the_same_teardown_and_setup(self):
        # One switch, six cases: the per-panel work lives here, not in the panels.
        retire = function_body("retirePanel")
        enter = function_body("enterPanel")
        for key in PANEL_KEYS:
            self.assertIn('"%s"' % key, enter, key)          # every panel gets its data
        for key in ("wifi", "bluetooth", "battery", "resources", "organize"):
            self.assertIn('"%s"' % key, retire, key)         # …and the four panels with state get a teardown
        self.assertIn('emitRequest({action:"wifiPanel",open:false})', retire)
        self.assertIn('emitRequest({action:"wifiPanel",open:true})', enter)


class HoverAreaTests(unittest.TestCase):
    def test_two_timers_own_all_the_timing(self):
        self.assertEqual(WIDGET.count("id:hoverIntent"), 1)
        self.assertEqual(WIDGET.count("id:leaveTimer"), 1)
        self.assertIn("interval:root.hoverIntentMs", WIDGET)
        self.assertIn("interval:root.leaveGraceMs", WIDGET)
        for other in ("hoverTimer", "clearTimer", "panelTimer", "closeTimer"):
            self.assertNotIn("id:" + other, WIDGET, other)

    def test_entering_an_area_only_arms_the_intent(self):
        enter = function_body("hoverEnter")
        self.assertIn("root.hoveredAreas=areas;", enter)
        self.assertIn("leaveTimer.stop();", enter)
        self.assertIn("pendingPanel=key;", enter)
        self.assertIn("hoverIntent.restart();", enter)
        # the newest orb wins: the timer is restarted, never queued
        self.assertIn("on the NEWEST orb", enter)

    def test_leaving_every_area_starts_the_grace_and_only_then(self):
        leave = function_body("hoverLeave")
        self.assertIn("if(root.hoverAreaCount()>0) return;", leave)
        self.assertIn("if(root.pinned) { root.dbg(\"pinned: leave ignored\"); return; }", leave)
        self.assertIn("leaveTimer.restart();", leave)

    def test_returning_inside_the_grace_cancels_it(self):
        # leaveTimer is stopped on every enter, so coming back before it fires
        # means the fade never starts — the clear cannot half-happen.
        self.assertIn("leaveTimer.stop();                   // coming back cancels the grace",
                      function_body("hoverEnter"))

    def test_the_disc_and_the_bridges_are_hover_areas(self):
        # the centre is asked of the pointer's own position, not of a square
        self.assertIn("function insideDisc(", WIDGET)
        self.assertIn('hoverEnter("disc", "", -1)', WIDGET)
        self.assertIn('hoverLeave("disc")', WIDGET)
        # and one bridge per gem, from the stone to the disc
        self.assertIn('objectName:"gemBridge"', WIDGET)
        self.assertIn('root.hoverEnter("bridge:"+bridge.index', WIDGET)
        self.assertIn("blocking: false", WIDGET)

    def test_no_full_size_hit_area_sits_above_a_gem(self):
        # the catcher is the only full-screen surface, and it is at the bottom
        catcher = WIDGET.split("id:inputCatcher", 1)[1].split("HoverHandler", 1)[0]
        self.assertIn("z:1", catcher)
        self.assertNotIn("z: 26", WIDGET)  # the plates' hit layer is gone
        self.assertIn("z: 30", WIDGET)     # the gems
        self.assertIn("z:45", WIDGET)      # panels
        # every pointer handler the bridges use is declared non-blocking
        bridges = WIDGET.split('objectName:"gemBridge"', 1)[1].split("\n    }", 1)[0]
        self.assertIn("blocking: false", bridges)
        # and the artwork itself holds no hit area at all
        self.assertNotIn("MouseArea", RING)
        self.assertNotIn("HoverHandler", RING)


class ContainerTests(unittest.TestCase):
    def test_the_ring_is_never_hidden_for_a_panel(self):
        ring = WIDGET.split('id:magicRing;objectName:"magicRing"', 1)[1].split("Repeater {", 1)[0]
        self.assertIn("opacity: root.presence", ring)
        self.assertIn("radius: root.ringR", ring)
        self.assertNotIn("activePanel===", ring.split("activeIndex", 1)[0])
        disc = WIDGET.split('id:disc;objectName:"centreDisc"', 1)[1].split("Behaviour", 1)[0]
        self.assertIn("visible: root.sphereVisible", disc)
        self.assertNotIn("activePanel===", disc)       # it expands; it never unmounts
        self.assertNotIn("Loader", WIDGET)

    def test_only_the_idle_centre_fades(self):
        # the mark and the core (with its clock) are what give way to a panel; the
        # ring and the disc stay exactly where they are
        slot = WIDGET.split('id:logoSlot;objectName:"logoSlot"', 1)[1].split("Image {", 1)[0]
        self.assertIn("opacity: root.discOpen>0.02 ? 0 : 1", slot)
        self.assertIn("Behavior on opacity { NumberAnimation { duration: 200", slot)
        core = WIDGET.split("JarvisCore {", 1)[1].split("\n        }", 1)[0]
        self.assertIn("opacity: root.discOpen>0.02 ? 0 : 1", core)
        self.assertIn("Behavior on opacity { NumberAnimation { duration: 200", core)

    def test_every_panel_is_declared_once_and_never_resized_by_the_state(self):
        self.assertEqual(WIDGET.count("PanelFrame {"), 5)
        for key, flag in ALIASES.items():
            self.assertIn("hosted:true;active:root.%s;switchMs:root.switchFadeMs" % flag, WIDGET)
        # the geometry of a frame is not a function of the active panel
        blocks = WIDGET.split("hosted:true;")
        self.assertEqual(len(blocks) - 1, 5)
        for block in blocks[1:]:
            head = block.split("orbStatus", 1)[0]
            self.assertIn("x:root.width/2-width/2;y:root.height/2-height/2;z:45", head)
            # the size comes from the ring's one radius, never from the state
            self.assertIn("radius:root.orbRadius", head)

    def test_the_frame_crossfades_instead_of_unmounting(self):
        self.assertIn("property bool active: true", FRAME)
        self.assertIn("visible: !hosted || active || keepAlive", FRAME)
        self.assertIn("opacity: hosted ? (active ? 1 : 0) : 0", FRAME)
        self.assertIn("Behavior on opacity { enabled: frame.hosted; NumberAnimation { duration: frame.switchMs",
                      FRAME)
        self.assertIn("id: keepTimer", FRAME)
        self.assertIn("interval: frame.switchMs + 20", FRAME)

    def test_a_hosted_panel_draws_no_second_sphere(self):
        # the old glass orb and its per-panel copy are gone; the frame is a thin
        # gold rim on black inside the one disc the widget owns
        self.assertNotIn("showsGlass", FRAME)
        self.assertNotIn("MainOrb", FRAME)
        self.assertIn('color: "#f2070605"', FRAME)          # the near-black face
        self.assertIn('border.color: frame.withAlpha("#F5B82E", 0.55)', FRAME)
        self.assertNotIn("mainOrb.accent", WIDGET)

    def test_the_boot_in_animation_runs_only_on_a_real_appearance(self):
        self.assertIn("if (hosted) return;                 // the host owns opacity", FRAME)
        self.assertIn("id: openAnim", FRAME)


class PinAndClearTests(unittest.TestCase):
    def test_a_click_pins_and_a_second_click_closes_without_a_hover_fight(self):
        act = function_body("gemActivated")
        self.assertIn('if(root.activePanel===key) {', act)
        self.assertIn("if(!root.pinned) { root.pinned=true;", act)
        self.assertIn("root.suppressArea=", act)
        self.assertIn('root.clearPanel("click again")', act)
        self.assertIn('root.suppressArea=(area && area.length>0) ? area : ("orb:"+index);', act)
        enter = function_body("hoverEnter")
        self.assertIn("if(root.suppressArea===area)", enter)

    def test_a_gem_without_a_panel_could_not_launch_anything(self):
        # the app orbs — and the launcher behind them — went with the assign flow
        act = function_body("gemActivated")
        self.assertIn('if(key==="") return;', act)
        self.assertNotIn("launchOrb", WIDGET)

    def test_escape_and_the_background_unpin_before_they_clear(self):
        keys = WIDGET.split("Keys.onEscapePressed", 1)[1].split("signal dismissRequested", 1)[0]
        self.assertIn('else if(activePanel!=="") { clearPanel("escape")', keys)
        bg = function_body("backgroundClicked")
        self.assertIn('clearPanel("background")', bg)
        self.assertIn("root.pinned=false", function_body("clearPanel"))

    def test_a_prompt_or_a_press_is_never_cleared_from_under_the_user(self):
        self.assertIn("readonly property bool autoClearBlocked", WIDGET)
        blocked = WIDGET.split("readonly property bool autoClearBlocked", 1)[1].split("property var screenNames", 1)[0]
        for token in ("panelModal", "wifiPasswordSsid", "organizerPrompt"):
            self.assertIn(token, blocked, token)
        # the reason a panel is modal lives in the frame, once
        self.assertIn("readonly property bool modalOpen: promptVisible || holdActive || pressedActions > 0", FRAME)
        self.assertIn("readonly property bool promptFocused: promptVisible && promptInput.activeFocus", FRAME)
        # a press on an action chip counts as a hold
        self.assertIn("onPressed: frame.pressedActions = frame.pressedActions + 1", FRAME)

    def test_the_guard_resumes_the_grace_when_the_dialog_closes(self):
        handler = WIDGET.split("onAutoClearBlockedChanged: {", 1)[1].split("\n    }", 1)[0]
        self.assertIn("root.clearWhenFree", handler)
        self.assertIn("leaveTimer.restart()", handler)
        self.assertIn("hoverIntent.restart()", handler)
        grace = function_body("leaveGraceFired")
        self.assertIn("if(root.autoClearBlocked) { root.clearWhenFree=true;", grace)

    def test_polling_never_touches_the_open_state(self):
        for timer, owner in (("interval:2500", "resourcesOpen"), ("interval:5000", "batteryOpen"),
                             ("interval:6000", "wifiOpen"), ("interval:120000", None)):
            block = WIDGET.split(timer, 1)[1].split("}", 1)[0]
            self.assertNotIn("activePanel", block, timer)
            self.assertNotIn("pinned", block, timer)
            if owner:
                self.assertIn("running:root.%s" % owner, WIDGET)

    def test_the_gem_table_obeys_the_same_rules(self):
        # one table decides which panel a stone opens, for hover and for click
        self.assertIn("function panelKeyAt(index) { return root.gemKey(index); }", WIDGET)
        self.assertIn("root.hoverEnter(\"gem:\"+gemSlot.index, root.panelKeyAt(gemSlot.index), gemSlot.index)",
                      WIDGET)
        self.assertIn('onClicked: root.gemActivated(gemSlot.index, "gem:"+gemSlot.index)', WIDGET)
        self.assertNotIn("showSlot(", WIDGET)


class DecorationTests(unittest.TestCase):
    def test_the_panel_surface_is_the_spheres_own_circle(self):
        # A panel is the sphere, so its frosted surface is the sphere's circle —
        # the same centre, the diameter of the glass, `radius: width / 2`. The
        # rounded rectangle it used to be is gone everywhere, including the
        # inset highlight, which stays concentric with it.
        slab = FRAME.split('objectName: frame.key + "PanelScrim"', 1)[1].split(
            'HoverHandler', 1)[0]
        self.assertIn("anchors.centerIn: parent", slab)
        self.assertIn("width: frame.glassR * 2", slab)
        self.assertIn("radius: width / 2", slab)
        self.assertNotIn("safeSide", slab)          # no square footprint left
        self.assertNotIn("width * 0.26", slab)
        self.assertIn("border.width: frame.rimWidth", slab)
        self.assertIn('border.color: frame.withAlpha("#F5B82E", 0.55)', slab)

    def test_the_glass_parts_keep_their_names_and_order(self):
        for part in ("PanelScrim", "PanelBody", "PanelArea", "FrameHover", "Header"):
            self.assertIn('objectName: frame.key + "%s"' % part, FRAME, part)
        # the content still lives inside the inscribed square, so a circle can
        # never crop it: the safe side is what the body is sized from
        self.assertIn("width: frame.safeSide\n        height: frame.safeSide", FRAME)

    def test_the_panel_surface_is_under_its_content_and_inert_when_inactive(self):
        area = FRAME.split('objectName: frame.key + "PanelArea"', 1)[1].split("onClicked", 1)[0]
        # the surface is the square inscribed in the content circle — never the
        # frame's whole 2·radius item, whose corners reach the gems
        self.assertIn("width: frame.glassR * Math.SQRT2 * 0.98", area)
        self.assertIn("anchors.centerIn: parent", area)
        self.assertIn("enabled: frame.interactive", area)

    def test_a_panel_reports_its_own_hover_so_reading_it_never_clears_it(self):
        self.assertIn("signal hoverChanged(bool inside)", FRAME)
        self.assertIn("frame.hoverChanged(frameHover.hovered)", FRAME)
        for key in PANEL_KEYS:
            self.assertIn('root.hoverEnter("panel:%s", "", -1)' % key, WIDGET, key)


if __name__ == "__main__":
    unittest.main()
