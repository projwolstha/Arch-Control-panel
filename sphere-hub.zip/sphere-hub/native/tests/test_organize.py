"""The file organizer: the backend that moves files, and nothing else.

The backend is a standalone script (``native/jarvis-organize``) with a JSON
contract, so it is tested the way it is used: against real temporary folders,
with duplicates, no-extension files, spaces, unicode and half-written downloads.

The safety promises are the important ones here — never delete, never overwrite,
never leave the selected folder, refuse system paths, and undo exactly what the
run did — so each of them gets its own test rather than being implied.
"""
import importlib.machinery
import importlib.util
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

NATIVE = Path(__file__).resolve().parents[1]
SCRIPT = NATIVE / "jarvis-organize"
REPO = NATIVE.parent
PREP = REPO / "shell" / "organize-prep.sh"
CONSTANTS = REPO / "installer" / "constants.py"
DEPLOY = REPO / "installer" / "ops" / "deploy.py"
UNINSTALL = REPO / "installer" / "ops" / "uninstall.py"
SHELL = NATIVE / "shell.qml"
WIDGET = (NATIVE / "SphereWidget.qml").read_text()
FRAME = (NATIVE / "PanelFrame.qml").read_text()
REPO_ONLY = PREP.is_file()


def load_backend():
    loader = importlib.machinery.SourceFileLoader("jarvis_organize", str(SCRIPT))
    spec = importlib.util.spec_from_loader("jarvis_organize", loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


organize = load_backend()


class Fixture(unittest.TestCase):
    """A throw-away $HOME with a Downloads folder and rules with no age floor."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="organize-test-"))
        self.home = self.tmp / "home"
        self.downloads = self.home / "Downloads"
        self.downloads.mkdir(parents=True)
        config = self.home / ".config" / "jarvis"
        config.mkdir(parents=True)
        rules = organize.Rules.default_json()
        rules["options"]["min_age_seconds"] = 0
        (config / "organize.json").write_text(json.dumps(rules, indent=2))
        self.organizer = organize.Organizer(home=self.home, supervise=False)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    # -- helpers ---------------------------------------------------------
    def write(self, name, data=b"x" * 10, folder=None):
        path = (folder or self.downloads) / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def categories(self, summary):
        return {c["name"]: c for c in summary["categories"]}

    def names(self, summary):
        return {c["name"]: sorted(f["name"] for f in c["files"]) for c in summary["categories"]}


class RulesTests(Fixture):
    def test_the_rules_file_is_created_with_the_specified_defaults(self):
        rules_path = self.home / ".config" / "jarvis" / "organize.json"
        rules_path.unlink()
        self.organizer.load_rules()
        self.assertTrue(rules_path.is_file())
        data = json.loads(rules_path.read_text())
        categories = {c["name"]: c["extensions"] for c in data["categories"]}
        self.assertEqual(list(categories), ["Images", "Videos", "Audio", "Documents", "Spreadsheets",
                                            "Presentations", "Archives", "Code", "Installers",
                                            "Fonts", "Other"])
        self.assertEqual(categories["Images"], ["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "heic"])
        self.assertEqual(categories["Videos"], ["mp4", "mkv", "mov", "avi", "webm"])
        self.assertEqual(categories["Audio"], ["mp3", "wav", "flac", "ogg", "m4a"])
        self.assertEqual(categories["Documents"], ["pdf", "doc", "docx", "odt", "txt", "md", "rtf", "epub"])
        self.assertEqual(categories["Spreadsheets"], ["xls", "xlsx", "ods", "csv"])
        self.assertEqual(categories["Presentations"], ["ppt", "pptx", "odp"])
        self.assertEqual(categories["Archives"], ["zip", "tar", "gz", "xz", "7z", "rar", "zst"])
        self.assertEqual(categories["Code"], ["py", "js", "ts", "sh", "c", "cpp", "rs", "go",
                                              "html", "css", "json", "yaml"])
        self.assertEqual([e.lower() for e in categories["Installers"]],
                         ["deb", "rpm", "appimage", "exe", "msi", "iso", "pkg.tar.zst"])
        self.assertEqual(categories["Fonts"], ["ttf", "otf", "woff", "woff2"])
        self.assertEqual(categories["Other"], [])
        self.assertIn("*.part", data["ignore"])

    def test_a_broken_rules_file_falls_back_instead_of_crashing(self):
        (self.home / ".config" / "jarvis" / "organize.json").write_text("{ this is not json")
        rules = self.organizer.load_rules()
        self.assertEqual(rules.category_for_extension("a.png"), "Images")
        self.assertIn("_error", rules.raw)

    def test_extensions_are_matched_case_insensitively_and_by_longest_suffix(self):
        rules = organize.Rules(organize.Rules.default_json())
        self.assertEqual(rules.category_for_extension("PIC.JPG"), "Images")
        self.assertEqual(rules.category_for_extension("setup.pkg.tar.zst"), "Installers")
        self.assertEqual(rules.category_for_extension("anything.zst"), "Archives")
        self.assertEqual(rules.category_for_extension("MyApp.AppImage"), "Installers")
        self.assertEqual(rules.category_for_extension("archive.tar.gz"), "Archives")
        self.assertIsNone(rules.category_for_extension("mystery"))

    def test_the_ignore_list_comes_from_the_rules_file(self):
        rules = organize.Rules({"categories": [{"name": "Images", "extensions": ["png"]}],
                                "ignore": ["*.keep"]})
        self.assertTrue(rules.ignored("photo.KEEP"))
        self.assertFalse(rules.ignored("photo.png"))


class ScanTests(Fixture):
    def test_scan_plans_moves_and_never_touches_the_disk(self):
        self.write("holiday photo.png")
        self.write("notes.txt")
        summary = self.organizer.scan(str(self.downloads))
        self.assertTrue(summary["ok"])
        self.assertEqual(summary["files"], 2)
        self.assertEqual(self.names(summary), {"Images": ["holiday photo.png"],
                                               "Documents": ["notes.txt"]})
        self.assertEqual(summary["destination"], "inside")
        self.assertFalse((self.downloads / "Images").exists(), "scan must not create folders")
        self.assertTrue(summary["dry_run"])

    def test_names_with_spaces_and_unicode_survive_the_round_trip(self):
        names = ["Résumé final.pdf", "café ☕.txt", "photo 2024 (1).png", "日本語のメモ.md",
                 "naïve track.mp3"]
        for name in names:
            self.write(name)
        summary = self.organizer.scan(str(self.downloads))
        planned = sorted(f["name"] for c in summary["categories"] for f in c["files"])
        self.assertEqual(planned, sorted(names))
        for item in (f for c in summary["categories"] for f in c["files"]):
            self.assertIn(item["name"], item["target"])

    def test_a_file_without_an_extension_is_classified_by_mime(self):
        self.write("no-extension", b"This is plainly a text file, written to disk.\n")
        summary = self.organizer.scan(str(self.downloads))
        self.assertEqual(self.names(summary), {"Documents": ["no-extension"]})
        item = summary["categories"][0]["files"][0]
        self.assertTrue(item["match"].startswith("mime:") or item["match"] == "fallback")

    def test_unknown_files_land_in_other(self):
        self.write("blob.qqq", b"\x00\x01\x02")
        summary = self.organizer.scan(str(self.downloads))
        self.assertEqual(self.names(summary), {"Other": ["blob.qqq"]})

    def test_hidden_incomplete_symlinked_and_recent_files_are_skipped(self):
        self.write(".hidden.txt")
        self.write("download.part")
        self.write("partial.crdownload")
        self.write("half.tmp")
        self.write("real.png")
        target = self.write("target.txt")
        os.symlink(target, self.downloads / "link.txt")
        rules = json.loads((self.home / ".config" / "jarvis" / "organize.json").read_text())
        rules["options"]["min_age_seconds"] = 3600          # everything is "recent" now
        (self.home / ".config" / "jarvis" / "organize.json").write_text(json.dumps(rules))
        summary = self.organizer.scan(str(self.downloads))
        self.assertEqual(summary["files"], 0)
        reasons = {item["name"]: item["reason"] for item in summary["skipped"]["items"]}
        self.assertIn("hidden", reasons[".hidden.txt"])
        self.assertIn("incomplete", reasons["download.part"])
        self.assertIn("symlink", reasons["link.txt"])
        self.assertTrue(any("last" in r for r in reasons.values()))

    def test_the_top_level_only_unless_subfolders_are_enabled(self):
        self.write("top.png")
        self.write("middle.mp3", folder=self.downloads / "nested")
        self.assertEqual(self.organizer.scan(str(self.downloads))["files"], 1)
        summary = self.organizer.scan(str(self.downloads), include_subfolders=True)
        self.assertEqual(summary["files"], 2)
        rels = sorted(f["rel"] for c in summary["categories"] for f in c["files"])
        self.assertEqual(rels, ["nested/middle.mp3", "top.png"])

    def test_existing_category_folders_are_not_walked_into(self):
        self.write("Images/already-sorted.png")
        summary = self.organizer.scan(str(self.downloads), include_subfolders=True)
        self.assertEqual(summary["files"], 0, "a category folder must not be re-sorted into itself")

    def test_a_name_collision_is_planned_as_a_renamed_target(self):
        self.write("photo.png")
        self.write("Images/photo.png", b"older")
        summary = self.organizer.scan(str(self.downloads))
        item = summary["categories"][0]["files"][0]
        self.assertTrue(item["renamed"])
        self.assertEqual(Path(item["target"]).name, "photo (1).png")


class SafetyTests(Fixture):
    def test_system_paths_are_refused(self):
        for path in ("/", "/usr", "/etc", "/bin", "/proc", "/sys", "/boot", str(self.home)):
            resolved, reason = self.organizer.refuse(path)
            self.assertIsNone(resolved, path)
            self.assertTrue(reason)
        resolved, reason = self.organizer.refuse(str(self.home / ".config"))
        self.assertIsNone(resolved)
        self.assertIn("configuration", reason)

    def test_relative_missing_and_symlinked_folders_are_refused(self):
        self.assertIn("absolute", self.organizer.refuse("Downloads")[1])
        self.assertIn("does not exist", self.organizer.refuse(str(self.home / "Ghost"))[1])
        os.symlink(self.downloads, self.home / "Link")
        self.assertIn("symlink", self.organizer.refuse(str(self.home / "Link"))[1])

    def test_a_refused_folder_still_answers_json(self):
        summary = self.organizer.scan("/etc")
        self.assertFalse(summary["ok"])
        self.assertIn("system path", summary["error"])
        self.assertEqual(self.organizer.run("/etc", stream=lambda obj: None)["ok"], False)

    def test_nothing_is_ever_deleted(self):
        self.write("photo.png")
        self.write("notes.txt")
        result = self.organizer.run(str(self.downloads), stream=lambda obj: None)
        self.assertEqual(result["moved"], 2)
        self.assertTrue((self.downloads / "Images" / "photo.png").is_file())
        self.assertTrue((self.downloads / "Documents" / "notes.txt").is_file())
        undone = self.organizer.undo()
        self.assertEqual(undone["restored"], 2)
        self.assertTrue((self.downloads / "photo.png").is_file())
        self.assertTrue((self.downloads / "notes.txt").is_file())

    def test_an_existing_file_is_never_overwritten(self):
        self.write("photo.png", b"NEW")
        self.write("Images/photo.png", b"OLD")
        self.organizer.run(str(self.downloads), stream=lambda obj: None)
        self.assertEqual((self.downloads / "Images" / "photo.png").read_bytes(), b"OLD")
        self.assertEqual((self.downloads / "Images" / "photo (1).png").read_bytes(), b"NEW")
        # …and the next run keeps counting up instead of reusing the suffix
        self.write("photo.png", b"NEWER")
        self.organizer.run(str(self.downloads), stream=lambda obj: None)
        self.assertEqual((self.downloads / "Images" / "photo (2).png").read_bytes(), b"NEWER")

    def test_the_unique_name_handles_compound_suffixes(self):
        folder = self.tmp / "c"
        folder.mkdir()
        (folder / "archive.tar.gz").write_bytes(b"1")
        once = organize.unique_path(folder / "archive.tar.gz")
        self.assertEqual(once.name, "archive (1).tar.gz")
        (folder / "archive (1).tar.gz").write_bytes(b"2")
        twice = organize.unique_path(folder / "archive.tar.gz")
        self.assertEqual(twice.name, "archive (2).tar.gz")


class RunTests(Fixture):
    def test_run_moves_everything_and_reports_progress(self):
        for name in ("a.png", "b.mp4", "c.zip", "notes.txt", "script.py"):
            self.write(name)
        events = []
        result = self.organizer.run(str(self.downloads), stream=events.append)
        self.assertTrue(result["ok"])
        self.assertEqual(result["moved"], 5)
        self.assertEqual(result["skipped"], 0)
        self.assertTrue(result["undo_available"])
        self.assertEqual([e["done"] for e in events], [1, 2, 3, 4, 5])
        self.assertEqual(events[-1]["percent"], 100.0)
        self.assertEqual(sorted(p.name for p in (self.downloads / "Images").iterdir()), ["a.png"])
        self.assertEqual(sorted(p.name for p in (self.downloads / "Videos").iterdir()), ["b.mp4"])

    def test_the_undo_log_is_one_json_file_per_run(self):
        self.write("a.png")
        self.organizer.run(str(self.downloads), stream=lambda obj: None)
        logs = sorted(self.organizer.state_dir.glob("undo-*.json"))
        self.assertEqual(len(logs), 1)
        record = json.loads(logs[0].read_text())
        self.assertEqual(len(record["moves"]), 1)
        self.assertEqual(Path(record["moves"][0]["from"]).name, "a.png")
        self.assertEqual(Path(record["moves"][0]["to"]).name, "a.png")
        self.assertIn(str(self.downloads / "Images"), record["created_dirs"])
        self.assertIsNone(record["undone"])

    def test_undo_restores_everything_and_removes_only_the_folders_it_created(self):
        self.write("a.png")
        self.write("b.mp4")
        (self.downloads / "Documents").mkdir()          # pre-existing: must survive
        self.write("Documents/keep.txt", b"keep")
        self.organizer.run(str(self.downloads), stream=lambda obj: None)
        result = self.organizer.undo()
        self.assertTrue(result["ok"])
        self.assertEqual(result["restored"], 2)
        self.assertEqual(sorted(p.name for p in self.downloads.iterdir()),
                         ["Documents", "a.png", "b.mp4"])
        self.assertTrue((self.downloads / "Documents" / "keep.txt").is_file())
        self.assertFalse((self.downloads / "Images").exists())
        self.assertFalse((self.downloads / "Videos").exists())

    def test_undo_twice_walks_back_one_run_at_a_time_and_then_says_so(self):
        self.write("a.png")
        self.organizer.run(str(self.downloads), stream=lambda obj: None)
        self.write("b.mp4")
        self.organizer.run(str(self.downloads), stream=lambda obj: None)
        first = self.organizer.undo()
        self.assertEqual(first["restored"], 1)
        self.assertEqual(first["undo_available"], True, "the earlier run is still undoable")
        second = self.organizer.undo()
        self.assertEqual(second["restored"], 1)
        third = self.organizer.undo()
        self.assertEqual(third["restored"], 0)
        self.assertEqual(third["message"], "Nothing to undo.")

    def test_undo_does_not_clobber_a_file_that_came_back(self):
        self.write("photo.png", b"NEW")
        self.organizer.run(str(self.downloads), stream=lambda obj: None)
        self.write("photo.png", b"REPLACEMENT")
        result = self.organizer.undo()
        self.assertEqual(result["restored"], 1)
        self.assertEqual((self.downloads / "photo.png").read_bytes(), b"REPLACEMENT")
        self.assertEqual((self.downloads / "photo (1).png").read_bytes(), b"NEW")

    def test_a_central_destination_is_used_when_chosen(self):
        central = self.home / "Documents" / "Sorted"
        self.write("a.png")
        self.write("b.mp4")
        self.organizer.set_config("central", str(central))
        result = self.organizer.run(str(self.downloads), stream=lambda obj: None)
        self.assertEqual(result["moved"], 2)
        self.assertTrue((central / "Images" / "a.png").is_file())
        self.assertTrue((central / "Videos" / "b.mp4").is_file())
        self.assertEqual([p.name for p in self.downloads.iterdir()], [])
        self.organizer.undo()
        self.assertTrue((self.downloads / "a.png").is_file())
        self.assertFalse((central / "Images").exists())


class StatusTests(Fixture):
    def test_status_reports_the_folders_auto_schedule_and_undo(self):
        status = self.organizer.status()
        self.assertEqual(status["folders"], ["~/Downloads"])
        self.assertEqual(status["auto"], False)
        self.assertEqual(status["schedule"], "manual")
        self.assertEqual(status["undo_available"], False)
        self.assertTrue(status["rules"].endswith(".config/jarvis/organize.json"))
        self.write("a.png")
        self.organizer.run(str(self.downloads), stream=lambda obj: None)
        status = self.organizer.status()
        self.assertEqual(status["undo_available"], True)
        self.assertEqual(status["last_run"]["moved"], 1)

    def test_folders_can_be_added_removed_and_set(self):
        videos = self.home / "Videos"
        videos.mkdir()
        self.assertEqual(self.organizer.set_folders("add", str(videos))["folders"],
                         ["~/Downloads", "~/Videos"])
        self.assertEqual(self.organizer.set_folders("remove", str(videos))["folders"], ["~/Downloads"])
        self.assertEqual(self.organizer.set_folders("set", str(videos))["folders"], ["~/Videos"])
        error = self.organizer.set_folders("remove", str(videos))
        self.assertFalse(error["ok"], "the last folder cannot be removed")
        self.assertFalse(self.organizer.set_folders("add", "/etc")["ok"])

    def test_auto_and_schedule_persist_in_the_state_file(self):
        state = self.organizer.load_state()
        state["auto"] = True
        state["schedule"] = "daily"
        self.organizer.save_state(state)
        again = organize.Organizer(home=self.home, supervise=False)
        self.assertTrue(again.status()["auto"])
        self.assertEqual(again.status()["schedule"], "daily")

    def test_a_folder_that_disappeared_is_reported_not_crashed(self):
        state = self.organizer.load_state()
        state["folders"] = [str(self.home / "Gone")]
        self.organizer.save_state(state)
        status = self.organizer.status()
        self.assertEqual(status["folder_exists"], False)
        self.assertFalse(self.organizer.scan(status["folder"])["ok"])


class WatchTests(Fixture):
    def test_a_new_download_is_sorted_after_its_size_settles(self):
        self.write("already-here.png")          # pre-existing: must be left alone
        events = []
        stop = lambda: any(e["event"] == "moved" for e in events)
        thread = threading.Thread(target=lambda: self.organizer.watch(
            [str(self.downloads)], interval=0.05, stable=0.2, stream=events.append, stop=stop))
        thread.start()
        try:
            time.sleep(0.3)
            self.write("download.mp3", b"a" * 10)
            time.sleep(0.1)
            self.write("download.mp3", b"a" * 400)      # still growing
            thread.join(timeout=8)
        finally:
            thread.join(timeout=1)
        self.assertTrue((self.downloads / "already-here.png").is_file(),
                        "a file that was already there is not a download")
        self.assertTrue((self.downloads / "Audio" / "download.mp3").is_file())
        moved = [e for e in events if e["event"] == "moved"]
        self.assertEqual([e["name"] for e in moved], ["download.mp3"])

    def test_watch_refuses_a_system_folder(self):
        result = self.organizer.watch(["/etc"], max_cycles=1, interval=0.01)
        self.assertFalse(result["ok"])


class CliTests(Fixture):
    """The commands the panel runs, executed exactly as the panel runs them."""

    def cli(self, *args, timeout=60):
        env = dict(os.environ, HOME=str(self.home),
                   XDG_CONFIG_HOME=str(self.home / ".config"),
                   XDG_STATE_HOME=str(self.home / ".local/state"))
        return subprocess.run([sys.executable, str(SCRIPT)] + list(args), capture_output=True,
                              text=True, timeout=timeout, env=env)

    def test_scan_prints_one_json_object(self):
        self.write("a.png")
        result = self.cli("scan", str(self.downloads))
        self.assertEqual(result.returncode, 0, result.stderr)
        data = json.loads(result.stdout)
        self.assertEqual(data["command"], "scan")
        self.assertEqual(data["files"], 1)

    def test_run_dry_run_prints_a_readable_table_and_moves_nothing(self):
        self.write("a.png")
        self.write("notes.txt")
        result = self.cli("run", str(self.downloads), "--dry-run")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("PREVIEW", result.stdout)
        self.assertIn("Images", result.stdout)
        self.assertIn("DRY RUN", result.stdout)
        self.assertNotIn('"event"', result.stdout)
        self.assertTrue((self.downloads / "a.png").is_file())

    def test_run_then_undo_through_the_cli(self):
        self.write("a.png")
        run = self.cli("run", str(self.downloads))
        self.assertEqual(run.returncode, 0, run.stderr)
        lines = [json.loads(line) for line in run.stdout.splitlines() if line.strip()]
        self.assertEqual(lines[-1]["event"], "done")
        self.assertEqual(lines[-1]["moved"], 1)
        undo = self.cli("undo")
        data = json.loads(undo.stdout)
        self.assertEqual(data["restored"], 1)
        self.assertTrue((self.downloads / "a.png").is_file())

    def test_a_refusal_exits_cleanly_with_json(self):
        data = json.loads(self.cli("scan", "/usr").stdout)
        self.assertFalse(data["ok"])
        self.assertIn("system path", data["error"])

    def test_status_folders_and_version(self):
        self.assertEqual(json.loads(self.cli("version").stdout)["version"], organize.VERSION)
        status = json.loads(self.cli("status").stdout)
        self.assertEqual(status["folders"], ["~/Downloads"])
        videos = self.home / "Videos"
        videos.mkdir()
        added = json.loads(self.cli("folders", "add", str(videos)).stdout)
        self.assertEqual(len(added["folders"]), 2)


@unittest.skipUnless(REPO_ONLY, "installer and shell sources are repo-only")
class PackagingTests(unittest.TestCase):
    def test_the_backend_ships_and_is_installed_into_local_bin(self):
        self.assertTrue(SCRIPT.is_file())
        self.assertTrue(os.access(SCRIPT, os.R_OK))
        deploy = DEPLOY.read_text()
        self.assertIn("install_organizer", deploy)
        self.assertIn('"jarvis-organize"', deploy)
        self.assertIn("0o755", deploy)

    def test_the_installer_creates_the_rules_file_and_never_overwrites_it(self):
        deploy = DEPLOY.read_text()
        self.assertIn("organize.json", deploy)
        self.assertIn("organize.json\").exists()", deploy)

    def test_uninstall_removes_the_command_but_keeps_my_rules(self):
        text = UNINSTALL.read_text()
        self.assertIn("jarvis-organize", text)
        self.assertNotIn('unlink(missing_ok=True)\n        (Path.home()/".config"/"jarvis"/"organize.json")', text)

    def test_the_prep_script_installs_only_what_is_used(self):
        prep = PREP.read_text()
        for package in ("python", "xdg-utils", "file"):
            self.assertIn(package, prep)
        self.assertIn("pacman -S --needed --noconfirm", prep)
        self.assertIn("organize.json", prep)
        # polling is used, not inotifywait, so inotify-tools is not requested
        self.assertNotIn("inotify-tools", prep.split("packages=", 1)[1].split("\n", 1)[0])

    def test_the_shell_runs_the_backend_and_the_widget_only_shows_json(self):
        shell = SHELL.read_text()
        self.assertIn("jarvis-organize", shell)
        self.assertIn("onOrganizerRequest", shell)
        # the widget never moves a file: it has no filesystem calls at all
        for forbidden in ("shutil", "os.rename", "moveFile", "FolderListModel"):
            self.assertNotIn(forbidden, WIDGET)
