"""The shared panel frame: one layout, every panel.

The panels used to carry their own copy of the layout, which is how their headers
ended up outside the sphere's curve and their rows past the rim. Now there is one
component — ``PanelFrame.qml`` — that owns the glass, the frosted slab, the safe
area, the vertical structure, the scales, the scrolling, the fade edges and the
action row. A panel only hands over data.

These tests pin that structure, the geometry that keeps content inside the circle
at every orb size, and the promise that a new panel inherits all of it for free.
"""
import math
import re
import unittest
from pathlib import Path

NATIVE = Path(__file__).resolve().parents[1]
WIDGET = (NATIVE/"SphereWidget.qml").read_text()
FRAME = (NATIVE/"PanelFrame.qml").read_text()

# the panels that exist today, in the order they are declared
PANEL_KEYS = ("wifi", "bluetooth", "battery", "system", "organize")

# the constants the QML is mirrored from, for the size sweep at the bottom
GLASS_RATIO = 0.80          # the content circle, as a fraction of the open disc
SAFE_INSET = 0.935          # the margin the inscribed square keeps off the rim
ORB_RADIUS_AT_UI_SCALE_1 = 150


def panel_block(key):
    start = WIDGET.index('key:"%s"' % key)
    return WIDGET[start:WIDGET.index("\n    }\n", start)]


def safe_side(radius):
    return radius*GLASS_RATIO*math.sqrt(2)*SAFE_INSET


class FrameComponentTests(unittest.TestCase):
    def test_the_frame_exists_and_ships_with_the_payload(self):
        self.assertTrue((NATIVE/"PanelFrame.qml").is_file())
        # In an installed config the installer lives elsewhere; the payload
        # inventory is only readable in a checkout.
        constants = NATIVE.parent/"installer"/"constants.py"
        if not constants.is_file():
            self.skipTest("installer sources are repo-only")
        self.assertIn('"PanelFrame.qml"', constants.read_text())

    def test_every_panel_uses_the_frame_and_nothing_else(self):
        # Five panels: Wi-Fi, Bluetooth, Battery, System and the file organizer.
        # Every one is a PanelFrame instance, which is the whole point: the fifth
        # cost no layout code, and the empty-slot placeholder is gone with the
        # three "+" orbs it existed for.
        self.assertEqual(WIDGET.count("PanelFrame {"), len(PANEL_KEYS))
        for key in PANEL_KEYS:
            block = panel_block(key)
            self.assertIn("radius:root.orbRadius", block, key)
            self.assertIn("uiScale:root.uiScale", block, key)
            # a panel brings data, never structure
            for forbidden in ("Rectangle", "ListView", "MouseArea", "Canvas",
                              "ColumnLayout", "RowLayout", "Text {"):
                self.assertNotIn(forbidden, block, "%s must not declare a %s" % (key, forbidden))
            # …and it is only wired through the frame's own signals
            self.assertIn("onClose:", block, key)
            self.assertIn("onAction:", block, key)

    def test_a_new_panel_inherits_the_layout_for_free(self):
        # The only thing a panel hands the frame is data; every layout decision
        # lives in one component, so a sixth panel cannot drift out of alignment.
        for prop in ('property string mode: "list"', 'property var items: []',
                     'property var actions: []', 'property string title: ""',
                     'property string status: ""', 'property string tone: "neutral"'):
            self.assertIn(prop, FRAME)
        # the frame draws each of those exactly once
        self.assertEqual(FRAME.count("ListView {"), 1)
        self.assertEqual(FRAME.count("PanelGlyph {"), 4)      # header, row glyph, row badge, empty state

    def test_the_vertical_structure_is_fixed_and_centred(self):
        order = ['objectName: frame.key + "Header"',
                 'objectName: frame.key + "Rule"',
                 'objectName: frame.key + "StatusRow"',
                 'objectName: frame.key + "Body"',
                 'objectName: frame.key + "Actions"']
        positions = [FRAME.index(token) for token in order]
        self.assertEqual(positions, sorted(positions), "header → rule → status → body → actions")
        # one column, anchored to the safe area, so everything is centred on it
        self.assertIn('anchors.fill: parent\n            spacing: frame.u * 7', FRAME)

    def test_the_close_button_sits_inside_the_safe_area(self):
        header = FRAME.split('objectName: frame.key + "Header"', 1)[1]
        header = header.split('objectName: frame.key + "Rule"', 1)[0]
        self.assertIn('objectName: frame.key + "CloseArea"', header)
        # the state sits immediately left of the disc (it is *anchored* to it,
        # which is what keeps both inside the safe area at every orb size)
        self.assertIn("anchors.right: frame.showClose ? closeDisc.left : parent.right",
                      header)
        self.assertIn("anchors.right: stateText.visible ? stateText.left", header)
        # it is anchored inside the header, not stretched with it
        self.assertIn("anchors.right: parent.right", header)
        self.assertIn("anchors.verticalCenter: parent.verticalCenter", header)
        # the close disc is one spacing step, never a fixed size
        self.assertIn("width: frame.s3\n                    height: frame.s3", header)

    def test_one_spacing_scale_and_one_type_scale(self):
        for step in ("readonly property real s1: u * 4", "readonly property real s2: u * 8",
                     "readonly property real s3: u * 12", "readonly property real s4: u * 16"):
            self.assertIn(step, FRAME)
        self.assertIn("readonly property real u: radius / 200", FRAME)
        for step in ("readonly property real fsTitle:", "readonly property real fsValue:",
                     "readonly property real fsLabel:", "readonly property real fsCaption:"):
            self.assertIn(step, FRAME)
        # one family, resolved once
        # one family, handed in by the widget so the panels match the plates
        self.assertIn("property string typeFamily: Qt.application.font.family", FRAME)
        self.assertEqual(FRAME.count("font.family:"), FRAME.count("font.family: frame.typeFamily"))
        # tabular figures for every number, guarded so an older Qt cannot break it
        self.assertIn("function tabular(target)", FRAME)
        self.assertIn('target.font.features = { "tnum": 1 }', FRAME)

    def test_no_panel_carries_a_pixel_size(self):
        tree = FRAME.split("width: radius * 2", 1)[1]
        code = "\n".join(line.split("//", 1)[0] for line in tree.splitlines())
        code = re.sub(r"spacing:\s*0\b", "", code)                 # a zero gap
        code = re.sub(r"(?<![\d.])1(?![\d.])", "", code)           # 1 px hairlines
        self.assertNotRegex(code, r"(?:width|height|radius|spacing|pixelSize)\s*:\s*\d+(?:\.\d+)?\b")

    def test_glass_slab_border_and_highlight(self):
        # dark frosted surface, thin light border, soft inner highlight
        self.assertIn('readonly property color cSlab: withAlpha(mix(cPaint, "#05090f", 0.66), 0.62)', FRAME)
        # …a thin gold rim on black, at the radius the disc left for it
        self.assertIn("border.width: frame.rimWidth", FRAME)
        self.assertIn('border.color: frame.withAlpha("#F5B82E", 0.55)', FRAME)
        # The surface is the sphere's own circle — never a rounded card inside it.
        self.assertIn("radius: width / 2", FRAME)
        self.assertNotIn("radius: width * 0.26", FRAME)
        # …and the old glass orb is gone with the rest of the sphere's innards
        self.assertNotIn("MainOrb {", FRAME)
        self.assertNotIn("glassAccent", FRAME)

    def test_semantic_accents(self):
        # green good, amber warning, red critical, gold neutral — the ring's gold
        # is the panel's default accent; the semantic tones stay for the data
        for colour in ('"#55f49a"', '"#ffd36a"', '"#ff7777"', '"#F5B82E"'):
            self.assertIn(colour, FRAME)

    def test_the_open_transition_is_short_and_never_delays_input(self):
        self.assertIn("property int openMs: 170", FRAME)
        self.assertTrue(150 <= 170 <= 200)
        self.assertIn("NumberAnimation { target: frame; property: \"opacity\"", FRAME)
        self.assertIn("NumberAnimation { target: frame; property: \"scale\"", FRAME)
        # opacity/scale are painted only: nothing may turn them into a gate
        for gate in ("enabled: opacity", "enabled: frame.opacity", "visible: opacity",
                     "visible: frame.opacity", "containsMouse && opacity"):
            self.assertNotIn(gate, FRAME)
        # The widget still owns which panel is the active one; the frame decides
        # when it is mounted, so the outgoing panel can finish its crossfade.
        self.assertIn("hosted:true;active:root.wifiOpen;switchMs:root.switchFadeMs", WIDGET)
        self.assertIn("visible: !hosted || active || keepAlive", FRAME)
        # …and opacity is still paint only: nothing may turn it into a gate.
        self.assertNotIn("enabled: opacity", FRAME)


class SafeAreaTests(unittest.TestCase):
    def test_the_safe_area_is_the_inscribed_square_with_a_margin(self):
        self.assertIn("readonly property real glassR: radius * 0.80", FRAME)
        self.assertIn("readonly property real safeSide: glassR * Math.SQRT2 * 0.935", FRAME)
        # …and it is clipped, as the safety net under every other rule
        self.assertIn("width: frame.safeSide\n        height: frame.safeSide\n        clip: true", FRAME)

    def test_rows_are_narrowed_by_the_chord_at_their_own_height(self):
        self.assertIn("function chordHalf(dy)", FRAME)
        self.assertIn("var r = glassR - s1;", FRAME)
        self.assertIn("return Math.min(safeSide, chordHalf(dy) * 2 * 0.97);", FRAME)
        self.assertIn("width: frame.rowWidth(row.y + row.height / 2 - bodyArea.height / 2)", FRAME)

    def test_the_chord_never_lets_a_row_touch_the_rim(self):
        for radius in (60, 97, 150, 218, 260, 330, 420):
            glass = radius*GLASS_RATIO
            for frac in (-0.5, -0.25, 0.0, 0.25, 0.5):
                dy = safe_side(radius)/2*frac
                half = min(safe_side(radius)/2,
                           math.sqrt(max(0.0, (glass - radius/200*4)**2 - dy*dy))*0.97)
                # the far corner of a row that wide still lies inside the glass
                corner = math.hypot(half, abs(dy))
                self.assertLess(corner, glass, "radius %s, dy %s" % (radius, dy))

    def test_every_size_inside_the_body_is_a_fraction_of_the_radius(self):
        # nothing in the frame may be pinned to the screen or to a fixed pixel
        for fixed in ("*root.uiScale", "orbUnit"):
            self.assertNotIn(fixed, FRAME)


class ContentAdaptationTests(unittest.TestCase):
    def test_lists_scroll_inside_their_own_clipped_area(self):
        body = FRAME.split('objectName: frame.key + "Body"', 1)[1].split("// ── action row", 1)[0]
        self.assertIn("clip: true", body)
        self.assertIn("boundsBehavior: Flickable.StopAtBounds", body)
        self.assertIn("ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }", body)
        self.assertIn('objectName: frame.key + "FadeTop"', body)
        self.assertIn('objectName: frame.key + "FadeBottom"', body)
        # a fade is only drawn when there really is more content that way
        self.assertIn("list.contentHeight > list.height + 1 && !list.atYEnd", body)
        self.assertIn("valueFlick.contentHeight > valueFlick.height + 1", body)

    def test_long_text_elides_instead_of_overflowing(self):
        self.assertGreaterEqual(FRAME.count("elide: Text.ElideRight"), 8)
        self.assertIn("wrapMode: Text.WordWrap", FRAME)
        self.assertIn("maximumLineCount: 4", FRAME)       # the empty state

    def test_a_small_orbit_drops_detail_instead_of_shrinking_type(self):
        # a floor under every size, and three explicit adaptations
        self.assertIn("readonly property real fsCaption: Math.max(7.0, u * 6.9)", FRAME)
        self.assertIn("readonly property bool compact: radius < 155", FRAME)
        self.assertIn("readonly property bool hasStatusRoom: safeSide >= 152", FRAME)
        # the facts stay in two columns at every size — stacking them in one
        # column is what used to push the segmented control under the rim
        self.assertIn("columns: 2", FRAME)
        self.assertNotIn("columns: frame.compact ? 1 : 2", FRAME)
        self.assertIn("visible: !frame.compact", FRAME.split('objectName: frame.key + "Header"', 1)[1]
                      .split('objectName: frame.key + "Rule"', 1)[0])   # the header icon


class PanelCoverageTests(unittest.TestCase):
    def test_every_panel_is_present(self):
        for key in PANEL_KEYS:
            self.assertIn('key:"%s"' % key, WIDGET, key)

    def test_the_placeholder_panel_is_gone_with_the_plus_orbs(self):
        # The three empty "+" orbs, their placeholder panel and the whole assign
        # flow were removed; there is no sixth panel and nothing to assign.
        for gone in ('key:"slot"', "function openSlot(", "function slotPanelAction(",
                     "slotAssignChip", "Empty slot"):
            self.assertNotIn(gone, WIDGET, gone)
        self.assertEqual(WIDGET.count("PanelFrame {"), 5)
        self.assertIn("systemListOpen: wifiOpen || bluetoothOpen || batteryOpen || resourcesOpen || organizerOpen",
                      WIDGET)

    def test_battery_is_the_ring_dashboard_the_brief_asked_for(self):
        block = panel_block("battery")
        self.assertIn('mode:root.batteryPresent ? "value" : "empty"', block)
        self.assertIn('value:root.batteryLevel>=0 ? root.batteryLevel+"%" : "—"', block)
        self.assertIn("ring:root.batteryLevel>=0 ? root.batteryLevel/100 : -1", block)
        self.assertIn("stats:root.batteryStats()", block)
        self.assertIn("segments:root.batterySegments()", block)
        stats = WIDGET.split("function batteryStats()", 1)[1].split("function ", 1)[0]
        for label in ('"Draw"', '"Health"', '"Cycles"', '"Voltage"'):
            self.assertIn(label, stats)

    def test_system_is_ram_ring_plus_bars_plus_chips(self):
        block = panel_block("system")
        self.assertIn("ringSecondary:root.diskPercent>=0 ? root.diskPercent/100 : -1", block)
        self.assertIn("bars:root.systemBars()", block)
        self.assertIn("tags:root.systemTags()", block)
        bars = WIDGET.split("function systemBars()", 1)[1].split("function ", 1)[0]
        self.assertIn('label:"Swap"', bars)
        self.assertIn("label:d.target", bars)

    def test_wifi_and_bluetooth_are_stacked_cards_with_scan_and_power(self):
        for chip in ('objectName:"wifiScanChip"', 'objectName:"wifiRadioChip"',
                     'objectName:"bluetoothScanChip"', 'objectName:"bluetoothPowerChip"'):
            self.assertIn(chip, WIDGET)
        # the buttons are the frame's action row; a panel only names them
        self.assertIn('actions:root.wifiActions()', panel_block("wifi"))
        self.assertIn('actions:root.bluetoothActions()', panel_block("bluetooth"))
        # the row renderer is the frame's rounded card
        self.assertIn("delegate: Rectangle {", FRAME)
        self.assertIn("radius: frame.s2", FRAME)
        self.assertIn("elide: Text.ElideRight", FRAME)


if __name__ == "__main__":
    unittest.main()
