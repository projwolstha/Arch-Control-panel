"""Which package manager the installer uses on this machine.

The bug this guards: on Bedrock Linux `/etc/os-release` can describe a Debian
stratum while pacman owns every package the desktop runs, so the installer must
not decide from the release file alone. Arch wins whenever Arch owns the root;
`SPHERE_PKG_MANAGER` overrides the guess.

These checks need the installer source, which is not part of the deployed
payload, so the class skips cleanly in ~/.config/quickshell/sphere-hub.
"""
import os
import pathlib
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

NATIVE = Path(__file__).resolve().parents[1]
REPO = NATIVE.parent
sys.path.insert(0, str(REPO))

HAVE_INSTALLER = (REPO / "installer").is_dir()
HAVE_SOURCE_TREE = HAVE_INSTALLER and (REPO / "shell" / "preflight.sh").is_file()


@unittest.skipUnless(HAVE_INSTALLER, "installer source is not part of the deployed payload")
class ManagerDetectionTests(unittest.TestCase):
    def setUp(self):
        from installer import packages
        self.packages = packages
        self.tmp = tempfile.TemporaryDirectory()
        self.bin = Path(self.tmp.name) / "bin"
        self.bin.mkdir()
        self.saved_path = os.environ.get("PATH", "")
        self.saved_force = os.environ.pop("SPHERE_PKG_MANAGER", None)
        self.saved_arch = packages.arch_native

    def tearDown(self):
        os.environ["PATH"] = self.saved_path
        self.packages.arch_native = self.saved_arch
        if self.saved_force is not None:
            os.environ["SPHERE_PKG_MANAGER"] = self.saved_force
        self.tmp.cleanup()

    def tool(self, *names):
        for name in names:
            path = self.bin / name
            path.write_text("#!/bin/sh\nexit 0\n")
            path.chmod(path.stat().st_mode | stat.S_IEXEC)
        os.environ["PATH"] = f"{self.bin}:{self.saved_path}"

    def test_arch_wins_when_arch_owns_the_root(self):
        # The machine from the bug report: os-release says Debian 13, pacman
        # (and apt) are both installed, Arch is the stratum being used.
        self.tool("pacman", "apt-get")
        self.packages.arch_native = lambda: True
        self.assertEqual(self.packages.detect_manager({"ID": "debian", "ID_LIKE": "debian"}),
                         "pacman")

    def test_a_plain_debian_machine_still_gets_apt(self):
        self.tool("pacman", "apt-get")
        self.packages.arch_native = lambda: False
        self.assertEqual(self.packages.detect_manager({"ID": "debian", "ID_LIKE": "debian"}), "apt")

    def test_id_like_is_consulted_when_id_is_unknown(self):
        self.tool("dnf")
        self.packages.arch_native = lambda: False
        self.assertEqual(self.packages.detect_manager({"ID": "nobara", "ID_LIKE": "fedora"}), "dnf")

    def test_a_named_manager_is_only_used_when_its_binary_exists(self):
        self.tool("apt-get")
        self.packages.arch_native = lambda: False
        self.assertEqual(self.packages.manager_for_release({"ID": "arch"}), None)

    def test_the_override_wins(self):
        self.tool("pacman", "apt-get")
        self.packages.arch_native = lambda: True
        os.environ["SPHERE_PKG_MANAGER"] = "apt"
        self.assertEqual(self.packages.detect_manager({"ID": "arch"}), "apt")

    def test_an_absent_override_binary_is_not_used(self):
        self.tool("apt-get")
        os.environ["SPHERE_PKG_MANAGER"] = "pacman"
        self.assertIsNone(self.packages.detect_manager({"ID": "debian"}))

    def test_arch_ids_cover_the_derivatives_the_family_table_knows(self):
        for name in ("arch", "manjaro", "endeavouros", "cachyos"):
            self.assertIn(name, self.packages.ARCH_IDS)
            self.assertEqual(self.packages.FAMILY_MANAGER[name], "pacman")

    def test_the_dry_run_reports_the_platform_it_will_actually_use(self):
        pkg = self.packages.Packages.__new__(self.packages.Packages)
        pkg.kind = "pacman"
        pkg.os = {"ID": "debian", "PRETTY_NAME": "Debian GNU/Linux 13 (trixie)"}
        self.packages.arch_stratum = lambda: "arch"
        self.assertEqual(pkg.describe(), "Arch Linux (Bedrock stratum 'arch')")
        self.packages.arch_stratum = lambda: ""
        self.assertEqual(pkg.describe(), "Arch Linux")

    def test_a_matching_release_is_reported_verbatim(self):
        pkg = self.packages.Packages.__new__(self.packages.Packages)
        pkg.kind = "apt"
        pkg.os = {"ID": "debian", "PRETTY_NAME": "Debian GNU/Linux 13 (trixie)"}
        self.assertEqual(pkg.describe(), "Debian GNU/Linux 13 (trixie)")


@unittest.skipUnless(HAVE_INSTALLER, "installer source is not part of the deployed payload")
class ArchReleaseTests(unittest.TestCase):
    def test_arch_release_is_detected_from_a_bedrock_stratum(self):
        from installer import util
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = pathlib.Path(self.tmp.name)
        arch = root / "arch"
        (arch / "etc").mkdir(parents=True)
        (arch / "etc" / "arch-release").write_text("")
        (root / "debian").mkdir()
        saved = util.BEDROCK_STRATA
        util.BEDROCK_STRATA = root
        self.addCleanup(setattr, util, "BEDROCK_STRATA", saved)
        self.assertTrue(util.arch_native())
        self.assertEqual(util.arch_stratum(), "arch")

    def test_a_populated_pacman_database_counts_as_arch(self):
        from installer import util
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = pathlib.Path(self.tmp.name) / "local"
        root.mkdir()
        (root / "glibc-2.41-5").mkdir()          # pacman's per-package entries
        saved_strata, saved_db = util.BEDROCK_STRATA, util.PACMAN_DB
        util.BEDROCK_STRATA = pathlib.Path(self.tmp.name) / "strata"
        util.PACMAN_DB = root
        self.addCleanup(setattr, util, "BEDROCK_STRATA", saved_strata)
        self.addCleanup(setattr, util, "PACMAN_DB", saved_db)
        self.assertTrue(util.arch_native())

    def test_an_empty_pacman_database_does_not(self):
        from installer import util
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        saved_strata, saved_db = util.BEDROCK_STRATA, util.PACMAN_DB
        util.BEDROCK_STRATA = pathlib.Path(self.tmp.name) / "strata"
        util.PACMAN_DB = pathlib.Path(self.tmp.name) / "local"
        util.PACMAN_DB.mkdir()
        self.addCleanup(setattr, util, "BEDROCK_STRATA", saved_strata)
        self.addCleanup(setattr, util, "PACMAN_DB", saved_db)
        self.assertFalse(util.arch_native())

    def test_no_strata_means_no_arch(self):
        from installer import util
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        saved = util.BEDROCK_STRATA
        util.BEDROCK_STRATA = pathlib.Path(self.tmp.name)
        self.addCleanup(setattr, util, "BEDROCK_STRATA", saved)
        self.assertEqual(util.bedrock_strata(), [])
        self.assertEqual(util.arch_stratum(), "")


@unittest.skipUnless(HAVE_INSTALLER, "installer source is not part of the deployed payload")
class StaleWidgetTests(unittest.TestCase):
    """An update must not leave the previous ring on screen.

    The failure this guards is real: the installer deploys the new files, calls
    `qs kill -p <config>`, and if that particular binary cannot reach the live
    instance (different build, different IPC version) the old process keeps its
    layer surface and the user sees an update that changed nothing — while the
    installer reports success.
    """

    def test_stop_finds_instances_by_their_own_command_line(self):
        source = (REPO / "installer" / "ops" / "session.py").read_text()
        self.assertIn("def own_instances(self):", source)
        # both spellings Quickshell accepts, and only for OUR directory
        self.assertIn('if arg in ("-p", "--path")', source)
        self.assertIn('elif arg.startswith("--path=")', source)
        self.assertIn("if Path(name).expanduser().resolve() == target:", source)
        # and the match is what stop() acts on, after the IPC attempt
        self.assertIn("others = self.own_instances()", source)
        self.assertLess(source.index('query([qs, "kill", "-p"'),
                        source.index("others = self.own_instances()"))

    def test_it_never_kills_a_process_bound_to_another_directory(self):
        source = (REPO / "installer" / "ops" / "session.py").read_text()
        block = source.split("def own_instances(self):", 1)[1].split("def stop(", 1)[0]
        # the binary, or a wrapper script around it — but nothing else
        self.assertIn('names = {Path(a).name for a in argv[:2]}', block)
        self.assertIn('if not names & {"qs", "quickshell"}:', block)
        self.assertIn("entry.stat().st_uid != os.getuid()", block)
        # a blanket pkill would take the user's other bars with it
        for forbidden in ("pkill", "killall", "pgrep"):
            self.assertNotIn(forbidden, block)

    def test_start_clears_a_dead_instance_before_spawning_one(self):
        source = (REPO / "installer" / "ops" / "session.py").read_text()
        block = source.split("def start(self):", 1)[1].split("def supervisor_pid(", 1)[0]
        self.assertIn("self.stop(quiet=True)", block)
        self.assertLess(block.index("self.stop(quiet=True)"),
                        block.index("_supervise"))

    def test_the_restart_does_not_depend_on_a_binary_on_PATH(self):
        # the first attempt at this fix told the user to run `sphere-check.sh --fix`,
        # which needs sphere-setup on PATH — exactly what a fresh shell may lack
        source = (REPO / "installer" / "ops" / "session.py").read_text()
        self.assertIn("def restart_after_update(self):", source)
        block = source.split("def restart_after_update(self):", 1)[1].split("def own_instances", 1)[0]
        self.assertIn("self.stop(quiet=True)", block)
        self.assertIn("self.clear_qml_cache()", block)
        self.assertIn("self.start()", block)
        # only the advice line, on failure, may name the command; the work itself
        # must not shell out to it
        for forbidden in ("subprocess.run", "os.system", "Popen("):
            self.assertNotIn(forbidden, block)
        self.assertLess(block.index("self.start()"), block.index("sphere-setup restart"))
        install = (REPO / "installer" / "ops" / "install.py").read_text()
        self.assertIn("self.restart_after_update()", install)
        # and it must still honour --no-start
        self.assertIn("if not self.args.no_start and not self.args.dry_run:", install)

    def test_a_deploy_drops_the_compiled_qml_cache(self):
        source = (REPO / "installer" / "ops" / "deploy.py").read_text()
        self.assertIn("def clear_qml_cache(self):", source)
        self.assertIn('"quickshell"', source)
        install = (REPO / "installer" / "ops" / "install.py").read_text()
        self.assertIn("self.deploy_native()\n            self.clear_qml_cache()", install)


if __name__ == "__main__":
    unittest.main()

@unittest.skipUnless(HAVE_INSTALLER, "installer source is not part of the deployed payload")
class ArchPacmanTests(unittest.TestCase):
    """What Arch actually gets: pacman commands, never apt, and no silent no-op."""

    def setUp(self):
        from installer import packages
        self.packages = packages
        self.tmp = tempfile.TemporaryDirectory()
        self.bin = Path(self.tmp.name) / "bin"
        self.bin.mkdir()
        self.saved_path = os.environ.get("PATH", "")
        self.saved_arch = packages.arch_native
        self.calls = Path(self.tmp.name) / "calls.log"
        self.make_pacman(sync=["bash", "qt6-base", "quickshell", "hyprland"], installed=["bash"])
        packages.arch_native = lambda: True
        os.environ["PATH"] = f"{self.bin}:{self.saved_path}"

    def tearDown(self):
        os.environ["PATH"] = self.saved_path
        self.packages.arch_native = self.saved_arch
        self.tmp.cleanup()

    def make_pacman(self, sync, installed):
        """A pacman that resolves targets first and aborts on an unknown one."""
        script = """#!/bin/sh
printf '%s\\n' "$*" >> @LOG@
sync="@SYNC@"
installed="@INSTALLED@"
case "$1" in
  -Si)
    for n in $sync; do [ "$n" = "$2" ] && { printf 'Name : %s\\nVersion : 1.0\\n' "$2"; exit 0; }; done
    printf "error: package '%s' was not found\\n" "$2" >&2; exit 1 ;;
  -Q)
    for n in $installed; do [ "$n" = "$2" ] && exit 0; done; exit 1 ;;
  -S)
    for a in "$@"; do
      case "$a" in -S|--needed|--noconfirm|-Syu) continue ;; esac
      ok=0; for n in $sync; do [ "$n" = "$a" ] && ok=1; done
      [ "$ok" = 1 ] || { printf "error: target not found: %s\\n" "$a" >&2; exit 1; }
    done; exit 0 ;;
esac
exit 0
"""
        script = (script.replace("@LOG@", str(self.calls))
                        .replace("@SYNC@", " ".join(sync))
                        .replace("@INSTALLED@", " ".join(installed)))
        path = self.bin / "pacman"
        path.write_text(script)
        path.chmod(path.stat().st_mode | stat.S_IEXEC)

    def manager(self, dry_run=False):
        from installer import packages as pk
        args = type("A", (), {"dry_run": dry_run, "pacman_upgrade": False})()
        runner = type("R", (), {
            "args": args,
            "run": lambda self, argv, timeout=None: self.recorded.append(list(argv)),
            "say": lambda self, message: None,
            "recorded": [],
        })()
        pkg = pk.Packages(runner)
        pkg.kind = "pacman"
        pkg.elevator = "sudo"
        pkg.authenticated = True
        return pkg, runner

    def test_arch_gets_pacman_and_never_apt(self):
        pkg, runner = self.manager()
        pkg.install(["quickshell", "qt6-base"])
        flat = [word for call in runner.recorded for word in call]
        self.assertIn("pacman", flat)
        self.assertNotIn("apt-get", flat)
        self.assertNotIn("apt", flat)
        # --needed so an already-installed package is a no-op, --noconfirm so the
        # run cannot hang waiting on a prompt it never showed anyone
        calls = [c for c in runner.recorded if "pacman" in c and "-S" in c]
        self.assertTrue(calls, runner.recorded)
        install = calls[0]
        self.assertIn("--needed", install)
        self.assertIn("--noconfirm", install)
        self.assertIn("quickshell", install)
        self.assertNotIn("-Sy", install)          # never a half refresh
        self.assertNotIn("-Syu", install)

    def test_an_empty_sync_database_is_named_not_ignored(self):
        # the fresh-Arch case: nothing resolves, so say so instead of quietly
        # installing nothing and failing later inside a cmake build
        self.make_pacman(sync=[], installed=["bash"])
        pkg, runner = self.manager()
        from installer.errors import SetupError
        with self.assertRaises(SetupError) as caught:
            pkg.install(["quickshell"])
        self.assertIn("pacman -Syu", str(caught.exception))
        self.assertEqual([c for c in runner.recorded if "pacman" in c and "-S" in c
                          and "-Syu" not in c], [])

    def test_a_dry_run_still_reports_the_empty_database_without_stopping(self):
        self.make_pacman(sync=[], installed=["bash"])
        pkg, runner = self.manager(dry_run=True)
        pkg.install(["quickshell"], required=True)     # must not raise in a plan
        self.assertFalse([c for c in runner.recorded if c[0] == "pacman" and "-S" in c])

    def test_only_names_that_exist_are_ever_passed_to_pacman(self):
        # rfkill is not a package on Arch (util-linux ships the binary); passing it
        # makes pacman abort the whole transaction and take the valid names with it
        pkg, runner = self.manager()
        pkg.install(["quickshell", "rfkill"], required=False)
        install = next((c for c in runner.recorded if "pacman" in c and "-S" in c), [])
        self.assertIn("quickshell", install)
        self.assertNotIn("rfkill", install)

    def test_the_opt_in_upgrade_is_one_full_system_upgrade(self):
        pkg, runner = self.manager()
        pkg.upgrade()
        self.assertEqual(runner.recorded, [["sudo", "pacman", "-Syu", "--noconfirm"]])

    def test_quickshell_is_expected_from_the_repository_now(self):
        # extra carries quickshell >= 0.3 (checked against archlinux.org), so the
        # pinned source build is a fallback, not the normal path on Arch
        from installer.constants import MIN_QS
        self.assertGreaterEqual((0, 3, 2), MIN_QS)          # extra has 0.3.2
        from installer.constants import RUNTIME_PACKAGES
        arch = RUNTIME_PACKAGES["pacman"]
        for needed in ("qt6-base", "qt6-declarative", "qt6-wayland", "qt6-svg"):
            self.assertIn(needed, arch)
        # Debian's split QML module names must never reach pacman
        for name in arch:
            self.assertFalse(name.startswith("qml6-"), name)
            self.assertFalse(name.startswith("libqt6"), name)

    def test_the_preparation_scripts_never_name_a_package_that_does_not_exist(self):
        # every entry of every prep list is either in Arch's repositories or the
        # binary ships inside a package that is (rfkill -> util-linux)
        import re
        prep = (REPO / "shell" / "bluetooth-prep.sh").read_text()
        wanted = re.search(r'BT_PKGS_WANTED="([^"]+)"', prep).group(1).split()
        self.assertNotIn("rfkill", wanted)
        self.assertIn("util-linux", wanted)
        for name in wanted:
            self.assertRegex(name, r"^[a-z0-9][a-z0-9+._-]*$")


@unittest.skipUnless(HAVE_SOURCE_TREE, "requires the source tree; the deployed self-test carries tests/ only")
class ArchBootstrapTests(unittest.TestCase):
    """The Python bootstrap in shell/preflight.sh must reach pacman first on Arch.

    It used to check apt-get before pacman and ran under `set -e`, so one failing
    apt shim ended the whole setup before pacman was tried. These tests run the
    real block from the shipped script against fake package managers.
    """

    BLOCK = (REPO / "shell" / "preflight.sh")

    def block(self, tmp, family, managers):
        """Extract the bootstrap loop, point its release read at `family`."""
        text = self.BLOCK.read_text()
        start = text.index("Sphere: automatically installing Python.")
        start = text.rindex("\n", 0, start) + 1
        end = text.index("\n  fi\n", start) + len("\n  fi\n")
        block = text[start:end].replace("/etc/os-release", str(tmp / "os-release"))
        (tmp / "os-release").write_text(family)
        (tmp / "block.sh").write_text(block)
        bindir = tmp / "bin"
        bindir.mkdir()
        log = tmp / "log"
        (bindir / "sudo").write_text('#!/bin/sh\nexec "$@"\n')
        for name, rc in managers.items():
            (bindir / name).write_text(
                '#!/bin/sh\nprintf "%s %s\\n" "$(basename "$0")" "$*" >> @LOG@\nexit @RC@\n'
                .replace("@LOG@", str(log)).replace("@RC@", str(rc)))
        for f in bindir.iterdir():
            f.chmod(0o755)
        env = {"PATH": "%s:/usr/bin:/bin" % bindir, "ELEVATOR": "sudo"}
        run = subprocess.run(["sh", "-eu", str(tmp / "block.sh")],
                             env=env, capture_output=True, text=True)
        return run, log.read_text().splitlines()

    def test_arch_reaches_pacman_without_touching_apt(self):
        with tempfile.TemporaryDirectory() as d:
            run, calls = self.block(Path(d), "ID=arch\nID_LIKE=archlinux\n",
                                    {"apt-get": 0, "pacman": 0})
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertTrue(calls[0].startswith("pacman"), calls)
            self.assertFalse([c for c in calls if c.startswith("apt-get")], calls)

    def test_a_failing_manager_hands_over_instead_of_aborting(self):
        with tempfile.TemporaryDirectory() as d:
            run, calls = self.block(Path(d), "ID=arch\nID_LIKE=archlinux\n",
                                    {"pacman": 1, "apt-get": 0})
            self.assertEqual(run.returncode, 0, run.stderr)
            order = [c.split()[0] for c in calls]
            self.assertEqual(list(dict.fromkeys(order)), ["pacman", "apt-get"])   # apt is update + install
            self.assertIn("pacman -Syu", run.stderr)

    def test_a_debian_host_still_starts_at_apt(self):
        with tempfile.TemporaryDirectory() as d:
            run, calls = self.block(Path(d), "ID=debian\nID_LIKE=debian\n",
                                    {"apt-get": 0, "pacman": 0})
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertTrue(calls[0].startswith("apt-get"), calls)
            self.assertFalse([c for c in calls if c.startswith("pacman")], calls)

    def test_no_manager_at_all_is_a_named_failure(self):
        with tempfile.TemporaryDirectory() as d:
            run, calls = self.block(Path(d), "ID=arch\n", {"pacman": 1})
            self.assertEqual(run.returncode, 1)
            self.assertIn("No supported package manager could install Python", run.stderr)


@unittest.skipUnless((REPO / "native" / "sphere_adapter" / "system.py").is_file(), "requires the source tree")
class PreferredManagerTests(unittest.TestCase):
    """system.py must let the distribution's marker outrank the release text."""

    def setUp(self):
        sys.path.insert(0, str(REPO / "native"))
        from sphere_adapter import system
        self.system = system

    def test_the_arch_marker_wins_over_debian_release_text(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            marker = Path(d) / "arch-release"
            marker.write_text("")
            original = self.system.DISTRO_MARKERS
            self.system.DISTRO_MARKERS = ((str(marker), "pacman"),)
            try:
                chosen = self.system.preferred_manager({"ID": "ubuntu", "ID_LIKE": "debian"},
                                                       ["apt", "pacman"])
            finally:
                self.system.DISTRO_MARKERS = original
            self.assertEqual(chosen, "pacman")

    def test_a_marker_for_an_absent_manager_falls_back_to_what_is_installed(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            marker = Path(d) / "arch-release"
            marker.write_text("")
            original = self.system.DISTRO_MARKERS
            self.system.DISTRO_MARKERS = ((str(marker), "pacman"),)
            try:
                chosen = self.system.preferred_manager({"ID": "ubuntu"}, ["apt"])
            finally:
                self.system.DISTRO_MARKERS = original
            self.assertEqual(chosen, "apt")

    def test_without_a_marker_the_release_text_is_still_read(self):
        original = self.system.DISTRO_MARKERS
        self.system.DISTRO_MARKERS = (("/nonexistent/marker", "pacman"),)
        try:
            self.assertEqual(
                self.system.preferred_manager({"ID": "arch"}, ["apt", "pacman"]), "pacman")
            self.assertEqual(
                self.system.preferred_manager({"ID": "debian"}, ["apt", "pacman"]), "apt")
        finally:
            self.system.DISTRO_MARKERS = original


@unittest.skipUnless(HAVE_SOURCE_TREE, "requires the source tree; the deployed self-test carries tests/ only")
class ElevatorTests(unittest.TestCase):
    """No privilege path may assume sudo exists.

    doas is a common sudo replacement on Arch; the prep scripts and the
    Bluetooth helper used to hard-code `sudo`, so on such a box every install
    and every `systemctl enable` failed.
    """

    SCRIPTS = ("bluetooth", "battery", "resources", "organize")

    def test_every_prep_script_resolves_the_helper(self):
        for name in self.SCRIPTS:
            text = (REPO / "shell" / f"{name}-prep.sh").read_text()
            prefix = {"bluetooth": "BT", "battery": "BAT",
                      "resources": "RES", "organize": "OG"}[name]
            self.assertIn(f"{prefix}_ELEVATOR=", text, name)
            self.assertIn("for _sphere_e in sudo doas pkexec", text, name)

    def test_no_prep_script_escalates_with_a_bare_sudo(self):
        import re
        for name in self.SCRIPTS:
            text = (REPO / "shell" / f"{name}-prep.sh").read_text()
            offenders = [line for line in text.splitlines()
                         if re.search(r"\b_run sudo\b", line)]
            self.assertEqual(offenders, [], name)

    def test_the_advice_names_the_helper_that_exists(self):
        text = (REPO / "shell" / "bluetooth-prep.sh").read_text()
        self.assertIn("Run '${BT_ELEVATOR} pacman -Syu' first", text)

    def test_the_bluetooth_helper_uses_the_same_order(self):
        from unittest import mock
        sys.path.insert(0, str(REPO / "installer"))
        import bluetooth_setup

        def which_map(present):
            return lambda name: "/usr/bin/" + name if name in present else None

        with mock.patch.object(bluetooth_setup.shutil, "which", which_map({"doas"})):
            self.assertEqual(bluetooth_setup.elevator(), "doas")
        with mock.patch.object(bluetooth_setup.shutil, "which", which_map(set())):
            self.assertEqual(bluetooth_setup.elevator(), "sudo")     # last resort, still named

    def test_the_bluetooth_helper_never_names_rfkill_as_a_package(self):
        sys.path.insert(0, str(REPO / "installer"))
        import bluetooth_setup
        names = [name for name, _ in bluetooth_setup.PACMAN_PACKAGES]
        self.assertNotIn("rfkill", names)
        self.assertIn("util-linux", names)

    def test_the_debian_list_can_decode_the_artwork(self):
        # Image{} of an SVG needs the imageformat plugin, packaged separately
        # from the QtSvg module on Debian/Ubuntu; without it the logo is blank
        from installer.constants import RUNTIME_PACKAGES
        debian = RUNTIME_PACKAGES["apt"]
        self.assertIn("qt6-svg-plugins", debian)
        self.assertIn("libqt6svg6", debian)
