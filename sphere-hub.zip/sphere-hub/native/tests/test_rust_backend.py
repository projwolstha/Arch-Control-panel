"""Parity, safety, and resident-memory tests for the native Rust backend."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent


def find_rust_binary(name: str) -> Path | None:
    candidates = [
        Path(os.environ.get("SPHERE_BACKEND_BIN", "")) if name == "sphere-backend" else Path(""),
        ROOT / name,
        REPO / "rust-backend" / "target" / "release" / name,
        REPO / "target" / "release" / name,
        Path.home() / ".local" / "bin" / name,
    ]
    for path in candidates:
        if path and path.is_file() and os.access(path, os.X_OK):
            return path
    return None


@unittest.skipUnless(find_rust_binary("sphere-backend") is not None, "compiled Rust backend not present")
class RustBackendTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sphere-rust-suite-"))
        self.backend = find_rust_binary("sphere-backend")
        self.organizer = find_rust_binary("jarvis-organize")
        self.launcher = ROOT / "backend-launch.sh"

        xdg = self.root / "share"
        (xdg / "applications").mkdir(parents=True)
        (xdg / "icons" / "hicolor" / "48x48" / "apps").mkdir(parents=True)
        (xdg / "applications" / "firefox.desktop").write_text(
            "[Desktop Entry]\nType=Application\nName=Firefox\nComment=Web Browser\nExec=sh -c true\nIcon=firefox\n"
        )
        (xdg / "icons" / "hicolor" / "48x48" / "apps" / "firefox.svg").write_text("<svg/>")

        bat = self.root / "power" / "BAT0"
        bat.mkdir(parents=True)
        for key, value in (
            ("type", "Battery"),
            ("capacity", "84"),
            ("status", "Discharging"),
            ("energy_now", "42000000"),
            ("energy_full", "50000000"),
            ("energy_full_design", "54000000"),
            ("power_now", "9500000"),
            ("cycle_count", "92"),
        ):
            (bat / key).write_text(value + "\n")

        self.meminfo = self.root / "meminfo"
        self.meminfo.write_text(
            "MemTotal:       16777216 kB\n"
            "MemFree:         4194304 kB\n"
            "MemAvailable:    8388608 kB\n"
            "Buffers:          524288 kB\n"
            "Cached:          2097152 kB\n"
            "SwapTotal:       4194304 kB\n"
            "SwapFree:        3145728 kB\n"
        )

        self.home = self.root / "home"
        (self.home / "Downloads").mkdir(parents=True)
        self.env = {
            **os.environ,
            "HOME": str(self.home),
            "XDG_DATA_HOME": str(self.root / "user_share"),
            "XDG_DATA_DIRS": str(xdg),
            "HYPRLAND_INSTANCE_SIGNATURE": "",
            "SPHERE_POWER_SUPPLY": str(self.root / "power"),
            "SPHERE_MEMINFO": str(self.meminfo),
            "SPHERE_BACKEND_BIN": str(self.backend),
        }

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_launcher_execs_rust_backend_and_keeps_low_rss(self):
        self.assertTrue(self.launcher.is_file())
        self.assertTrue(os.access(self.launcher, os.X_OK))

        cfg = self.root / "state.json"
        proc = subprocess.Popen(
            [str(self.launcher), "serve", "--config", str(cfg)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=self.env,
        )
        try:
            snap = json.loads(proc.stdout.readline())
            self.assertEqual(snap["type"], "snapshot")
            self.assertEqual(len(snap["apps"]), 1)
            self.assertEqual(snap["apps"][0]["name"], "Firefox")
            self.assertTrue(snap["apps"][0]["icon"].startswith("file://"))

            # Verify `exec` replaced `/bin/sh` with `sphere-backend` in-place
            exe_name = Path(f"/proc/{proc.pid}/comm").read_text().strip()
            self.assertEqual(exe_name, "sphere-backend")

            # Verify resident memory stays well under 8 MB (~2.8 MB typical)
            status_lines = Path(f"/proc/{proc.pid}/status").read_text().splitlines()
            rss_kb = next(
                int(line.split()[1]) for line in status_lines if line.startswith("VmRSS:")
            )
            self.assertLess(rss_kb, 8192, f"Expected < 8 MB VmRSS, got {rss_kb} kB")

            # Exercise full NDJSON action dispatch round-trip
            requests = [
                {"requestId": 1, "action": "battery"},
                {"requestId": 2, "action": "resources"},
                {"requestId": 3, "action": "preferences", "values": {"paused": True}},
                {"requestId": 4, "action": "assign", "slot": 0, "target": {"kind": "desktop", "id": "firefox.desktop"}},
                {"requestId": 5, "action": "clear", "slot": 0},
            ]
            for req in requests:
                proc.stdin.write(json.dumps(req) + "\n")
            proc.stdin.flush()

            responses = {}
            while len(responses) < len(requests):
                msg = json.loads(proc.stdout.readline())
                if msg.get("type") == "response":
                    responses[msg["requestId"]] = msg

            self.assertTrue(all(r["ok"] for r in responses.values()), responses)
            self.assertEqual(responses[1]["result"]["percent"], 84)
            self.assertEqual(responses[2]["result"]["ram"]["percent"], 50)
            self.assertTrue(responses[3]["result"]["preferences"]["paused"])
        finally:
            proc.stdin.close()
            proc.wait(timeout=5)
            proc.stdout.close()
            proc.stderr.close()

    def test_oversized_request_is_rejected_cleanly(self):
        cfg = self.root / "oversize.json"
        huge = '{"action":"snapshot","pad":"' + ("x" * 70000) + '"}\n'
        res = subprocess.run(
            [str(self.backend), "serve", "--config", str(cfg)],
            input=huge,
            capture_output=True,
            text=True,
            env=self.env,
            timeout=5,
        )
        lines = [json.loads(l) for l in res.stdout.splitlines() if l.strip()]
        resp = next((l for l in lines if l.get("type") == "response"), None)
        self.assertIsNotNone(resp)
        self.assertFalse(resp["ok"])
        self.assertEqual(resp["error"], "Request too large.")

    def test_install_cli_rejects_flag_injection(self):
        res = subprocess.run(
            [str(self.backend), "install", "--manager", "pacman", "--package", "--evil"],
            input="INSTALL\n",
            capture_output=True,
            text=True,
            env=self.env,
            timeout=5,
        )
        self.assertNotEqual(res.returncode, 0)

    def test_rust_organizer_scan_run_and_undo(self):
        if self.organizer is None:
            self.skipTest("jarvis-organize binary not present")
        dl = self.home / "Downloads"
        img = dl / "screenshot.png"
        img.write_bytes(b"\x89PNG\r\n")
        old_ts = time.time() - 120
        os.utime(img, (old_ts, old_ts))

        scan = json.loads(
            subprocess.check_output([str(self.organizer), "scan", str(dl)], text=True, env=self.env)
        )
        self.assertTrue(scan["ok"])
        self.assertEqual(scan["files"], 1)

        run_out = subprocess.check_output([str(self.organizer), "run", str(dl)], text=True, env=self.env)
        events = [json.loads(l) for l in run_out.splitlines() if l.strip()]
        self.assertEqual(events[-1]["event"], "done")
        self.assertEqual(events[-1]["moved"], 1)
        self.assertTrue((dl / "Images" / "screenshot.png").is_file())

        undo = json.loads(
            subprocess.check_output([str(self.organizer), "undo"], text=True, env=self.env)
        )
        self.assertEqual(undo["restored"], 1)
        self.assertTrue(img.is_file())


if __name__ == "__main__":
    unittest.main()
