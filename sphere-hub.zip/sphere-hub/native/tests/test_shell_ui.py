"""Static guarantees for the overlay interaction model.

The dashboard is a full-screen Overlay layer: while it is visible it owns every
click, scroll and key, and while it is hidden the surface is unmapped and input
passes through. The bottom control bar is gone, and only an orb's + sign may open
the picker.
These run from the deployed config directory, so they must touch only payload
files; installer-source checks are skipped when the repo tree is absent.
"""
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SHELL = (ROOT/"shell.qml").read_text()
WIDGET = (ROOT/"SphereWidget.qml").read_text()
PANEL_FRAME = (ROOT/"PanelFrame.qml").read_text()
MANAGER = Path(__file__).resolve().parents[2]/"installer"
BACKEND = ROOT/"sphere_adapter"


def merged(folder):
    """The split sources of one component, as a single text, for static assertions."""
    return "\n".join(path.read_text() for path in sorted(folder.rglob("*.py")) if "__pycache__" not in path.parts)


class InteractionModelTests(unittest.TestCase):
    def test_the_surface_owns_input_for_as_long_as_it_is_visible(self):
        # Input is no longer opt-in. `interactionEnabled` survives only as a
        # status field for `sphere-setup status` and the IPC health report;
        # nothing may gate an orb, a panel or the mask on it any more.
        self.assertIn("property bool interactionEnabled: true", WIDGET)
        self.assertNotRegex(WIDGET, r"if\(!root\.interactionEnabled")
        self.assertNotIn("!widget.interactionEnabled", SHELL)
        self.assertIn("sphereVisible: true", WIDGET)
        self.assertRegex(SHELL, r"function toggle\(\): string")
        # Dismiss = hidden AND the whole process exits (0 MB while hidden);
        # summon = visible AND usable.
        self.assertRegex(SHELL, r"function summon\(\): string")
        self.assertRegex(SHELL, r"function dismiss\(\): string")
        self.assertIn('function summon(): string { widget.summon(); return "summoned"; }', SHELL)
        self.assertIn("widget.beginDismiss();", SHELL)
        self.assertIn("if(!widget.sphereVisible) return summon();", SHELL)
        self.assertIn("visible:widget.sphereVisible", SHELL)

    def test_the_input_region_is_the_whole_surface(self):
        # One rectangle, computed from `visible` alone: no orb rect, no panel
        # rect, no editor rect, nothing that an animation or a flag can empty.
        mask = SHELL.split("mask:Region {", 1)[1].split("}", 1)[0]
        self.assertIn("width:widget.sphereVisible?panel.width:0", mask)
        self.assertIn("height:widget.sphereVisible?panel.height:0", mask)
        for stale in ("orbHit", "PanelRegion", "editorGeometry", "interactionEnabled",
                      "RegionShape.Ellipse"):
            self.assertNotIn(stale, mask, f"{stale} must not appear in the input mask")
        # The ring geometry helpers stay: health and the doctor report them.
        for helper in ("function orbRegion(", "function wifiOrbRegion(", "function bluetoothOrbRegion(",
                       "function batteryOrbRegion(", "function resourcesOrbRegion(",
                       "function mainOrbRegion("):
            self.assertIn(helper, SHELL)
        self.assertNotIn("toolbarGeometry", SHELL)

    def test_keyboard_focus_follows_visibility(self):
        # Exclusive while the dashboard is up (so Escape always lands), None the
        # moment it is gone (so the window underneath keeps typing).
        self.assertIn("WlrKeyboardFocus.Exclusive", SHELL)
        self.assertIn("WlrKeyboardFocus.None", SHELL)
        self.assertIn("keyboardFocus:widget.sphereVisible?WlrKeyboardFocus.Exclusive:WlrKeyboardFocus.None",
                      SHELL)

    def test_health_reports_interaction_state_and_version(self):
        self.assertIn("sphere-native-6.18.0", SHELL)
        # What health reports is what actually decides input now.
        self.assertIn("interactive:widget.sphereVisible", SHELL)
        self.assertIn("clickThrough:!widget.sphereVisible", SHELL)
        self.assertIn("sphereVisible:widget.sphereVisible", SHELL)
        self.assertIn('layer:"overlay",keyboardFocus:widget.sphereVisible?"exclusive":"none"', SHELL)
        self.assertIn("inputRegion:({x:0,y:0,width:panel.width,height:panel.height})", SHELL)

    def test_discovery_scan_report_is_in_the_snapshot(self):
        backend = merged(BACKEND)
        self.assertIn('"scan":scan', backend)
        self.assertIn('"listed"] = len(self.catalog.entries)', backend)
        self.assertIn("def icon_index(self):", backend)

    def test_status_colours_are_the_three_specified_tints(self):
        # Connected emerald, connecting amber, disconnected crimson — as tints on
        # the panel's data language, never a solid fill.
        for colour in ('"#55f49a"', '"#ffd36a"', '"#ff7777"'):
            self.assertIn(colour, PANEL_FRAME, colour)
        # …and the five gems carry their own light, not a status colour. The hues
        # live in Theme.qml now — one token each — and the widget's table reads them
        # from there, so a recolour is one edit and not five.
        theme = (ROOT / "Theme.qml").read_text()
        # the classic five: red, green, pink, blue, yellow
        for token, colour in (("gemWifi", '"#ff3b3b"'), ("gemBluetooth", '"#3ddc84"'),
                              ("gemBattery", '"#ff3bd4"'), ("gemSystem", '"#3b7bff"'),
                              ("gemFiles", '"#ffd23b"')):
            self.assertIn("readonly property color %s: %s" % (token, colour), theme)
        self.assertIn("color:theme.gemWifi", WIDGET)
    def test_the_wifi_panel_reports_the_truth_the_user_asked_for(self):
        # "on · N" from the list a real scan produced, "Scanning…" only while that
        # scan runs, and the specific problem sentence instead of a generic empty.
        self.assertIn('state:root.wifi.scanning ? "Scanning…"', WIDGET)
        self.assertIn('root.wifi.radioOn ? ("on · "+root.wifiNetworkCount) : "off"', WIDGET)
        self.assertIn("readonly property int wifiNetworkCount: (wifi.networks || []).length", WIDGET)
        self.assertIn('emptyText:root.wifiEmptyText()', WIDGET)
        self.assertIn(": problem.length>0 ? problem", WIDGET)
        self.assertIn('objectName: frame.n("empty", "EmptyState")', PANEL_FRAME)
        # The power chip reflects and drives `nmcli radio wifi`.
        self.assertIn('objectName:"wifiRadioChip"', WIDGET)
        self.assertIn('label:wifi.radioOn ? "Wi-Fi off" : "Wi-Fi on"', WIDGET)
        self.assertIn('if(name==="radio") root.setWifiRadio(!(root.wifi.radioOn===true));', WIDGET)
        self.assertIn('emitRequest({action:"wifiRadio",enabled:enabled})', WIDGET)
        # And the state shape carries the new fields.
        for field in ("scanning:false", "problem:\"\"", "detail:\"\"", "nm:\"unknown\""):
            self.assertIn(field, WIDGET)

    def panel_block(self, key):
        """The data block of one panel: from its PanelFrame to its closing brace."""
        start = WIDGET.index('key:"%s"' % key)
        return WIDGET[start:WIDGET.index("\n    }\n", start)]

    def test_escape_in_the_orb_peels_the_password_prompt_first(self):
        # Escape is the innermost layer first: a pending passphrase prompt is
        # cancelled before the whole list is closed.
        self.assertIn("if(wifiOpen && wifiPasswordSsid.length>0) { cancelWifiPassword()", WIDGET)
        self.assertLess(WIDGET.index("cancelWifiPassword();event.accepted=true"),
                        WIDGET.index('else if(activePanel!=="") { clearPanel("escape")'))
        # The prompt appears only when a password is needed, so it takes focus —
        # and it lives in the frame, once, for any panel that ever needs a secret.
        self.assertIn("focus: frame.promptVisible", PANEL_FRAME)
        self.assertIn("promptVisible:root.wifiPasswordSsid.length>0", WIDGET)
        self.assertIn("Qt.callLater(function(){ wifiPanel.focusPrompt(); });", WIDGET)

    def test_the_wifi_orb_keeps_its_geometry_helper_and_its_verbs(self):
        # The Wi-Fi orb is still its own panel's off switch; what changed is that
        # the *mask* is the whole surface, so the helper is now only geometry
        # (reported by health/doctor) instead of the thing that decides input.
        self.assertIn("function wifiOrbRegion() { return root.orbHit(0); }", SHELL)
        self.assertIn("function mainOrbRegion() { return widget.mainOrbRegion; }", SHELL)
        self.assertIn("function toggleWifi(): string", SHELL)
        self.assertIn("function toggleSystem(): string", SHELL)
        self.assertIn("function toggleBluetooth()", WIDGET)
        self.assertIn("function toggleBattery()", WIDGET)

    def test_every_gem_glyph_is_a_drawn_asset(self):
        # one pre-rendered silhouette per gem, loaded as an image — no font
        # characters, no per-orb canvas
        for name in ("wifi", "bluetooth", "battery", "chip", "folder"):
            asset = ROOT / "assets" / ("glyph-%s.svg" % name)
            self.assertTrue(asset.is_file(), name)
            self.assertIn("<svg", asset.read_text())
        self.assertIn('glyphSource: Qt.resolvedUrl("assets/glyph-"+root.gemGlyph(gemSlot.index)+".svg")',
                      WIDGET)
    def test_wifi_passphrase_is_never_persisted_by_the_widget(self):
        # Typed once, sent in a request, then cleared from the UI state immediately.
        self.assertIn('emitRequest({action:"wifiConnect",ssid:wifiPasswordSsid,password:(text===undefined?wifiPanel.promptText:text)', WIDGET)
        # …and the field is cleared at once, from both sides of the frame.
        self.assertIn("wifiPanel.clearPrompt();wifiPasswordSsid=\"\";wifiPasswordSecurity=\"\";", WIDGET)
        self.assertIn("function clearPrompt() {", PANEL_FRAME)
        self.assertIn("echoMode: frame.promptMasked ? TextInput.Password : TextInput.Normal", PANEL_FRAME)
        # No preference/state write path takes a password.
        self.assertNotIn("savePreference(\"wifi", WIDGET)
        self.assertNotIn("snapshot.preferences.wifiPassword", WIDGET)

    def test_every_wifi_command_reaches_the_local_adapter(self):
        import re
        backend = merged(BACKEND)
        for action in ("wifi", "wifiScan", "wifiConnect", "wifiDisconnect", "wifiRadio",
                       "wifiPanel", "wifiScanStop"):
            self.assertIn('"'+action+'"', backend)
        # nmcli is only ever invoked as an argument vector, and the passphrase goes
        # through a 0600 passwd-file — never through argv.
        self.assertIn('"wifiPanel"', backend)
        self.assertIn('"wifiScanStop"', backend)
        wifi = (BACKEND/"wifi.py").read_text()
        self.assertIn("subprocess.run([cli, *args]", wifi)
        self.assertIn('"passwd-file", path', wifi)
        self.assertIn("os.fchmod(handle, 0o600)", wifi)
        self.assertNotIn("shell=True", wifi)
        self.assertNotIn("os.system", wifi)

    def test_the_halo_and_the_rays_are_pre_rendered_assets(self):
        # the expensive artwork is SVG the script generates once; QML only loads
        # it and animates opacity, so a hover costs no paint rebuild
        for name in ("magic-bezel",):
            self.assertTrue((ROOT / "assets" / (name + ".svg")).is_file(), name)
        for key in ("wifi", "bluetooth", "battery", "resources", "organize"):
            self.assertTrue((ROOT / "assets" / ("ray-%s.svg" % key)).is_file(), key)
            self.assertTrue((ROOT / "assets" / ("glow-%s.svg" % key)).is_file(), key)
        self.assertIn('haloSource: Qt.resolvedUrl("assets/glow-"+root.gemKey(gemSlot.index)+".svg")',
                      WIDGET)
        # the sheet plumbing is gone: the ring structure is computed geometry
        self.assertNotIn("frameSource", WIDGET)
        self.assertNotIn("runeSource", WIDGET)
    def test_no_webgl_era_painter_survives(self):
        # the Canvas glass painter and the shader that replaced it are both gone:
        # nothing may import them, and no QML file may paint with shadowBlur
        self.assertNotIn("SphereFlow", WIDGET)
        self.assertNotIn("MainOrb", WIDGET)
        for name in ("SphereWidget.qml", "MagicRing.qml", "MagicGem.qml"):
            self.assertNotIn("shadowBlur", (ROOT / name).read_text(), name)
        # and the ring's own painter never uses a Canvas at all
        self.assertNotIn("Canvas", (ROOT / "MagicRing.qml").read_text())
        self.assertNotIn("Canvas", (ROOT / "MagicGem.qml").read_text())
        self.assertFalse((ROOT / "MainOrb.qml").exists())
        self.assertFalse((ROOT / "SphereFlow.js").exists())
    def test_the_ring_stops_when_the_dashboard_is_hidden_or_paused(self):
        # one clock drives every animation, and it is gated in one place
        self.assertIn("property real aliveTime: 0", WIDGET)
        self.assertIn("animated: !root.paused && root.sphereVisible", WIDGET)
        self.assertIn("time: root.aliveTime", WIDGET)
        # and the low-power mode is a property the ring reads, not a second loop
        self.assertIn("lowPower: root.lowPower", WIDGET)
    def test_visual_state_comes_from_networkmanager_not_from_the_icon(self):
        wifi = (BACKEND/"wifi.py").read_text()
        self.assertIn("def device_states(", wifi)
        self.assertIn("def active_connections(", wifi)
        self.assertIn("def visual_state(", wifi)
        self.assertIn('"auth-pending"', wifi)
        # Device/connection state of the real thing, never the scan result.
        self.assertIn('["-t", "-f", "DEVICE,TYPE,STATE", "device", "status"]', wifi)
        self.assertIn('["-t", "-f", "NAME,TYPE,STATE", "connection", "show", "--active"]', wifi)
        # The widget never invents a state from the SSID alone.
        self.assertIn("readonly property string wifiReason", WIDGET)

    def test_state_pushes_are_event_driven_not_polled(self):
        bridge = (BACKEND/"bridge.py").read_text()
        self.assertIn("def watch_wifi(", bridge)
        self.assertIn('["nmcli", "monitor"]', bridge)
        # The watcher asks the monitor for its cache instead of running nmcli in
        # the request path; the monitor itself polls 20 s closed / 2 s open.
        self.assertIn("self.wifi.refresh()", bridge)
        self.assertIn("self.wifi.current()", bridge)
        # The old 20 s orb poll is gone; what is left is a 2-minute safety net.
        self.assertNotIn("interval:20000", WIDGET)
        self.assertIn("interval:120000", WIDGET)
        # `serve` starts the watcher next to the Hyprland threads.
        self.assertIn("bridge.watch_wifi, args=(emit,)", bridge)

    def test_examples_document_the_binding(self):
        conf = (ROOT/"hyprland.conf.example").read_text()
        lua = (ROOT/"hyprland.lua.example").read_text()
        self.assertIn("bind = SUPER, A, exec", conf)
        self.assertIn('hl.bind("SUPER + A"', lua)
        # The optional layer rule is documented in both dialects, and both say
        # that nothing here is required for input to work.
        self.assertIn("layerrule = noanim, sphere-hub", conf)
        self.assertIn("match:namespace = sphere-hub; no_anim = true", conf)
        self.assertIn('hl.layer_rule({ name = "sphere-hub-noanim"', lua)
        self.assertIn("Nothing else is needed", lua)
        self.assertIn("Nothing here is required for input to work", conf)


class ShellRootTests(unittest.TestCase):
    """The one file Quickshell loads as the component root."""

    def test_the_root_assigns_component_on_completed_once(self):
        # Two handlers on one object is not a merge, it is a load-time error:
        # "Property value set multiple times" — the whole shell then refuses to
        # load and nothing appears. This build shipped that bug once.
        self.assertEqual(SHELL.count("Component.onCompleted:"), 1)
        self.assertIn("Component.onCompleted:{ root.syncLogo(); boot.start(); }", SHELL)

    def test_the_logo_is_watched_not_polled(self):
        self.assertEqual(SHELL.count("watchChanges:true"), 2)          # svg + png
        self.assertEqual(SHELL.count("onFileChanged:"), 2)
        self.assertIn('path:root.logoDir+"/logo.svg"', SHELL)
        self.assertIn('path:root.logoDir+"/logo.png"', SHELL)
        # Only documented FileView properties: an unknown one is fatal, not a
        # warning. printErrors is documented (Quickshell 0.2.1 and 0.3.0) and is
        # used on exactly the two /proc readers, where a missing file is a state
        # the widget draws rather than a line in the log.
        self.assertEqual(SHELL.count("printErrors:false"), 2)
        self.assertIn("widget.logoSource", SHELL)
        self.assertIn("widget.logoRevision", SHELL)


class OverlaySurfaceTests(unittest.TestCase):
    """The dashboard is a full-screen Overlay layer while it is visible.

    These pin the properties that decide whether the pointer and the keyboard
    belong to the dashboard or to the window underneath — the four things that
    were wrong before: no anchors, a Top layer, an opt-in keyboard focus, and an
    19-rectangle mask instead of the whole surface.
    """

    def test_the_surface_is_anchored_to_every_edge(self):
        self.assertIn("anchors { top:true; bottom:true; left:true; right:true }", SHELL)
        # The surface follows the screen it is placed on, not a fixed 760 px square.
        self.assertIn("implicitWidth:screen?screen.width:1920", SHELL)
        self.assertIn("implicitHeight:screen?screen.height:1080", SHELL)

    def test_the_layer_is_overlay_and_never_reserves_space(self):
        self.assertIn("WlrLayershell.layer:WlrLayer.Overlay", SHELL)
        self.assertNotIn("WlrLayer.Top", SHELL)
        self.assertNotIn("WlrLayer.Bottom", SHELL)
        self.assertIn("exclusionMode:ExclusionMode.Ignore", SHELL)
        self.assertIn('WlrLayershell.namespace:"sphere-hub"', SHELL)

    def test_visibility_is_the_only_input_switch(self):
        self.assertIn("visible:widget.sphereVisible", SHELL)
        # Nothing else may gate the mask: no interaction flag, no pose rect,
        # no editor rect, no per-panel rectangle.
        mask = SHELL.split("mask:Region {", 1)[1].split("}", 1)[0]
        self.assertIn("width:widget.sphereVisible?panel.width:0", mask)
        self.assertIn("height:widget.sphereVisible?panel.height:0", mask)
        self.assertNotIn("widget.", mask.replace("widget.sphereVisible", ""))

    def test_the_entrance_fade_never_gates_hit_testing(self):
        # presence is opacity; it must never appear in a visible/enabled binding.
        self.assertIn("opacity: root.presence", WIDGET)
        for line in WIDGET.splitlines():
            if "presence" in line and ("visible:" in line or "enabled:" in line):
                self.fail(f"presence gates input: {line.strip()}")
        self.assertIn("Behavior on presence", WIDGET)

    def test_the_surface_is_mapped_before_the_fade_in_and_unmapped_after_the_fade_out(self):
        summon = WIDGET.split("function summon() {", 1)[1].split("// Leave:", 1)[0]
        self.assertLess(summon.index("setSphereVisible(true)"), summon.index("presence=1"))
        dismiss = WIDGET.split("function beginDismiss() {", 1)[1].split("Timer {", 1)[0]
        self.assertLess(dismiss.index("presence=0"), dismiss.index("dismissTimer.restart()"))
        self.assertIn("id:dismissTimer;interval:190", WIDGET)
        timer = WIDGET.split("id:dismissTimer", 1)[1].split("}")
        self.assertTrue(any("root.sphereVisible=false" in line for line in timer))
        self.assertIn("root.dismissFinished()", WIDGET)
        self.assertIn("function onDismissFinished() { Qt.quit(); }", SHELL)
        self.assertIn("id:quitFallback;interval:700", SHELL)

    def test_the_adapter_cannot_stall_the_first_frames(self):
        # The process used to start at load time and its JSON snapshot is parsed
        # on the UI thread. Paint and hit-test first, connect after.
        self.assertIn("running:false", SHELL)
        self.assertIn("id:boot;interval:150", SHELL)
        self.assertIn("Component.onCompleted:{ root.syncLogo(); boot.start(); }", SHELL)
        self.assertIn("id:boot;interval:150;repeat:false", SHELL)

    def test_the_docs_explain_the_compositor_side(self):
        docs = ROOT.parent/"docs"/"INPUT.md"
        if not docs.is_file():
            self.skipTest("docs are not part of the deployed payload")
        text = docs.read_text()
        # The claim has to be the honest one: no config change is required, and
        # no layer rule can grant keyboard focus.
        self.assertIn("no change is required", text)
        self.assertIn("stayfocused", text)
        self.assertIn("match:namespace = sphere-hub", text)      # hyprlang v2
        self.assertIn("layerrule = noanim, sphere-hub", text)    # legacy one-liner
        self.assertIn("hl.layer_rule(", text)                    # Lua configs
        self.assertIn("input:follow_mouse", text)
        self.assertIn("qs kill; qs &", text)


@unittest.skipUnless(MANAGER.is_dir(), "installer source is not part of the deployed payload")
class ManagerBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.TEXT = merged(MANAGER)

    def test_version_is_current(self):
        self.assertIn('VERSION = "6.18.0"', self.TEXT)

    def test_managed_block_binds_super_a_for_both_config_formats(self):
        self.assertIn('hl.bind("SUPER + A", hl.dsp.exec_cmd', self.TEXT)
        self.assertIn("bind = SUPER, A, exec, {toggle}", self.TEXT)
        self.assertIn('"#,\\n\\r"', self.TEXT)

    def test_toggle_command_is_dispatched_over_ipc(self):
        self.assertIn('"_supervise","toggle","summon","dismiss"', self.TEXT)
        self.assertIn('self.dismiss_marker = self.data/"dismissed"', self.TEXT)

    def test_dismissal_stops_everything_and_summon_relaunches(self):
        self.assertIn("def dismiss(self):", self.TEXT)
        self.assertIn("def summon(self):", self.TEXT)
        self.assertIn('atomic(self.p.dismiss_marker', self.TEXT)
        # Supervisor and start() must both honor the dismissal marker.
        self.assertIn('if not self.real_session() or self.p.dismiss_marker.exists():', self.TEXT)
        self.assertIn('or self.p.dismiss_marker.exists():\n                                terminate()', self.TEXT)
        self.assertIn('if self.p.dismiss_marker.exists():\n            self.say("Sphere was dismissed with SUPER+A', self.TEXT)
        # toggle routes through marker-aware dismiss()/summon(), not a bare ipc toggle.
        self.assertIn('if health and health.get("sphereVisible"):\n            manager.dismiss()\n        else:\n            manager.summon()', self.TEXT)
        self.assertIn('self.ipc("summon", timeout=4)', self.TEXT)


if __name__ == "__main__":
    unittest.main()
