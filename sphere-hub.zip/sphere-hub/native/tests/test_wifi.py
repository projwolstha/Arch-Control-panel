"""Wi-Fi adapter tests. No NetworkManager, radio or real network is touched."""
import subprocess
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch
import unittest

import importlib.util
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sphere_adapter import wifi  # noqa: E402

# Exactly the shape of `nmcli -t -f IN-USE,SSID,SIGNAL,SECURITY device wifi list`.
LIST = "\n".join((
    ":HomeNet:82:WPA2",
    "*:Office 5G:67:WPA2 WPA3",
    ":Guest:41:",
    ":Office 5G:55:WPA2 WPA3",
    ":cafe\\:wifi:33:WPA2",
    "::12:WPA2",                   # hidden network: no SSID, must be skipped
    ":HomeNet:70:WPA2",
))

PROFILES = "\n".join((
    "HomeNet:802-11-wireless",
    "Office 5G:802-11-wireless",
    "wired:802-3-ethernet",
))


def process(stdout="", returncode=0, stderr=""):
    return subprocess.CompletedProcess([], returncode, stdout, stderr)


class WifiAdapterTests(unittest.TestCase):
    def setUp(self):
        self.run = patch.object(wifi, "_run", return_value=process(LIST)).start()
        self.addCleanup(patch.stopall)
        patch.object(wifi, "profiles", return_value={"HomeNet", "Office 5G"}).start()
        patch.object(wifi, "available", return_value=True).start()

    # ── parsing ────────────────────────────────────────────────────────────────
    def test_terse_parser_handles_escaped_colons(self):
        self.assertEqual(wifi.split_terse(":cafe\\:wifi:33:WPA2"), ["", "cafe:wifi", "33", "WPA2"])
        self.assertEqual(wifi.split_terse(""), [""])
        # The exact field list the panel reads, split correctly.
        self.assertEqual(wifi.split_terse("*:Office 5G:67:WPA2 WPA3"),
                         ["*", "Office 5G", "67", "WPA2 WPA3"])

    def test_networks_deduplicate_sort_and_skip_hidden(self):
        listed = wifi.networks()
        # order: in-use first, then saved, then strongest signal
        self.assertEqual([entry["ssid"] for entry in listed], ["Office 5G", "HomeNet", "Guest", "cafe:wifi"])
        office = listed[0]
        self.assertTrue(office["inUse"] and office["secure"] and office["saved"])
        self.assertEqual(office["signal"], 67)          # best of the two sightings
        self.assertEqual(office["label"], "WPA2 WPA3")
        self.assertFalse(next(e for e in listed if e["ssid"] == "Guest")["secure"])   # open network
        self.assertNotIn("", [entry["ssid"] for entry in listed])

    def test_security_flags(self):
        self.assertTrue(wifi._security("WPA3")["sae"])
        self.assertTrue(wifi._security("WPA2 802.1X")["enterprise"])
        self.assertTrue(wifi._security("WEP")["wep"])
        self.assertFalse(wifi._security("--")["secure"])

    def test_status_reports_active_network(self):
        patch.object(wifi, "radio_on", return_value=True).start()
        state = wifi.status()
        self.assertEqual(state["active"]["ssid"], "Office 5G")
        self.assertTrue(state["radioOn"] and state["available"])
        self.assertEqual(state["error"], "")

    def test_status_never_lists_networks_while_the_radio_is_off(self):
        patch.object(wifi, "radio_on", return_value=False).start()
        state = wifi.status()
        self.assertEqual(state["networks"], [])
        self.assertFalse(state["radioOn"])

    # ── validation ─────────────────────────────────────────────────────────────
    def test_ssid_validation_rejects_option_like_and_oversized_names(self):
        for value in ("-c", "", None, "x"*33, "bad\nname", "ctrl\x01"):
            with self.assertRaises(wifi.WifiError, msg=repr(value)):
                wifi.check_ssid(value)
        self.assertEqual(wifi.check_ssid("cafe:with colon"), "cafe:with colon")

    def test_passphrase_validation(self):
        self.assertIsNone(wifi.check_passphrase(None))
        self.assertIsNone(wifi.check_passphrase(""))
        self.assertEqual(wifi.check_passphrase("a"*8), "a"*8)
        self.assertEqual(wifi.check_passphrase("a"*64), "a"*64)     # raw PSK
        for value in ("short", "a"*65, "tab\tinside", 12345):
            with self.assertRaises(wifi.WifiError, msg=repr(value)):
                wifi.check_passphrase(value)

    # ── connect ────────────────────────────────────────────────────────────────
    def test_open_network_connects_through_device_wifi_connect(self):
        wifi.connect("Guest")
        self.assertEqual(self.run.call_args.args[0], ["--wait", "30", "device", "wifi", "connect", "Guest"])

    def test_saved_secure_network_reuses_its_profile(self):
        wifi.connect("HomeNet", security="WPA2")
        self.assertEqual(self.run.call_args.args[0], ["--wait", "30", "device", "wifi", "connect", "HomeNet"])

    def test_new_secure_network_gets_a_profile_then_a_0600_passwd_file(self):
        calls, files = [], []

        def run(args, timeout=wifi.TIMEOUT):
            calls.append(args)
            if "passwd-file" in args:
                path = Path(args[args.index("passwd-file")+1])
                files.append((path, path.exists(), oct(path.stat().st_mode & 0o777), path.read_text()))
            return process()

        self.run.stop()
        patch.object(wifi, "_run", side_effect=run).start()
        self.assertEqual(wifi.connect("NewNet", "correct horse", security="WPA2"), "NewNet")
        self.assertEqual(calls[0][:4], ["connection", "add", "type", "wifi"])
        self.assertIn(["wifi-sec.key-mgmt", "wpa-psk"], [calls[0][i:i+2] for i in range(len(calls[0]))])
        path, existed, mode, text = files[0]
        self.assertTrue(existed)
        self.assertEqual(mode, "0o600")
        self.assertEqual(text, "802-11-wireless-security.psk:correct horse\n")
        self.assertFalse(path.exists(), "the passphrase file must be removed afterwards")
        # The passphrase itself never appears in any command line.
        self.assertFalse(any("correct horse" in argument for call in calls for argument in call))

    def test_failed_first_attempt_retries_once_with_corrected_key_management(self):
        calls = []

        def run(args, timeout=wifi.TIMEOUT):
            calls.append(args)
            is_up = args[:1] == ["--wait"]
            if is_up and sum(1 for c in calls if c[:1] == ["--wait"]) == 1:
                return process(returncode=4, stderr="Error: 802-11-wireless-security.key-mgmt: property is missing.")
            return process()

        self.run.stop()
        patch.object(wifi, "_run", side_effect=run).start()
        wifi.connect("NewNet", "a"*9, security="WPA3")
        kinds = [" ".join(call[:3]) for call in calls]
        self.assertIn("connection modify id", kinds)       # the one correction
        self.assertEqual(sum(1 for call in calls if call[:1] == ["--wait"]), 2)
        self.assertEqual(calls[2][:5], ["connection", "modify", "id", "NewNet", "wifi-sec.key-mgmt"])

    def test_enterprise_and_wep_networks_are_refused_clearly(self):
        with self.assertRaisesRegex(wifi.WifiError, "Enterprise"):
            wifi.connect("Corp", "secret123", security="WPA2 802.1X")
        with self.assertRaisesRegex(wifi.WifiError, "WEP"):
            wifi.connect("Old", "secret123", security="WEP")
        self.run.assert_called  # neither attempt reached nmcli
        self.assertEqual(self.run.call_count, 0)

    def test_common_nmcli_failures_are_translated_for_the_orb(self):
        self.run.stop()
        patch.object(wifi, "_run", return_value=process(returncode=4, stderr="Error: No Wi-Fi device found.\n")).start()
        with self.assertRaisesRegex(wifi.WifiError, "No Wi-Fi adapter"):
            wifi.connect("HomeNet")
        self.run.stop()
        patch.object(wifi, "_run", return_value=process(returncode=8, stderr="Error: NetworkManager is not running.\n")).start()
        with self.assertRaisesRegex(wifi.WifiError, "NetworkManager is not running"):
            wifi.connect("HomeNet")
        self.run.stop()
        patch.object(wifi, "_run", return_value=process(returncode=2, stderr="something unexpected\n")).start()
        with self.assertRaisesRegex(wifi.WifiError, "nmcli could not connect to HomeNet: something unexpected"):
            wifi.connect("HomeNet")

    def test_missing_nmcli_is_reported_as_unavailable(self):
        patch.stopall()
        with patch.object(wifi.shutil, "which", return_value=None):
            self.assertFalse(wifi.available())
            state = wifi.status()
            self.assertFalse(state["available"])
            self.assertIn("NetworkManager", state["error"])
            self.assertEqual(state["networks"], [])
            with self.assertRaisesRegex(wifi.WifiError, "NetworkManager"):
                wifi.connect("HomeNet")

    def test_radio_and_disconnect(self):
        calls = []
        self.run.side_effect = lambda args, timeout=wifi.TIMEOUT: (calls.append(args), process("enabled"))[1]
        wifi.radio(False)
        self.assertIn(["radio", "wifi", "off"], calls)
        with self.assertRaises(wifi.WifiError):
            wifi.radio("yes")                                  # not a bool
        self.run.side_effect = lambda args, timeout=wifi.TIMEOUT: (calls.append(args), process())[1]
        patch.object(wifi, "wifi_device", return_value="wlan0").start()
        self.assertEqual(wifi.disconnect(), "wlan0")
        self.assertIn(["device", "disconnect", "wlan0"], calls)
        patch.object(wifi, "wifi_device", return_value="").start()
        with self.assertRaisesRegex(wifi.WifiError, "No Wi-Fi interface"):
            wifi.disconnect()

    def test_nmcli_failure_becomes_a_readable_wifi_error(self):
        self.run.stop()
        patch.object(wifi, "_run", return_value=process(returncode=10, stderr="Error: Device 'wlan0' is not available.\n")).start()
        patch.object(wifi, "wifi_device", return_value="wlan0").start()
        with self.assertRaisesRegex(wifi.WifiError, "Device 'wlan0' is not available."):
            wifi.disconnect()


class ScanRulesTests(unittest.TestCase):
    """The rules behind "on · 0" and the generic empty list.

    Each one exists because the panel used to sit on "on · 0 / No networks visible
    yet" while the adapter was healthy: the scan was a blocking call whose result
    was thrown away when it came back empty, and every cause of an empty list was
    painted as the same sentence.
    """

    def setUp(self):
        patch.object(wifi, "available", return_value=True).start()
        patch.object(wifi, "profiles", return_value={"HomeNet"}).start()
        self.addCleanup(patch.stopall)

    # ── the exact command, and the exact parsing ──────────────────────────
    def test_the_list_command_is_exactly_the_documented_one(self):
        calls = []

        def run(args, timeout=wifi.TIMEOUT):
            calls.append(list(args))
            return process(LIST)
        patch.object(wifi, "_run", side_effect=run).start()
        wifi.networks(rescan=True)
        self.assertEqual(calls[0], ["-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY",
                                    "device", "wifi", "list", "--rescan", "yes"])

    def test_four_fields_are_enough_and_escaped_colons_do_not_shift_them(self):
        rows = wifi.parse_networks(LIST, saved={"HomeNet"})
        self.assertEqual([row["ssid"] for row in rows], ["Office 5G", "HomeNet", "Guest", "cafe:wifi"])
        cafe = next(row for row in rows if row["ssid"] == "cafe:wifi")
        self.assertEqual(cafe["signal"], 33)
        self.assertTrue(cafe["secure"])
        self.assertEqual(next(row for row in rows if row["ssid"] == "Office 5G")["signal"], 67)

    def test_empty_ssids_are_skipped(self):
        rows = wifi.parse_networks("::12:WPA2\n:Real:50:\n", saved=set())
        self.assertEqual([row["ssid"] for row in rows], ["Real"])

    def test_duplicates_keep_the_strongest_and_the_sort_is_by_signal(self):
        text = "\n".join((":Weak:20:WPA2", ":Strong:90:WPA2", ":Weak:70:WPA2", ":Mid:50:WPA2"))
        rows = wifi.parse_networks(text, saved=set())
        self.assertEqual([row["ssid"] for row in rows], ["Strong", "Weak", "Mid"])
        self.assertEqual(next(row for row in rows if row["ssid"] == "Weak")["signal"], 70)

    def test_the_connected_network_stays_first(self):
        rows = wifi.parse_networks("*:Slow:10:WPA2\n:Fast:99:WPA2", saved=set())
        self.assertEqual(rows[0]["ssid"], "Slow")
        self.assertTrue(rows[0]["inUse"])

    # ── the 3-5 s first scan ──────────────────────────────────────────────
    def test_an_empty_first_scan_is_retried_once_after_two_seconds(self):
        import time as clock
        answers = iter([[], [{"ssid": "HomeNet", "signal": 80, "inUse": False}]])
        waits = []
        patch.object(wifi, "networks", side_effect=lambda rescan=True: next(answers)).start()
        patch.object(wifi.time, "sleep", side_effect=lambda seconds: waits.append(seconds)).start()
        listed, retried, detail = wifi.scan_networks()
        self.assertEqual([row["ssid"] for row in listed], ["HomeNet"])
        self.assertTrue(retried)
        self.assertEqual(waits, [2.0], "the retry must wait two seconds, not spin")
        self.assertEqual(detail, "")

    def test_a_scan_that_finds_nothing_twice_is_reported_as_such(self):
        patch.object(wifi, "networks", return_value=[]).start()
        patch.object(wifi.time, "sleep", return_value=None).start()
        listed, retried, detail = wifi.scan_networks()
        self.assertEqual(listed, [])
        self.assertTrue(retried)
        self.assertEqual(detail, "")

    # ── who is to blame when the list is empty ────────────────────────────
    def test_the_problem_sentences_are_specific(self):
        import json
        cases = {
            "nm-stopped": ({"nm": "stopped", "radioOn": True, "devices": {"wlan0": "connected"},
                            "detail": "NetworkManager is not running"}, "NetworkManager is not running"),
            "radio-off": ({"nm": "running", "radioOn": False, "devices": {"wlan0": "disconnected"},
                           "detail": ""}, "switched off"),
            "no-device": ({"nm": "running", "radioOn": True, "devices": {}, "detail": ""},
                          "No Wi-Fi device"),
            "unmanaged": ({"nm": "running", "radioOn": True, "devices": {"wlan0": "unmanaged"},
                           "detail": ""}, "not managed"),
            "healthy-empty": ({"nm": "running", "radioOn": True, "devices": {"wlan0": "disconnected"},
                               "detail": ""}, ""),
        }
        for name, (facts, expected) in cases.items():
            with self.subTest(case=name):
                said = wifi.problem(facts)
                if expected:
                    self.assertIn(expected, said)
                else:
                    self.assertEqual(said, "", "an empty list with a healthy adapter is not a problem")

    def test_nmcli_own_words_are_appended(self):
        said = wifi.problem({"nm": "stopped", "radioOn": False, "devices": {},
                             "detail": "Error: NetworkManager is not running."})
        self.assertIn("nmcli said", said)
        self.assertIn("Error: NetworkManager is not running.", said)

    def test_status_uses_the_problem_instead_of_an_empty_error(self):
        def run(args, timeout=wifi.TIMEOUT):
            if args[0] == "-t" and "radio" in args:
                return process("enabled")
            if "general" in args:
                return process("running")
            if "status" in args:
                return process("wlan0:wifi:unmanaged")
            if "show" in args:
                return process("")
            if "list" in args:
                return process("")
            return process("")
        patch.object(wifi, "_run", side_effect=run).start()
        state = wifi.status()
        self.assertEqual(state["networks"], [])
        self.assertIn("not managed", state["problem"])
        self.assertEqual(state["radioOn"], True)
        self.assertEqual(state["nm"], "running")

    # ── the radio switch ──────────────────────────────────────────────────
    def test_the_radio_state_is_read_from_nmcli_radio_wifi(self):
        patch.object(wifi, "_run", return_value=process("enabled\n")).start()
        self.assertIs(wifi.radio_on(), True)
        patch.object(wifi, "_run", return_value=process("disabled\n")).start()
        self.assertIs(wifi.radio_on(), False)
        patch.object(wifi, "_run", return_value=process("garbage\n")).start()
        self.assertIsNone(wifi.radio_on(), "an unreadable answer is 'unknown', never a guess")

    def test_toggling_the_radio_reflects_the_real_state(self):
        calls, state = [], {"on": False}

        def run(args, timeout=wifi.TIMEOUT):
            calls.append(list(args))
            if args[:3] == ["-t", "radio", "wifi"]:
                return process("enabled" if state["on"] else "disabled")
            if args[:3] == ["radio", "wifi", "on"]:
                state["on"] = True
                return process("")
            if args[:3] == ["radio", "wifi", "off"]:
                state["on"] = False
                return process("")
            return process("")
        patch.object(wifi, "_run", side_effect=run).start()
        self.assertIs(wifi.radio(True), True)
        self.assertIn(["radio", "wifi", "on"], calls)
        self.assertIs(wifi.radio(False), False)
        self.assertIn(["radio", "wifi", "off"], calls)

    # ── the environment ───────────────────────────────────────────────────
    def test_nmcli_runs_with_a_completed_environment(self):
        env = wifi.cli_environment({"PATH": "/broken"})
        self.assertIn("/usr/bin", env["PATH"].split(":"))
        self.assertEqual(env["LC_ALL"], "C")
        from pathlib import Path as _Path
        if _Path("/run/dbus/system_bus_socket").exists():
            self.assertTrue(env["DBUS_SYSTEM_BUS_ADDRESS"].startswith("unix:path="))

    def test_a_broken_path_cannot_hide_an_installed_nmcli(self):
        self.assertIn("/usr/bin/nmcli", wifi.CLI_FALLBACKS)


class FailureTextTests(unittest.TestCase):
    """A failed nmcli run must never raise a TypeError or say nothing."""

    def setUp(self):
        patch.object(wifi, "available", return_value=True).start()
        self.addCleanup(patch.stopall)

    def test_a_failed_list_carries_nmcli_own_sentence(self):
        patch.object(wifi, "_run", return_value=process(
            returncode=8, stderr="Error: NetworkManager is not running.\n")).start()
        with self.assertRaises(wifi.WifiError) as caught:
            wifi.networks(rescan=True)
        said = str(caught.exception)
        self.assertIn("NetworkManager is not running", said)
        self.assertIn("NetworkManager is not running", caught.exception.detail)

    def test_an_unknown_failure_is_quoted_verbatim(self):
        patch.object(wifi, "_run", return_value=process(
            returncode=10, stderr="Error: Device 'wlan0' request failed: Timeout was reached\n")).start()
        with self.assertRaises(wifi.WifiError) as caught:
            wifi.networks(rescan=True)
        self.assertIn("Device 'wlan0' request failed", str(caught.exception))

    def test_a_silent_failure_still_says_something(self):
        patch.object(wifi, "_run", return_value=process(returncode=3)).start()
        with self.assertRaises(wifi.WifiError) as caught:
            wifi.networks(rescan=True)
        self.assertIn("could not list Wi-Fi networks", str(caught.exception))

    def test_the_scan_worker_turns_a_failure_into_a_problem_sentence(self):
        import threading
        patch.object(wifi, "networks", side_effect=wifi.WifiError(
            "NetworkManager is not running. Start it, then press Scan again.",
            "Error: NetworkManager is not running.")).start()
        done = threading.Event()
        seen = []
        wifi.start_scan(on_done=lambda listed, retried, detail: (seen.append(detail), done.set()))
        self.assertTrue(done.wait(5))
        self.assertIn("NetworkManager is not running", seen[0])


class AsyncScanTests(unittest.TestCase):
    """A scan is a thread; the panel must never wait for it."""

    def setUp(self):
        patch.object(wifi, "available", return_value=True).start()
        self.addCleanup(patch.stopall)
        wifi.stop_scan()
        with wifi._SCAN_LOCK:
            wifi._SCAN.update(thread=None, result=None, callback=None)

    def tearDown(self):
        wifi.stop_scan()
        with wifi._SCAN_LOCK:
            wifi._SCAN.update(thread=None, result=None, callback=None)

    def test_starting_a_scan_returns_at_once_and_finishes_on_its_own(self):
        import threading
        import time as clock
        started = clock.monotonic()
        patch.object(wifi, "networks", return_value=[{"ssid": "HomeNet", "signal": 80}]).start()
        done = threading.Event()
        seen = []

        def on_done(listed, retried, detail):
            seen.append((listed, retried, detail))
            done.set()

        wifi.start_scan(on_done=on_done)
        self.assertLess(clock.monotonic() - started, 1.0, "a scan must not block the caller")
        self.assertTrue(done.wait(5), "the scan thread must finish")
        self.assertEqual([row["ssid"] for row in seen[0][0]], ["HomeNet"])
        self.assertFalse(wifi.scanning())

    def test_scanning_is_false_before_and_after(self):
        self.assertFalse(wifi.scanning())
        import threading
        import time as clock
        released = threading.Event()

        def slow(rescan=True):
            released.wait(2)
            return []
        patch.object(wifi, "networks", side_effect=slow).start()
        # The retry delay is a module constant, so shortening it does not touch
        # time.sleep (which this test still needs to actually wait).
        patch.object(wifi, "SCAN_RETRY_DELAY", 0).start()
        wifi.start_scan()
        self.assertTrue(wifi.scanning(), "a running thread is a running scan")
        released.set()
        deadline = clock.monotonic() + 5
        while clock.monotonic() < deadline and wifi.scanning():
            clock.sleep(.01)
        self.assertFalse(wifi.scanning())

    def test_a_failed_scan_reports_the_real_text(self):
        import threading
        patch.object(wifi, "networks",
                     side_effect=wifi.WifiError("nmcli could not list Wi-Fi networks.",
                                                "Error: NetworkManager is not running.")).start()
        done = threading.Event()
        seen = []

        def on_done(listed, retried, detail):
            seen.append(detail)
            done.set()
        wifi.start_scan(on_done=on_done)
        self.assertTrue(done.wait(5))
        self.assertIn("NetworkManager is not running", seen[0])

    def test_the_monitor_publishes_the_scan_result_and_flips_scanning(self):
        import threading
        import time as clock
        published = []
        monitor = wifi.Monitor(on_change=published.append)
        patch.object(wifi, "networks", return_value=[{"ssid": "HomeNet", "signal": 80, "inUse": False,
                                                     "saved": False, "label": "", "secure": True}]).start()
        patch.object(wifi, "read_state", return_value={"state": "disconnected", "reason": "disconnected",
                                                       "radioOn": True, "devices": {"wlan0": "disconnected"},
                                                       "connections": [], "nm": "running", "detail": ""}).start()
        monitor.scan()
        self.assertTrue(published and published[0]["scanning"] is True,
                        "the panel must learn about the scan immediately")
        deadline = clock.monotonic() + 5
        while clock.monotonic() < deadline and not monitor.current().get("networks"):
            clock.sleep(.02)
        self.assertEqual([row["ssid"] for row in monitor.current()["networks"]], ["HomeNet"])
        self.assertFalse(monitor.current()["scanning"])


class WifiStateMachineTests(unittest.TestCase):
    """NetworkManager facts -> one of the three visual states. Pure mapping, no nmcli."""

    def setUp(self):
        # This sandbox has no NetworkManager: every test states that nmcli exists and
        # then supplies the exact output it would print.
        patch.object(wifi, "available", return_value=True).start()
        self.addCleanup(patch.stopall)

    def state(self, radio=True, devices=None, connections=None, available=True):
        return wifi.visual_state(available_=available, radio=radio,
                                 devices={"wlan0": d for d in ([devices] if devices else [])},
                                 connections=connections or [])

    def test_state_table(self):
        cases = [
            # connected
            (dict(devices="connected"), "connected", "connected"),
            (dict(devices="activated"), "connected", "connected"),
            # connected device but a profile still activating = authentication pending
            (dict(devices="connected", connections=[("HomeNet", "activating")]), "connecting", "auth-pending"),
            # attempts in progress
            (dict(devices="activating"), "connecting", "activating"),
            (dict(devices="deactivating"), "connecting", "activating"),
            # failures
            (dict(devices="failed"), "disconnected", "failed"),
            (dict(devices="disconnected"), "disconnected", "disconnected"),
            # radio off wins over any stale device state
            (dict(radio=False, devices="connected"), "disconnected", "radio-off"),
            # no nmcli at all
            (dict(available=False), "disconnected", "no-networkmanager"),
        ]
        for kwargs, state, reason in cases:
            with self.subTest(kwargs=kwargs):
                self.assertEqual(self.state(**kwargs), {"state": state, "reason": reason})

    def test_no_adapter_is_disconnected_not_green(self):
        self.assertEqual(wifi.visual_state(available_=True, radio=True, devices={}, connections=[]),
                         {"state": "disconnected", "reason": "no-device"})

    def test_device_states_and_active_connections_are_parsed(self):
        listing = "wlan0:wifi:connected\ndummy0:dummy:unmanaged\neth0:ethernet:unmanaged"
        active = "HomeNet:802-11-wireless:activated\nWired:802-3-ethernet:activated"
        calls = []
        def run(args, timeout=wifi.TIMEOUT):
            calls.append(args)
            return process(listing if "device" in args else active)
        patch.object(wifi, "_run", side_effect=run).start()
        self.assertEqual(wifi.device_states(), {"wlan0": "connected"})
        self.assertEqual(wifi.active_connections(), [("HomeNet", "activated")])
        self.assertIn(["-t", "-f", "DEVICE,TYPE,STATE", "device", "status"], calls)
        self.assertIn(["-t", "-f", "NAME,TYPE,STATE", "connection", "show", "--active"], calls)

    def test_state_only_read_never_scans(self):
        """The orb's push path must not trigger a scan: no wifi list command at all."""
        calls = []
        def run(args, timeout=wifi.TIMEOUT):
            calls.append(args)
            if args[0] == "-t" and "radio" in args: return process("enabled")
            if "device" in args and "status" in args: return process("wlan0:wifi:connected")
            if "connection" in args: return process("HomeNet:802-11-wireless:activated")
            if "device" in args and "show" in args: return process("GENERAL.CONNECTION:HomeNet")
            return process("")
        patch.object(wifi, "_run", side_effect=run).start()
        state = wifi.status(include_networks=False)
        self.assertEqual((state["state"], state["reason"]), ("connected", "connected"))
        self.assertEqual(state["networks"], [])
        self.assertEqual(state["active"]["ssid"], "HomeNet")
        self.assertFalse(any("wifi" in call and "list" in call for call in calls), calls)


class BridgeWifiTests(unittest.TestCase):
    """The stdio bridge exposes Wi-Fi as fixed actions and never as a free command."""

    def setUp(self):
        from sphere_adapter import bridge as bridge_module
        self.bridge_module = bridge_module
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.bridge = bridge_module.Bridge(store=bridge_module.ConfigStore(Path(self.temp.name)/"state.json"))

    def test_wifi_actions_return_the_cached_state_at_once(self):
        # A scan takes 3-5 s: the request cannot wait for it. The answer is the
        # cache with `scanning: true`, and the finished list arrives as an event.
        cached = {"available": True, "radioOn": True, "active": {"ssid": "HomeNet"},
                  "networks": [{"ssid": "HomeNet"}], "error": "", "scanning": False,
                  "problem": "", "state": "connected", "reason": "connected",
                  "devices": {}, "connections": [], "nm": "running", "detail": ""}
        with patch.object(self.bridge.wifi, "current", return_value=dict(cached)), \
             patch.object(self.bridge.wifi, "scan") as scan:
            self.assertEqual(self.bridge.request({"action": "wifi"})["type"], "wifi")
            result = self.bridge.request({"action": "wifiScan"})
        scan.assert_called_once_with()
        self.assertEqual(result["networks"], [{"ssid": "HomeNet"}])
        self.assertEqual(result["type"], "wifi")
        with patch.object(self.bridge.wifi, "current", return_value=dict(cached)), \
             patch.object(self.bridge.wifi, "connect") as connect:
            result = self.bridge.request({"action": "wifiConnect", "ssid": "HomeNet",
                                          "password": "12345678", "security": "WPA2"})
        connect.assert_called_once_with("HomeNet", "12345678", "WPA2")
        self.assertEqual(result["connected"], "HomeNet")
        self.assertEqual(result["type"], "wifi")

    def test_wifi_radio_and_disconnect_dispatch(self):
        state = {"available": True, "radioOn": False, "active": None, "networks": [], "error": "",
                 "scanning": False, "problem": ""}
        with patch.object(self.bridge.wifi, "current", return_value=dict(state)), \
             patch.object(self.bridge.wifi, "set_radio") as radio, \
             patch.object(self.bridge.wifi, "disconnect") as disconnect:
            self.bridge.request({"action": "wifiRadio", "enabled": False})
            self.bridge.request({"action": "wifiDisconnect"})
        radio.assert_called_once_with(False)
        disconnect.assert_called_once_with()

    def test_wifi_errors_surface_in_the_state_not_as_a_crash(self):
        # connect() runs on the monitor thread now: a failure must reach the panel
        # as `problem`/`error` in the next state, not as a dead adapter.
        error = self.bridge_module.wifi_control.WifiError("bad password", "Error: Secrets were required")
        with patch.object(self.bridge_module.wifi_control, "connect", side_effect=error):
            with patch.object(self.bridge.wifi, "current", return_value={"error": "bad password",
                                                                        "problem": "bad password"}):
                result = self.bridge.request({"action": "wifiConnect", "ssid": "HomeNet", "password": "x"})
        self.assertEqual(result["type"], "wifi")
        self.assertEqual(result["error"], "bad password")

    def test_watcher_pushes_state_changes_and_stops_with_the_adapter(self):
        import threading
        import time as _time
        emitted, reads = [], []
        states = iter([
            {"state": "connected", "reason": "connected", "available": True, "radioOn": True},
            {"state": "connected", "reason": "connected", "available": True, "radioOn": True},   # duplicate: no push
            {"state": "connecting", "reason": "auth-pending", "available": True, "radioOn": True},
        ])

        # The watcher may read once more than the script above (a slow machine
        # delivers the last `nmcli monitor` line twice). Repeating the final
        # state keeps the test about de-duplication, not about thread timing.
        final = {"state": "connecting", "reason": "auth-pending", "available": True, "radioOn": True}

        def current():
            reads.append(1)
            try:
                state = next(states)
            except StopIteration:
                state = final
            return {**state, "active": None, "networks": [], "error": ""}

        class FakeStdout:
            def __iter__(inner):
                for _ in range(3):
                    _time.sleep(0.01)
                    yield "wlan0: connected\n"
                self.bridge.stop.set()

        class FakeProcess:
            stdout = FakeStdout()
            def terminate(inner): pass
            def wait(inner, timeout=None): return 0

        with patch.object(self.bridge_module.wifi_control, "available", return_value=True), \
             patch.object(self.bridge.wifi, "current", side_effect=current), \
             patch.object(self.bridge.wifi, "refresh"), \
             patch.object(self.bridge_module.subprocess, "Popen", return_value=FakeProcess()):
            thread = threading.Thread(target=self.bridge.watch_wifi, args=(emitted.append,), daemon=True)
            thread.start()
            thread.join(5)
        self.assertFalse(thread.is_alive())
        self.assertEqual([message["state"] for message in emitted], ["connected", "connecting"])
        self.assertTrue(all(message["type"] == "wifi" for message in emitted))

    def test_watcher_is_absent_without_networkmanager(self):
        emitted = []
        with patch.object(self.bridge_module.wifi_control, "available", return_value=False):
            self.bridge.watch_wifi(emitted.append)      # returns immediately
        self.assertEqual(emitted, [])

    def test_arbitrary_shell_is_still_rejected(self):
        with self.assertRaisesRegex(ValueError, "Unknown action"):
            self.bridge.request({"action": "exec", "command": "nmcli dev disconnect wlan0"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
