//! Battery state for the orb panel, read from UPower and `/sys/class/power_supply`.

use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};
use std::time::Instant;

use crate::constants::run_cmd_timeout;
use crate::json::JsonVal;
use crate::pathutil::which;

pub const PROFILES: &[&str] = &["power-saver", "balanced", "performance"];
const CACHE_MS: u128 = 1500;

struct BatCache {
    at: Option<Instant>,
    val: Option<JsonVal>,
}

fn cache() -> &'static Mutex<BatCache> {
    static CACHE: OnceLock<Mutex<BatCache>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(BatCache { at: None, val: None }))
}

fn supply_root() -> PathBuf {
    std::env::var("SPHERE_POWER_SUPPLY")
        .ok()
        .filter(|s| !s.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/sys/class/power_supply"))
}

fn read_trim(path: &Path) -> Option<String> {
    fs::read_to_string(path).ok().map(|s| s.trim().to_string())
}

fn parse_first_float(text: Option<&str>) -> Option<f64> {
    let raw = text?.replace(',', ".");
    let bytes = raw.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        let is_neg = bytes[i] == b'-' && i + 1 < bytes.len() && bytes[i + 1].is_ascii_digit();
        if bytes[i].is_ascii_digit() || is_neg {
            let start = i;
            if is_neg {
                i += 1;
            }
            while i < bytes.len() && bytes[i].is_ascii_digit() {
                i += 1;
            }
            if i + 1 < bytes.len() && bytes[i] == b'.' && bytes[i + 1].is_ascii_digit() {
                i += 1;
                while i < bytes.len() && bytes[i].is_ascii_digit() {
                    i += 1;
                }
            }
            if let Ok(s) = std::str::from_utf8(&bytes[start..i]) {
                if let Ok(v) = s.parse::<f64>() {
                    return Some(v);
                }
            }
        }
        i += 1;
    }
    None
}

fn parse_first_int(text: Option<&str>) -> Option<i64> {
    parse_first_float(text).map(|v| v.round() as i64)
}

fn clamp_percent(val: Option<f64>) -> Option<i64> {
    val.map(|v| (v.round() as i64).clamp(0, 100))
}

fn norm_state(text: Option<&str>) -> &'static str {
    match text.unwrap_or("").trim().to_ascii_lowercase().as_str() {
        "charging" => "charging",
        "discharging" => "discharging",
        "full" => "full",
        "not charging" => "not-charging",
        _ => "unknown",
    }
}

struct RawBattery {
    percent: Option<i64>,
    state: &'static str,
    power_now: Option<f64>,
    energy_now: Option<f64>,
    energy_full: Option<f64>,
    energy_design: Option<f64>,
    voltage: Option<f64>,
    cycles: Option<i64>,
    time_to_empty: Option<i64>,
    time_to_full: Option<i64>,
    health_percent: Option<i64>,
    source: &'static str,
}

fn sysfs_batteries() -> Vec<PathBuf> {
    let root = supply_root();
    let Ok(rd) = fs::read_dir(&root) else {
        return Vec::new();
    };
    let mut out = Vec::new();
    for entry in rd.flatten() {
        let name = entry.file_name().to_string_lossy().into_owned();
        let path = entry.path();
        let is_bat = name.starts_with("BAT")
            || read_trim(&path.join("type"))
                .map(|t| t.eq_ignore_ascii_case("battery"))
                .unwrap_or(false);
        if is_bat {
            out.push(path);
        }
    }
    out.sort();
    out
}

fn sysfs_battery() -> Option<RawBattery> {
    for path in sysfs_batteries() {
        let pct = parse_first_int(read_trim(&path.join("capacity")).as_deref());
        let st = norm_state(read_trim(&path.join("status")).as_deref());
        if pct.is_none() && st == "unknown" {
            continue;
        }
        let e_now = parse_first_float(read_trim(&path.join("energy_now")).as_deref());
        let e_full = parse_first_float(read_trim(&path.join("energy_full")).as_deref());
        let e_design = parse_first_float(read_trim(&path.join("energy_full_design")).as_deref());
        let c_now = parse_first_float(read_trim(&path.join("charge_now")).as_deref());
        let c_full = parse_first_float(read_trim(&path.join("charge_full")).as_deref());
        let c_design = parse_first_float(read_trim(&path.join("charge_full_design")).as_deref());
        let v_uv = parse_first_float(read_trim(&path.join("voltage_now")).as_deref());

        let mut p_uw = parse_first_float(read_trim(&path.join("power_now")).as_deref());
        if p_uw.is_none() {
            if let (Some(cur_ua), Some(v)) = (
                parse_first_float(read_trim(&path.join("current_now")).as_deref()),
                v_uv,
            ) {
                if v > 0.0 {
                    p_uw = Some((cur_ua * v / 1e6).abs());
                }
            }
        }

        let conv = |energy: Option<f64>, charge: Option<f64>| -> Option<f64> {
            if let Some(e) = energy {
                Some(e / 1e6)
            } else if let (Some(c), Some(v)) = (charge, v_uv) {
                if v > 0.0 {
                    Some(c * v / 1e12)
                } else {
                    None
                }
            } else {
                None
            }
        };

        return Some(RawBattery {
            percent: pct.map(|v| v.clamp(0, 100)),
            state: st,
            power_now: p_uw.map(|p| p / 1e6),
            energy_now: conv(e_now, c_now),
            energy_full: conv(e_full, c_full),
            energy_design: conv(e_design, c_design),
            voltage: v_uv.filter(|&v| v > 0.0).map(|v| v / 1e6),
            cycles: parse_first_int(read_trim(&path.join("cycle_count")).as_deref()),
            time_to_empty: parse_first_int(read_trim(&path.join("time_to_empty_now")).as_deref()),
            time_to_full: parse_first_int(read_trim(&path.join("time_to_full_now")).as_deref()),
            health_percent: None,
            source: "sysfs",
        });
    }
    None
}

fn parse_duration_seconds(text: Option<&str>) -> Option<i64> {
    let raw = text?.to_ascii_lowercase();
    let mut total = 0.0;
    let mut matched = false;
    let tokens: Vec<&str> = raw.split_whitespace().collect();
    for pair in tokens.windows(2) {
        if let Ok(num) = pair[0].replace(',', ".").parse::<f64>() {
            if pair[1].starts_with("hour") {
                total += num * 3600.0;
                matched = true;
            } else if pair[1].starts_with("minute") {
                total += num * 60.0;
                matched = true;
            } else if pair[1].starts_with("second") {
                total += num;
                matched = true;
            }
        }
    }
    if matched {
        Some(total as i64)
    } else {
        None
    }
}

fn upower_battery() -> Option<RawBattery> {
    which("upower")?;
    let enum_res = run_cmd_timeout("upower", &["-e"], None, 6000);
    let dev = enum_res
        .stdout
        .lines()
        .find(|l| l.to_ascii_lowercase().contains("battery") || l.contains("BAT"))?
        .trim()
        .to_string();
    if dev.is_empty() {
        return None;
    }

    let info_res = run_cmd_timeout("upower", &["-i", &dev], None, 6000);
    if info_res.code != 0 {
        return None;
    }
    let mut fields = HashMap::new();
    for line in info_res.stdout.lines() {
        if let Some((k, v)) = line.split_once(':') {
            let k = k.trim().to_ascii_lowercase();
            let v = v.trim().to_string();
            if !k.is_empty() && !v.is_empty() {
                fields.insert(k, v);
            }
        }
    }
    if fields.is_empty() {
        return None;
    }
    let percent = clamp_percent(parse_first_float(fields.get("percentage").map(|s| s.as_str())));
    let state = norm_state(fields.get("state").map(|s| s.as_str()));
    if percent.is_none() && state == "unknown" {
        return None;
    }
    let cycles = parse_first_int(
        fields
            .get("cycle count")
            .or_else(|| fields.get("charge cycles"))
            .map(|s| s.as_str()),
    );
    Some(RawBattery {
        percent,
        state,
        power_now: parse_first_float(fields.get("energy-rate").map(|s| s.as_str())),
        energy_now: parse_first_float(fields.get("energy").map(|s| s.as_str())),
        energy_full: parse_first_float(fields.get("energy-full").map(|s| s.as_str())),
        energy_design: parse_first_float(fields.get("energy-full-design").map(|s| s.as_str())),
        voltage: parse_first_float(fields.get("voltage").map(|s| s.as_str())),
        cycles,
        time_to_empty: parse_duration_seconds(fields.get("time to empty").map(|s| s.as_str())),
        time_to_full: parse_duration_seconds(fields.get("time to full").map(|s| s.as_str())),
        health_percent: parse_first_int(fields.get("capacity").map(|s| s.as_str())),
        source: "upower",
    })
}

fn read_profiles() -> (String, Vec<String>) {
    if which("powerprofilesctl").is_none() {
        return (String::new(), Vec::new());
    }
    let cur = run_cmd_timeout("powerprofilesctl", &["get"], None, 4000)
        .stdout
        .trim()
        .to_string();
    let listing = run_cmd_timeout("powerprofilesctl", &["list"], None, 4000).stdout;
    let mut found = Vec::new();
    for &p in PROFILES {
        let needle = format!("{}:", p);
        if listing.lines().any(|line| {
            let trimmed = line.trim_start_matches(|c: char| !c.is_ascii_alphanumeric());
            trimmed.starts_with(&needle)
        }) {
            found.push(p.to_string());
        }
    }
    if found.is_empty() {
        found = PROFILES.iter().map(|s| (*s).to_string()).collect();
    }
    let active = if found.iter().any(|p| p == &cur) {
        cur
    } else {
        String::new()
    };
    (active, found)
}

pub fn set_profile(name: &str) -> Result<JsonVal, String> {
    if !PROFILES.contains(&name) {
        return Err("Unknown power profile.".to_string());
    }
    if which("powerprofilesctl").is_none() {
        return Err("powerprofilesctl is not installed.".to_string());
    }
    let res = run_cmd_timeout("powerprofilesctl", &["set", name], None, 6000);
    if res.code != 0 {
        return Err("power-profiles-daemon refused the profile change.".to_string());
    }
    if let Ok(mut guard) = cache().lock() {
        guard.at = None;
    }
    Ok(status())
}

fn round2(v: f64) -> f64 {
    (v * 100.0).round() / 100.0
}

pub fn status() -> JsonVal {
    if let Ok(guard) = cache().lock() {
        if let (Some(at), Some(val)) = (guard.at, &guard.val) {
            if at.elapsed().as_millis() < CACHE_MS {
                return val.clone();
            }
        }
    }

    let raw = upower_battery().or_else(sysfs_battery);
    let (profile, profiles) = read_profiles();
    let profiles_json = JsonVal::Arr(profiles.into_iter().map(JsonVal::Str).collect());

    let built = match raw {
        None => JsonVal::obj(vec![
            ("available", JsonVal::Bool(false)),
            ("present", JsonVal::Bool(false)),
            ("percent", JsonVal::Null),
            ("state", JsonVal::Str("unknown".to_string())),
            ("timeToEmpty", JsonVal::Null),
            ("timeToFull", JsonVal::Null),
            ("watts", JsonVal::Null),
            (
                "health",
                JsonVal::obj(vec![
                    ("full", JsonVal::Null),
                    ("design", JsonVal::Null),
                    ("percent", JsonVal::Null),
                ]),
            ),
            ("cycles", JsonVal::Null),
            ("voltage", JsonVal::Null),
            ("profile", JsonVal::Str(profile)),
            ("profiles", profiles_json),
            ("source", JsonVal::Str(String::new())),
            ("error", JsonVal::Str("No battery detected.".to_string())),
        ]),
        Some(r) => {
            let mut health_pct = r.health_percent;
            if health_pct.is_none() {
                if let (Some(full), Some(design)) = (r.energy_full, r.energy_design) {
                    if full > 0.0 && design > 0.0 {
                        health_pct = clamp_percent(Some(full / design * 100.0));
                    }
                }
            }
            let watts = r.power_now.map(|w| w.abs());
            let mut seconds: Option<i64> = None;
            if r.state == "discharging" {
                seconds = r.time_to_empty.filter(|&s| s > 0);
                if seconds.is_none() {
                    if let (Some(now_wh), Some(rate)) = (r.energy_now, watts) {
                        if rate > 0.0 {
                            seconds = Some((now_wh / rate * 3600.0) as i64);
                        }
                    }
                }
            } else if r.state == "charging" {
                seconds = r.time_to_full.filter(|&s| s > 0);
                if seconds.is_none() {
                    if let (Some(now_wh), Some(total), Some(rate)) =
                        (r.energy_now, r.energy_full, watts)
                    {
                        if rate > 0.0 {
                            seconds = Some(((total - now_wh).max(0.0) / rate * 3600.0) as i64);
                        }
                    }
                }
            }

            JsonVal::obj(vec![
                ("available", JsonVal::Bool(true)),
                ("present", JsonVal::Bool(true)),
                ("percent", r.percent.into()),
                ("state", JsonVal::Str(r.state.to_string())),
                (
                    "timeToEmpty",
                    if r.state == "discharging" {
                        seconds.filter(|&s| s > 0).into()
                    } else {
                        JsonVal::Null
                    },
                ),
                (
                    "timeToFull",
                    if r.state == "charging" {
                        seconds.filter(|&s| s > 0).into()
                    } else {
                        JsonVal::Null
                    },
                ),
                (
                    "watts",
                    watts.filter(|&w| w > 0.0).map(round2).into(),
                ),
                (
                    "health",
                    JsonVal::obj(vec![
                        ("full", r.energy_full.into()),
                        ("design", r.energy_design.into()),
                        ("percent", health_pct.into()),
                    ]),
                ),
                ("cycles", r.cycles.into()),
                (
                    "voltage",
                    r.voltage.filter(|&v| v > 0.0).map(round2).into(),
                ),
                ("profile", JsonVal::Str(profile)),
                ("profiles", profiles_json),
                ("source", JsonVal::Str(r.source.to_string())),
                ("error", JsonVal::Str(String::new())),
            ])
        }
    };

    if let Ok(mut guard) = cache().lock() {
        guard.at = Some(Instant::now());
        guard.val = Some(built.clone());
    }
    built
}
