//! Bluetooth control through `bluetoothctl` — tolerant, asynchronous, stdout-only.

use std::path::Path;
use std::process::{Child, Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Condvar, Mutex, OnceLock};
use std::thread;
use std::time::{Duration, Instant};

use crate::constants::{cli_environment, run_cmd_timeout, spawn_small, CmdResult};
use crate::json::JsonVal;
use crate::pathutil::{is_executable_file, which};

const DETECT_TIMEOUT_MS: u64 = 6_000;
const PAIR_TIMEOUT_MS: u64 = 60_000;
const SCAN_SECONDS: u64 = 8;
const SCAN_GRACE_SECONDS: u64 = 15;
const MAX_DEVICES: usize = 24;
const MAX_DETAIL: usize = 240;

const CLI_FALLBACKS: &[&str] = &[
    "/usr/bin/bluetoothctl",
    "/bin/bluetoothctl",
    "/usr/local/bin/bluetoothctl",
    "/usr/sbin/bluetoothctl",
    "/sbin/bluetoothctl",
];

const DEFINITIVE: &[&str] = &["no default controller available", "no controller available"];

const FRIENDLY: &[(&str, &str)] = &[
    (
        "No default controller available",
        "No Bluetooth adapter was found. Check that it is plugged in and not disabled in firmware.",
    ),
    (
        "Failed to connect to bus",
        "The Bluetooth service (bluetoothd) is not running. Start it with: sudo systemctl start bluetooth",
    ),
    (
        "Blocked through rfkill",
        "Bluetooth is blocked by rfkill. The power button unblocks it; or run: sudo rfkill unblock bluetooth",
    ),
    (
        "org.bluez.Error.AuthenticationFailed",
        "The device rejected the pairing.",
    ),
    (
        "org.bluez.Error.AuthenticationRejected",
        "The device rejected the pairing.",
    ),
    (
        "org.bluez.Error.AuthenticationTimeout",
        "Pairing timed out. Put the device in pairing mode and try again.",
    ),
    (
        "org.bluez.Error.Failed",
        "The device refused the request. Make sure it is in range and awake.",
    ),
    (
        "org.bluez.Error.Blocked",
        "The adapter is blocked. The power button unblocks it first.",
    ),
    (
        "le-connection-abort-by-local",
        "The connection attempt was dropped. Try again.",
    ),
];

#[derive(Clone, Debug)]
pub struct BluetoothError {
    pub message: String,
    pub detail: String,
}

impl BluetoothError {
    pub fn new(msg: impl Into<String>, detail: impl Into<String>) -> Self {
        let d: String = detail.into();
        Self {
            message: msg.into(),
            detail: d.chars().take(MAX_DETAIL).collect(),
        }
    }
}

pub fn cli_path() -> Option<String> {
    if let Some(p) = which("bluetoothctl") {
        return Some(p.to_string_lossy().into_owned());
    }
    for cand in CLI_FALLBACKS {
        if is_executable_file(Path::new(cand)) {
            return Some((*cand).to_string());
        }
    }
    None
}

pub fn available() -> bool {
    cli_path().is_some()
}

pub fn valid_mac(addr: &str) -> bool {
    let b = addr.as_bytes();
    if b.len() != 17 {
        return false;
    }
    for i in 0..6 {
        let p = i * 3;
        if !b[p].is_ascii_hexdigit() || !b[p + 1].is_ascii_hexdigit() {
            return false;
        }
        if i < 5 && b[p + 2] != b':' {
            return false;
        }
    }
    true
}

fn clean_address(addr: Option<&str>) -> Result<String, BluetoothError> {
    let Some(s) = addr.map(|a| a.trim()) else {
        return Err(BluetoothError::new("That is not a Bluetooth address.", ""));
    };
    if !valid_mac(s) {
        return Err(BluetoothError::new("That is not a Bluetooth address.", ""));
    }
    Ok(s.to_ascii_uppercase())
}

fn icon_kind(icon: &str) -> &'static str {
    match icon {
        "audio-card"
        | "audio-headset"
        | "audio-headphones"
        | "audio-speakers"
        | "audio-input-microphone" => "audio",
        "input-keyboard" => "keyboard",
        "input-mouse" => "mouse",
        "input-tablet" => "tablet",
        "input-gaming" => "gamepad",
        "phone" | "smartphone" => "phone",
        "computer" | "laptop" => "computer",
        "watch" => "watch",
        "printer" => "printer",
        "camera-photo" => "camera",
        _ => "other",
    }
}

fn run_bt(args: &[&str], timeout_ms: u64) -> Result<CmdResult, BluetoothError> {
    let Some(cli) = cli_path() else {
        return Err(BluetoothError::new(
            "bluetoothctl is not installed. On Arch: sudo pacman -S bluez bluez-utils",
            "",
        ));
    };
    let env = cli_environment();
    let res = run_cmd_timeout(&cli, args, Some(&env), timeout_ms);
    if let Some(err) = res.spawn_error {
        return Err(BluetoothError::new(
            format!("bluetoothctl could not be started: {} ({})", err, cli),
            "",
        ));
    }
    if res.timed_out {
        let d = if !res.stdout.trim().is_empty() {
            res.stdout.trim()
        } else {
            res.stderr.trim()
        };
        return Err(BluetoothError::new(
            format!(
                "bluetoothctl {} did not answer in {}s.",
                args.join(" "),
                timeout_ms / 1000
            ),
            d,
        ));
    }
    Ok(res)
}

fn first_detail(res: &CmdResult) -> String {
    for line in res.stdout.lines().chain(res.stderr.lines()) {
        let t = line.trim();
        if !t.is_empty() {
            return t.chars().take(MAX_DETAIL).collect();
        }
    }
    String::new()
}

fn combined_message(res: &CmdResult) -> String {
    let out: Vec<&str> = res
        .stdout
        .lines()
        .map(|l| l.trim())
        .filter(|l| !l.is_empty())
        .collect();
    if !out.is_empty() {
        return out.join("\n");
    }
    res.stderr
        .lines()
        .map(|l| l.trim())
        .filter(|l| !l.is_empty())
        .collect::<Vec<_>>()
        .join("\n")
}

fn humanize(text: &str, fallback: &str) -> String {
    let lower = text.to_ascii_lowercase();
    for (needle, friendly) in FRIENDLY {
        if lower.contains(&needle.to_ascii_lowercase()) && !friendly.is_empty() {
            return (*friendly).to_string();
        }
    }
    fallback.to_string()
}

fn strip_controller_qualifier(s: &str) -> &str {
    let trimmed = s.trim_start();
    for prefix in ["(public)", "(le)", "(bredr)", "(dual)"] {
        if trimmed.len() >= prefix.len()
            && trimmed[..prefix.len()].eq_ignore_ascii_case(prefix)
        {
            return trimmed[prefix.len()..].trim_start();
        }
    }
    trimmed
}

fn controller_from(text: &str) -> Option<JsonVal> {
    let lines: Vec<&str> = text.lines().map(|l| l.trim()).filter(|l| !l.is_empty()).collect();
    for (pos, &line) in lines.iter().enumerate() {
        if line.len() < 11 || !line[..11].eq_ignore_ascii_case("controller ") {
            continue;
        }
        let mut parts = line.splitn(3, char::is_whitespace);
        let _ = parts.next();
        let raw_addr = parts
            .next()
            .unwrap_or("")
            .trim()
            .trim_matches(&['(', ')'][..]);
        if !valid_mac(raw_addr) {
            continue;
        }
        let rest_raw = parts.next().unwrap_or("");
        let mut rest = strip_controller_qualifier(rest_raw)
            .replace("[default]", "")
            .trim()
            .to_string();
        if rest.is_empty() {
            for follow in lines.iter().skip(pos + 1).take(11) {
                let fl = follow.to_ascii_lowercase();
                if fl.starts_with("name:") {
                    rest = follow.split_once(':').map(|(_, v)| v.trim()).unwrap_or("").to_string();
                    break;
                }
                if fl.starts_with("controller ") {
                    break;
                }
            }
        }
        return Some(JsonVal::obj(vec![
            ("address", JsonVal::Str(raw_addr.to_ascii_uppercase())),
            ("name", JsonVal::Str(rest)),
            ("default", JsonVal::Bool(line.contains("[default]"))),
        ]));
    }
    None
}

fn power_from(text: &str) -> Option<bool> {
    for line in text.lines().map(|l| l.trim()) {
        let lower = line.to_ascii_lowercase();
        if let Some(rest) = lower.strip_prefix("powered:") {
            match rest.trim() {
                "yes" | "on" | "true" => return Some(true),
                "no" | "off" | "false" => return Some(false),
                _ => {}
            }
        }
    }
    None
}

fn rfkill_blocked() -> (bool, bool) {
    let Some(rfkill) = which("rfkill") else {
        return (false, false);
    };
    let env = cli_environment();
    let res = run_cmd_timeout(
        &rfkill.to_string_lossy(),
        &["list", "bluetooth"],
        Some(&env),
        6_000,
    );
    let mut soft = false;
    let mut hard = false;
    for line in res.stdout.lines() {
        let l = line.to_ascii_lowercase();
        if l.contains("soft blocked: yes") {
            soft = true;
        }
        if l.contains("hard blocked: yes") {
            hard = true;
        }
    }
    (soft || hard, hard)
}

fn rfkill_unblock() -> bool {
    let Some(rfkill) = which("rfkill") else {
        return false;
    };
    let env = cli_environment();
    run_cmd_timeout(
        &rfkill.to_string_lossy(),
        &["unblock", "bluetooth"],
        Some(&env),
        6_000,
    )
    .spawn_error
    .is_none()
}

fn detect_controller() -> (Option<JsonVal>, Option<bool>, Vec<String>) {
    let mut notes = Vec::new();
    for attempt in 0..2 {
        match run_bt(&["list"], DETECT_TIMEOUT_MS) {
            Ok(res) => {
                if let Some(adapter) = controller_from(&res.stdout) {
                    return (Some(adapter), None, notes);
                }
                let note = first_detail(&res);
                if !note.is_empty() && !notes.contains(&note) {
                    notes.push(note);
                }
                let said = format!("{}\n{}", res.stderr, res.stdout).to_ascii_lowercase();
                let transient = !DEFINITIVE.iter().any(|tok| said.contains(tok))
                    && !res.stdout.lines().any(|l| !l.trim().is_empty());
                if !transient {
                    break;
                }
            }
            Err(err) => {
                let n = if err.detail.is_empty() {
                    err.message
                } else {
                    format!("{}: {}", err.message, err.detail)
                };
                if !notes.contains(&n) {
                    notes.push(n);
                }
            }
        }
        if attempt == 0 {
            thread::sleep(Duration::from_secs(1));
        }
    }

    match run_bt(&["show"], DETECT_TIMEOUT_MS) {
        Ok(res) => {
            let adapter = controller_from(&res.stdout);
            let powered = power_from(&res.stdout);
            if adapter.is_some() {
                return (adapter, powered, notes);
            }
            let note = first_detail(&res);
            if !note.is_empty() && !notes.contains(&note) {
                notes.push(note);
            }
        }
        Err(err) => {
            let n = if err.detail.is_empty() {
                err.message
            } else {
                format!("{}: {}", err.message, err.detail)
            };
            if !notes.contains(&n) {
                notes.push(n);
            }
        }
    }
    (None, None, notes)
}

fn scan_slot() -> &'static Mutex<Option<Child>> {
    static SLOT: OnceLock<Mutex<Option<Child>>> = OnceLock::new();
    SLOT.get_or_init(|| Mutex::new(None))
}

pub fn scanning() -> bool {
    if let Ok(mut guard) = scan_slot().lock() {
        if let Some(ref mut child) = *guard {
            match child.try_wait() {
                Ok(None) => return true,
                _ => {
                    *guard = None;
                }
            }
        }
    }
    false
}

pub fn stop_scan() -> bool {
    let child_opt = scan_slot().lock().ok().and_then(|mut g| g.take());
    let Some(mut child) = child_opt else {
        return false;
    };
    if matches!(child.try_wait(), Ok(Some(_))) {
        return false;
    }
    let _ = child.kill();
    let _ = child.wait();
    true
}

pub fn start_scan_bg<F>(seconds: u64, on_done: F) -> JsonVal
where
    F: FnOnce() + Send + 'static,
{
    let Some(cli) = cli_path() else {
        return status(false);
    };
    if scanning() {
        let mut st = status(false);
        st.set("scanning", JsonVal::Bool(true));
        return st;
    }
    let mut st = status(false);
    if st.get("adapter").map(|v| v.is_null()).unwrap_or(true) {
        return st;
    }
    if st.get_bool("powered") != Some(true) {
        st.set("scanning", JsonVal::Bool(false));
        if st.get_str("error").unwrap_or("").is_empty() {
            st.set(
                "error",
                JsonVal::Str("Bluetooth is off. Switch it on to scan for devices.".to_string()),
            );
        }
        return st;
    }

    let mut cmd = Command::new(&cli);
    cmd.args(["--timeout", &seconds.to_string(), "scan", "on"])
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    for (k, v) in cli_environment() {
        cmd.env(k, v);
    }
    let child = match cmd.spawn() {
        Ok(c) => c,
        Err(e) => {
            st.set(
                "error",
                JsonVal::Str(format!("bluetoothctl could not start a scan: {}", e)),
            );
            return st;
        }
    };
    let pid = child.id();
    if let Ok(mut guard) = scan_slot().lock() {
        *guard = Some(child);
    }

    spawn_small("sphere-bt-scan", move || {
        let deadline = Instant::now() + Duration::from_secs(seconds + SCAN_GRACE_SECONDS);
        loop {
            let alive = if let Ok(mut guard) = scan_slot().lock() {
                match guard.as_mut() {
                    Some(c) if c.id() == pid => match c.try_wait() {
                        Ok(None) => {
                            if Instant::now() >= deadline {
                                let _ = c.kill();
                                let _ = c.wait();
                                *guard = None;
                                false
                            } else {
                                true
                            }
                        }
                        _ => {
                            *guard = None;
                            false
                        }
                    },
                    _ => false,
                }
            } else {
                false
            };
            if !alive {
                break;
            }
            thread::sleep(Duration::from_millis(150));
        }
        on_done();
    });

    st.set("scanning", JsonVal::Bool(true));
    st.set("error", JsonVal::Str(String::new()));
    st
}

struct DevDetail {
    paired: bool,
    connected: bool,
    trusted: bool,
    icon: String,
    alias: String,
}

fn device_details(address: &str) -> DevDetail {
    let mut d = DevDetail {
        paired: false,
        connected: false,
        trusted: false,
        icon: String::new(),
        alias: String::new(),
    };
    let Ok(res) = run_bt(&["info", address], 8_000) else {
        return d;
    };
    for line in res.stdout.lines().map(|l| l.trim()) {
        let Some((k, v)) = line.split_once(':') else {
            continue;
        };
        let k = k.trim().to_ascii_lowercase();
        let v = v.trim();
        match k.as_str() {
            "paired" => d.paired = v.eq_ignore_ascii_case("yes"),
            "connected" => d.connected = v.eq_ignore_ascii_case("yes"),
            "trusted" => d.trusted = v.eq_ignore_ascii_case("yes"),
            "icon" => d.icon = v.to_string(),
            "alias" => d.alias = v.to_string(),
            _ => {}
        }
    }
    d
}

fn list_devices() -> Result<Vec<JsonVal>, BluetoothError> {
    let known = run_bt(&["devices"], 12_000)?;
    let mut ordered: Vec<(String, String)> = Vec::new();
    for line in known.stdout.lines().map(|l| l.trim()).filter(|l| !l.is_empty()) {
        let mut parts = line.splitn(3, char::is_whitespace);
        if parts.next() != Some("Device") {
            continue;
        }
        let Some(mac_raw) = parts.next() else {
            continue;
        };
        if !valid_mac(mac_raw) {
            continue;
        }
        let addr = mac_raw.to_ascii_uppercase();
        let name = parts.next().unwrap_or("").trim().to_string();
        if let Some((_, existing_name)) = ordered.iter_mut().find(|(a, _)| *a == addr) {
            if existing_name.is_empty() && !name.is_empty() {
                *existing_name = name;
            }
        } else {
            ordered.push((addr, name));
        }
    }
    ordered.truncate(MAX_DEVICES);

    struct Row {
        address: String,
        name: String,
        label: String,
        paired: bool,
        connected: bool,
        trusted: bool,
        icon: String,
        kind: &'static str,
    }

    let mut rows = Vec::with_capacity(ordered.len());
    for (address, mut name) in ordered {
        let det = device_details(&address);
        if name.is_empty() && !det.alias.is_empty() {
            name = det.alias;
        }
        let label = if name.is_empty() {
            address.clone()
        } else {
            name.clone()
        };
        let kind = icon_kind(&det.icon);
        rows.push(Row {
            address,
            name,
            label,
            paired: det.paired,
            connected: det.connected,
            trusted: det.trusted,
            icon: det.icon,
            kind,
        });
    }

    rows.sort_by(|a, b| {
        (!a.connected, !a.paired, a.label.to_lowercase()).cmp(&(
            !b.connected,
            !b.paired,
            b.label.to_lowercase(),
        ))
    });

    Ok(rows
        .into_iter()
        .map(|r| {
            JsonVal::obj(vec![
                ("address", JsonVal::Str(r.address)),
                ("name", JsonVal::Str(r.name)),
                ("paired", JsonVal::Bool(r.paired)),
                ("connected", JsonVal::Bool(r.connected)),
                ("trusted", JsonVal::Bool(r.trusted)),
                ("icon", JsonVal::Str(r.icon)),
                ("kind", JsonVal::Str(r.kind.to_string())),
                ("label", JsonVal::Str(r.label)),
            ])
        })
        .collect())
}

pub fn blank_state() -> JsonVal {
    JsonVal::obj(vec![
        ("available", JsonVal::Bool(false)),
        ("powered", JsonVal::Bool(false)),
        ("adapter", JsonVal::Null),
        ("devices", JsonVal::Arr(Vec::new())),
        ("scanning", JsonVal::Bool(scanning())),
        ("blocked", JsonVal::Bool(false)),
        ("blockedHard", JsonVal::Bool(false)),
        ("pending", JsonVal::Bool(false)),
        ("cli", JsonVal::Str(String::new())),
        ("error", JsonVal::Str(String::new())),
        ("detail", JsonVal::Str(String::new())),
    ])
}

fn query_powered() -> Result<bool, BluetoothError> {
    let res = run_bt(&["show"], DETECT_TIMEOUT_MS)?;
    power_from(&res.stdout).ok_or_else(|| {
        BluetoothError::new(
            "bluetoothctl did not report the adapter's power state.",
            first_detail(&res),
        )
    })
}

pub fn status(include_devices: bool) -> JsonVal {
    let started = Instant::now();
    let mut st = blank_state();
    let Some(cli) = cli_path() else {
        st.set(
            "error",
            JsonVal::Str(
                "bluez-utils (bluetoothctl) is not installed, so Bluetooth cannot be controlled from Sphere. On Arch: sudo pacman -S bluez bluez-utils"
                    .to_string(),
            ),
        );
        return st;
    };
    st.set("cli", JsonVal::Str(cli));
    st.set("available", JsonVal::Bool(true));

    let (blocked, hard) = rfkill_blocked();
    st.set("blocked", JsonVal::Bool(blocked));
    st.set("blockedHard", JsonVal::Bool(hard));

    let (adapter, powered_opt, notes) = detect_controller();
    let Some(adapter_val) = adapter else {
        let joined: String = notes.join(" · ").chars().take(MAX_DETAIL).collect();
        let err = if hard {
            "The Bluetooth adapter is hard-blocked (firmware or hardware switch). Enable it in the BIOS or with the hardware switch.".to_string()
        } else {
            humanize(&joined, "No Bluetooth adapter was found on this system.")
        };
        st.set("detail", JsonVal::Str(joined));
        st.set("error", JsonVal::Str(err));
        return st;
    };

    st.set("adapter", adapter_val);
    let powered = match powered_opt {
        Some(p) => p,
        None => match query_powered() {
            Ok(p) => p,
            Err(err) => {
                st.set("detail", JsonVal::Str(err.message));
                false
            }
        },
    };
    st.set("powered", JsonVal::Bool(powered));

    if blocked && !hard {
        st.set(
            "error",
            JsonVal::Str(
                "Bluetooth is blocked by rfkill. Press Power on to unblock and switch it on, or run: sudo rfkill unblock bluetooth"
                    .to_string(),
            ),
        );
    } else if hard && !powered {
        st.set(
            "error",
            JsonVal::Str(
                "The adapter is hard-blocked (firmware or hardware switch). Enable it in the BIOS or with the hardware switch."
                    .to_string(),
            ),
        );
    }

    if include_devices && powered {
        match list_devices() {
            Ok(devs) => st.set("devices", JsonVal::Arr(devs)),
            Err(err) => {
                if st.get_str("error").unwrap_or("").is_empty() {
                    st.set("error", JsonVal::Str(err.message));
                }
                if st.get_str("detail").unwrap_or("").is_empty() {
                    st.set("detail", JsonVal::Str(err.detail));
                }
            }
        }
    }

    st.set("scanning", JsonVal::Bool(scanning()));
    let took = (started.elapsed().as_secs_f64() * 1000.0).round() / 1000.0;
    st.set("took", JsonVal::Float(took));
    st
}

pub fn connect_sync(address: Option<&str>) -> JsonVal {
    let target = match clean_address(address) {
        Ok(t) => t,
        Err(err) => {
            let mut st = status(false);
            st.set("error", JsonVal::Str(err.message));
            st.set("connectedTo", JsonVal::Str(String::new()));
            return st;
        }
    };
    if cli_path().is_none() {
        return status(true);
    }

    let attempt = (|| -> Result<(), BluetoothError> {
        if !query_powered()? {
            return Err(BluetoothError::new(
                "Bluetooth is switched off. Switch it on, then choose the device again.",
                "",
            ));
        }
        let det = device_details(&target);
        if !det.paired {
            let pair = run_bt(&["pair", &target], PAIR_TIMEOUT_MS)?;
            let said = combined_message(&pair);
            let lower = said.to_ascii_lowercase();
            if (lower.contains("failed") || lower.contains("error"))
                && !lower.contains("alreadyexists")
            {
                return Err(BluetoothError::new(
                    humanize(&said, "Pairing with that device failed."),
                    said,
                ));
            }
            let _ = run_bt(&["trust", &target], PAIR_TIMEOUT_MS);
        }
        let res = run_bt(&["connect", &target], PAIR_TIMEOUT_MS)?;
        let said = combined_message(&res);
        let lower = said.to_ascii_lowercase();
        let delivered = lower.contains("connection successful")
            || lower.contains("alreadyconnected")
            || lower.contains("already connected");
        if !delivered && !device_details(&target).connected {
            return Err(BluetoothError::new(
                humanize(&said, "The device did not accept the connection."),
                said,
            ));
        }
        Ok(())
    })();

    if let Err(err) = attempt {
        let mut st = status(false);
        st.set("error", JsonVal::Str(err.message));
        if !err.detail.is_empty() {
            st.set("detail", JsonVal::Str(err.detail));
        }
        st.set("connectedTo", JsonVal::Str(String::new()));
        return st;
    }

    let mut st = status(true);
    let mut label = String::new();
    if let Some(devs) = st.get("devices").and_then(|v| v.as_arr()) {
        for d in devs {
            if d.get_str("address") == Some(target.as_str())
                && d.get_bool("connected") == Some(true)
            {
                label = d.get_str("label").unwrap_or("").to_string();
                break;
            }
        }
    }
    st.set("connectedTo", JsonVal::Str(label));
    st
}

pub fn power_sync(enabled: bool) -> JsonVal {
    if cli_path().is_none() {
        return status(true);
    }
    let mut said = String::new();
    let attempt = (|| -> Result<(), BluetoothError> {
        if enabled {
            let (blocked, hard) = rfkill_blocked();
            if blocked && !hard && rfkill_unblock() {
                thread::sleep(Duration::from_millis(300));
            }
        }
        let res = run_bt(&["power", if enabled { "on" } else { "off" }], 15_000)?;
        said = combined_message(&res);
        let powered = query_powered()?;
        if powered != enabled {
            let detail = if said.is_empty() {
                format!("Powered: {}", if powered { "yes" } else { "no" })
            } else {
                said.clone()
            };
            return Err(BluetoothError::new(
                humanize(&said, "The adapter did not change its power state."),
                detail,
            ));
        }
        Ok(())
    })();

    if let Err(err) = attempt {
        let mut st = status(false);
        st.set("error", JsonVal::Str(err.message));
        if !err.detail.is_empty() {
            st.set("detail", JsonVal::Str(err.detail));
        }
        return st;
    }

    let mut st = status(true);
    if !st.get_str("error").unwrap_or("").is_empty()
        && st.get_str("detail").unwrap_or("").is_empty()
    {
        st.set(
            "detail",
            JsonVal::Str(said.chars().take(MAX_DETAIL).collect()),
        );
    }
    st
}

pub struct Monitor {
    state: Mutex<Option<JsonVal>>,
    wake: (Mutex<bool>, Condvar),
    stop_flag: AtomicBool,
    started: AtomicBool,
    on_change: Box<dyn Fn(JsonVal) + Send + Sync>,
}

impl Monitor {
    pub fn new<F>(on_change: F) -> Arc<Self>
    where
        F: Fn(JsonVal) + Send + Sync + 'static,
    {
        Arc::new(Self {
            state: Mutex::new(None),
            wake: (Mutex::new(false), Condvar::new()),
            stop_flag: AtomicBool::new(false),
            started: AtomicBool::new(false),
            on_change: Box::new(on_change),
        })
    }

    pub fn pending_state(&self) -> JsonVal {
        let mut st = blank_state();
        let cli = cli_path().unwrap_or_default();
        st.set("available", JsonVal::Bool(!cli.is_empty()));
        st.set("pending", JsonVal::Bool(true));
        st.set("cli", JsonVal::Str(cli));
        st
    }

    pub fn current(&self) -> JsonVal {
        if let Ok(guard) = self.state.lock() {
            if let Some(ref s) = *guard {
                return s.clone();
            }
        }
        self.wake();
        self.pending_state()
    }

    pub fn refresh(&self) {
        self.wake();
    }

    pub fn wake(&self) {
        let (lock, cvar) = &self.wake;
        if let Ok(mut w) = lock.lock() {
            *w = true;
            cvar.notify_all();
        }
    }

    fn publish(&self, next: JsonVal) {
        let changed = if let Ok(mut guard) = self.state.lock() {
            let diff = guard.as_ref() != Some(&next);
            *guard = Some(next.clone());
            diff
        } else {
            false
        };
        if changed {
            (self.on_change)(next);
        }
    }

    pub fn start(self: &Arc<Self>) {
        if self.started.swap(true, Ordering::SeqCst) {
            return;
        }
        let me = Arc::clone(self);
        spawn_small("sphere-bt-mon", move || {
            while !me.stop_flag.load(Ordering::SeqCst) {
                let next = status(true);
                let is_scanning = next.get_bool("scanning") == Some(true);
                me.publish(next);
                let wait = if is_scanning {
                    Duration::from_secs(1)
                } else {
                    Duration::from_secs(4)
                };
                let (lock, cvar) = &me.wake;
                if let Ok(mut w) = lock.lock() {
                    if !*w && !me.stop_flag.load(Ordering::SeqCst) {
                        let (mut nw, _) = cvar.wait_timeout(w, wait).unwrap_or_else(|e| e.into_inner());
                        *nw = false;
                    } else {
                        *w = false;
                    }
                }
            }
        });
    }

    pub fn stop(&self) {
        self.stop_flag.store(true, Ordering::SeqCst);
        stop_scan();
        self.wake();
    }

    pub fn set_power(self: &Arc<Self>, enabled: bool) {
        let me = Arc::clone(self);
        spawn_small("sphere-bt-power", move || {
            let next = power_sync(enabled);
            me.publish(next);
            me.wake();
        });
    }

    pub fn connect(self: &Arc<Self>, address: Option<String>) {
        let me = Arc::clone(self);
        spawn_small("sphere-bt-conn", move || {
            let next = connect_sync(address.as_deref());
            me.publish(next);
            me.wake();
        });
    }

    pub fn start_scan(self: &Arc<Self>) {
        let me = Arc::clone(self);
        spawn_small("sphere-bt-scan-req", move || {
            let waker = Arc::clone(&me);
            let next = start_scan_bg(SCAN_SECONDS, move || {
                waker.wake();
            });
            me.publish(next);
        });
    }

    pub fn stop_scan(&self) {
        if stop_scan() {
            self.wake();
        }
    }
}
