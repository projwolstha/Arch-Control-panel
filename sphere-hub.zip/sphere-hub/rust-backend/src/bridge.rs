//! The stdio JSON protocol: requests in, events/responses out.

use std::collections::BTreeSet;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::os::unix::net::UnixStream;
use std::os::unix::process::CommandExt;
use std::path::Path;
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Condvar, Mutex};
use std::time::Duration;

use crate::battery;
use crate::bluetooth;
use crate::catalog::{DesktopCatalog, DesktopEntry};
use crate::config::{ConfigStore, SlotTarget};
use crate::constants::{recipe_by_id, spawn_small, RECIPES, SLOT_COUNT};
use crate::hypr::{desktop_environment, hypr_command};
use crate::json::{parse_json, JsonVal};
use crate::pathutil::{expand_exec, socket_path, which};
use crate::resources;
use crate::system::{install_plan, terminal_argv, SystemInfo};
use crate::wifi;

pub fn render_capability() -> JsonVal {
    JsonVal::obj(vec![
        ("renderer", JsonVal::Str("svg-shapes".to_string())),
        ("shader", JsonVal::Bool(false)),
        ("reason", JsonVal::Str("not-used".to_string())),
    ])
}

fn prepend_type(ty: &str, val: JsonVal) -> JsonVal {
    let mut entries = Vec::with_capacity(16);
    entries.push(("type".to_string(), JsonVal::Str(ty.to_string())));
    if let JsonVal::Obj(rest) = val {
        for (k, v) in rest {
            if k != "type" {
                entries.push((k, v));
            }
        }
    }
    JsonVal::Obj(entries)
}

struct BridgeInner {
    catalog: DesktopCatalog,
    store: ConfigStore,
    clients: Vec<JsonVal>,
}

pub struct Bridge {
    inner: Mutex<BridgeInner>,
    pub stop: AtomicBool,
    dirty: (Mutex<bool>, Condvar),
    stop_wait: (Mutex<bool>, Condvar),
    pub bluetooth: Arc<bluetooth::Monitor>,
    pub wifi: Arc<wifi::Monitor>,
    emit: Arc<dyn Fn(JsonVal) + Send + Sync>,
}

impl Bridge {
    pub fn new<F>(config_path: Option<&Path>, emit: F) -> Arc<Self>
    where
        F: Fn(JsonVal) + Send + Sync + 'static,
    {
        let emit_arc: Arc<dyn Fn(JsonVal) + Send + Sync> = Arc::new(emit);
        let mut catalog = DesktopCatalog::new(None);
        catalog.refresh();
        let store = ConfigStore::new(config_path);

        let emit_bt = Arc::clone(&emit_arc);
        let bt_mon = bluetooth::Monitor::new(move |st| {
            emit_bt(prepend_type("bluetooth", st));
        });

        let emit_wf = Arc::clone(&emit_arc);
        let wf_mon = wifi::Monitor::new(move |st| {
            emit_wf(prepend_type("wifi", st));
        });

        Arc::new(Self {
            inner: Mutex::new(BridgeInner {
                catalog,
                store,
                clients: Vec::new(),
            }),
            stop: AtomicBool::new(false),
            dirty: (Mutex::new(true), Condvar::new()),
            stop_wait: (Mutex::new(false), Condvar::new()),
            bluetooth: bt_mon,
            wifi: wf_mon,
            emit: emit_arc,
        })
    }

    pub fn signal_stop(&self) {
        self.stop.store(true, Ordering::SeqCst);
        self.mark_dirty();
        let (lock, cvar) = &self.stop_wait;
        if let Ok(mut g) = lock.lock() {
            *g = true;
            cvar.notify_all();
        }
    }

    pub fn wait_stop(&self, dur: Duration) -> bool {
        if self.stop.load(Ordering::SeqCst) {
            return true;
        }
        let (lock, cvar) = &self.stop_wait;
        if let Ok(g) = lock.lock() {
            if *g {
                return true;
            }
            let (ng, _) = cvar.wait_timeout(g, dur).unwrap_or_else(|e| e.into_inner());
            return *ng || self.stop.load(Ordering::SeqCst);
        }
        self.stop.load(Ordering::SeqCst)
    }

    pub fn mark_dirty(&self) {
        let (lock, cvar) = &self.dirty;
        if let Ok(mut d) = lock.lock() {
            *d = true;
            cvar.notify_all();
        }
    }

    fn resolved_slot(catalog: &DesktopCatalog, target: Option<&SlotTarget>) -> JsonVal {
        let Some(t) = target else {
            return JsonVal::Null;
        };
        if t.kind == "desktop" {
            if let Some(entry) = catalog.get(&t.id) {
                return entry.public_json();
            }
            let short = t.id.strip_suffix(".desktop").unwrap_or(&t.id).to_string();
            return JsonVal::obj(vec![
                ("id", JsonVal::Str(t.id.clone())),
                ("name", JsonVal::Str(short)),
                (
                    "description",
                    JsonVal::Str(
                        "Desktop entry is no longer installed. Right-click to replace it."
                            .to_string(),
                    ),
                ),
                ("icon", JsonVal::Str(String::new())),
                ("installed", JsonVal::Bool(false)),
            ]);
        }
        let Some(recipe) = recipe_by_id(&t.id) else {
            return JsonVal::obj(vec![
                ("id", JsonVal::Str(t.id.clone())),
                ("name", JsonVal::Str("Unknown app".to_string())),
                (
                    "description",
                    JsonVal::Str("Please choose an application again.".to_string()),
                ),
                ("icon", JsonVal::Str(String::new())),
                ("installed", JsonVal::Bool(false)),
            ]);
        };
        if let Some(entry) = catalog.recipe_entry(recipe) {
            let mut pub_j = entry.public_json();
            pub_j.set("recipeId", JsonVal::Str(recipe.id.to_string()));
            return pub_j;
        }
        JsonVal::obj(vec![
            ("id", JsonVal::Str(format!("recipe:{}", recipe.id))),
            ("recipeId", JsonVal::Str(recipe.id.to_string())),
            ("name", JsonVal::Str(recipe.name.to_string())),
            ("description", JsonVal::Str(recipe.description.to_string())),
            ("icon", JsonVal::Str(String::new())),
            ("installed", JsonVal::Bool(false)),
        ])
    }

    pub fn snapshot(&self, refresh: bool) -> JsonVal {
        let mut guard = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        if refresh {
            guard.catalog.refresh();
        }
        let mut recipes_json = Vec::with_capacity(RECIPES.len());
        for recipe in RECIPES {
            let mut resolved = Self::resolved_slot(
                &guard.catalog,
                Some(&SlotTarget {
                    kind: "recipe".to_string(),
                    id: recipe.id.to_string(),
                }),
            );
            resolved.set("recipeId", JsonVal::Str(recipe.id.to_string()));
            resolved.set(
                "managers",
                JsonVal::Arr(
                    recipe
                        .packages
                        .iter()
                        .map(|(m, _)| JsonVal::Str((*m).to_string()))
                        .collect(),
                ),
            );
            recipes_json.push(resolved);
        }
        let slot_apps: Vec<JsonVal> = guard
            .store
            .slots
            .iter()
            .map(|s| Self::resolved_slot(&guard.catalog, s.as_ref()))
            .collect();
        let scan = JsonVal::obj(vec![
            ("dirs", JsonVal::Int(guard.catalog.scan_dirs as i64)),
            ("files", JsonVal::Int(guard.catalog.scan_files as i64)),
            ("listed", JsonVal::Int(guard.catalog.entries.len() as i64)),
        ]);

        JsonVal::obj(vec![
            ("type", JsonVal::Str("snapshot".to_string())),
            ("apps", JsonVal::Arr(guard.catalog.public_entries())),
            ("recipes", JsonVal::Arr(recipes_json)),
            ("slots", guard.store.slots_json()),
            ("slotApps", JsonVal::Arr(slot_apps)),
            ("preferences", guard.store.preferences.to_json()),
            ("system", SystemInfo::gather().to_json()),
            ("scan", scan),
            (
                "savedTo",
                JsonVal::Str(guard.store.path.to_string_lossy().into_owned()),
            ),
            ("render", render_capability()),
        ])
    }

    pub fn status(&self) -> JsonVal {
        let clients_raw = hypr_command("j/clients");
        let active_raw = hypr_command("j/activewindow");
        let (Ok(c_str), Ok(a_str)) = (clients_raw, active_raw) else {
            if let Ok(mut g) = self.inner.lock() {
                g.clients.clear();
            }
            return JsonVal::obj(vec![
                ("type", JsonVal::Str("status".to_string())),
                ("hyprland", JsonVal::Bool(false)),
                ("activeDesktopId", JsonVal::Str(String::new())),
                ("runningDesktopIds", JsonVal::Arr(Vec::new())),
            ]);
        };
        let (Ok(JsonVal::Arr(clients)), Ok(active)) = (parse_json(&c_str), parse_json(&a_str))
        else {
            if let Ok(mut g) = self.inner.lock() {
                g.clients.clear();
            }
            return JsonVal::obj(vec![
                ("type", JsonVal::Str("status".to_string())),
                ("hyprland", JsonVal::Bool(false)),
                ("activeDesktopId", JsonVal::Str(String::new())),
                ("runningDesktopIds", JsonVal::Arr(Vec::new())),
            ]);
        };
        if active.as_obj().is_none() {
            return JsonVal::obj(vec![
                ("type", JsonVal::Str("status".to_string())),
                ("hyprland", JsonVal::Bool(false)),
                ("activeDesktopId", JsonVal::Str(String::new())),
                ("runningDesktopIds", JsonVal::Arr(Vec::new())),
            ]);
        }

        let mut guard = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        let mut running_set = BTreeSet::new();
        for c in &clients {
            let m = guard.catalog.match_client(
                c.get_str("class").unwrap_or(""),
                c.get_str("initialClass").unwrap_or(""),
            );
            if !m.is_empty() {
                running_set.insert(m);
            }
        }
        let active_id = if !active.get_str("address").unwrap_or("").is_empty() {
            guard.catalog.match_client(
                active.get_str("class").unwrap_or(""),
                active.get_str("initialClass").unwrap_or(""),
            )
        } else {
            String::new()
        };
        guard.clients = clients;

        JsonVal::obj(vec![
            ("type", JsonVal::Str("status".to_string())),
            ("hyprland", JsonVal::Bool(true)),
            ("activeDesktopId", JsonVal::Str(active_id)),
            (
                "runningDesktopIds",
                JsonVal::Arr(running_set.into_iter().map(JsonVal::Str).collect()),
            ),
        ])
    }

    fn launch_entry(&self, entry: DesktopEntry) -> Result<JsonVal, String> {
        let _ = self.status();
        let matching_addr = {
            let guard = self.inner.lock().unwrap_or_else(|e| e.into_inner());
            let mut matching: Vec<(i64, String)> = guard
                .clients
                .iter()
                .filter(|c| {
                    guard.catalog.match_client(
                        c.get_str("class").unwrap_or(""),
                        c.get_str("initialClass").unwrap_or(""),
                    ) == entry.id
                })
                .map(|c| {
                    (
                        c.get_i64("focusHistoryID").unwrap_or(99_999),
                        c.get_str("address").unwrap_or("").to_string(),
                    )
                })
                .collect();
            matching.sort_by_key(|(fh, _)| *fh);
            matching.into_iter().next().map(|(_, a)| a)
        };

        if let Some(addr) = matching_addr {
            if addr.starts_with("0x")
                && addr.len() > 2
                && addr[2..].bytes().all(|b| b.is_ascii_hexdigit())
            {
                let mut reply = hypr_command(&format!("dispatch focuswindow address:{}", addr))
                    .unwrap_or_default();
                if reply.trim().to_ascii_lowercase() != "ok" {
                    let arg = JsonVal::Str(format!("address:{}", addr)).to_json_line();
                    reply = hypr_command(&format!("dispatch hl.dsp.focus({{ window = {} }})", arg))
                        .unwrap_or_default();
                }
                if reply.trim().to_ascii_lowercase() != "ok" {
                    return Err("Hyprland could not focus the existing app window.".to_string());
                }
                return Ok(JsonVal::obj(vec![
                    ("launched", JsonVal::Bool(true)),
                    ("focusedExisting", JsonVal::Bool(true)),
                ]));
            }
        }

        let command = if entry.terminal {
            let expanded = expand_exec(&entry.argv, &entry.name, &entry.path)?;
            terminal_argv(&expanded, &format!("Sphere — {}", entry.name))?
        } else if which("gio").is_some() {
            vec!["gio".to_string(), "launch".to_string(), entry.path.clone()]
        } else {
            expand_exec(&entry.argv, &entry.name, &entry.path)?
        };

        spawn_detached(&command, Some(&entry.working_directory))?;
        self.mark_dirty();
        Ok(JsonVal::obj(vec![
            ("launched", JsonVal::Bool(true)),
            ("focusedExisting", JsonVal::Bool(false)),
        ]))
    }

    pub fn wifi_state(&self, rescan: bool) -> JsonVal {
        if rescan {
            self.wifi.scan();
        } else {
            self.wifi.refresh();
        }
        let mut st = self.wifi.current();
        st.set_default("scanning", JsonVal::Bool(false));
        prepend_type("wifi", st)
    }

    pub fn battery_state(&self) -> JsonVal {
        prepend_type("battery", battery::status())
    }

    pub fn resources_state(&self) -> JsonVal {
        prepend_type("resources", resources::status(true))
    }

    pub fn bluetooth_state(&self, scan: bool) -> JsonVal {
        if scan {
            self.bluetooth.start_scan();
        } else {
            self.bluetooth.refresh();
        }
        prepend_type("bluetooth", self.bluetooth.current())
    }

    pub fn request(&self, message: &JsonVal) -> Result<JsonVal, String> {
        if message.as_obj().is_none() {
            return Err("Request must be a JSON object.".to_string());
        }
        let action = message.get_str("action").unwrap_or("");
        match action {
            "wifi" | "wifiScan" => {
                if action == "wifiScan" {
                    self.wifi.set_open(true);
                }
                Ok(self.wifi_state(action == "wifiScan"))
            }
            "wifiPanel" => {
                let opened = message.get_bool("open") == Some(true);
                self.wifi.set_open(opened);
                if opened {
                    self.wifi.scan();
                }
                Ok(self.wifi_state(false))
            }
            "wifiConnect" => {
                let ssid = message.get_str("ssid").map(|s| s.to_string());
                let pass = message.get_str("password").map(|s| s.to_string());
                let sec = message.get_str("security").unwrap_or("").to_string();
                self.wifi.connect(ssid.clone(), pass, sec);
                let mut st = self.wifi_state(false);
                st.set("connected", JsonVal::Str(ssid.unwrap_or_default()));
                Ok(st)
            }
            "wifiDisconnect" => {
                self.wifi.disconnect();
                Ok(self.wifi_state(false))
            }
            "wifiRadio" => {
                self.wifi.set_radio(message.get_bool("enabled") == Some(true));
                Ok(self.wifi_state(false))
            }
            "wifiScanStop" => {
                wifi::stop_scan();
                Ok(self.wifi_state(false))
            }
            "resources" => Ok(self.resources_state()),
            "battery" => Ok(self.battery_state()),
            "batteryProfile" => {
                let name = message.get_str("profile").unwrap_or("");
                match battery::set_profile(name) {
                    Ok(st) => Ok(prepend_type("battery", st)),
                    Err(err) => {
                        let mut st = prepend_type("battery", battery::status());
                        st.set("error", JsonVal::Str(err));
                        Ok(st)
                    }
                }
            }
            "bluetooth" | "bluetoothScan" => Ok(self.bluetooth_state(action == "bluetoothScan")),
            "bluetoothConnect" => {
                let addr = message.get_str("address").map(|s| s.to_string());
                self.bluetooth.connect(addr);
                Ok(prepend_type("bluetooth", self.bluetooth.current()))
            }
            "bluetoothPower" => {
                self.bluetooth
                    .set_power(message.get_bool("enabled") == Some(true));
                Ok(prepend_type("bluetooth", self.bluetooth.current()))
            }
            "bluetoothScanStop" => {
                self.bluetooth.stop_scan();
                Ok(prepend_type("bluetooth", self.bluetooth.current()))
            }
            "bluetoothRefresh" => {
                self.bluetooth.refresh();
                Ok(prepend_type("bluetooth", self.bluetooth.current()))
            }
            "snapshot" | "refresh" => {
                let res = self.snapshot(true);
                self.mark_dirty();
                Ok(res)
            }
            "assign" | "clear" | "launch" => {
                let slot_val = message
                    .get("slot")
                    .and_then(|v| v.as_i64())
                    .ok_or_else(|| "Choose an orb from 1 to 8.".to_string())?;
                if !(0..SLOT_COUNT as i64).contains(&slot_val) {
                    return Err("Choose an orb from 1 to 8.".to_string());
                }
                let index = slot_val as usize;

                if action == "assign" {
                    let target_obj = message
                        .get("target")
                        .filter(|v| v.as_obj().is_some())
                        .ok_or_else(|| {
                            "Choose an installed app or a listed install recipe.".to_string()
                        })?;
                    let kind = target_obj.get_str("kind").unwrap_or("");
                    if !matches!(kind, "desktop" | "recipe") {
                        return Err(
                            "Choose an installed app or a listed install recipe.".to_string()
                        );
                    }
                    let id = target_obj.get_str("id").unwrap_or("").to_string();
                    let new_target = SlotTarget {
                        kind: kind.to_string(),
                        id: id.clone(),
                    };

                    {
                        let mut guard = self.inner.lock().unwrap_or_else(|e| e.into_inner());
                        if kind == "desktop" && guard.catalog.get(&id).is_none() {
                            return Err("This desktop entry is not installed. Refresh the list or choose an install recipe.".to_string());
                        }
                        if kind == "recipe" && recipe_by_id(&id).is_none() {
                            return Err("Unknown install recipe.".to_string());
                        }
                        let mut next_slots = guard.store.slots.clone();
                        let previous = next_slots[index].clone();
                        let resolved = Self::resolved_slot(&guard.catalog, Some(&new_target));
                        let resolved_id = resolved.get_str("id").unwrap_or("").to_string();
                        for (i, other) in next_slots.iter_mut().enumerate() {
                            if i == index {
                                continue;
                            }
                            let existing = Self::resolved_slot(&guard.catalog, other.as_ref());
                            let existing_id = existing.get_str("id").unwrap_or("");
                            if other.as_ref() == Some(&new_target)
                                || (!resolved_id.is_empty() && resolved_id == existing_id)
                            {
                                *other = previous;
                                break;
                            }
                        }
                        next_slots[index] = Some(new_target);
                        let backup = guard.store.slots.clone();
                        guard.store.slots = next_slots;
                        if let Err(e) = guard.store.save() {
                            guard.store.slots = backup;
                            return Err(e);
                        }
                    }
                    return Ok(self.snapshot(false));
                }

                if action == "clear" {
                    {
                        let mut guard = self.inner.lock().unwrap_or_else(|e| e.into_inner());
                        let backup = guard.store.slots.clone();
                        guard.store.slots[index] = None;
                        if let Err(e) = guard.store.save() {
                            guard.store.slots = backup;
                            return Err(e);
                        }
                    }
                    return Ok(self.snapshot(false));
                }

                // launch
                let entry = {
                    let guard = self.inner.lock().unwrap_or_else(|e| e.into_inner());
                    let resolved =
                        Self::resolved_slot(&guard.catalog, guard.store.slots[index].as_ref());
                    if resolved.is_null() || resolved.get_bool("installed") != Some(true) {
                        return Err("This app is not installed. Choose Install in terminal, then refresh the application list.".to_string());
                    }
                    let did = resolved.get_str("id").unwrap_or("");
                    guard
                        .catalog
                        .get(did)
                        .cloned()
                        .ok_or_else(|| "Refresh the application list before launching.".to_string())?
                };
                self.launch_entry(entry)
            }
            "previewInstall" | "install" => {
                let plan = install_plan(
                    message.get_str("recipeId"),
                    message.get_str("package"),
                    message.get_str("manager"),
                )?;
                if action == "previewInstall" {
                    return Ok(plan.to_json(true));
                }
                if message.get_bool("confirmed") != Some(true) {
                    return Err("Explicit confirmation is required before opening an installer terminal.".to_string());
                }
                let self_exe = std::env::current_exe()
                    .map(|p| p.to_string_lossy().into_owned())
                    .unwrap_or_else(|_| "sphere-backend".to_string());
                let cmd = vec![
                    self_exe,
                    "install".to_string(),
                    "--manager".to_string(),
                    plan.manager.clone(),
                    "--package".to_string(),
                    plan.package.clone(),
                ];
                let argv = terminal_argv(&cmd, "Sphere — install")?;
                spawn_detached(&argv, None)?;
                Ok(JsonVal::obj(vec![
                    ("openedTerminal", JsonVal::Bool(true)),
                    ("command", JsonVal::Str(plan.command)),
                    ("installed", JsonVal::Bool(false)),
                    (
                        "note",
                        JsonVal::Str(
                            "Terminal opened. Installation has not been reported as successful. Confirm there, then use Refresh apps."
                                .to_string(),
                        ),
                    ),
                ]))
            }
            "preferences" => {
                let values = message
                    .get("values")
                    .cloned()
                    .unwrap_or_else(|| JsonVal::Obj(Vec::new()));
                {
                    let mut guard = self.inner.lock().unwrap_or_else(|e| e.into_inner());
                    let backup = guard.store.preferences.clone();
                    guard.store.preferences.apply_update(&values)?;
                    if let Err(e) = guard.store.save() {
                        guard.store.preferences = backup;
                        return Err(e);
                    }
                }
                Ok(self.snapshot(false))
            }
            _ => Err("Unknown action. Arbitrary shell commands are not supported.".to_string()),
        }
    }

    pub fn event_listener(&self) {
        const INTERESTING: &[&str] = &[
            "activewindow",
            "activewindowv2",
            "openwindow",
            "closewindow",
            "workspace",
            "workspacev2",
            "movewindow",
            "movewindowv2",
        ];
        while !self.stop.load(Ordering::SeqCst) {
            let Some(path) = socket_path(".socket2.sock") else {
                if self.wait_stop(Duration::from_secs(3)) {
                    break;
                }
                continue;
            };
            let Ok(mut client) = UnixStream::connect(&path) else {
                if self.wait_stop(Duration::from_secs(3)) {
                    break;
                }
                continue;
            };
            let _ = client.set_read_timeout(Some(Duration::from_secs(1)));
            self.mark_dirty();
            let mut pending: Vec<u8> = Vec::with_capacity(512);
            let mut buf = [0u8; 4096];
            while !self.stop.load(Ordering::SeqCst) {
                match client.read(&mut buf) {
                    Ok(0) => break,
                    Ok(n) => {
                        pending.extend_from_slice(&buf[..n]);
                        while let Some(pos) = pending.iter().position(|&b| b == b'\n') {
                            let line: Vec<u8> = pending.drain(..=pos).collect();
                            if let Some(sep) = line.windows(2).position(|w| w == b">>") {
                                if let Ok(ev) = std::str::from_utf8(&line[..sep]) {
                                    if INTERESTING.contains(&ev) {
                                        self.mark_dirty();
                                    }
                                }
                            }
                        }
                        if pending.len() > 64 * 1024 {
                            pending.clear();
                        }
                    }
                    Err(e)
                        if matches!(
                            e.kind(),
                            std::io::ErrorKind::WouldBlock | std::io::ErrorKind::TimedOut
                        ) =>
                    {
                        continue;
                    }
                    Err(_) => break,
                }
            }
        }
    }

    pub fn status_worker(&self) {
        let mut last_status: Option<JsonVal> = None;
        while !self.stop.load(Ordering::SeqCst) {
            let is_dirty = {
                let (lock, cvar) = &self.dirty;
                if let Ok(d) = lock.lock() {
                    if *d {
                        true
                    } else {
                        let (nd, _) = cvar
                            .wait_timeout(d, Duration::from_secs(5))
                            .unwrap_or_else(|e| e.into_inner());
                        *nd
                    }
                } else {
                    false
                }
            };
            if self.stop.load(Ordering::SeqCst) {
                break;
            }
            if is_dirty {
                if self.wait_stop(Duration::from_millis(80)) {
                    break;
                }
                if let Ok(mut d) = self.dirty.0.lock() {
                    *d = false;
                }
            }
            let st = self.status();
            if last_status.as_ref() != Some(&st) {
                last_status = Some(st.clone());
                (self.emit)(st);
            }
        }
    }

    pub fn watch_wifi(&self) {
        if !wifi::available() {
            return;
        }
        let mut last: Option<JsonVal> = None;
        let mut publish = |me: &Bridge| {
            me.wifi.refresh();
            let cur = me.wifi.current();
            if last.as_ref() != Some(&cur) {
                last = Some(cur.clone());
                (me.emit)(prepend_type("wifi", cur));
            }
        };

        while !self.stop.load(Ordering::SeqCst) {
            let child_opt = Command::new("nmcli")
                .arg("monitor")
                .stdin(Stdio::null())
                .stdout(Stdio::piped())
                .stderr(Stdio::null())
                .spawn()
                .ok();
            let Some(mut child) = child_opt else {
                while !self.wait_stop(Duration::from_secs(20)) {
                    publish(self);
                }
                return;
            };
            publish(self);
            if let Some(stdout) = child.stdout.take() {
                let reader = BufReader::with_capacity(1024, stdout);
                for line in reader.lines() {
                    if line.is_err() || self.stop.load(Ordering::SeqCst) {
                        break;
                    }
                    if self.wait_stop(Duration::from_millis(350)) {
                        break;
                    }
                    publish(self);
                }
            }
            let _ = child.kill();
            let _ = child.wait();
            if self.wait_stop(Duration::from_secs(5)) {
                break;
            }
        }
    }
}

fn spawn_detached(command: &[String], cwd: Option<&str>) -> Result<(), String> {
    if command.is_empty() {
        return Err("Empty launch command.".to_string());
    }
    let mut cmd = Command::new(&command[0]);
    cmd.args(&command[1..])
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    cmd.env_clear();
    for (k, v) in desktop_environment() {
        cmd.env(k, v);
    }
    if let Some(dir) = cwd.filter(|d| !d.is_empty()) {
        if Path::new(dir).is_dir() {
            cmd.current_dir(dir);
        }
    }
    unsafe {
        cmd.pre_exec(|| {
            setsid();
            Ok(())
        });
    }
    cmd.spawn().map(|_| ()).map_err(|e| e.to_string())
}

extern "C" {
    fn setsid() -> i32;
}

fn watch_battery(bridge: Arc<Bridge>) {
    let last: Arc<Mutex<Option<JsonVal>>> = Arc::new(Mutex::new(None));
    let publish = |b: &Bridge, last: &Mutex<Option<JsonVal>>| {
        let st = b.battery_state();
        let changed = if let Ok(mut g) = last.lock() {
            let diff = g.as_ref() != Some(&st);
            *g = Some(st.clone());
            diff
        } else {
            false
        };
        if changed {
            (b.emit)(st);
        }
    };

    if which("upower").is_some() {
        if let Ok(mut child) = Command::new("upower")
            .arg("--monitor")
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
        {
            let b2 = Arc::clone(&bridge);
            let l2 = Arc::clone(&last);
            spawn_small("sphere-upower-mon", move || {
                if let Some(stdout) = child.stdout.take() {
                    let reader = BufReader::with_capacity(1024, stdout);
                    for line in reader.lines() {
                        if line.is_err() || b2.stop.load(Ordering::SeqCst) {
                            break;
                        }
                        if b2.wait_stop(Duration::from_millis(250)) {
                            break;
                        }
                        let st = b2.battery_state();
                        let changed = if let Ok(mut g) = l2.lock() {
                            let diff = g.as_ref() != Some(&st);
                            *g = Some(st.clone());
                            diff
                        } else {
                            false
                        };
                        if changed {
                            (b2.emit)(st);
                        }
                    }
                }
                let _ = child.kill();
                let _ = child.wait();
            });
        }
    }

    while !bridge.wait_stop(Duration::from_secs(4)) {
        publish(&bridge, &last);
    }
}

fn watch_resources(bridge: Arc<Bridge>) {
    #[derive(PartialEq)]
    struct Sig {
        ram_pct: Option<i64>,
        swap_pct: Option<i64>,
        disks: Vec<(String, Option<i64>)>,
        procs: Vec<String>,
    }

    let mut last_sig: Option<Sig> = None;
    while !bridge.stop.load(Ordering::SeqCst) {
        let st = bridge.resources_state();
        let ram_pct = st.get("ram").and_then(|r| r.get_i64("percent"));
        let swap_pct = st.get("swap").and_then(|s| s.get_i64("percent"));
        let disks = st
            .get("disks")
            .and_then(|v| v.as_arr())
            .map(|arr| {
                arr.iter()
                    .map(|d| {
                        (
                            d.get_str("target").unwrap_or("").to_string(),
                            d.get_i64("percent"),
                        )
                    })
                    .collect()
            })
            .unwrap_or_default();
        let procs = st
            .get("processes")
            .and_then(|v| v.as_arr())
            .map(|arr| {
                arr.iter()
                    .map(|p| p.get_str("name").unwrap_or("").to_string())
                    .collect()
            })
            .unwrap_or_default();
        let cur_sig = Sig {
            ram_pct,
            swap_pct,
            disks,
            procs,
        };
        if last_sig.as_ref() != Some(&cur_sig) {
            last_sig = Some(cur_sig);
            (bridge.emit)(st);
        }
        if bridge.wait_stop(Duration::from_millis(2500)) {
            break;
        }
    }
}

pub fn serve(config_path: Option<&Path>) {
    let stdout_mtx: Arc<Mutex<()>> = Arc::new(Mutex::new(()));
    let out_lock = Arc::clone(&stdout_mtx);
    let emit = move |msg: JsonVal| {
        let mut line = msg.to_json_line();
        line.push('\n');
        if let Ok(_g) = out_lock.lock() {
            let mut out = io::stdout().lock();
            let _ = out.write_all(line.as_bytes());
            let _ = out.flush();
        }
    };

    let bridge = Bridge::new(config_path, emit.clone());
    emit(bridge.snapshot(false));

    bridge.bluetooth.start();
    bridge.wifi.start();

    {
        let b = Arc::clone(&bridge);
        spawn_small("sphere-hypr-ev", move || b.event_listener());
    }
    {
        let b = Arc::clone(&bridge);
        spawn_small("sphere-hypr-st", move || b.status_worker());
    }
    {
        let b = Arc::clone(&bridge);
        spawn_small("sphere-wifi-wt", move || b.watch_wifi());
    }
    {
        let b = Arc::clone(&bridge);
        spawn_small("sphere-bat-wt", move || watch_battery(b));
    }
    {
        let b = Arc::clone(&bridge);
        spawn_small("sphere-res-wt", move || watch_resources(b));
    }

    let stdin = io::stdin();
    let mut reader = BufReader::with_capacity(4096, stdin.lock());
    let mut raw_line: Vec<u8> = Vec::with_capacity(512);

    loop {
        raw_line.clear();
        let mut exceeded = false;
        let mut eof = false;
        loop {
            let available = match reader.fill_buf() {
                Ok([]) => {
                    eof = raw_line.is_empty();
                    break;
                }
                Ok(buf) => buf,
                Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
                Err(_) => {
                    eof = true;
                    break;
                }
            };
            if let Some(nl_pos) = available.iter().position(|&b| b == b'\n') {
                raw_line.extend_from_slice(&available[..=nl_pos]);
                reader.consume(nl_pos + 1);
                if raw_line.len() > 65536 {
                    exceeded = true;
                }
                break;
            } else {
                raw_line.extend_from_slice(available);
                let len = available.len();
                reader.consume(len);
                if raw_line.len() > 65536 {
                    exceeded = true;
                    break;
                }
            }
        }

        if eof {
            break;
        }
        if exceeded {
            emit(JsonVal::obj(vec![
                ("type", JsonVal::Str("response".to_string())),
                ("ok", JsonVal::Bool(false)),
                ("error", JsonVal::Str("Request too large.".to_string())),
            ]));
            break;
        }

        let line_str = String::from_utf8_lossy(&raw_line);
        match parse_json(&line_str) {
            Ok(req) => {
                let req_id = req.get("requestId").cloned().unwrap_or(JsonVal::Null);
                match bridge.request(&req) {
                    Ok(result) => {
                        emit(JsonVal::obj(vec![
                            ("type", JsonVal::Str("response".to_string())),
                            ("requestId", req_id),
                            ("ok", JsonVal::Bool(true)),
                            ("result", result),
                        ]));
                    }
                    Err(err) => {
                        emit(JsonVal::obj(vec![
                            ("type", JsonVal::Str("response".to_string())),
                            ("requestId", req_id),
                            ("ok", JsonVal::Bool(false)),
                            ("error", JsonVal::Str(err)),
                        ]));
                    }
                }
            }
            Err(err) => {
                emit(JsonVal::obj(vec![
                    ("type", JsonVal::Str("response".to_string())),
                    ("requestId", JsonVal::Null),
                    ("ok", JsonVal::Bool(false)),
                    ("error", JsonVal::Str(err)),
                ]));
            }
        }
    }

    bridge.signal_stop();
    bridge.bluetooth.stop();
    bridge.wifi.stop();
}
