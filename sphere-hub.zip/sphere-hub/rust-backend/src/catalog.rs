//! Memory-slim discovery of installed XDG/Flatpak/Snap desktop entries and theme icons.
//!
//! Key memory optimization over Python:
//! Instead of indexing and retaining 100,000+ icon URIs in RAM forever (`_icon_index`),
//! `refresh()` collects ONLY the ~50–150 icon names referenced by installed `.desktop`
//! entries, resolves only those matches in a single directory walk, and drops the
//! temporary lookup map before returning.

use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::{Path, PathBuf};

use crate::constants::Recipe;
use crate::json::JsonVal;
use crate::pathutil::{data_dirs, executable, file_uri, home_dir, norm, shlex_split};

#[derive(Clone, Debug)]
pub struct DesktopEntry {
    pub id: String,
    pub name: String,
    pub description: String,
    pub icon: String,
    pub installed: bool,
    pub path: String,
    pub exec: String,
    pub argv: Vec<String>,
    pub terminal: bool,
    pub working_directory: String,
    pub classes: HashSet<String>,
}

impl DesktopEntry {
    pub fn public_json(&self) -> JsonVal {
        JsonVal::obj(vec![
            ("id", JsonVal::Str(self.id.clone())),
            ("name", JsonVal::Str(self.name.clone())),
            ("description", JsonVal::Str(self.description.clone())),
            ("icon", JsonVal::Str(self.icon.clone())),
            ("installed", JsonVal::Bool(self.installed)),
        ])
    }
}

pub struct DesktopCatalog {
    pub dirs: Vec<PathBuf>,
    pub entries: Vec<DesktopEntry>,
    pub by_id: HashMap<String, usize>,
    pub scan_dirs: usize,
    pub scan_files: usize,
}

impl DesktopCatalog {
    pub fn new(dirs: Option<Vec<PathBuf>>) -> Self {
        Self {
            dirs: dirs.unwrap_or_else(data_dirs),
            entries: Vec::new(),
            by_id: HashMap::new(),
            scan_dirs: 0,
            scan_files: 0,
        }
    }

    pub fn get(&self, id: &str) -> Option<&DesktopEntry> {
        self.by_id.get(id).and_then(|&idx| self.entries.get(idx))
    }

    pub fn refresh(&mut self) {
        self.entries.clear();
        self.by_id.clear();
        self.scan_dirs = self
            .dirs
            .iter()
            .filter(|b| b.join("applications").is_dir())
            .count();
        self.scan_files = 0;

        let desktop_names: HashSet<String> = std::env::var("XDG_CURRENT_DESKTOP")
            .unwrap_or_else(|_| "Hyprland".to_string())
            .split(':')
            .filter(|s| !s.is_empty())
            .map(|s| s.to_lowercase())
            .collect();

        let lang_full = std::env::var("LC_ALL")
            .ok()
            .filter(|s| !s.is_empty())
            .or_else(|| std::env::var("LANG").ok().filter(|s| !s.is_empty()))
            .unwrap_or_else(|| "en".to_string());
        let lang = lang_full.split('.').next().unwrap_or("en").to_string();
        let lang_short = lang.split('_').next().unwrap_or("en").to_string();
        let name_key_lang = format!("Name[{}]", lang);
        let name_key_short = format!("Name[{}]", lang_short);

        let mut seen = HashSet::new();
        let mut pending_icons: Vec<(usize, String)> = Vec::new();
        let mut wanted_icon_keys: HashSet<String> = HashSet::new();

        for base in &self.dirs {
            let folder = base.join("applications");
            if !folder.is_dir() {
                continue;
            }
            let mut desktop_files = Vec::new();
            collect_desktop_files(&folder, &mut desktop_files);
            desktop_files.sort();

            for path in desktop_files {
                self.scan_files += 1;
                let rel = match path.strip_prefix(&folder) {
                    Ok(r) => r,
                    Err(_) => continue,
                };
                let desktop_id = rel
                    .components()
                    .map(|c| c.as_os_str().to_string_lossy().into_owned())
                    .collect::<Vec<_>>()
                    .join("-");
                if desktop_id.is_empty() || !seen.insert(desktop_id.clone()) {
                    continue;
                }

                let raw = match fs::read_to_string(&path) {
                    Ok(s) => s,
                    Err(_) => continue,
                };
                let fields = match parse_desktop_entry_section(&raw) {
                    Some(f) => f,
                    None => continue,
                };

                let entry_type = fields.get("Type").map(|s| s.as_str()).unwrap_or("Application");
                let hidden = fields
                    .get("Hidden")
                    .map(|s| s.eq_ignore_ascii_case("true"))
                    .unwrap_or(false);
                let no_display = fields
                    .get("NoDisplay")
                    .map(|s| s.eq_ignore_ascii_case("true"))
                    .unwrap_or(false);
                if entry_type != "Application" || hidden || no_display {
                    continue;
                }

                if let Some(only_raw) = fields.get("OnlyShowIn") {
                    let only: HashSet<String> = only_raw
                        .split(';')
                        .filter(|s| !s.is_empty())
                        .map(|s| s.to_lowercase())
                        .collect();
                    if !only.is_empty() && desktop_names.is_disjoint(&only) {
                        continue;
                    }
                }
                if let Some(not_raw) = fields.get("NotShowIn") {
                    let never: HashSet<String> = not_raw
                        .split(';')
                        .filter(|s| !s.is_empty())
                        .map(|s| s.to_lowercase())
                        .collect();
                    if !desktop_names.is_disjoint(&never) {
                        continue;
                    }
                }

                if let Some(try_exec) = fields.get("TryExec") {
                    if !try_exec.is_empty() && !executable(try_exec) {
                        continue;
                    }
                }

                let exec_str = fields.get("Exec").cloned().unwrap_or_default();
                let argv = match shlex_split(&exec_str) {
                    Ok(a) => a,
                    Err(_) => continue,
                };
                let dbus_act = fields
                    .get("DBusActivatable")
                    .map(|s| s.eq_ignore_ascii_case("true"))
                    .unwrap_or(false);
                if argv.is_empty() && !dbus_act {
                    continue;
                }

                let name = fields
                    .get(&name_key_lang)
                    .or_else(|| fields.get(&name_key_short))
                    .or_else(|| fields.get("Name"))
                    .cloned()
                    .unwrap_or_else(|| desktop_id.clone());

                let description = fields
                    .get("Comment")
                    .or_else(|| fields.get("GenericName"))
                    .cloned()
                    .unwrap_or_default();

                let mut classes = HashSet::new();
                let norm_id = norm(&desktop_id);
                if !norm_id.is_empty() {
                    if let Some((_, tail)) = norm_id.rsplit_once('.') {
                        if !tail.is_empty() {
                            classes.insert(tail.to_string());
                        }
                    }
                    classes.insert(norm_id);
                }
                if let Some(wm_class) = fields.get("StartupWMClass") {
                    let nw = norm(wm_class);
                    if !nw.is_empty() {
                        classes.insert(nw);
                    }
                }
                if !argv.is_empty() {
                    let mut first = Path::new(&argv[0])
                        .file_name()
                        .and_then(|s| s.to_str())
                        .unwrap_or("")
                        .to_string();
                    if first == "env" {
                        first = argv[1..]
                            .iter()
                            .find(|v| !v.contains('=') && !v.starts_with('-'))
                            .and_then(|v| Path::new(v).file_name().and_then(|s| s.to_str()))
                            .unwrap_or("")
                            .to_string();
                    }
                    if !first.is_empty()
                        && !matches!(
                            first.as_str(),
                            "env"
                                | "sh"
                                | "bash"
                                | "flatpak"
                                | "snap"
                                | "python"
                                | "python3"
                                | "java"
                        )
                    {
                        classes.insert(norm(&first));
                    }
                }

                let resolved_path = fs::canonicalize(&path)
                    .unwrap_or_else(|_| path.clone())
                    .to_string_lossy()
                    .into_owned();
                let icon_raw = fields.get("Icon").cloned().unwrap_or_default();
                let mut resolved_icon = String::new();
                let idx = self.entries.len();
                if !icon_raw.is_empty() {
                    let p = Path::new(&icon_raw);
                    if p.is_absolute() {
                        if p.is_file() {
                            resolved_icon = file_uri(p);
                        }
                    } else {
                        wanted_icon_keys.insert(icon_raw.clone());
                        if let Some(stem) = Path::new(&icon_raw).file_stem().and_then(|s| s.to_str())
                        {
                            wanted_icon_keys.insert(stem.to_string());
                        }
                        pending_icons.push((idx, icon_raw));
                    }
                }

                let terminal = fields
                    .get("Terminal")
                    .map(|s| s.eq_ignore_ascii_case("true"))
                    .unwrap_or(false);
                let working_directory = fields.get("Path").cloned().unwrap_or_default();

                self.by_id.insert(desktop_id.clone(), idx);
                self.entries.push(DesktopEntry {
                    id: desktop_id,
                    name,
                    description,
                    icon: resolved_icon,
                    installed: true,
                    path: resolved_path,
                    exec: exec_str,
                    argv,
                    terminal,
                    working_directory,
                    classes,
                });
            }
        }

        // Resolve ONLY the icons actually needed by discovered entries, then drop the map!
        if !wanted_icon_keys.is_empty() {
            let found_icons = resolve_wanted_icons(&self.dirs, &wanted_icon_keys);
            for (idx, icon_name) in pending_icons {
                let url = found_icons
                    .get(&icon_name)
                    .or_else(|| {
                        Path::new(&icon_name)
                            .file_stem()
                            .and_then(|s| s.to_str())
                            .and_then(|stem| found_icons.get(stem))
                    })
                    .cloned()
                    .unwrap_or_default();
                self.entries[idx].icon = url;
            }
        }
    }

    pub fn public_entries(&self) -> Vec<JsonVal> {
        let mut sorted: Vec<&DesktopEntry> = self.entries.iter().collect();
        sorted.sort_by_key(|e| e.name.to_lowercase());
        sorted.into_iter().map(|e| e.public_json()).collect()
    }

    pub fn recipe_entry(&self, recipe: &Recipe) -> Option<&DesktopEntry> {
        for did in recipe.desktop_ids {
            if let Some(e) = self.get(did) {
                return Some(e);
            }
        }
        let commands: HashSet<String> = recipe.commands.iter().map(|c| norm(c)).collect();
        self.entries
            .iter()
            .find(|e| !e.classes.is_disjoint(&commands))
    }

    pub fn match_client(&self, class_name: &str, initial_class: &str) -> String {
        let mut values: Vec<String> = [norm(class_name), norm(initial_class)]
            .into_iter()
            .filter(|s| !s.is_empty())
            .collect();
        values.sort();
        values.dedup();
        if values.is_empty() {
            return String::new();
        }
        for v in &values {
            let did = format!("{}.desktop", v);
            if let Some(entry) = self.get(&did) {
                return entry.id.clone();
            }
        }
        let val_set: HashSet<String> = values.iter().cloned().collect();
        if let Some(entry) = self.entries.iter().find(|e| !e.classes.is_disjoint(&val_set)) {
            return entry.id.clone();
        }
        let short_set: HashSet<String> = values
            .iter()
            .map(|v| v.rsplit('.').next().unwrap_or(v).to_string())
            .collect();
        self.entries
            .iter()
            .find(|e| !e.classes.is_disjoint(&short_set))
            .map(|e| e.id.clone())
            .unwrap_or_default()
    }
}

fn collect_desktop_files(dir: &Path, out: &mut Vec<PathBuf>) {
    let entries = match fs::read_dir(dir) {
        Ok(rd) => rd,
        Err(_) => return,
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            collect_desktop_files(&path, out);
        } else if path.extension().and_then(|e| e.to_str()) == Some("desktop") && path.is_file() {
            out.push(path);
        }
    }
}

fn parse_desktop_entry_section(text: &str) -> Option<HashMap<String, String>> {
    let mut in_section = false;
    let mut found = false;
    let mut map = HashMap::new();
    for raw_line in text.lines() {
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') || line.starts_with(';') {
            continue;
        }
        if line.starts_with('[') && line.ends_with(']') {
            in_section = line == "[Desktop Entry]";
            if in_section {
                found = true;
            }
            continue;
        }
        if in_section {
            if let Some((k, v)) = line.split_once('=') {
                map.entry(k.trim().to_string())
                    .or_insert_with(|| v.trim().to_string());
            }
        }
    }
    if found { Some(map) } else { None }
}

fn resolve_wanted_icons(dirs: &[PathBuf], wanted: &HashSet<String>) -> HashMap<String, String> {
    let mut found = HashMap::with_capacity(wanted.len());
    let mut roots = Vec::with_capacity(dirs.len() * 2 + 1);
    for base in dirs {
        roots.push(base.join("pixmaps"));
        roots.push(base.join("icons"));
    }
    roots.push(home_dir().join(".icons"));

    for root in roots {
        if !root.is_dir() {
            continue;
        }
        walk_icons(&root, wanted, &mut found);
    }
    found
}

fn walk_icons(dir: &Path, wanted: &HashSet<String>, found: &mut HashMap<String, String>) {
    let rd = match fs::read_dir(dir) {
        Ok(r) => r,
        Err(_) => return,
    };
    for entry in rd.flatten() {
        let path = entry.path();
        let Ok(ft) = entry.file_type() else {
            continue;
        };
        if ft.is_dir() {
            walk_icons(&path, wanted, found);
            continue;
        }
        let ext = path
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("")
            .to_ascii_lowercase();
        if !matches!(ext.as_str(), "svg" | "png" | "xpm") {
            continue;
        }
        let fname = entry.file_name();
        let Some(fname_str) = fname.to_str() else {
            continue;
        };
        let stem = Path::new(fname_str)
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("");

        let want_exact = wanted.contains(fname_str) && !found.contains_key(fname_str);
        let want_stem = !stem.is_empty() && wanted.contains(stem) && !found.contains_key(stem);
        if (want_exact || want_stem) && path.is_file() {
            let uri = file_uri(&path);
            if want_exact {
                found.insert(fname_str.to_string(), uri.clone());
            }
            if want_stem {
                found.insert(stem.to_string(), uri);
            }
        }
    }
}
