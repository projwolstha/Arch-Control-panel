//! The eight-slot state file (atomic, validated, corruption-safe).

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::os::unix::fs::{OpenOptionsExt, PermissionsExt};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

use crate::constants::SLOT_COUNT;
use crate::json::{parse_json, JsonVal};
use crate::pathutil::default_config_path;

#[derive(Clone, Debug, PartialEq)]
pub struct SlotTarget {
    pub kind: String,
    pub id: String,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Preferences {
    pub orbit_locked: bool,
    pub paused: bool,
    pub power_save: bool,
    pub above_windows: bool,
    pub screen_name: String,
    pub rotation_seconds: i64,
}

impl Default for Preferences {
    fn default() -> Self {
        Self {
            orbit_locked: false,
            paused: false,
            power_save: false,
            above_windows: true,
            screen_name: String::new(),
            rotation_seconds: 90,
        }
    }
}

impl Preferences {
    pub fn to_json(&self) -> JsonVal {
        JsonVal::obj(vec![
            ("orbitLocked", JsonVal::Bool(self.orbit_locked)),
            ("paused", JsonVal::Bool(self.paused)),
            ("powerSave", JsonVal::Bool(self.power_save)),
            ("aboveWindows", JsonVal::Bool(self.above_windows)),
            ("screenName", JsonVal::Str(self.screen_name.clone())),
            ("rotationSeconds", JsonVal::Int(self.rotation_seconds)),
        ])
    }

    pub fn apply_update(&mut self, values: &JsonVal) -> Result<(), String> {
        let entries = values
            .as_obj()
            .ok_or_else(|| "Preferences must be an object.".to_string())?;
        let mut next = self.clone();
        for (k, val) in entries {
            match k.as_str() {
                "orbitLocked" => {
                    next.orbit_locked = val
                        .as_bool()
                        .ok_or_else(|| "Unsupported preference.".to_string())?;
                }
                "paused" => {
                    next.paused = val
                        .as_bool()
                        .ok_or_else(|| "Unsupported preference.".to_string())?;
                }
                "powerSave" => {
                    next.power_save = val
                        .as_bool()
                        .ok_or_else(|| "Unsupported preference.".to_string())?;
                }
                "aboveWindows" => {
                    next.above_windows = val
                        .as_bool()
                        .ok_or_else(|| "Unsupported preference.".to_string())?;
                }
                "screenName" => {
                    let s = val
                        .as_str()
                        .ok_or_else(|| "Unsupported preference.".to_string())?;
                    next.screen_name = s.chars().take(128).collect();
                }
                "rotationSeconds" => {
                    let n = val
                        .as_i64()
                        .ok_or_else(|| "Unsupported preference.".to_string())?;
                    next.rotation_seconds = n.clamp(20, 180);
                }
                _ => return Err("Unsupported preference.".to_string()),
            }
        }
        *self = next;
        Ok(())
    }
}

#[derive(Clone, Debug)]
pub struct ConfigStore {
    pub path: PathBuf,
    pub slots: Vec<Option<SlotTarget>>,
    pub preferences: Preferences,
}

impl ConfigStore {
    pub fn new(path: Option<&Path>) -> Self {
        let path = path
            .map(|p| p.to_path_buf())
            .unwrap_or_else(default_config_path);
        let mut slots: Vec<Option<SlotTarget>> = vec![None; SLOT_COUNT];
        let mut preferences = Preferences::default();

        if let Ok(raw) = fs::read_to_string(&path) {
            if let Ok(saved) = parse_json(&raw) {
                if let Some(arr) = saved.get("slots").and_then(|v| v.as_arr()) {
                    for (i, item) in arr.iter().take(SLOT_COUNT).enumerate() {
                        let kind = item.get_str("kind").unwrap_or("");
                        let id = item.get_str("id");
                        if matches!(kind, "desktop" | "recipe") {
                            if let Some(id_str) = id {
                                if id_str.len() <= 256 {
                                    slots[i] = Some(SlotTarget {
                                        kind: kind.to_string(),
                                        id: id_str.to_string(),
                                    });
                                }
                            }
                        }
                    }
                }
                if let Some(prefs) = saved.get("preferences") {
                    if let Some(b) = prefs.get_bool("orbitLocked") {
                        preferences.orbit_locked = b;
                    }
                    if let Some(b) = prefs.get_bool("paused") {
                        preferences.paused = b;
                    }
                    if let Some(b) = prefs.get_bool("powerSave") {
                        preferences.power_save = b;
                    }
                    if let Some(b) = prefs.get_bool("aboveWindows") {
                        preferences.above_windows = b;
                    }
                    if let Some(s) = prefs.get_str("screenName") {
                        preferences.screen_name = s.to_string();
                    }
                    if let Some(n) = prefs.get_i64("rotationSeconds") {
                        preferences.rotation_seconds = n.clamp(20, 180);
                    }
                }
            }
        }

        Self {
            path,
            slots,
            preferences,
        }
    }

    pub fn slots_json(&self) -> JsonVal {
        JsonVal::Arr(
            self.slots
                .iter()
                .map(|slot| match slot {
                    Some(t) => JsonVal::obj(vec![
                        ("kind", JsonVal::Str(t.kind.clone())),
                        ("id", JsonVal::Str(t.id.clone())),
                    ]),
                    None => JsonVal::Null,
                })
                .collect(),
        )
    }

    pub fn to_json(&self) -> JsonVal {
        JsonVal::obj(vec![
            ("version", JsonVal::Int(1)),
            ("slots", self.slots_json()),
            ("preferences", self.preferences.to_json()),
        ])
    }

    pub fn save(&self) -> Result<(), String> {
        let parent = self
            .path
            .parent()
            .ok_or_else(|| "Invalid config path.".to_string())?;
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        let _ = fs::set_permissions(parent, fs::Permissions::from_mode(0o700));

        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0);
        let tmp = parent.join(format!(".sphere-{}-{}.tmp", std::process::id(), nanos));

        let write_res = (|| -> Result<(), String> {
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .mode(0o600)
                .open(&tmp)
                .map_err(|e| e.to_string())?;
            let mut body = self.to_json().to_json_pretty();
            body.push('\n');
            file.write_all(body.as_bytes()).map_err(|e| e.to_string())?;
            file.flush().map_err(|e| e.to_string())?;
            file.sync_all().map_err(|e| e.to_string())?;
            drop(file);
            fs::rename(&tmp, &self.path).map_err(|e| e.to_string())?;
            Ok(())
        })();

        if write_res.is_err() {
            let _ = fs::remove_file(&tmp);
        }
        write_res
    }
}
