//! Fixed table of install recipes, slot count, terminals, package-name validation,
//! and small-stack worker thread helpers.

use std::path::Path;
use std::thread::{self, JoinHandle};

pub const SLOT_COUNT: usize = 8;

pub const MANAGERS: &[&str] = &["pacman", "apt", "dnf", "zypper", "apk", "flatpak"];

pub const TERMINALS: &[&str] = &[
    "kitty",
    "ghostty",
    "foot",
    "alacritty",
    "wezterm",
    "konsole",
    "gnome-terminal",
    "xfce4-terminal",
    "xterm",
];

pub struct Recipe {
    pub id: &'static str,
    pub name: &'static str,
    pub description: &'static str,
    pub desktop_ids: &'static [&'static str],
    pub commands: &'static [&'static str],
    pub packages: &'static [(&'static str, &'static str)],
}

impl Recipe {
    pub fn package_for(&self, manager: &str) -> Option<&'static str> {
        self.packages
            .iter()
            .find(|(m, _)| *m == manager)
            .map(|(_, p)| *p)
    }
}

pub const RECIPES: &[Recipe] = &[
    Recipe {
        id: "firefox",
        name: "Firefox",
        description: "Web browser",
        desktop_ids: &["firefox.desktop", "firefox-esr.desktop", "org.mozilla.firefox.desktop"],
        commands: &["firefox", "firefox-esr"],
        packages: &[
            ("pacman", "firefox"),
            ("apt", "firefox-esr"),
            ("dnf", "firefox"),
            ("zypper", "MozillaFirefox"),
            ("apk", "firefox"),
            ("flatpak", "org.mozilla.firefox"),
        ],
    },
    Recipe {
        id: "chromium",
        name: "Chromium",
        description: "Web browser",
        desktop_ids: &["chromium.desktop", "chromium-browser.desktop", "org.chromium.Chromium.desktop"],
        commands: &["chromium", "chromium-browser"],
        packages: &[
            ("pacman", "chromium"),
            ("apt", "chromium"),
            ("dnf", "chromium"),
            ("zypper", "chromium"),
            ("apk", "chromium"),
            ("flatpak", "org.chromium.Chromium"),
        ],
    },
    Recipe {
        id: "kitty",
        name: "Kitty",
        description: "Terminal emulator",
        desktop_ids: &["kitty.desktop"],
        commands: &["kitty"],
        packages: &[
            ("pacman", "kitty"),
            ("apt", "kitty"),
            ("dnf", "kitty"),
            ("zypper", "kitty"),
            ("apk", "kitty"),
        ],
    },
    Recipe {
        id: "alacritty",
        name: "Alacritty",
        description: "Terminal emulator",
        desktop_ids: &["Alacritty.desktop", "alacritty.desktop"],
        commands: &["alacritty"],
        packages: &[
            ("pacman", "alacritty"),
            ("apt", "alacritty"),
            ("dnf", "alacritty"),
            ("zypper", "alacritty"),
            ("apk", "alacritty"),
        ],
    },
    Recipe {
        id: "foot",
        name: "Foot",
        description: "Wayland terminal",
        desktop_ids: &["foot.desktop"],
        commands: &["foot"],
        packages: &[
            ("pacman", "foot"),
            ("apt", "foot"),
            ("dnf", "foot"),
            ("apk", "foot"),
        ],
    },
    Recipe {
        id: "thunar",
        name: "Thunar",
        description: "File manager",
        desktop_ids: &["thunar.desktop", "Thunar.desktop"],
        commands: &["thunar"],
        packages: &[
            ("pacman", "thunar"),
            ("apt", "thunar"),
            ("dnf", "Thunar"),
            ("zypper", "thunar"),
            ("apk", "thunar"),
        ],
    },
    Recipe {
        id: "dolphin",
        name: "Dolphin",
        description: "File manager",
        desktop_ids: &["org.kde.dolphin.desktop"],
        commands: &["dolphin"],
        packages: &[
            ("pacman", "dolphin"),
            ("apt", "dolphin"),
            ("dnf", "dolphin"),
            ("zypper", "dolphin"),
            ("apk", "dolphin"),
        ],
    },
    Recipe {
        id: "code",
        name: "VS Code / Code OSS",
        description: "Code editor (system repository or Flatpak)",
        desktop_ids: &[
            "code.desktop",
            "code-oss.desktop",
            "code_code.desktop",
            "com.visualstudio.code.desktop",
        ],
        commands: &["code", "code-oss"],
        packages: &[("pacman", "code"), ("flatpak", "com.visualstudio.code")],
    },
    Recipe {
        id: "vlc",
        name: "VLC",
        description: "Media player",
        desktop_ids: &["vlc.desktop", "org.videolan.VLC.desktop"],
        commands: &["vlc"],
        packages: &[
            ("pacman", "vlc"),
            ("apt", "vlc"),
            ("dnf", "vlc"),
            ("zypper", "vlc"),
            ("apk", "vlc"),
            ("flatpak", "org.videolan.VLC"),
        ],
    },
    Recipe {
        id: "gimp",
        name: "GIMP",
        description: "Image editor",
        desktop_ids: &["gimp.desktop", "org.gimp.GIMP.desktop"],
        commands: &["gimp"],
        packages: &[
            ("pacman", "gimp"),
            ("apt", "gimp"),
            ("dnf", "gimp"),
            ("zypper", "gimp"),
            ("apk", "gimp"),
            ("flatpak", "org.gimp.GIMP"),
        ],
    },
    Recipe {
        id: "krita",
        name: "Krita",
        description: "Painting and illustration",
        desktop_ids: &["org.kde.krita.desktop", "krita.desktop"],
        commands: &["krita"],
        packages: &[
            ("pacman", "krita"),
            ("apt", "krita"),
            ("dnf", "krita"),
            ("zypper", "krita"),
            ("apk", "krita"),
            ("flatpak", "org.kde.krita"),
        ],
    },
    Recipe {
        id: "obs",
        name: "OBS Studio",
        description: "Recording and broadcasting",
        desktop_ids: &["com.obsproject.Studio.desktop", "obs.desktop"],
        commands: &["obs"],
        packages: &[
            ("pacman", "obs-studio"),
            ("apt", "obs-studio"),
            ("dnf", "obs-studio"),
            ("zypper", "obs-studio"),
            ("apk", "obs-studio"),
            ("flatpak", "com.obsproject.Studio"),
        ],
    },
    Recipe {
        id: "libreoffice",
        name: "LibreOffice Writer",
        description: "Documents",
        desktop_ids: &[
            "libreoffice-writer.desktop",
            "org.libreoffice.LibreOffice.writer.desktop",
        ],
        commands: &["libreoffice"],
        packages: &[
            ("pacman", "libreoffice-fresh"),
            ("apt", "libreoffice-writer"),
            ("dnf", "libreoffice-writer"),
            ("zypper", "libreoffice-writer"),
            ("apk", "libreoffice"),
            ("flatpak", "org.libreoffice.LibreOffice"),
        ],
    },
    Recipe {
        id: "qalculate",
        name: "Qalculate!",
        description: "Calculator",
        desktop_ids: &["qalculate-gtk.desktop", "qalculate-qt.desktop"],
        commands: &["qalculate-gtk", "qalculate-qt"],
        packages: &[
            ("pacman", "qalculate-gtk"),
            ("apt", "qalculate-gtk"),
            ("dnf", "qalculate-gtk"),
            ("zypper", "qalculate-gtk"),
            ("apk", "qalculate-gtk"),
        ],
    },
    Recipe {
        id: "pavucontrol",
        name: "Volume control",
        description: "Audio settings",
        desktop_ids: &["pavucontrol.desktop"],
        commands: &["pavucontrol"],
        packages: &[
            ("pacman", "pavucontrol"),
            ("apt", "pavucontrol"),
            ("dnf", "pavucontrol"),
            ("zypper", "pavucontrol"),
            ("apk", "pavucontrol"),
        ],
    },
];

pub fn recipe_by_id(id: &str) -> Option<&'static Recipe> {
    RECIPES.iter().find(|r| r.id == id)
}

/// Matches `^[A-Za-z0-9][A-Za-z0-9+._:-]{0,127}$`.
pub fn valid_package_name(pkg: &str) -> bool {
    let bytes = pkg.as_bytes();
    if bytes.is_empty() || bytes.len() > 128 {
        return false;
    }
    if !bytes[0].is_ascii_alphanumeric() {
        return false;
    }
    bytes[1..].iter().all(|b| {
        b.is_ascii_alphanumeric() || matches!(*b, b'+' | b'.' | b'_' | b':' | b'-')
    })
}

/// Cap glibc malloc arenas to 1 so background watcher threads do not reserve
/// separate 64 MiB virtual arenas or fragment small allocations across heaps.
pub fn tune_allocator() {
    #[cfg(all(target_os = "linux", target_env = "gnu"))]
    {
        extern "C" {
            fn mallopt(param: i32, val: i32) -> i32;
        }
        const M_ARENA_MAX: i32 = -8;
        unsafe {
            let _ = mallopt(M_ARENA_MAX, 1);
        }
    }
}

/// Spawn a background daemon worker with a compact 128 KiB stack (64x smaller than 8 MiB default).
pub fn spawn_small<F, T>(name: &str, f: F) -> JoinHandle<T>
where
    F: FnOnce() -> T + Send + 'static,
    T: Send + 'static,
{
    thread::Builder::new()
        .name(name.to_string())
        .stack_size(128 * 1024)
        .spawn(f)
        .expect("spawn worker thread")
}

/// Complete PATH and D-Bus session/system bus variables for child CLI processes (`nmcli`, `bluetoothctl`).
pub fn cli_environment() -> Vec<(String, String)> {
    let mut env: Vec<(String, String)> = std::env::vars().collect();
    let get_val = |env: &[(String, String)], key: &str| -> Option<String> {
        env.iter().find(|(k, _)| k == key).map(|(_, v)| v.clone())
    };
    let set_val = |env: &mut Vec<(String, String)>, key: &str, val: String| {
        if let Some((_, existing)) = env.iter_mut().find(|(k, _)| k == key) {
            *existing = val;
        } else {
            env.push((key.to_string(), val));
        }
    };

    let raw_path = get_val(&env, "PATH").unwrap_or_default();
    let mut parts: Vec<String> = raw_path
        .split(':')
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .collect();
    for extra in [
        "/usr/local/sbin",
        "/usr/local/bin",
        "/usr/bin",
        "/usr/sbin",
        "/bin",
        "/sbin",
    ] {
        if !parts.iter().any(|p| p == extra) {
            parts.push(extra.to_string());
        }
    }
    let joined_path = if parts.is_empty() {
        "/usr/bin:/bin".to_string()
    } else {
        parts.join(":")
    };
    set_val(&mut env, "PATH", joined_path);

    let uid = unsafe { getuid() };
    let mut runtime = get_val(&env, "XDG_RUNTIME_DIR").unwrap_or_default();
    if runtime.is_empty() || !Path::new(&runtime).is_dir() {
        let candidate = format!("/run/user/{}", uid);
        if Path::new(&candidate).is_dir() {
            runtime = candidate;
        }
    }
    if !runtime.is_empty() {
        set_val(&mut env, "XDG_RUNTIME_DIR", runtime.clone());
    }
    if get_val(&env, "DBUS_SESSION_BUS_ADDRESS")
        .unwrap_or_default()
        .is_empty()
        && !runtime.is_empty()
    {
        let bus = format!("{}/bus", runtime);
        if Path::new(&bus).exists() {
            set_val(&mut env, "DBUS_SESSION_BUS_ADDRESS", format!("unix:path={}", bus));
        }
    }
    if get_val(&env, "DBUS_SYSTEM_BUS_ADDRESS")
        .unwrap_or_default()
        .is_empty()
    {
        let sys_sock = "/run/dbus/system_bus_socket";
        if Path::new(sys_sock).exists() {
            set_val(
                &mut env,
                "DBUS_SYSTEM_BUS_ADDRESS",
                format!("unix:path={}", sys_sock),
            );
        }
    }
    if get_val(&env, "LC_ALL").is_none() {
        set_val(&mut env, "LC_ALL", "C".to_string());
    }
    env
}

extern "C" {
    fn getuid() -> u32;
}

#[derive(Clone, Debug)]
pub struct CmdResult {
    pub code: i32,
    pub stdout: String,
    pub stderr: String,
    pub timed_out: bool,
    pub spawn_error: Option<String>,
}

/// Run an argument vector without a shell, bounded by `timeout_ms`, draining stdout/stderr concurrently.
pub fn run_cmd_timeout(
    program: &str,
    args: &[&str],
    env: Option<&[(String, String)]>,
    timeout_ms: u64,
) -> CmdResult {
    use std::io::Read;
    use std::process::{Command, Stdio};
    use std::time::{Duration, Instant};

    let mut cmd = Command::new(program);
    cmd.args(args)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    if let Some(vars) = env {
        cmd.env_clear();
        for (k, v) in vars {
            cmd.env(k, v);
        }
    } else {
        cmd.env("LC_ALL", "C");
    }

    let mut child = match cmd.spawn() {
        Ok(c) => c,
        Err(e) => {
            return CmdResult {
                code: 1,
                stdout: String::new(),
                stderr: e.to_string(),
                timed_out: false,
                spawn_error: Some(e.to_string()),
            };
        }
    };

    let mut out_pipe = child.stdout.take();
    let mut err_pipe = child.stderr.take();
    let out_handle = spawn_small("cmd-out", move || {
        let mut buf = Vec::new();
        if let Some(ref mut p) = out_pipe {
            let _ = p.read_to_end(&mut buf);
        }
        String::from_utf8_lossy(&buf).into_owned()
    });
    let err_handle = spawn_small("cmd-err", move || {
        let mut buf = Vec::new();
        if let Some(ref mut p) = err_pipe {
            let _ = p.read_to_end(&mut buf);
        }
        String::from_utf8_lossy(&buf).into_owned()
    });

    let deadline = Instant::now() + Duration::from_millis(timeout_ms);
    let mut timed_out = false;
    let code = loop {
        match child.try_wait() {
            Ok(Some(status)) => break status.code().unwrap_or(1),
            Ok(None) => {
                if Instant::now() >= deadline {
                    timed_out = true;
                    let _ = child.kill();
                    let _ = child.wait();
                    break 124;
                }
                std::thread::sleep(Duration::from_millis(12));
            }
            Err(_) => break 1,
        }
    };

    let stdout = out_handle.join().unwrap_or_default();
    let stderr = err_handle.join().unwrap_or_default();
    CmdResult {
        code,
        stdout,
        stderr,
        timed_out,
        spawn_error: None,
    }
}

