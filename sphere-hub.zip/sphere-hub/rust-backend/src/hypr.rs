//! Hyprland IPC over its unix socket and sanitized child environment for launched apps.

use std::io::{Read, Write};
use std::os::unix::net::UnixStream;
use std::time::Duration;

use crate::pathutil::socket_path;

pub fn hypr_command(command: &str) -> Result<String, String> {
    let path = socket_path(".socket.sock")
        .ok_or_else(|| "Hyprland IPC is not available in this session.".to_string())?;
    let mut client = UnixStream::connect(&path).map_err(|e| e.to_string())?;
    let timeout = Some(Duration::from_millis(800));
    let _ = client.set_read_timeout(timeout);
    let _ = client.set_write_timeout(timeout);
    client
        .write_all(command.as_bytes())
        .map_err(|e| e.to_string())?;

    let mut out = Vec::with_capacity(4096);
    let mut buf = [0u8; 8192];
    loop {
        match client.read(&mut buf) {
            Ok(0) => break,
            Ok(n) => {
                if out.len() + n > 4 * 1024 * 1024 {
                    return Err("Hyprland IPC reply was too large.".to_string());
                }
                out.extend_from_slice(&buf[..n]);
            }
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(e.to_string()),
        }
    }
    Ok(String::from_utf8_lossy(&out).into_owned())
}

/// Keep widget-only Qt overrides out of launched applications/terminals.
pub fn desktop_environment() -> Vec<(String, String)> {
    let mut env: Vec<(String, String)> = std::env::vars().collect();
    for key in [
        "QT_QPA_PLATFORM",
        "QT_QUICK_CONTROLS_STYLE",
        "QT_QUICK_BACKEND",
    ] {
        let marker = format!("SPHERE_SAVED_{}", key);
        if let Some(pos) = env.iter().position(|(k, _)| k == &marker) {
            let (_, saved) = env.remove(pos);
            if saved == "__SPHERE_UNSET__" {
                env.retain(|(k, _)| k != key);
            } else if let Some((_, existing)) = env.iter_mut().find(|(k, _)| k == key) {
                *existing = saved;
            } else {
                env.push((key.to_string(), saved));
            }
        }
    }
    env
}
