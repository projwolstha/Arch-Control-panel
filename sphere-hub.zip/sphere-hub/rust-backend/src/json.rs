//! Compact, zero-dependency RFC 8259 JSON parser and serializer.
//! Preserves object key insertion order and distinguishes integer vs float values.

use std::fmt::Write as _;

#[derive(Clone, Debug, PartialEq)]
pub enum JsonVal {
    Null,
    Bool(bool),
    Int(i64),
    Float(f64),
    Str(String),
    Arr(Vec<JsonVal>),
    Obj(Vec<(String, JsonVal)>),
}

impl JsonVal {
    pub fn obj(entries: Vec<(&str, JsonVal)>) -> Self {
        JsonVal::Obj(entries.into_iter().map(|(k, v)| (k.to_string(), v)).collect())
    }

    pub fn as_bool(&self) -> Option<bool> {
        match self {
            JsonVal::Bool(b) => Some(*b),
            _ => None,
        }
    }

    pub fn as_i64(&self) -> Option<i64> {
        match self {
            JsonVal::Int(n) => Some(*n),
            _ => None,
        }
    }

    pub fn as_f64(&self) -> Option<f64> {
        match self {
            JsonVal::Int(n) => Some(*n as f64),
            JsonVal::Float(f) => Some(*f),
            _ => None,
        }
    }

    pub fn as_str(&self) -> Option<&str> {
        match self {
            JsonVal::Str(s) => Some(s.as_str()),
            _ => None,
        }
    }

    pub fn as_arr(&self) -> Option<&[JsonVal]> {
        match self {
            JsonVal::Arr(a) => Some(a.as_slice()),
            _ => None,
        }
    }

    pub fn as_obj(&self) -> Option<&[(String, JsonVal)]> {
        match self {
            JsonVal::Obj(o) => Some(o.as_slice()),
            _ => None,
        }
    }

    pub fn as_obj_mut(&mut self) -> Option<&mut Vec<(String, JsonVal)>> {
        match self {
            JsonVal::Obj(o) => Some(o),
            _ => None,
        }
    }

    pub fn is_null(&self) -> bool {
        matches!(self, JsonVal::Null)
    }

    pub fn get(&self, key: &str) -> Option<&JsonVal> {
        match self {
            JsonVal::Obj(entries) => entries.iter().find(|(k, _)| k == key).map(|(_, v)| v),
            _ => None,
        }
    }

    pub fn get_str(&self, key: &str) -> Option<&str> {
        self.get(key).and_then(|v| v.as_str())
    }

    pub fn get_bool(&self, key: &str) -> Option<bool> {
        self.get(key).and_then(|v| v.as_bool())
    }

    pub fn get_i64(&self, key: &str) -> Option<i64> {
        self.get(key).and_then(|v| v.as_i64())
    }

    pub fn set(&mut self, key: impl Into<String>, val: JsonVal) {
        let key = key.into();
        if let JsonVal::Obj(entries) = self {
            for (k, v) in entries.iter_mut() {
                if *k == key {
                    *v = val;
                    return;
                }
            }
            entries.push((key, val));
        }
    }

    pub fn set_default(&mut self, key: impl Into<String>, val: JsonVal) {
        let key = key.into();
        if let JsonVal::Obj(entries) = self {
            if !entries.iter().any(|(k, _)| *k == key) {
                entries.push((key, val));
            }
        }
    }

    pub fn to_json_line(&self) -> String {
        let mut out = String::with_capacity(256);
        self.write_compact(&mut out);
        out
    }

    pub fn to_json_pretty(&self) -> String {
        let mut out = String::with_capacity(512);
        self.write_pretty(&mut out, 0);
        out
    }

    fn write_compact(&self, out: &mut String) {
        match self {
            JsonVal::Null => out.push_str("null"),
            JsonVal::Bool(true) => out.push_str("true"),
            JsonVal::Bool(false) => out.push_str("false"),
            JsonVal::Int(n) => {
                let _ = write!(out, "{}", n);
            }
            JsonVal::Float(f) => {
                if !f.is_finite() {
                    out.push_str("null");
                } else {
                    let mut s = format!("{}", f);
                    if !s.contains('.') && !s.contains('e') && !s.contains('E') {
                        s.push_str(".0");
                    }
                    out.push_str(&s);
                }
            }
            JsonVal::Str(s) => write_escaped_str(out, s),
            JsonVal::Arr(items) => {
                out.push('[');
                for (i, item) in items.iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    item.write_compact(out);
                }
                out.push(']');
            }
            JsonVal::Obj(entries) => {
                out.push('{');
                for (i, (k, v)) in entries.iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    write_escaped_str(out, k);
                    out.push(':');
                    v.write_compact(out);
                }
                out.push('}');
            }
        }
    }

    fn write_pretty(&self, out: &mut String, indent: usize) {
        match self {
            JsonVal::Arr(items) if items.is_empty() => out.push_str("[]"),
            JsonVal::Arr(items) => {
                out.push_str("[\n");
                for (i, item) in items.iter().enumerate() {
                    for _ in 0..(indent + 2) {
                        out.push(' ');
                    }
                    item.write_pretty(out, indent + 2);
                    if i + 1 < items.len() {
                        out.push(',');
                    }
                    out.push('\n');
                }
                for _ in 0..indent {
                    out.push(' ');
                }
                out.push(']');
            }
            JsonVal::Obj(entries) if entries.is_empty() => out.push_str("{}"),
            JsonVal::Obj(entries) => {
                out.push_str("{\n");
                for (i, (k, v)) in entries.iter().enumerate() {
                    for _ in 0..(indent + 2) {
                        out.push(' ');
                    }
                    write_escaped_str(out, k);
                    out.push_str(": ");
                    v.write_pretty(out, indent + 2);
                    if i + 1 < entries.len() {
                        out.push(',');
                    }
                    out.push('\n');
                }
                for _ in 0..indent {
                    out.push(' ');
                }
                out.push('}');
            }
            _ => self.write_compact(out),
        }
    }
}

pub fn write_escaped_str(out: &mut String, s: &str) {
    out.push('"');
    for ch in s.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\x08' => out.push_str("\\b"),
            '\x0c' => out.push_str("\\f"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => {
                let _ = write!(out, "\\u{:04x}", c as u32);
            }
            c => out.push(c),
        }
    }
    out.push('"');
}

impl From<bool> for JsonVal {
    fn from(v: bool) -> Self {
        JsonVal::Bool(v)
    }
}
impl From<i64> for JsonVal {
    fn from(v: i64) -> Self {
        JsonVal::Int(v)
    }
}
impl From<usize> for JsonVal {
    fn from(v: usize) -> Self {
        JsonVal::Int(v as i64)
    }
}
impl From<f64> for JsonVal {
    fn from(v: f64) -> Self {
        JsonVal::Float(v)
    }
}
impl From<&str> for JsonVal {
    fn from(v: &str) -> Self {
        JsonVal::Str(v.to_string())
    }
}
impl From<String> for JsonVal {
    fn from(v: String) -> Self {
        JsonVal::Str(v)
    }
}
impl<T: Into<JsonVal>> From<Option<T>> for JsonVal {
    fn from(v: Option<T>) -> Self {
        match v {
            Some(inner) => inner.into(),
            None => JsonVal::Null,
        }
    }
}

pub fn parse_json(input: &str) -> Result<JsonVal, String> {
    let mut parser = Parser {
        bytes: input.as_bytes(),
        pos: 0,
    };
    let val = parser.parse_value(0)?;
    parser.skip_ws();
    if parser.pos != parser.bytes.len() {
        return Err("Trailing characters in JSON input.".to_string());
    }
    Ok(val)
}

struct Parser<'a> {
    bytes: &'a [u8],
    pos: usize,
}

impl<'a> Parser<'a> {
    fn skip_ws(&mut self) {
        while self.pos < self.bytes.len() {
            match self.bytes[self.pos] {
                b' ' | b'\t' | b'\r' | b'\n' => self.pos += 1,
                _ => break,
            }
        }
    }

    fn parse_value(&mut self, depth: usize) -> Result<JsonVal, String> {
        if depth > 64 {
            return Err("JSON nesting too deep.".to_string());
        }
        self.skip_ws();
        if self.pos >= self.bytes.len() {
            return Err("Unexpected end of JSON input.".to_string());
        }
        match self.bytes[self.pos] {
            b'n' => self.expect_kw(b"null", JsonVal::Null),
            b't' => self.expect_kw(b"true", JsonVal::Bool(true)),
            b'f' => self.expect_kw(b"false", JsonVal::Bool(false)),
            b'"' => self.parse_string().map(JsonVal::Str),
            b'[' => self.parse_array(depth + 1),
            b'{' => self.parse_object(depth + 1),
            b'-' | b'0'..=b'9' => self.parse_number(),
            _ => Err("Invalid JSON token.".to_string()),
        }
    }

    fn expect_kw(&mut self, kw: &[u8], val: JsonVal) -> Result<JsonVal, String> {
        if self.bytes[self.pos..].starts_with(kw) {
            self.pos += kw.len();
            Ok(val)
        } else {
            Err("Invalid JSON literal.".to_string())
        }
    }

    fn parse_hex4(&mut self) -> Result<u16, String> {
        if self.pos + 4 > self.bytes.len() {
            return Err("Incomplete Unicode escape.".to_string());
        }
        let s = std::str::from_utf8(&self.bytes[self.pos..self.pos + 4])
            .map_err(|_| "Invalid Unicode escape.".to_string())?;
        let code = u16::from_str_radix(s, 16).map_err(|_| "Invalid hex escape.".to_string())?;
        self.pos += 4;
        Ok(code)
    }

    fn parse_string(&mut self) -> Result<String, String> {
        self.pos += 1; // skip opening '"'
        let mut out = String::new();
        while self.pos < self.bytes.len() {
            let b = self.bytes[self.pos];
            if b == b'"' {
                self.pos += 1;
                return Ok(out);
            }
            if b == b'\\' {
                self.pos += 1;
                if self.pos >= self.bytes.len() {
                    return Err("Unterminated escape.".to_string());
                }
                let esc = self.bytes[self.pos];
                self.pos += 1;
                match esc {
                    b'"' => out.push('"'),
                    b'\\' => out.push('\\'),
                    b'/' => out.push('/'),
                    b'b' => out.push('\x08'),
                    b'f' => out.push('\x0c'),
                    b'n' => out.push('\n'),
                    b'r' => out.push('\r'),
                    b't' => out.push('\t'),
                    b'u' => {
                        let hi = self.parse_hex4()?;
                        if (0xD800..=0xDBFF).contains(&hi) {
                            if self.pos + 2 <= self.bytes.len()
                                && self.bytes[self.pos] == b'\\'
                                && self.bytes[self.pos + 1] == b'u'
                            {
                                self.pos += 2;
                                let lo = self.parse_hex4()?;
                                if (0xDC00..=0xDFFF).contains(&lo) {
                                    let cp = 0x10000
                                        + (((hi as u32 - 0xD800) << 10) | (lo as u32 - 0xDC00));
                                    if let Some(ch) = char::from_u32(cp) {
                                        out.push(ch);
                                        continue;
                                    }
                                }
                            }
                            out.push('\u{FFFD}');
                        } else if let Some(ch) = char::from_u32(hi as u32) {
                            out.push(ch);
                        } else {
                            out.push('\u{FFFD}');
                        }
                    }
                    _ => return Err("Invalid escape sequence.".to_string()),
                }
            } else if b < 0x20 {
                return Err("Unescaped control character in JSON string.".to_string());
            } else {
                let start = self.pos;
                self.pos += 1;
                while self.pos < self.bytes.len() {
                    let nb = self.bytes[self.pos];
                    if nb == b'"' || nb == b'\\' || nb < 0x20 {
                        break;
                    }
                    self.pos += 1;
                }
                let chunk = std::str::from_utf8(&self.bytes[start..self.pos])
                    .map_err(|_| "Invalid UTF-8 in JSON string.".to_string())?;
                out.push_str(chunk);
            }
        }
        Err("Unterminated JSON string.".to_string())
    }

    fn parse_number(&mut self) -> Result<JsonVal, String> {
        let start = self.pos;
        if self.bytes[self.pos] == b'-' {
            self.pos += 1;
        }
        if self.pos >= self.bytes.len() || !self.bytes[self.pos].is_ascii_digit() {
            return Err("Invalid number.".to_string());
        }
        if self.bytes[self.pos] == b'0' {
            self.pos += 1;
        } else {
            while self.pos < self.bytes.len() && self.bytes[self.pos].is_ascii_digit() {
                self.pos += 1;
            }
        }
        let mut is_float = false;
        if self.pos < self.bytes.len() && self.bytes[self.pos] == b'.' {
            is_float = true;
            self.pos += 1;
            if self.pos >= self.bytes.len() || !self.bytes[self.pos].is_ascii_digit() {
                return Err("Invalid decimal fraction.".to_string());
            }
            while self.pos < self.bytes.len() && self.bytes[self.pos].is_ascii_digit() {
                self.pos += 1;
            }
        }
        if self.pos < self.bytes.len()
            && (self.bytes[self.pos] == b'e' || self.bytes[self.pos] == b'E')
        {
            is_float = true;
            self.pos += 1;
            if self.pos < self.bytes.len()
                && (self.bytes[self.pos] == b'+' || self.bytes[self.pos] == b'-')
            {
                self.pos += 1;
            }
            if self.pos >= self.bytes.len() || !self.bytes[self.pos].is_ascii_digit() {
                return Err("Invalid exponent.".to_string());
            }
            while self.pos < self.bytes.len() && self.bytes[self.pos].is_ascii_digit() {
                self.pos += 1;
            }
        }
        let raw = std::str::from_utf8(&self.bytes[start..self.pos])
            .map_err(|_| "Invalid number UTF-8.".to_string())?;
        if !is_float {
            if let Ok(n) = raw.parse::<i64>() {
                return Ok(JsonVal::Int(n));
            }
        }
        let f = raw.parse::<f64>().map_err(|_| "Invalid float.".to_string())?;
        Ok(JsonVal::Float(f))
    }

    fn parse_array(&mut self, depth: usize) -> Result<JsonVal, String> {
        self.pos += 1;
        self.skip_ws();
        let mut items = Vec::new();
        if self.pos < self.bytes.len() && self.bytes[self.pos] == b']' {
            self.pos += 1;
            return Ok(JsonVal::Arr(items));
        }
        loop {
            items.push(self.parse_value(depth)?);
            self.skip_ws();
            if self.pos >= self.bytes.len() {
                return Err("Unterminated array.".to_string());
            }
            match self.bytes[self.pos] {
                b',' => self.pos += 1,
                b']' => {
                    self.pos += 1;
                    return Ok(JsonVal::Arr(items));
                }
                _ => return Err("Expected ',' or ']' in array.".to_string()),
            }
        }
    }

    fn parse_object(&mut self, depth: usize) -> Result<JsonVal, String> {
        self.pos += 1;
        self.skip_ws();
        let mut entries: Vec<(String, JsonVal)> = Vec::new();
        if self.pos < self.bytes.len() && self.bytes[self.pos] == b'}' {
            self.pos += 1;
            return Ok(JsonVal::Obj(entries));
        }
        loop {
            self.skip_ws();
            if self.pos >= self.bytes.len() || self.bytes[self.pos] != b'"' {
                return Err("Expected string key in object.".to_string());
            }
            let key = self.parse_string()?;
            self.skip_ws();
            if self.pos >= self.bytes.len() || self.bytes[self.pos] != b':' {
                return Err("Expected ':' after object key.".to_string());
            }
            self.pos += 1;
            let val = self.parse_value(depth)?;
            if let Some((_, existing)) = entries.iter_mut().find(|(k, _)| *k == key) {
                *existing = val;
            } else {
                entries.push((key, val));
            }
            self.skip_ws();
            if self.pos >= self.bytes.len() {
                return Err("Unterminated object.".to_string());
            }
            match self.bytes[self.pos] {
                b',' => self.pos += 1,
                b'}' => {
                    self.pos += 1;
                    return Ok(JsonVal::Obj(entries));
                }
                _ => return Err("Expected ',' or '}' in object.".to_string()),
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_complex_json() {
        let src = r#"{"action":"wifiConnect","ssid":"My:Home \"5G\"","slot":3,"flag":true,"empty":null,"arr":[1,-2,3.5]}"#;
        let parsed = parse_json(src).expect("parse");
        assert_eq!(parsed.get_str("ssid"), Some("My:Home \"5G\""));
        assert_eq!(parsed.get_i64("slot"), Some(3));
        assert_eq!(parsed.get_bool("flag"), Some(true));
        let re_encoded = parsed.to_json_line();
        let parsed2 = parse_json(&re_encoded).expect("re-parse");
        assert_eq!(parsed, parsed2);
    }
}
