//! Sphere Hub native Rust backend — zero external crates, minimal RSS footprint.

pub mod battery;
pub mod bluetooth;
pub mod bridge;
pub mod catalog;
pub mod config;
pub mod constants;
pub mod hypr;
pub mod json;
pub mod organize;
pub mod pathutil;
pub mod resources;
pub mod system;
pub mod wifi;
