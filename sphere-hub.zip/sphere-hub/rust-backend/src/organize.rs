//! Native Rust implementation of `jarvis-organize` — safe folder sorting with undo & watch.

use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
use std::fs::{self, OpenOptions};
use std::io::{self, Write};
use std::os::unix::fs::{OpenOptionsExt, PermissionsExt};
use std::os::unix::process::CommandExt;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use crate::constants::run_cmd_timeout;
use crate::json::{parse_json, JsonVal};
use crate::pathutil::{home_dir, which};

pub const VERSION: &str = "1.0.0";
pub const PROTOCOL: i64 = 1;

const INCOMPLETE_SUFFIXES: &[&str] = &[".part", ".crdownload", ".tmp", ".download", ".opdownload"];

const DEFAULT_IGNORE: &[&str] = &[
    "*.part",
    "*.crdownload",
    "*.tmp",
    "*.download",
    "*.opdownload",
    ".~lock.*",
    "*.aria2",
    "*.!qb",
];

const SYSTEM_ROOTS: &[&str] = &[
    "/usr", "/bin", "/sbin", "/lib", "/lib32", "/lib64", "/etc", "/boot", "/dev", "/proc", "/sys",
    "/var", "/opt", "/root", "/snap", "/run", "/srv",
];

const SYSTEMD_UNIT: &str = "jarvis-organize-watch.service";
const SCHEDULE_UNITS: &[&str] = &[
    "jarvis-organize-autorun.service",
    "jarvis-organize-daily.service",
    "jarvis-organize-daily.timer",
];

const SYSTEMD_UNIT_TEXT: &str = "[Unit]\n\
Description=Sphere file organizer — watch the selected folders\n\
PartOf=graphical-session.target\n\
\n\
[Service]\n\
Type=simple\n\
ExecStart={script} watch-all\n\
Restart=on-failure\n\
RestartSec=5\n\
Nice=10\n\
\n\
[Install]\n\
WantedBy=default.target\n";

const AUTORUN_UNIT_TEXT: &str = "[Unit]\n\
Description=Sphere file organizer — sort once at login\n\
\n\
[Service]\n\
Type=oneshot\n\
ExecStart={script} run-all\n\
Nice=10\n\
\n\
[Install]\n\
WantedBy=default.target\n";

const DAILY_UNIT_TEXT: &str = "[Unit]\n\
Description=Sphere file organizer — daily sort\n\
\n\
[Service]\n\
Type=oneshot\n\
ExecStart={script} run-all\n\
Nice=10\n";

const DAILY_TIMER_TEXT: &str = "[Unit]\n\
Description=Sphere file organizer — daily sort timer\n\
\n\
[Timer]\n\
OnCalendar=daily\n\
Persistent=true\n\
\n\
[Install]\n\
WantedBy=timers.target\n";

struct DefaultCat {
    name: &'static str,
    exts: &'static [&'static str],
    mimes: &'static [&'static str],
}

const DEFAULT_CATEGORIES: &[DefaultCat] = &[
    DefaultCat {
        name: "Images",
        exts: &["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "heic"],
        mimes: &["image/"],
    },
    DefaultCat {
        name: "Videos",
        exts: &["mp4", "mkv", "mov", "avi", "webm"],
        mimes: &["video/"],
    },
    DefaultCat {
        name: "Audio",
        exts: &["mp3", "wav", "flac", "ogg", "m4a"],
        mimes: &["audio/"],
    },
    DefaultCat {
        name: "Documents",
        exts: &["pdf", "doc", "docx", "odt", "txt", "md", "rtf", "epub"],
        mimes: &[
            "text/",
            "application/pdf",
            "application/msword",
            "application/rtf",
            "application/epub+zip",
            "application/vnd.oasis.opendocument.text",
            "application/vnd.openxmlformats-officedocument.wordprocessingml",
        ],
    },
    DefaultCat {
        name: "Spreadsheets",
        exts: &["xls", "xlsx", "ods", "csv"],
        mimes: &[
            "text/csv",
            "application/vnd.ms-excel",
            "application/vnd.oasis.opendocument.spreadsheet",
            "application/vnd.openxmlformats-officedocument.spreadsheetml",
        ],
    },
    DefaultCat {
        name: "Presentations",
        exts: &["ppt", "pptx", "odp"],
        mimes: &[
            "application/vnd.ms-powerpoint",
            "application/vnd.oasis.opendocument.presentation",
            "application/vnd.openxmlformats-officedocument.presentationml",
        ],
    },
    DefaultCat {
        name: "Archives",
        exts: &["zip", "tar", "gz", "xz", "7z", "rar", "zst"],
        mimes: &[
            "application/zip",
            "application/x-tar",
            "application/gzip",
            "application/x-gzip",
            "application/x-xz",
            "application/x-7z-compressed",
            "application/vnd.rar",
            "application/x-rar",
            "application/zstd",
            "application/x-bzip2",
        ],
    },
    DefaultCat {
        name: "Code",
        exts: &[
            "py", "js", "ts", "sh", "c", "cpp", "rs", "go", "html", "css", "json", "yaml",
        ],
        mimes: &[
            "text/x-python",
            "text/x-script.python",
            "application/javascript",
            "text/javascript",
            "application/json",
            "text/html",
            "text/css",
            "text/x-c",
            "text/x-c++",
            "application/x-sh",
            "text/x-shellscript",
            "application/yaml",
            "text/x-yaml",
        ],
    },
    DefaultCat {
        name: "Installers",
        exts: &["deb", "rpm", "AppImage", "exe", "msi", "iso", "pkg.tar.zst"],
        mimes: &[
            "application/vnd.debian.binary-package",
            "application/x-rpm",
            "application/x-iso9660-image",
            "application/x-msdownload",
            "application/x-msi",
            "application/x-executable",
            "application/vnd.appimage",
        ],
    },
    DefaultCat {
        name: "Fonts",
        exts: &["ttf", "otf", "woff", "woff2"],
        mimes: &["font/", "application/font", "application/x-font"],
    },
    DefaultCat {
        name: "Other",
        exts: &[],
        mimes: &[],
    },
];

pub fn human_bytes(bytes: u64) -> String {
    let mut size = bytes as f64;
    for unit in ["B", "KB", "MB", "GB", "TB"] {
        if size < 1024.0 || unit == "TB" {
            if unit == "B" {
                return format!("{} B", bytes);
            }
            return format!("{:.1} {}", size, unit);
        }
        size /= 1024.0;
    }
    String::new()
}

fn tidy(s: &str) -> String {
    s.replace(['\n', '\r'], " ").trim().to_string()
}

fn expand_tilde(text: &str, home: &Path) -> PathBuf {
    if text == "~" {
        return home.to_path_buf();
    }
    if let Some(rest) = text.strip_prefix("~/") {
        return home.join(rest);
    }
    PathBuf::from(text)
}

fn is_symlink_path(p: &Path) -> bool {
    fs::symlink_metadata(p)
        .map(|m| m.file_type().is_symlink())
        .unwrap_or(false)
}

fn exists_or_symlink(p: &Path) -> bool {
    fs::symlink_metadata(p).is_ok()
}

fn same_path(a: &Path, b: &Path) -> bool {
    match (fs::canonicalize(a), fs::canonicalize(b)) {
        (Ok(ca), Ok(cb)) => ca == cb,
        _ => a == b,
    }
}

fn inside(child: &Path, parent: &Path) -> bool {
    match (fs::canonicalize(child), fs::canonicalize(parent)) {
        (Ok(c), Ok(p)) => c.starts_with(&p),
        _ => child.starts_with(parent),
    }
}

pub fn unique_path(path: &Path) -> PathBuf {
    if !exists_or_symlink(path) {
        return path.to_path_buf();
    }
    let fname = path
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("file");
    let (mut stem, mut suffix) = match fname.rsplit_once('.') {
        Some((b, ext)) if !b.is_empty() => (b.to_string(), format!(".{}", ext)),
        _ => (fname.to_string(), String::new()),
    };
    if stem.to_ascii_lowercase().ends_with(".tar")
        && matches!(
            suffix.to_ascii_lowercase().as_str(),
            ".gz" | ".xz" | ".zst" | ".bz2"
        )
    {
        stem.truncate(stem.len() - 4);
        suffix = format!(".tar{}", suffix);
    }
    let parent = path.parent().unwrap_or_else(|| Path::new("."));
    for num in 1..10_000 {
        let cand = parent.join(format!("{} ({}){}", stem, num, suffix));
        if !exists_or_symlink(&cand) {
            return cand;
        }
    }
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.subsec_nanos())
        .unwrap_or(0);
    parent.join(format!("{} ({:06x}){}", stem, nanos & 0xffffff, suffix))
}

fn move_no_clobber(source: &Path, destination: &Path) -> Result<PathBuf, String> {
    if let Some(parent) = destination.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let target = unique_path(destination);
    match fs::rename(source, &target) {
        Ok(()) => Ok(target),
        Err(err) => {
            // EXDEV cross-filesystem fallback: copy then unlink source
            if err.raw_os_error() == Some(18) {
                fs::copy(source, &target).map_err(|e| e.to_string())?;
                fs::remove_file(source).map_err(|e| e.to_string())?;
                Ok(target)
            } else {
                Err(err.to_string())
            }
        }
    }
}

fn fnmatch_ci(name: &str, pattern: &str) -> bool {
    let n: Vec<char> = name.to_lowercase().chars().collect();
    let p: Vec<char> = pattern.to_lowercase().chars().collect();
    glob_match(&n, &p)
}

fn glob_match(text: &[char], pat: &[char]) -> bool {
    let (mut ti, mut pi) = (0usize, 0usize);
    let (mut star_pi, mut star_ti) = (None, 0usize);
    while ti < text.len() {
        if pi < pat.len() && (pat[pi] == '?' || pat[pi] == text[ti]) {
            ti += 1;
            pi += 1;
        } else if pi < pat.len() && pat[pi] == '*' {
            star_pi = Some(pi);
            pi += 1;
            star_ti = ti;
        } else if let Some(sp) = star_pi {
            pi = sp + 1;
            star_ti += 1;
            ti = star_ti;
        } else {
            return false;
        }
    }
    while pi < pat.len() && pat[pi] == '*' {
        pi += 1;
    }
    pi == pat.len()
}

#[derive(Clone)]
pub struct CategoryRule {
    pub name: String,
    pub extensions: Vec<String>,
    pub mime: Vec<String>,
    pub fallback: bool,
}

pub struct Rules {
    pub raw: JsonVal,
    pub categories: Vec<CategoryRule>,
    pub ignore: Vec<String>,
    pub min_age_seconds: f64,
    pub opt_include_subfolders: bool,
    by_suffix: HashMap<String, String>,
}

impl Rules {
    pub fn default_json() -> JsonVal {
        let cats: Vec<JsonVal> = DEFAULT_CATEGORIES
            .iter()
            .map(|c| {
                JsonVal::obj(vec![
                    ("name", JsonVal::Str(c.name.to_string())),
                    (
                        "extensions",
                        JsonVal::Arr(
                            c.exts
                                .iter()
                                .map(|e| JsonVal::Str((*e).to_string()))
                                .collect(),
                        ),
                    ),
                    (
                        "mime",
                        JsonVal::Arr(
                            c.mimes
                                .iter()
                                .map(|m| JsonVal::Str((*m).to_string()))
                                .collect(),
                        ),
                    ),
                ])
            })
            .collect();
        let ig: Vec<JsonVal> = DEFAULT_IGNORE
            .iter()
            .map(|s| JsonVal::Str((*s).to_string()))
            .collect();
        JsonVal::obj(vec![
            ("version", JsonVal::Int(1)),
            (
                "_comment",
                JsonVal::Str(
                    "Edit the categories, their extensions and the ignore patterns. 'mime' is only used for files with no usable extension. The category named 'Other' collects everything unmatched."
                        .to_string(),
                ),
            ),
            ("categories", JsonVal::Arr(cats)),
            ("ignore", JsonVal::Arr(ig)),
            (
                "options",
                JsonVal::obj(vec![
                    ("min_age_seconds", JsonVal::Int(60)),
                    ("include_subfolders", JsonVal::Bool(false)),
                    ("central_destination", JsonVal::Str(String::new())),
                ]),
            ),
        ])
    }

    pub fn from_json(data: JsonVal) -> Self {
        let mut ignore: Vec<String> = data
            .get("ignore")
            .and_then(|v| v.as_arr())
            .map(|arr| {
                arr.iter()
                    .filter_map(|i| i.as_str())
                    .map(tidy)
                    .filter(|s| !s.is_empty())
                    .collect()
            })
            .unwrap_or_default();
        if ignore.is_empty() {
            ignore = DEFAULT_IGNORE.iter().map(|s| (*s).to_string()).collect();
        }

        let mut min_age = 60.0;
        let mut opt_inc = false;
        if let Some(opts) = data.get("options") {
            if let Some(age) = opts.get("min_age_seconds").and_then(|v| v.as_f64()) {
                if age >= 0.0 {
                    min_age = age;
                }
            }
            if let Some(inc) = opts.get_bool("include_subfolders") {
                opt_inc = inc;
            }
        }

        let mut categories = Vec::new();
        let mut seen = HashSet::new();
        if let Some(arr) = data.get("categories").and_then(|v| v.as_arr()) {
            for entry in arr {
                let (name_raw, exts_val, mime_val, fb_flag) = if let Some(s) = entry.as_str() {
                    (s, None, None, false)
                } else if entry.as_obj().is_some() {
                    (
                        entry.get_str("name").unwrap_or(""),
                        entry.get("extensions").and_then(|v| v.as_arr()),
                        entry.get("mime").and_then(|v| v.as_arr()),
                        entry.get_bool("fallback") == Some(true),
                    )
                } else {
                    continue;
                };
                let name = tidy(name_raw);
                if name.is_empty()
                    || name.contains('/')
                    || name == "."
                    || name == ".."
                    || !seen.insert(name.to_lowercase())
                {
                    continue;
                }
                let extensions: Vec<String> = exts_val
                    .map(|a| {
                        a.iter()
                            .filter_map(|v| v.as_str())
                            .map(|s| tidy(s).to_lowercase().trim_start_matches('.').to_string())
                            .filter(|s| !s.is_empty())
                            .collect()
                    })
                    .unwrap_or_default();
                let mime: Vec<String> = mime_val
                    .map(|a| {
                        a.iter()
                            .filter_map(|v| v.as_str())
                            .map(|s| tidy(s).to_lowercase())
                            .filter(|s| !s.is_empty())
                            .collect()
                    })
                    .unwrap_or_default();
                let fallback = fb_flag || name.eq_ignore_ascii_case("other");
                categories.push(CategoryRule {
                    name,
                    extensions,
                    mime,
                    fallback,
                });
            }
        }

        if !categories.iter().any(|c| c.fallback) {
            categories.push(CategoryRule {
                name: "Other".to_string(),
                extensions: Vec::new(),
                mime: Vec::new(),
                fallback: true,
            });
        }

        let mut by_suffix = HashMap::new();
        for cat in &categories {
            for ext in &cat.extensions {
                by_suffix
                    .entry(ext.clone())
                    .or_insert_with(|| cat.name.clone());
            }
        }

        Self {
            raw: data,
            categories,
            ignore,
            min_age_seconds: min_age,
            opt_include_subfolders: opt_inc,
            by_suffix,
        }
    }

    pub fn category_for_extension(&self, filename: &str) -> Option<String> {
        let lower = filename.to_lowercase();
        let parts: Vec<&str> = lower.split('.').filter(|p| !p.is_empty()).collect();
        if parts.len() < 2 {
            return None;
        }
        let max_take = 4.min(parts.len() - 1);
        for take in (1..=max_take).rev() {
            let suffix = parts[parts.len() - take..].join(".");
            if let Some(cat) = self.by_suffix.get(&suffix) {
                return Some(cat.clone());
            }
        }
        None
    }

    pub fn category_for_mime(&self, mime: &str) -> Option<String> {
        let m = mime.trim().to_lowercase();
        if m.is_empty() {
            return None;
        }
        for cat in &self.categories {
            for prefix in &cat.mime {
                if m == *prefix || m.starts_with(prefix) {
                    return Some(cat.name.clone());
                }
            }
        }
        None
    }

    pub fn fallback(&self) -> String {
        self.categories
            .iter()
            .find(|c| c.fallback)
            .map(|c| c.name.clone())
            .unwrap_or_else(|| "Other".to_string())
    }

    pub fn ignored(&self, filename: &str) -> bool {
        self.ignore.iter().any(|pat| fnmatch_ci(filename, pat))
    }
}

pub struct Organizer {
    pub home: PathBuf,
    pub config_dir: PathBuf,
    pub state_dir: PathBuf,
    pub rules_path: PathBuf,
    pub state_path: PathBuf,
}

impl Organizer {
    pub fn new() -> Self {
        let home = home_dir();
        let config_home = std::env::var("XDG_CONFIG_HOME")
            .ok()
            .filter(|s| !s.is_empty())
            .map(|s| expand_tilde(&s, &home))
            .unwrap_or_else(|| home.join(".config"));
        let state_home = std::env::var("XDG_STATE_HOME")
            .ok()
            .filter(|s| !s.is_empty())
            .map(|s| expand_tilde(&s, &home))
            .unwrap_or_else(|| home.join(".local/state"));
        let config_dir = std::env::var("JARVIS_CONFIG_DIR")
            .ok()
            .filter(|s| !s.is_empty())
            .map(|s| expand_tilde(&s, &home))
            .unwrap_or_else(|| config_home.join("jarvis"));
        let state_dir = std::env::var("JARVIS_STATE_DIR")
            .ok()
            .filter(|s| !s.is_empty())
            .map(|s| expand_tilde(&s, &home))
            .unwrap_or_else(|| state_home.join("jarvis/organize"));
        let rules_path = config_dir.join("organize.json");
        let state_path = state_dir.join("state.json");
        Self {
            home,
            config_dir,
            state_dir,
            rules_path,
            state_path,
        }
    }

    pub fn now_secs(&self) -> f64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs_f64())
            .unwrap_or(0.0)
    }

    pub fn ensure_dirs(&self) {
        let _ = fs::create_dir_all(&self.config_dir);
        let _ = fs::create_dir_all(&self.state_dir);
        let _ = fs::set_permissions(&self.state_dir, fs::Permissions::from_mode(0o700));
    }

    pub fn shorten(&self, path: &Path) -> String {
        let p_str = path.to_string_lossy();
        let h_str = self.home.to_string_lossy();
        if p_str == h_str {
            return "~".to_string();
        }
        let prefix = format!("{}/", h_str);
        if let Some(rest) = p_str.strip_prefix(&prefix) {
            return format!("~/{}", rest);
        }
        p_str.into_owned()
    }

    pub fn load_rules(&self, create: bool) -> Rules {
        if create && !self.rules_path.exists() {
            self.ensure_dirs();
            let _ = write_json_atomic(&self.rules_path, &Rules::default_json());
        }
        let data = match fs::read_to_string(&self.rules_path) {
            Ok(raw) => match parse_json(&raw) {
                Ok(v) if v.as_obj().is_some() => v,
                _ => {
                    let mut d = Rules::default_json();
                    d.set(
                        "_error",
                        JsonVal::Str(
                            "rules file is not valid JSON; the built-in defaults are in use"
                                .to_string(),
                        ),
                    );
                    d
                }
            },
            Err(e) if e.kind() == io::ErrorKind::NotFound => Rules::default_json(),
            Err(_) => {
                let mut d = Rules::default_json();
                d.set(
                    "_error",
                    JsonVal::Str(
                        "rules file is not valid JSON; the built-in defaults are in use"
                            .to_string(),
                    ),
                );
                d
            }
        };
        Rules::from_json(data)
    }

    pub fn load_state(&self) -> JsonVal {
        let mut data = fs::read_to_string(&self.state_path)
            .ok()
            .and_then(|s| parse_json(&s).ok())
            .filter(|v| v.as_obj().is_some())
            .unwrap_or_else(|| JsonVal::Obj(Vec::new()));

        data.set_default("version", JsonVal::Int(1));
        data.set_default("folders", JsonVal::Arr(Vec::new()));
        data.set_default("auto", JsonVal::Bool(false));
        data.set_default("schedule", JsonVal::Str("manual".to_string()));
        data.set_default("include_subfolders", JsonVal::Bool(false));
        data.set_default("central", JsonVal::Str(String::new()));
        data.set_default("last_run", JsonVal::Null);
        data.set_default("auto_pid", JsonVal::Null);
        data.set_default("auto_method", JsonVal::Str(String::new()));

        let mut folders: Vec<String> = Vec::new();
        if let Some(arr) = data.get("folders").and_then(|v| v.as_arr()) {
            for item in arr {
                if let Some(s) = item.as_str() {
                    let t = tidy(s);
                    if !t.is_empty()
                        && expand_tilde(&t, &self.home).is_absolute()
                        && !folders.contains(&t)
                    {
                        folders.push(t);
                    }
                }
            }
        }
        if folders.is_empty() {
            folders.push(self.home.join("Downloads").to_string_lossy().into_owned());
        }
        data.set(
            "folders",
            JsonVal::Arr(folders.into_iter().map(JsonVal::Str).collect()),
        );
        data
    }

    pub fn save_state(&self, state: &JsonVal) {
        self.ensure_dirs();
        let _ = write_json_atomic(&self.state_path, state);
    }

    pub fn refuse(&self, folder: &str) -> Result<PathBuf, String> {
        let text = tidy(folder);
        if text.is_empty() {
            return Err("no folder was given".to_string());
        }
        if text.contains('\0') {
            return Err("the path contains a NUL byte".to_string());
        }
        let path = expand_tilde(&text, &self.home);
        if !path.is_absolute() {
            return Err(format!("the folder must be an absolute path (got {})", text));
        }
        if is_symlink_path(&path) {
            return Err("the folder itself is a symlink; pick the real folder".to_string());
        }
        // Check system roots on lexical AND canonical path
        for root in SYSTEM_ROOTS {
            let rp = Path::new(root);
            if path == rp || path.starts_with(rp) {
                return Err(format!("{} is a system path; refusing to sort it", text));
            }
        }
        let resolved = match fs::canonicalize(&path) {
            Ok(r) => r,
            Err(_) => {
                if !path.exists() {
                    return Err("the folder does not exist".to_string());
                }
                return Err("the path cannot be resolved".to_string());
            }
        };
        if resolved == Path::new("/") {
            return Err("that is the filesystem root; refusing to sort it".to_string());
        }
        for root in SYSTEM_ROOTS {
            let rp = Path::new(root);
            if resolved == rp || resolved.starts_with(rp) {
                let shown = if resolved.to_string_lossy() != text {
                    text.as_str()
                } else {
                    *root
                };
                return Err(format!("{} is a system path; refusing to sort it", shown));
            }
        }
        if same_path(&resolved, &self.home) {
            return Err("that is your home directory itself; pick a folder inside it".to_string());
        }
        let protected = [
            self.config_dir.clone(),
            self.state_dir.clone(),
            self.home.join(".config"),
            self.home.join(".local"),
            self.home.join(".cache"),
            self.home.join(".ssh"),
            self.home.join(".gnupg"),
        ];
        for prot in &protected {
            if resolved == *prot || resolved.starts_with(prot) || inside(&resolved, prot) {
                return Err(format!(
                    "{} holds configuration or state; refusing to sort it",
                    self.shorten(prot)
                ));
            }
        }
        if !resolved.is_dir() {
            return Err("the folder does not exist".to_string());
        }
        Ok(resolved)
    }

    fn classify(&self, path: &Path, rules: &Rules) -> (String, String) {
        let name = path
            .file_name()
            .and_then(|s| s.to_str())
            .unwrap_or_default();
        if let Some(cat) = rules.category_for_extension(name) {
            return (cat, "extension".to_string());
        }
        let mime = detect_mime(path);
        if let Some(cat) = rules.category_for_mime(&mime) {
            return (cat, format!("mime:{}", mime));
        }
        (rules.fallback(), "fallback".to_string())
    }

    fn include_subfolders(&self, state: &JsonVal, rules: &Rules) -> bool {
        state
            .get_bool("include_subfolders")
            .unwrap_or(rules.opt_include_subfolders)
    }

    fn destination_root(&self, folder: &Path, state: &JsonVal, central: &str) -> (PathBuf, String) {
        let c = if !tidy(central).is_empty() {
            tidy(central)
        } else {
            tidy(state.get_str("central").unwrap_or(""))
        };
        if !c.is_empty() {
            let expanded = expand_tilde(&c, &self.home);
            let resolved = fs::canonicalize(&expanded).unwrap_or(expanded);
            let disp = self.shorten(&resolved);
            (resolved, disp)
        } else {
            (folder.to_path_buf(), self.shorten(folder))
        }
    }

    fn collect_candidates(
        &self,
        folder: &Path,
        include_subfolders: bool,
        rules: &Rules,
    ) -> Vec<(PathBuf, Option<String>)> {
        let mut category_names: HashSet<String> = rules
            .categories
            .iter()
            .map(|c| c.name.to_lowercase())
            .collect();
        category_names.insert("sorted".to_string());

        let mut out = Vec::new();
        let mut queue = vec![folder.to_path_buf()];

        while !queue.is_empty() {
            let cur = queue.remove(0);
            let rd = match fs::read_dir(&cur) {
                Ok(r) => r,
                Err(e) => {
                    out.push((
                        cur,
                        Some(format!("cannot read the folder: {}", e)),
                    ));
                    continue;
                }
            };
            let mut entries: Vec<_> = rd.flatten().collect();
            entries.sort_by_key(|e| e.file_name().to_string_lossy().to_lowercase());

            for entry in entries {
                let path = entry.path();
                let fname = entry.file_name().to_string_lossy().into_owned();
                let Ok(ft) = entry.file_type() else {
                    out.push((path, Some("cannot be inspected".to_string())));
                    continue;
                };
                if ft.is_symlink() {
                    out.push((path, Some("symlink".to_string())));
                    continue;
                }
                if ft.is_dir() {
                    if include_subfolders && !category_names.contains(&fname.to_lowercase()) {
                        queue.push(path);
                    }
                    continue;
                }
                if !ft.is_file() {
                    out.push((path, Some("not a regular file".to_string())));
                    continue;
                }
                if fname.starts_with('.') {
                    out.push((path, Some("hidden".to_string())));
                    continue;
                }
                let lower_name = fname.to_lowercase();
                if INCOMPLETE_SUFFIXES.iter().any(|s| lower_name.ends_with(s)) {
                    out.push((path, Some("incomplete download".to_string())));
                    continue;
                }
                if rules.ignored(&fname) {
                    out.push((path, Some("ignored by the rules' ignore list".to_string())));
                    continue;
                }
                out.push((path, None));
            }
        }
        out
    }

    pub fn scan(&self, folder: &str, limit_per_category: Option<usize>) -> JsonVal {
        let resolved = match self.refuse(folder) {
            Ok(p) => p,
            Err(reason) => {
                return JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("scan".to_string())),
                    ("command", JsonVal::Str("scan".to_string())),
                    ("folder", JsonVal::Str(tidy(folder))),
                    ("error", JsonVal::Str(reason)),
                ]);
            }
        };

        let state = self.load_state();
        let rules = self.load_rules(true);
        let inc_sub = self.include_subfolders(&state, &rules);
        let min_age = rules.min_age_seconds;
        let wall = self.now_secs();
        let (root, root_display) = self.destination_root(&resolved, &state, "");

        struct Bucket {
            count: usize,
            bytes: u64,
            files: Vec<JsonVal>,
        }

        let mut buckets: HashMap<String, Bucket> = HashMap::new();
        let mut skipped: Vec<JsonVal> = Vec::new();
        let mut errors: Vec<JsonVal> = Vec::new();
        let mut total_files: usize = 0;
        let mut total_bytes: u64 = 0;

        for (path, skip_opt) in self.collect_candidates(&resolved, inc_sub, &rules) {
            let fname = path
                .file_name()
                .and_then(|s| s.to_str())
                .unwrap_or("")
                .to_string();
            if let Some(skip) = skip_opt {
                if skip.starts_with("cannot") {
                    errors.push(JsonVal::obj(vec![
                        ("path", JsonVal::Str(self.shorten(&path))),
                        ("reason", JsonVal::Str(skip)),
                    ]));
                } else {
                    skipped.push(JsonVal::obj(vec![
                        ("name", JsonVal::Str(fname)),
                        ("reason", JsonVal::Str(skip)),
                    ]));
                }
                continue;
            }

            let meta = match fs::metadata(&path) {
                Ok(m) => m,
                Err(e) => {
                    errors.push(JsonVal::obj(vec![
                        ("path", JsonVal::Str(self.shorten(&path))),
                        ("reason", JsonVal::Str(e.to_string())),
                    ]));
                    continue;
                }
            };

            let mtime = meta
                .modified()
                .ok()
                .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
                .map(|d| d.as_secs_f64())
                .unwrap_or(0.0);

            if min_age > 0.0 && (wall - mtime) < min_age {
                skipped.push(JsonVal::obj(vec![
                    ("name", JsonVal::Str(fname)),
                    (
                        "reason",
                        JsonVal::Str(format!("modified in the last {} s", min_age as i64)),
                    ),
                ]));
                continue;
            }

            let size = meta.len();
            let (category, how) = self.classify(&path, &rules);
            let bucket = buckets.entry(category.clone()).or_insert_with(|| Bucket {
                count: 0,
                bytes: 0,
                files: Vec::new(),
            });
            bucket.count += 1;
            bucket.bytes += size;
            total_files += 1;
            total_bytes += size;

            if limit_per_category.map(|lim| bucket.files.len() < lim).unwrap_or(true) {
                let dest = root.join(&category).join(&fname);
                let planned = unique_path(&dest);
                let planned_name = planned
                    .file_name()
                    .and_then(|s| s.to_str())
                    .unwrap_or(&fname);
                let rel = path
                    .strip_prefix(&resolved)
                    .unwrap_or(&path)
                    .to_string_lossy()
                    .into_owned();
                bucket.files.push(JsonVal::obj(vec![
                    ("name", JsonVal::Str(fname.clone())),
                    ("rel", JsonVal::Str(rel)),
                    ("size", JsonVal::Int(size as i64)),
                    ("size_h", JsonVal::Str(human_bytes(size))),
                    ("match", JsonVal::Str(how)),
                    ("target", JsonVal::Str(self.shorten(&planned))),
                    ("renamed", JsonVal::Bool(planned_name != fname)),
                ]));
            }
        }

        let mut ordered: Vec<(String, Bucket)> = buckets.into_iter().collect();
        ordered.sort_by(|(na, ba), (nb, bb)| {
            (
                na.eq_ignore_ascii_case("other"),
                std::cmp::Reverse(ba.count),
                na.clone(),
            )
                .cmp(&(
                    nb.eq_ignore_ascii_case("other"),
                    std::cmp::Reverse(bb.count),
                    nb.clone(),
                ))
        });

        let cats_json: Vec<JsonVal> = ordered
            .into_iter()
            .map(|(name, b)| {
                let share = if total_files > 0 {
                    ((b.count as f64 / total_files as f64) * 10000.0).round() / 10000.0
                } else {
                    0.0
                };
                JsonVal::obj(vec![
                    ("name", JsonVal::Str(name.clone())),
                    ("count", JsonVal::Int(b.count as i64)),
                    ("bytes", JsonVal::Int(b.bytes as i64)),
                    ("bytes_h", JsonVal::Str(human_bytes(b.bytes))),
                    ("share", JsonVal::Float(share)),
                    ("destination", JsonVal::Str(self.shorten(&root.join(&name)))),
                    ("files", JsonVal::Arr(b.files)),
                ])
            })
            .collect();

        let skip_count = skipped.len();
        skipped.truncate(40);
        errors.truncate(20);

        JsonVal::obj(vec![
            ("ok", JsonVal::Bool(true)),
            ("event", JsonVal::Str("scan".to_string())),
            ("command", JsonVal::Str("scan".to_string())),
            ("protocol", JsonVal::Int(PROTOCOL)),
            ("version", JsonVal::Str(VERSION.to_string())),
            (
                "folder",
                JsonVal::Str(resolved.to_string_lossy().into_owned()),
            ),
            ("display", JsonVal::Str(root_display)),
            (
                "destination",
                JsonVal::Str(if root != resolved { "central" } else { "inside" }.to_string()),
            ),
            (
                "central",
                JsonVal::Str(if root != resolved {
                    self.shorten(&root)
                } else {
                    String::new()
                }),
            ),
            ("include_subfolders", JsonVal::Bool(inc_sub)),
            ("files", JsonVal::Int(total_files as i64)),
            ("bytes", JsonVal::Int(total_bytes as i64)),
            ("bytes_h", JsonVal::Str(human_bytes(total_bytes))),
            ("categories", JsonVal::Arr(cats_json)),
            (
                "skipped",
                JsonVal::obj(vec![
                    ("count", JsonVal::Int(skip_count as i64)),
                    ("items", JsonVal::Arr(skipped)),
                ]),
            ),
            ("errors", JsonVal::Arr(errors)),
            ("rules", JsonVal::Str(self.shorten(&self.rules_path))),
            ("dry_run", JsonVal::Bool(true)),
        ])
    }

    pub fn run<F>(&self, folder: &str, mut stream: F) -> JsonVal
    where
        F: FnMut(&JsonVal),
    {
        let summary = self.scan(folder, None);
        if summary.get_bool("ok") != Some(true) {
            return summary;
        }
        let resolved = PathBuf::from(summary.get_str("folder").unwrap_or(""));
        let mut state = self.load_state();
        let (root, _) = self.destination_root(&resolved, &state, "");

        let mut pairs: Vec<(PathBuf, PathBuf, String)> = Vec::new();
        if let Some(cats) = summary.get("categories").and_then(|v| v.as_arr()) {
            for cat in cats {
                let cname = cat.get_str("name").unwrap_or("Other").to_string();
                if let Some(files) = cat.get("files").and_then(|v| v.as_arr()) {
                    for item in files {
                        let rel = item.get_str("rel").unwrap_or("");
                        let src = resolved.join(rel);
                        let fname = src
                            .file_name()
                            .and_then(|s| s.to_str())
                            .unwrap_or("file");
                        let dst = root.join(&cname).join(fname);
                        pairs.push((src, dst, cname.clone()));
                    }
                }
            }
        }

        self.ensure_dirs();
        let (ts_compact, started_iso) = utc_stamps();
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.subsec_nanos())
            .unwrap_or(0);
        let log_id = format!("undo-{}-{:04x}", ts_compact, nanos & 0xffff);
        let log_path = self.state_dir.join(format!("{}.json", log_id));

        let mut created_dirs: BTreeSet<String> = BTreeSet::new();
        let mut moves: Vec<JsonVal> = Vec::new();
        let mut errors: Vec<JsonVal> = Vec::new();
        let mut moved_bytes: u64 = 0;
        let mut counts: BTreeMap<String, usize> = BTreeMap::new();
        let total = pairs.len();

        for (i, (src, dst, cat)) in pairs.into_iter().enumerate() {
            let idx = i + 1;
            if !src.is_file() || is_symlink_path(&src) {
                errors.push(JsonVal::obj(vec![
                    ("path", JsonVal::Str(self.shorten(&src))),
                    (
                        "reason",
                        JsonVal::Str("disappeared before the move".to_string()),
                    ),
                ]));
                continue;
            }
            if let Some(parent) = dst.parent() {
                if !parent.exists() {
                    if let Err(e) = fs::create_dir_all(parent) {
                        errors.push(JsonVal::obj(vec![
                            ("path", JsonVal::Str(self.shorten(&src))),
                            ("reason", JsonVal::Str(e.to_string())),
                        ]));
                        continue;
                    }
                    created_dirs.insert(parent.to_string_lossy().into_owned());
                }
            }
            let src_name = src
                .file_name()
                .and_then(|s| s.to_str())
                .unwrap_or("")
                .to_string();
            match move_no_clobber(&src, &dst) {
                Ok(used) => {
                    let written = fs::metadata(&used).map(|m| m.len()).unwrap_or(0);
                    let used_name = used
                        .file_name()
                        .and_then(|s| s.to_str())
                        .unwrap_or("");
                    moved_bytes += written;
                    *counts.entry(cat.clone()).or_insert(0) += 1;
                    moves.push(JsonVal::obj(vec![
                        ("from", JsonVal::Str(src.to_string_lossy().into_owned())),
                        ("to", JsonVal::Str(used.to_string_lossy().into_owned())),
                        ("category", JsonVal::Str(cat.clone())),
                        ("bytes", JsonVal::Int(written as i64)),
                        ("renamed", JsonVal::Bool(used_name != src_name)),
                    ]));
                    let pct = if total > 0 {
                        ((idx as f64 * 100.0 / total as f64) * 10.0).round() / 10.0
                    } else {
                        100.0
                    };
                    let prog = JsonVal::obj(vec![
                        ("event", JsonVal::Str("progress".to_string())),
                        ("command", JsonVal::Str("run".to_string())),
                        ("total", JsonVal::Int(total as i64)),
                        ("done", JsonVal::Int(idx as i64)),
                        ("current", JsonVal::Str(src_name)),
                        ("category", JsonVal::Str(cat)),
                        ("percent", JsonVal::Float(pct)),
                    ]);
                    stream(&prog);
                }
                Err(err) => {
                    errors.push(JsonVal::obj(vec![
                        ("path", JsonVal::Str(self.shorten(&src))),
                        ("reason", JsonVal::Str(err)),
                    ]));
                }
            }
        }

        let (_, finished_iso) = utc_stamps();
        let has_undo = !moves.is_empty() || !created_dirs.is_empty();
        if has_undo {
            let record = JsonVal::obj(vec![
                ("version", JsonVal::Int(1)),
                ("protocol", JsonVal::Int(PROTOCOL)),
                ("id", JsonVal::Str(log_id.clone())),
                ("started", JsonVal::Str(started_iso)),
                ("finished", JsonVal::Str(finished_iso.clone())),
                (
                    "folders",
                    JsonVal::Arr(vec![JsonVal::Str(
                        summary.get_str("folder").unwrap_or("").to_string(),
                    )]),
                ),
                (
                    "destination",
                    JsonVal::Str(summary.get_str("destination").unwrap_or("inside").to_string()),
                ),
                (
                    "central",
                    JsonVal::Str(summary.get_str("central").unwrap_or("").to_string()),
                ),
                ("moves", JsonVal::Arr(moves.clone())),
                (
                    "created_dirs",
                    JsonVal::Arr(created_dirs.into_iter().map(JsonVal::Str).collect()),
                ),
                ("errors", JsonVal::Arr(errors.clone())),
                ("undone", JsonVal::Null),
            ]);
            let _ = write_json_atomic(&log_path, &record);
            state.set(
                "last_run",
                JsonVal::obj(vec![
                    ("id", JsonVal::Str(log_id.clone())),
                    ("at", JsonVal::Str(finished_iso)),
                    ("moved", JsonVal::Int(moves.len() as i64)),
                    (
                        "folder",
                        JsonVal::Str(summary.get_str("folder").unwrap_or("").to_string()),
                    ),
                    ("bytes", JsonVal::Int(moved_bytes as i64)),
                ]),
            );
            self.save_state(&state);
        }

        let mut cat_summary: Vec<(String, usize)> = counts.into_iter().collect();
        cat_summary.sort_by(|a, b| (std::cmp::Reverse(a.1), &a.0).cmp(&(std::cmp::Reverse(b.1), &b.0)));
        errors.truncate(20);
        let skipped_cnt = summary
            .get("skipped")
            .and_then(|s| s.get_i64("count"))
            .unwrap_or(0);

        JsonVal::obj(vec![
            ("ok", JsonVal::Bool(true)),
            ("event", JsonVal::Str("done".to_string())),
            ("command", JsonVal::Str("run".to_string())),
            ("protocol", JsonVal::Int(PROTOCOL)),
            ("version", JsonVal::Str(VERSION.to_string())),
            (
                "folder",
                JsonVal::Str(summary.get_str("folder").unwrap_or("").to_string()),
            ),
            (
                "display",
                JsonVal::Str(summary.get_str("display").unwrap_or("").to_string()),
            ),
            ("moved", JsonVal::Int(moves.len() as i64)),
            ("skipped", JsonVal::Int(skipped_cnt)),
            ("bytes", JsonVal::Int(moved_bytes as i64)),
            ("bytes_h", JsonVal::Str(human_bytes(moved_bytes))),
            (
                "categories",
                JsonVal::Arr(
                    cat_summary
                        .into_iter()
                        .map(|(k, v)| {
                            JsonVal::obj(vec![
                                ("name", JsonVal::Str(k)),
                                ("count", JsonVal::Int(v as i64)),
                            ])
                        })
                        .collect(),
                ),
            ),
            ("errors", JsonVal::Arr(errors)),
            (
                "undo",
                JsonVal::Str(if has_undo {
                    format!("{}.json", log_id)
                } else {
                    String::new()
                }),
            ),
            ("undo_available", JsonVal::Bool(has_undo)),
            ("dry_run", JsonVal::Bool(false)),
        ])
    }

    fn pending_undo(&self) -> Option<(PathBuf, JsonVal)> {
        let Ok(rd) = fs::read_dir(&self.state_dir) else {
            return None;
        };
        let mut logs: Vec<PathBuf> = rd
            .flatten()
            .map(|e| e.path())
            .filter(|p| {
                let n = p.file_name().and_then(|s| s.to_str()).unwrap_or("");
                n.starts_with("undo-") && n.ends_with(".json") && p.is_file()
            })
            .collect();
        logs.sort();
        for path in logs.into_iter().rev() {
            let Ok(raw) = fs::read_to_string(&path) else {
                continue;
            };
            let Ok(data) = parse_json(&raw) else {
                continue;
            };
            if data.as_obj().is_some()
                && data.get("undone").map(|v| v.is_null()).unwrap_or(true)
            {
                return Some((path, data));
            }
        }
        None
    }

    pub fn undo(&self) -> JsonVal {
        let Some((log_path, mut record)) = self.pending_undo() else {
            return JsonVal::obj(vec![
                ("ok", JsonVal::Bool(true)),
                ("event", JsonVal::Str("undo".to_string())),
                ("command", JsonVal::Str("undo".to_string())),
                ("restored", JsonVal::Int(0)),
                ("message", JsonVal::Str("Nothing to undo.".to_string())),
                ("undo_available", JsonVal::Bool(false)),
                ("removed_dirs", JsonVal::Arr(Vec::new())),
            ]);
        };

        let mut restored = 0i64;
        let mut missing: Vec<JsonVal> = Vec::new();
        let mut renamed: Vec<JsonVal> = Vec::new();

        let moves: Vec<JsonVal> = record
            .get("moves")
            .and_then(|v| v.as_arr())
            .map(|a| a.to_vec())
            .unwrap_or_default();

        for mv in moves.into_iter().rev() {
            let source = PathBuf::from(mv.get_str("from").unwrap_or(""));
            let target = PathBuf::from(mv.get_str("to").unwrap_or(""));
            if !target.is_file() || is_symlink_path(&target) {
                missing.push(JsonVal::Str(self.shorten(&target)));
                continue;
            }
            let Some(src_parent) = source.parent() else {
                missing.push(JsonVal::Str(self.shorten(&source)));
                continue;
            };
            if !src_parent.is_dir() {
                missing.push(JsonVal::Str(self.shorten(&source)));
                continue;
            }
            match move_no_clobber(&target, &source) {
                Ok(used) => {
                    restored += 1;
                    if used != source {
                        renamed.push(JsonVal::obj(vec![
                            ("from", JsonVal::Str(self.shorten(&source))),
                            ("to", JsonVal::Str(self.shorten(&used))),
                        ]));
                    }
                }
                Err(err) => {
                    missing.push(JsonVal::Str(format!("{} ({})", self.shorten(&target), err)));
                }
            }
        }

        let mut created_dirs: Vec<String> = record
            .get("created_dirs")
            .and_then(|v| v.as_arr())
            .map(|a| {
                a.iter()
                    .filter_map(|v| v.as_str())
                    .map(|s| s.to_string())
                    .collect()
            })
            .unwrap_or_default();
        created_dirs.sort_by_key(|s| std::cmp::Reverse(s.len()));

        let mut removed_dirs: Vec<JsonVal> = Vec::new();
        for d in created_dirs {
            let dp = Path::new(&d);
            if dp.is_dir() {
                let is_empty = fs::read_dir(dp)
                    .map(|mut rd| rd.next().is_none())
                    .unwrap_or(false);
                if is_empty && fs::remove_dir(dp).is_ok() {
                    removed_dirs.push(JsonVal::Str(self.shorten(dp)));
                }
            }
        }

        let (_, iso) = utc_stamps();
        record.set("undone", JsonVal::Str(iso));
        record.set("restored", JsonVal::Int(restored));
        let _ = write_json_atomic(&log_path, &record);

        let mut state = self.load_state();
        state.set("last_run", JsonVal::Null);
        self.save_state(&state);

        missing.truncate(20);
        renamed.truncate(20);
        let log_name = log_path
            .file_name()
            .and_then(|s| s.to_str())
            .unwrap_or("")
            .to_string();

        JsonVal::obj(vec![
            ("ok", JsonVal::Bool(true)),
            ("event", JsonVal::Str("undo".to_string())),
            ("command", JsonVal::Str("undo".to_string())),
            ("protocol", JsonVal::Int(PROTOCOL)),
            ("restored", JsonVal::Int(restored)),
            ("missing", JsonVal::Arr(missing)),
            ("renamed", JsonVal::Arr(renamed)),
            ("removed_dirs", JsonVal::Arr(removed_dirs)),
            ("log", JsonVal::Str(log_name)),
            (
                "message",
                JsonVal::Str(format!(
                    "Restored {} file{}.",
                    restored,
                    if restored == 1 { "" } else { "s" }
                )),
            ),
            ("undo_available", JsonVal::Bool(self.pending_undo().is_some())),
        ])
    }

    fn systemctl_user(&self, args: &[&str]) -> Option<String> {
        let bin = which("systemctl")?;
        let res = run_cmd_timeout(&bin.to_string_lossy(), &([&["--user"][..], args].concat()), None, 8_000);
        if res.code == 0 {
            Some(res.stdout.trim().to_string())
        } else {
            None
        }
    }

    fn watch_status(&self, state: &JsonVal) -> JsonVal {
        let pid_opt = state.get_i64("auto_pid");
        let alive = pid_opt
            .filter(|&p| p > 0)
            .map(|p| unsafe { kill(p as i32, 0) == 0 })
            .unwrap_or(false);
        let unit_active = self.systemctl_user(&["is-active", SYSTEMD_UNIT]).as_deref() == Some("active");
        let mut method = tidy(state.get_str("auto_method").unwrap_or(""));
        if method.is_empty() && unit_active {
            method = "systemd".to_string();
        }
        JsonVal::obj(vec![
            ("running", JsonVal::Bool(alive || unit_active)),
            (
                "pid",
                if alive {
                    pid_opt.into()
                } else {
                    JsonVal::Null
                },
            ),
            ("method", JsonVal::Str(method)),
            ("unit_active", JsonVal::Bool(unit_active)),
        ])
    }

    pub fn status(&self) -> JsonVal {
        let state = self.load_state();
        let rules = self.load_rules(true);
        let pending = self.pending_undo();

        let folders_raw: Vec<String> = state
            .get("folders")
            .and_then(|v| v.as_arr())
            .map(|a| {
                a.iter()
                    .filter_map(|v| v.as_str())
                    .map(|s| s.to_string())
                    .collect()
            })
            .unwrap_or_default();
        let first_folder = folders_raw
            .first()
            .cloned()
            .unwrap_or_else(|| self.home.join("Downloads").to_string_lossy().into_owned());
        let first_exp = expand_tilde(&first_folder, &self.home);
        let central = tidy(state.get_str("central").unwrap_or(""));
        let destination = if !central.is_empty() {
            format!("{}/<Category>", self.shorten(&expand_tilde(&central, &self.home)))
        } else {
            format!("{}/<Category>", self.shorten(&first_exp))
        };

        let (undo_avail, undo_log) = match pending {
            Some((p, _)) => (
                true,
                p.file_name()
                    .and_then(|s| s.to_str())
                    .unwrap_or("")
                    .to_string(),
            ),
            None => (false, String::new()),
        };

        JsonVal::obj(vec![
            ("ok", JsonVal::Bool(true)),
            ("event", JsonVal::Str("status".to_string())),
            ("command", JsonVal::Str("status".to_string())),
            ("protocol", JsonVal::Int(PROTOCOL)),
            ("version", JsonVal::Str(VERSION.to_string())),
            (
                "folders",
                JsonVal::Arr(
                    folders_raw
                        .iter()
                        .map(|f| JsonVal::Str(self.shorten(&expand_tilde(f, &self.home))))
                        .collect(),
                ),
            ),
            ("folder", JsonVal::Str(first_folder)),
            ("display", JsonVal::Str(self.shorten(&first_exp))),
            ("folder_exists", JsonVal::Bool(first_exp.is_dir())),
            (
                "auto",
                JsonVal::Bool(state.get_bool("auto") == Some(true)),
            ),
            (
                "auto_method",
                JsonVal::Str(tidy(state.get_str("auto_method").unwrap_or(""))),
            ),
            (
                "schedule",
                JsonVal::Str({
                    let s = tidy(state.get_str("schedule").unwrap_or(""));
                    if s.is_empty() {
                        "manual".to_string()
                    } else {
                        s
                    }
                }),
            ),
            (
                "include_subfolders",
                JsonVal::Bool(self.include_subfolders(&state, &rules)),
            ),
            (
                "central",
                JsonVal::Str(if !central.is_empty() {
                    self.shorten(&expand_tilde(&central, &self.home))
                } else {
                    String::new()
                }),
            ),
            ("destination", JsonVal::Str(destination)),
            ("rules", JsonVal::Str(self.shorten(&self.rules_path))),
            ("rules_exists", JsonVal::Bool(self.rules_path.exists())),
            (
                "categories",
                JsonVal::Arr(
                    rules
                        .categories
                        .iter()
                        .map(|c| JsonVal::Str(c.name.clone()))
                        .collect(),
                ),
            ),
            ("undo_available", JsonVal::Bool(undo_avail)),
            ("undo_log", JsonVal::Str(undo_log)),
            (
                "last_run",
                state.get("last_run").cloned().unwrap_or(JsonVal::Null),
            ),
            ("watch", self.watch_status(&state)),
            ("state_dir", JsonVal::Str(self.shorten(&self.state_dir))),
        ])
    }

    pub fn set_folders(&self, action: &str, folder: &str) -> JsonVal {
        if action == "list" {
            return self.status();
        }
        let resolved = match self.refuse(folder) {
            Ok(p) => p,
            Err(reason) => {
                return JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("folders".to_string())),
                    ("command", JsonVal::Str("folders".to_string())),
                    ("error", JsonVal::Str(reason)),
                ]);
            }
        };
        let mut state = self.load_state();
        let mut folders: Vec<String> = state
            .get("folders")
            .and_then(|v| v.as_arr())
            .map(|a| {
                a.iter()
                    .filter_map(|v| v.as_str())
                    .map(|s| s.to_string())
                    .collect()
            })
            .unwrap_or_default();
        let text = resolved.to_string_lossy().into_owned();

        match action {
            "add" => {
                if !folders.contains(&text) {
                    folders.push(text);
                }
            }
            "remove" => {
                folders.retain(|f| !same_path(Path::new(f), &resolved));
                if folders.is_empty() {
                    return JsonVal::obj(vec![
                        ("ok", JsonVal::Bool(false)),
                        ("event", JsonVal::Str("folders".to_string())),
                        ("command", JsonVal::Str("folders".to_string())),
                        (
                            "error",
                            JsonVal::Str("the last folder cannot be removed".to_string()),
                        ),
                    ]);
                }
            }
            "set" => {
                folders = vec![text];
            }
            _ => {
                return JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("folders".to_string())),
                    ("command", JsonVal::Str("folders".to_string())),
                    (
                        "error",
                        JsonVal::Str(format!("unknown folders action: {}", action)),
                    ),
                ]);
            }
        }
        state.set(
            "folders",
            JsonVal::Arr(folders.into_iter().map(JsonVal::Str).collect()),
        );
        self.save_state(&state);
        self.status()
    }

    pub fn set_config(&self, key: &str, value: &str) -> JsonVal {
        let mut state = self.load_state();
        match key {
            "include_subfolders" | "auto" => {
                let b = matches!(
                    value.trim().to_ascii_lowercase().as_str(),
                    "1" | "true" | "yes" | "on"
                );
                state.set(key, JsonVal::Bool(b));
            }
            "central" => {
                let t = tidy(value);
                if t.is_empty() {
                    state.set("central", JsonVal::Str(String::new()));
                } else {
                    let target = expand_tilde(&t, &self.home);
                    if !target.is_absolute() {
                        return JsonVal::obj(vec![
                            ("ok", JsonVal::Bool(false)),
                            ("event", JsonVal::Str("config".to_string())),
                            ("command", JsonVal::Str("config".to_string())),
                            (
                                "error",
                                JsonVal::Str(
                                    "the central destination must be an absolute path".to_string(),
                                ),
                            ),
                        ]);
                    }
                    for root in SYSTEM_ROOTS {
                        let rp = Path::new(root);
                        if target == rp || target.starts_with(rp) {
                            return JsonVal::obj(vec![
                                ("ok", JsonVal::Bool(false)),
                                ("event", JsonVal::Str("config".to_string())),
                                ("command", JsonVal::Str("config".to_string())),
                                (
                                    "error",
                                    JsonVal::Str(format!("{} is a system path", root)),
                                ),
                            ]);
                        }
                    }
                    if same_path(&target, &self.home) {
                        return JsonVal::obj(vec![
                            ("ok", JsonVal::Bool(false)),
                            ("event", JsonVal::Str("config".to_string())),
                            ("command", JsonVal::Str("config".to_string())),
                            (
                                "error",
                                JsonVal::Str(
                                    "the central destination cannot be your home directory"
                                        .to_string(),
                                ),
                            ),
                        ]);
                    }
                    state.set("central", JsonVal::Str(target.to_string_lossy().into_owned()));
                }
            }
            "schedule" => {
                state.set("schedule", JsonVal::Str(tidy(value)));
            }
            _ => {
                return JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("config".to_string())),
                    ("command", JsonVal::Str("config".to_string())),
                    (
                        "error",
                        JsonVal::Str(format!("unknown setting: {}", key)),
                    ),
                ]);
            }
        }
        self.save_state(&state);
        self.status()
    }

    pub fn set_auto(&self, value: &str) -> JsonVal {
        let mut state = self.load_state();
        let enabled = if value == "toggle" {
            state.get_bool("auto") != Some(true)
        } else {
            matches!(
                value.to_ascii_lowercase().as_str(),
                "1" | "true" | "on" | "yes"
            )
        };
        state.set("auto", JsonVal::Bool(enabled));
        self.save_state(&state);

        let self_bin = std::env::current_exe()
            .map(|p| p.to_string_lossy().into_owned())
            .unwrap_or_else(|_| {
                self.home
                    .join(".local/bin/jarvis-organize")
                    .to_string_lossy()
                    .into_owned()
            });

        let (how, msg, pid_val) = if enabled {
            self.start_supervisor(&self_bin)
        } else {
            self.stop_supervisor(&state)
        };

        state = self.load_state();
        state.set("auto_method", JsonVal::Str(how.clone()));
        state.set("auto_pid", pid_val);
        self.save_state(&state);

        let mut res = self.status();
        res.set("event", JsonVal::Str("auto".to_string()));
        res.set("command", JsonVal::Str("auto".to_string()));
        res.set("enabled", JsonVal::Bool(enabled));
        res.set("supervised", JsonVal::Bool(!how.is_empty()));
        res.set("method", JsonVal::Str(how));
        res.set("message", JsonVal::Str(msg));
        res
    }

    fn start_supervisor(&self, self_bin: &str) -> (String, String, JsonVal) {
        self.ensure_dirs();
        if self.systemctl_user(&["daemon-reload"]).is_some() {
            let unit_dir = self.home.join(".config/systemd/user");
            if fs::create_dir_all(&unit_dir).is_ok() {
                let unit_body = SYSTEMD_UNIT_TEXT.replace("{script}", self_bin);
                if write_text_atomic(&unit_dir.join(SYSTEMD_UNIT), &unit_body).is_ok()
                    && self.systemctl_user(&["daemon-reload"]).is_some()
                    && self
                        .systemctl_user(&["enable", "--now", SYSTEMD_UNIT])
                        .is_some()
                {
                    return (
                        "systemd".to_string(),
                        format!(
                            "Watching your folders (systemd user unit {}).",
                            SYSTEMD_UNIT
                        ),
                        JsonVal::Null,
                    );
                }
            }
        }
        let log_file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(self.state_dir.join("watch.log"));
        if let Ok(log) = log_file {
            let log2 = log.try_clone().unwrap_or_else(|_| {
                OpenOptions::new()
                    .append(true)
                    .open(self.state_dir.join("watch.log"))
                    .unwrap()
            });
            let mut cmd = Command::new(self_bin);
            cmd.arg("watch-all")
                .stdin(Stdio::null())
                .stdout(Stdio::from(log))
                .stderr(Stdio::from(log2));
            unsafe {
                cmd.pre_exec(|| {
                    setsid();
                    Ok(())
                });
            }
            if let Ok(child) = cmd.spawn() {
                let pid = child.id() as i64;
                return (
                    "process".to_string(),
                    format!("Watching your folders (background process {}).", pid),
                    JsonVal::Int(pid),
                );
            }
        }
        (
            String::new(),
            "Auto is on, but no watcher could be started.".to_string(),
            JsonVal::Null,
        )
    }

    fn stop_supervisor(&self, state: &JsonVal) -> (String, String, JsonVal) {
        if self.systemctl_user(&["is-active", SYSTEMD_UNIT]).as_deref() == Some("active") {
            let _ = self.systemctl_user(&["disable", "--now", SYSTEMD_UNIT]);
            return (
                "systemd".to_string(),
                "Stopped watching (systemd unit disabled).".to_string(),
                JsonVal::Null,
            );
        }
        if let Some(pid) = state.get_i64("auto_pid") {
            if pid > 0 && unsafe { kill(pid as i32, 15) == 0 } {
                return (
                    "process".to_string(),
                    format!("Stopped watching (process {}).", pid),
                    JsonVal::Null,
                );
            }
        }
        (String::new(), "Auto is off.".to_string(), JsonVal::Null)
    }

    pub fn set_schedule(&self, mode: &str) -> JsonVal {
        let m = tidy(mode).to_ascii_lowercase();
        if !matches!(m.as_str(), "manual" | "login" | "daily") {
            return JsonVal::obj(vec![
                ("ok", JsonVal::Bool(false)),
                ("event", JsonVal::Str("schedule".to_string())),
                ("command", JsonVal::Str("schedule".to_string())),
                (
                    "error",
                    JsonVal::Str("schedule must be manual, login or daily".to_string()),
                ),
            ]);
        }
        let mut state = self.load_state();
        state.set("schedule", JsonVal::Str(m.clone()));
        self.save_state(&state);

        let self_bin = std::env::current_exe()
            .map(|p| p.to_string_lossy().into_owned())
            .unwrap_or_else(|_| {
                self.home
                    .join(".local/bin/jarvis-organize")
                    .to_string_lossy()
                    .into_owned()
            });
        let unit_dir = self.home.join(".config/systemd/user");
        let mut msg = "Schedule saved.".to_string();
        if fs::create_dir_all(&unit_dir).is_ok() {
            if m == "manual" {
                for u in SCHEDULE_UNITS {
                    let _ = fs::remove_file(unit_dir.join(u));
                }
                let _ = self.systemctl_user(&["daemon-reload"]);
                let _ = self.systemctl_user(&[
                    "disable",
                    "jarvis-organize-autorun.service",
                    "jarvis-organize-daily.timer",
                ]);
                msg = "Manual only.".to_string();
            } else if m == "login" {
                let _ = write_text_atomic(
                    &unit_dir.join("jarvis-organize-autorun.service"),
                    &AUTORUN_UNIT_TEXT.replace("{script}", &self_bin),
                );
                let _ = self.systemctl_user(&["daemon-reload"]);
                let _ = self.systemctl_user(&["enable", "jarvis-organize-autorun.service"]);
                msg = "Sorting runs once at login.".to_string();
            } else if m == "daily" {
                let _ = write_text_atomic(
                    &unit_dir.join("jarvis-organize-daily.service"),
                    &DAILY_UNIT_TEXT.replace("{script}", &self_bin),
                );
                let _ = write_text_atomic(
                    &unit_dir.join("jarvis-organize-daily.timer"),
                    DAILY_TIMER_TEXT,
                );
                let _ = self.systemctl_user(&["daemon-reload"]);
                let _ = self.systemctl_user(&["enable", "--now", "jarvis-organize-daily.timer"]);
                msg = "Sorting runs daily.".to_string();
            }
        }

        let mut res = self.status();
        res.set("event", JsonVal::Str("schedule".to_string()));
        res.set("command", JsonVal::Str("schedule".to_string()));
        res.set("schedule", JsonVal::Str(m));
        res.set("message", JsonVal::Str(msg));
        res
    }

    pub fn watch<F>(&self, folders: &[String], mut emit: F) -> JsonVal
    where
        F: FnMut(&JsonVal),
    {
        let mut roots = Vec::new();
        for f in folders {
            match self.refuse(f) {
                Ok(r) => roots.push(r),
                Err(reason) => {
                    emit(&JsonVal::obj(vec![
                        ("event", JsonVal::Str("watch".to_string())),
                        ("ok", JsonVal::Bool(false)),
                        ("folder", JsonVal::Str(tidy(f))),
                        ("error", JsonVal::Str(reason)),
                    ]));
                }
            }
        }
        if roots.is_empty() {
            return JsonVal::obj(vec![
                ("ok", JsonVal::Bool(false)),
                ("event", JsonVal::Str("watch".to_string())),
                ("command", JsonVal::Str("watch".to_string())),
                ("error", JsonVal::Str("no folder to watch".to_string())),
            ]);
        }

        emit(&JsonVal::obj(vec![
            ("event", JsonVal::Str("watch".to_string())),
            ("ok", JsonVal::Bool(true)),
            ("command", JsonVal::Str("watch".to_string())),
            (
                "folders",
                JsonVal::Arr(
                    roots
                        .iter()
                        .map(|r| JsonVal::Str(r.to_string_lossy().into_owned()))
                        .collect(),
                ),
            ),
            ("stable", JsonVal::Float(5.0)),
            ("interval", JsonVal::Float(2.0)),
        ]));

        let mut seen: HashMap<PathBuf, (u64, f64)> = HashMap::new();
        let mut initial: HashSet<PathBuf> = HashSet::new();
        let mut priming = true;

        loop {
            let state = self.load_state();
            let rules = self.load_rules(false);
            for root in &roots {
                for (path, skip) in self.collect_candidates(root, false, &rules) {
                    if skip.is_some() {
                        continue;
                    }
                    let Ok(meta) = fs::metadata(&path) else {
                        continue;
                    };
                    let size = meta.len();
                    let wall = self.now_secs();
                    let rec = seen.get(&path).copied();
                    if rec.is_none() && priming {
                        initial.insert(path.clone());
                        seen.insert(path, (size, wall));
                        continue;
                    }
                    if initial.contains(&path) {
                        if rec.map(|(s, _)| s == size).unwrap_or(true) {
                            continue;
                        }
                        initial.remove(&path);
                    }
                    match rec {
                        Some((prev_sz, since)) if prev_sz == size => {
                            if wall - since >= 5.0 {
                                let (dest_root, _) = self.destination_root(root, &state, "");
                                let (cat, how) = self.classify(&path, &rules);
                                let fname = path
                                    .file_name()
                                    .and_then(|s| s.to_str())
                                    .unwrap_or("file")
                                    .to_string();
                                match move_no_clobber(&path, &dest_root.join(&cat).join(&fname)) {
                                    Ok(used) => {
                                        emit(&JsonVal::obj(vec![
                                            ("event", JsonVal::Str("moved".to_string())),
                                            ("command", JsonVal::Str("watch".to_string())),
                                            (
                                                "folder",
                                                JsonVal::Str(root.to_string_lossy().into_owned()),
                                            ),
                                            ("name", JsonVal::Str(fname)),
                                            ("category", JsonVal::Str(cat)),
                                            ("target", JsonVal::Str(self.shorten(&used))),
                                            ("match", JsonVal::Str(how)),
                                        ]));
                                    }
                                    Err(err) => {
                                        emit(&JsonVal::obj(vec![
                                            ("event", JsonVal::Str("error".to_string())),
                                            ("command", JsonVal::Str("watch".to_string())),
                                            ("name", JsonVal::Str(fname)),
                                            ("reason", JsonVal::Str(err)),
                                        ]));
                                    }
                                }
                                seen.remove(&path);
                            }
                        }
                        _ => {
                            seen.insert(path, (size, wall));
                        }
                    }
                }
            }
            seen.retain(|k, _| k.exists());
            priming = false;
            thread::sleep(Duration::from_secs(2));
        }
    }
}

fn detect_mime(path: &Path) -> String {
    if let Some(bin) = which("file") {
        let res = run_cmd_timeout(
            &bin.to_string_lossy(),
            &["--brief", "--mime-type", "--", &path.to_string_lossy()],
            None,
            5_000,
        );
        if res.code == 0 {
            if let Some(first) = res.stdout.lines().next() {
                return first.trim().to_string();
            }
        }
    }
    String::new()
}

fn write_json_atomic(path: &Path, val: &JsonVal) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let tmp = path.with_file_name(format!(
        "{}.tmp",
        path.file_name().and_then(|s| s.to_str()).unwrap_or("data")
    ));
    let mut body = val.to_json_pretty();
    body.push('\n');
    let mut f = OpenOptions::new()
        .write(true)
        .create(true)
        .truncate(true)
        .mode(0o600)
        .open(&tmp)
        .map_err(|e| e.to_string())?;
    f.write_all(body.as_bytes()).map_err(|e| e.to_string())?;
    drop(f);
    fs::rename(&tmp, path).map_err(|e| e.to_string())?;
    let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o600));
    Ok(())
}

fn write_text_atomic(path: &Path, text: &str) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let tmp = path.with_file_name(format!(
        "{}.tmp",
        path.file_name().and_then(|s| s.to_str()).unwrap_or("unit")
    ));
    fs::write(&tmp, text.as_bytes()).map_err(|e| e.to_string())?;
    fs::rename(&tmp, path).map_err(|e| e.to_string())?;
    Ok(())
}

/// Convert UNIX epoch seconds to `("YYYYMMDD-HHMMSS", "YYYY-MM-DDTHH:MM:SSZ")` in UTC without external crates.
fn utc_stamps() -> (String, String) {
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);
    let days = secs.div_euclid(86_400);
    let rem = secs.rem_euclid(86_400);
    let hh = rem / 3600;
    let mm = (rem % 3600) / 60;
    let ss = rem % 60;

    // Howard Hinnant's civil_from_days algorithm
    let z = days + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = (z - era * 146_097) as u64;
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let mut y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    if m <= 2 {
        y += 1;
    }

    (
        format!("{:04}{:02}{:02}-{:02}{:02}{:02}", y, m, d, hh, mm, ss),
        format!("{:04}-{:02}-{:02}T{:02}:{:02}:{:02}Z", y, m, d, hh, mm, ss),
    )
}

pub fn print_table(summary: &JsonVal) {
    println!("PREVIEW  {}", summary.get_str("display").unwrap_or(""));
    println!(
        "         → {}\n",
        summary.get_str("destination").unwrap_or("inside")
    );
    let cats = summary
        .get("categories")
        .and_then(|v| v.as_arr())
        .unwrap_or(&[]);
    if cats.is_empty() {
        println!("  ALL CLEAR — nothing to sort.");
    } else {
        let width = cats
            .iter()
            .map(|c| c.get_str("name").unwrap_or("").len())
            .max()
            .unwrap_or(10)
            .max(10);
        println!(
            "  {:<width$}  {:>7}  {:>10}  {}",
            "CATEGORY",
            "FILES",
            "SIZE",
            "DESTINATION",
            width = width
        );
        println!("  {}", "-".repeat(width + 40));
        for c in cats {
            println!(
                "  {:<width$}  {:>7}  {:>10}  {}",
                c.get_str("name").unwrap_or(""),
                c.get_i64("count").unwrap_or(0),
                c.get_str("bytes_h").unwrap_or(""),
                c.get_str("destination").unwrap_or(""),
                width = width
            );
        }
        println!("  {}", "-".repeat(width + 40));
        println!(
            "  {:<width$}  {:>7}  {:>10}",
            "TOTAL",
            summary.get_i64("files").unwrap_or(0),
            summary.get_str("bytes_h").unwrap_or(""),
            width = width
        );
    }
    println!("\nDRY RUN — nothing was moved. Run without --dry-run to apply it.");
}

pub fn emit_line(val: &JsonVal) {
    let mut line = val.to_json_line();
    line.push('\n');
    let mut out = io::stdout().lock();
    let _ = out.write_all(line.as_bytes());
    let _ = out.flush();
}

pub fn run_cli(args: &[String]) -> i32 {
    let mut flags = Vec::new();
    let mut words = Vec::new();
    for a in args {
        if a.starts_with('-') {
            flags.push(a.as_str());
        } else {
            words.push(a.as_str());
        }
    }

    if flags.contains(&"-h") || flags.contains(&"--help") || words.first() == Some(&"help") {
        print_usage();
        return 0;
    }
    if words.is_empty() {
        print_usage();
        return 2;
    }

    let command = words[0];
    let dry_run = flags.contains(&"--dry-run");
    let org = Organizer::new();

    match command {
        "version" => {
            emit_line(&JsonVal::obj(vec![
                ("ok", JsonVal::Bool(true)),
                ("version", JsonVal::Str(VERSION.to_string())),
                ("protocol", JsonVal::Int(PROTOCOL)),
            ]));
            0
        }
        "status" => {
            emit_line(&org.status());
            0
        }
        "rules" => {
            let rules = org.load_rules(true);
            if flags.contains(&"--open") {
                if let Some(opener) = which("xdg-open").or_else(|| which("gio")) {
                    let mut cmd = Command::new(opener);
                    cmd.arg(&org.rules_path)
                        .stdin(Stdio::null())
                        .stdout(Stdio::null())
                        .stderr(Stdio::null());
                    unsafe {
                        cmd.pre_exec(|| {
                            setsid();
                            Ok(())
                        });
                    }
                    if cmd.spawn().is_ok() {
                        emit_line(&JsonVal::obj(vec![
                            ("ok", JsonVal::Bool(true)),
                            ("event", JsonVal::Str("rules".to_string())),
                            (
                                "path",
                                JsonVal::Str(org.rules_path.to_string_lossy().into_owned()),
                            ),
                            ("opened", JsonVal::Bool(true)),
                        ]));
                        return 0;
                    }
                }
                emit_line(&JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("rules".to_string())),
                    (
                        "path",
                        JsonVal::Str(org.rules_path.to_string_lossy().into_owned()),
                    ),
                    ("opened", JsonVal::Bool(false)),
                    ("error", JsonVal::Str("no xdg-open on PATH".to_string())),
                ]));
                1
            } else {
                emit_line(&JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(true)),
                    ("event", JsonVal::Str("rules".to_string())),
                    (
                        "path",
                        JsonVal::Str(org.rules_path.to_string_lossy().into_owned()),
                    ),
                    ("rules", rules.raw),
                ]));
                0
            }
        }
        "scan" => {
            if words.len() < 2 {
                emit_line(&JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("scan".to_string())),
                    ("error", JsonVal::Str("scan needs a folder".to_string())),
                ]));
                return 2;
            }
            emit_line(&org.scan(words[1], Some(200)));
            0
        }
        "run" => {
            if words.len() < 2 {
                emit_line(&JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("run".to_string())),
                    ("error", JsonVal::Str("run needs a folder".to_string())),
                ]));
                return 2;
            }
            if dry_run {
                let summary = org.scan(words[1], None);
                if summary.get_bool("ok") != Some(true) {
                    println!(
                        "Cannot scan {}: {}",
                        summary.get_str("folder").unwrap_or(""),
                        summary.get_str("error").unwrap_or("")
                    );
                    return 1;
                }
                print_table(&summary);
                return 0;
            }
            let res = org.run(words[1], emit_line);
            let ok = res.get_bool("ok") == Some(true);
            emit_line(&res);
            if ok { 0 } else { 1 }
        }
        "run-all" => {
            let state = org.load_state();
            let folders: Vec<String> = state
                .get("folders")
                .and_then(|v| v.as_arr())
                .map(|a| {
                    a.iter()
                        .filter_map(|v| v.as_str())
                        .map(|s| s.to_string())
                        .collect()
                })
                .unwrap_or_default();
            if dry_run {
                for f in &folders {
                    let s = org.scan(f, None);
                    if s.get_bool("ok") == Some(true) {
                        print_table(&s);
                    } else {
                        println!("Cannot scan: {}", s.get_str("error").unwrap_or(""));
                    }
                }
            } else {
                let mut runs = Vec::new();
                for f in &folders {
                    let r = org.run(f, emit_line);
                    runs.push(JsonVal::obj(vec![
                        (
                            "folder",
                            JsonVal::Str(r.get_str("folder").unwrap_or(f).to_string()),
                        ),
                        ("moved", JsonVal::Int(r.get_i64("moved").unwrap_or(0))),
                        ("ok", JsonVal::Bool(r.get_bool("ok") == Some(true))),
                    ]));
                }
                emit_line(&JsonVal::obj(vec![
                    ("event", JsonVal::Str("done".to_string())),
                    ("command", JsonVal::Str("run-all".to_string())),
                    ("ok", JsonVal::Bool(true)),
                    ("runs", JsonVal::Arr(runs)),
                ]));
            }
            0
        }
        "undo" => {
            emit_line(&org.undo());
            0
        }
        "watch" | "watch-all" => {
            let folders: Vec<String> = if command == "watch-all" {
                let state = org.load_state();
                if state.get_bool("auto") != Some(true) {
                    emit_line(&JsonVal::obj(vec![
                        ("ok", JsonVal::Bool(false)),
                        ("event", JsonVal::Str("watch".to_string())),
                        ("command", JsonVal::Str("watch-all".to_string())),
                        ("error", JsonVal::Str("auto is off".to_string())),
                    ]));
                    return 0;
                }
                state
                    .get("folders")
                    .and_then(|v| v.as_arr())
                    .map(|a| {
                        a.iter()
                            .filter_map(|v| v.as_str())
                            .map(|s| s.to_string())
                            .collect()
                    })
                    .unwrap_or_default()
            } else {
                words[1..].iter().map(|s| (*s).to_string()).collect()
            };
            if folders.is_empty() {
                emit_line(&JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("watch".to_string())),
                    (
                        "error",
                        JsonVal::Str("watch needs at least one folder".to_string()),
                    ),
                ]));
                return 2;
            }
            let _ = org.watch(&folders, emit_line);
            0
        }
        "auto" => {
            let val = words.get(1).copied().unwrap_or("toggle");
            if !matches!(val, "on" | "off" | "toggle") {
                emit_line(&JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("auto".to_string())),
                    (
                        "error",
                        JsonVal::Str("auto must be on, off or toggle".to_string()),
                    ),
                ]));
                return 2;
            }
            emit_line(&org.set_auto(val));
            0
        }
        "schedule" => {
            let mode = words.get(1).copied().unwrap_or("manual");
            emit_line(&org.set_schedule(mode));
            0
        }
        "folders" => {
            let act = words.get(1).copied().unwrap_or("list");
            let tgt = words.get(2).copied().unwrap_or("");
            emit_line(&org.set_folders(act, tgt));
            0
        }
        "config" => {
            if words.len() < 4 || words[1] != "set" {
                emit_line(&JsonVal::obj(vec![
                    ("ok", JsonVal::Bool(false)),
                    ("event", JsonVal::Str("config".to_string())),
                    (
                        "error",
                        JsonVal::Str("config set <key> <value>".to_string()),
                    ),
                ]));
                return 2;
            }
            emit_line(&org.set_config(words[2], words[3]));
            0
        }
        "init" => {
            org.ensure_dirs();
            let _ = org.load_rules(true);
            let st = org.load_state();
            org.save_state(&st);
            emit_line(&org.status());
            0
        }
        _ => {
            eprintln!("Unknown command: {}", command);
            print_usage();
            2
        }
    }
}

fn print_usage() {
    println!(
        "jarvis-organize — sort a folder into category folders, safely, with undo.\n\n\
         \x20   jarvis-organize scan <folder>            JSON: what *would* move where\n\
         \x20   jarvis-organize run <folder>             do it, JSON progress + summary\n\
         \x20   jarvis-organize run <folder> --dry-run   the same plan as a readable table\n\
         \x20   jarvis-organize undo                     revert the last run\n\
         \x20   jarvis-organize watch <folders...>       auto mode: sort finished downloads\n\
         \x20   jarvis-organize status                   JSON: folders, auto, schedule, undo\n\
         \x20   jarvis-organize folders list|add|remove|set <path>\n\
         \x20   jarvis-organize config set <key> <value>\n\
         \x20   jarvis-organize auto on|off|toggle\n\
         \x20   jarvis-organize schedule manual|login|daily\n\
         \x20   jarvis-organize rules [--open]           print (or open) the rules file"
    );
}

extern "C" {
    fn kill(pid: i32, sig: i32) -> i32;
    fn setsid() -> i32;
}
