//! XDG data roots, executable lookup, URI encoding, and desktop-entry argv helpers.

use std::fmt::Write as _;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

pub fn home_dir() -> PathBuf {
    if let Ok(h) = std::env::var("HOME") {
        if !h.is_empty() {
            return PathBuf::from(h);
        }
    }
    PathBuf::from("/tmp")
}

pub fn data_dirs() -> Vec<PathBuf> {
    let home_base = home_dir();
    let xdg_data_home = std::env::var("XDG_DATA_HOME")
        .ok()
        .filter(|s| !s.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| home_base.join(".local/share"));

    let mut dirs = vec![xdg_data_home.clone()];
    let raw_dirs = std::env::var("XDG_DATA_DIRS")
        .ok()
        .unwrap_or_else(|| "/usr/local/share:/usr/share".to_string());
    for part in raw_dirs.split(':') {
        if !part.is_empty() {
            let p = PathBuf::from(part);
            if !dirs.contains(&p) {
                dirs.push(p);
            }
        }
    }

    let user = std::env::var("USER").unwrap_or_default();
    let extras = [
        xdg_data_home.join("flatpak/exports/share"),
        PathBuf::from("/var/lib/flatpak/exports/share"),
        PathBuf::from("/var/lib/snapd/desktop"),
        home_base.join(".nix-profile/share"),
        if !user.is_empty() {
            PathBuf::from("/etc/profiles/per-user").join(&user).join("share")
        } else {
            PathBuf::from("/nonexistent")
        },
        PathBuf::from("/run/current-system/sw/share"),
        home_base.join(".guix-profile/share"),
        home_base.join(".local/state/nix/profile/share"),
    ];
    for p in extras {
        if !dirs.contains(&p) && p.is_dir() {
            dirs.push(p);
        }
    }
    dirs
}

pub fn is_executable_file(path: &Path) -> bool {
    if let Ok(meta) = std::fs::metadata(path) {
        meta.is_file() && (meta.permissions().mode() & 0o111 != 0)
    } else {
        false
    }
}

pub fn which(cmd: &str) -> Option<PathBuf> {
    if cmd.is_empty() {
        return None;
    }
    if cmd.contains('/') {
        let p = PathBuf::from(cmd);
        return if is_executable_file(&p) { Some(p) } else { None };
    }
    let path_var = std::env::var("PATH").unwrap_or_else(|_| "/usr/bin:/bin".to_string());
    for dir in path_var.split(':') {
        if dir.is_empty() {
            continue;
        }
        let candidate = Path::new(dir).join(cmd);
        if is_executable_file(&candidate) {
            return Some(candidate);
        }
    }
    None
}

pub fn executable(value: &str) -> bool {
    !value.is_empty() && which(value).is_some()
}

pub fn norm(value: &str) -> String {
    let lower = value.to_lowercase();
    lower.strip_suffix(".desktop").unwrap_or(&lower).to_string()
}

pub fn default_config_path() -> PathBuf {
    let cfg = std::env::var("XDG_CONFIG_HOME")
        .ok()
        .filter(|s| !s.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".config"));
    cfg.join("sphere-hub").join("state.json")
}

pub fn socket_path(name: &str) -> Option<PathBuf> {
    let sig = std::env::var("HYPRLAND_INSTANCE_SIGNATURE").unwrap_or_default();
    let runtime = std::env::var("XDG_RUNTIME_DIR").unwrap_or_default();
    if sig.is_empty() || runtime.is_empty() || sig.contains('/') {
        return None;
    }
    Some(PathBuf::from(runtime).join("hypr").join(sig).join(name))
}

pub fn file_uri(path: &Path) -> String {
    let resolved = std::fs::canonicalize(path).unwrap_or_else(|_| path.to_path_buf());
    let bytes = resolved.to_string_lossy();
    let mut out = String::with_capacity(bytes.len() + 12);
    out.push_str("file://");
    for b in bytes.as_bytes() {
        match *b {
            b'A'..=b'Z'
            | b'a'..=b'z'
            | b'0'..=b'9'
            | b'-'
            | b'.'
            | b'_'
            | b'~'
            | b'/'
            | b':'
            | b'@' => out.push(*b as char),
            other => {
                let _ = write!(out, "%{:02X}", other);
            }
        }
    }
    out
}

/// Minimal POSIX shell word splitter matching `shlex.split` for `.desktop` `Exec=` lines.
pub fn shlex_split(input: &str) -> Result<Vec<String>, String> {
    let mut tokens = Vec::new();
    let mut current = String::new();
    let mut in_token = false;
    let mut chars = input.chars().peekable();

    while let Some(ch) = chars.next() {
        match ch {
            ' ' | '\t' | '\r' | '\n' => {
                if in_token {
                    tokens.push(std::mem::take(&mut current));
                    in_token = false;
                }
            }
            '\'' => {
                in_token = true;
                let mut closed = false;
                for c in chars.by_ref() {
                    if c == '\'' {
                        closed = true;
                        break;
                    }
                    current.push(c);
                }
                if !closed {
                    return Err("No closing single quote".to_string());
                }
            }
            '"' => {
                in_token = true;
                let mut closed = false;
                while let Some(c) = chars.next() {
                    if c == '"' {
                        closed = true;
                        break;
                    }
                    if c == '\\' {
                        if let Some(&next) = chars.peek() {
                            if matches!(next, '"' | '\\' | '$' | '`' | '\n') {
                                chars.next();
                                if next != '\n' {
                                    current.push(next);
                                }
                                continue;
                            }
                        }
                    }
                    current.push(c);
                }
                if !closed {
                    return Err("No closing double quote".to_string());
                }
            }
            '\\' => {
                in_token = true;
                if let Some(next) = chars.next() {
                    if next != '\n' {
                        current.push(next);
                    }
                }
            }
            other => {
                in_token = true;
                current.push(other);
            }
        }
    }
    if in_token {
        tokens.push(current);
    }
    Ok(tokens)
}

pub fn shlex_join(argv: &[String]) -> String {
    argv.iter()
        .map(|arg| {
            if !arg.is_empty()
                && arg.bytes().all(|b| {
                    b.is_ascii_alphanumeric()
                        || matches!(b, b'-' | b'_' | b'.' | b'/' | b':' | b'+' | b'=' | b'@')
                })
            {
                arg.clone()
            } else {
                format!("'{}'", arg.replace('\'', "'\"'\"'"))
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

pub fn expand_exec(argv: &[String], name: &str, path: &str) -> Result<Vec<String>, String> {
    let mut out = Vec::new();
    for token in argv {
        if matches!(
            token.as_str(),
            "%f" | "%F" | "%u" | "%U" | "%d" | "%D" | "%n" | "%N" | "%v" | "%m" | "%i"
        ) {
            continue;
        }
        let replaced = token
            .replace("%%", "\0")
            .replace("%c", name)
            .replace("%k", path);
        let bytes = replaced.as_bytes();
        for i in 0..bytes.len().saturating_sub(1) {
            if bytes[i] == b'%' && bytes[i + 1].is_ascii_alphabetic() {
                return Err(
                    "This desktop entry needs gio to expand its launch arguments.".to_string(),
                );
            }
        }
        out.push(replaced.replace('\0', "%"));
    }
    if out.is_empty() {
        return Err(
            "Install gio / GLib desktop utilities to launch this DBus-only desktop entry."
                .to_string(),
        );
    }
    Ok(out)
}
