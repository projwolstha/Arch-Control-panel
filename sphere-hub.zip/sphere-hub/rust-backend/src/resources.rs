//! System resources for the orb panel: RAM, swap, mounted filesystems, and top RSS processes.
//!
//! Memory optimization: reads `/proc/[pid]/statm` and `/proc/[pid]/comm` directly in-process
//! without forking `ps -eo rss=,comm=` on every 2.5s tick.

use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::Path;
use std::sync::{Mutex, OnceLock};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use crate::constants::run_cmd_timeout;
use crate::json::JsonVal;

const CACHE_MEM_MS: u128 = 1000;
const CACHE_DISK_MS: u128 = 30_000;
const CACHE_PROC_MS: u128 = 1000;
const GIB: f64 = 1024.0 * 1024.0 * 1024.0;
const BEDROCK_PREFIX: &str = "/bedrock/";
const ALWAYS_SHOW: &[&str] = &["/", "/home", "/boot", "/boot/efi", "/var", "/usr"];

const EXCLUDED_FSTYPES: &[&str] = &[
    "tmpfs",
    "devtmpfs",
    "squashfs",
    "overlay",
    "ramfs",
    "efivarfs",
    "proc",
    "sysfs",
    "cgroup",
    "cgroup2",
    "devpts",
    "fusectl",
    "mqueue",
    "debugfs",
    "tracefs",
    "securityfs",
    "pstore",
    "bpf",
    "autofs",
    "binfmt_misc",
    "configfs",
    "hugetlbfs",
    "nsfs",
    "rpc_pipefs",
    "selinuxfs",
    "fuse.gvfsd-fuse",
    "fuse.etcfs",
    "tmp",
    "dev",
];

struct ResCache {
    mem: Option<(Instant, Option<(JsonVal, JsonVal)>)>,
    disk: Option<(Instant, Vec<JsonVal>)>,
    proc_list: Option<(Instant, Vec<JsonVal>)>,
}

fn cache() -> &'static Mutex<ResCache> {
    static CACHE: OnceLock<Mutex<ResCache>> = OnceLock::new();
    CACHE.get_or_init(|| {
        Mutex::new(ResCache {
            mem: None,
            disk: None,
            proc_list: None,
        })
    })
}

fn round1(v: f64) -> f64 {
    (v * 10.0).round() / 10.0
}

fn round2(v: f64) -> f64 {
    (v * 100.0).round() / 100.0
}

fn gib_from_kib(kib: u64) -> f64 {
    round1(kib as f64 / 1_048_576.0)
}

fn pct(used: u64, total: u64) -> Option<i64> {
    if total == 0 {
        return None;
    }
    Some(((100.0 * used as f64 / total as f64).round() as i64).clamp(0, 100))
}

fn meminfo_path() -> String {
    std::env::var("SPHERE_MEMINFO")
        .ok()
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| "/proc/meminfo".to_string())
}

pub fn memory() -> Option<(JsonVal, JsonVal)> {
    if let Ok(guard) = cache().lock() {
        if let Some((at, ref val)) = guard.mem {
            if at.elapsed().as_millis() < CACHE_MEM_MS {
                return val.clone();
            }
        }
    }

    let raw = fs::read_to_string(meminfo_path()).ok();
    let mut fields: HashMap<String, u64> = HashMap::with_capacity(24);
    if let Some(text) = raw {
        for line in text.lines() {
            if let Some((k, rest)) = line.split_once(':') {
                if let Some(num_tok) = rest.split_whitespace().next() {
                    if let Ok(n) = num_tok.parse::<u64>() {
                        fields.insert(k.trim().to_string(), n);
                    }
                }
            }
        }
    }

    let total = fields.get("MemTotal").copied().unwrap_or(0);
    if total == 0 {
        if let Ok(mut guard) = cache().lock() {
            guard.mem = Some((Instant::now(), None));
        }
        return None;
    }

    let mem_free = fields.get("MemFree").copied().unwrap_or(0);
    let cached = fields.get("Cached").copied().unwrap_or(0);
    let sreclaimable = fields.get("SReclaimable").copied().unwrap_or(0);
    let buffers = fields.get("Buffers").copied().unwrap_or(0);
    let available = fields
        .get("MemAvailable")
        .copied()
        .unwrap_or(mem_free + cached + buffers);
    let used = total.saturating_sub(available);
    let cached_kib = cached + sreclaimable;

    let swap_total = fields.get("SwapTotal").copied().unwrap_or(0);
    let swap_free = fields.get("SwapFree").copied().unwrap_or(0);
    let swap_used = swap_total.saturating_sub(swap_free);
    let swap_json = if swap_total > 0 {
        JsonVal::obj(vec![
            ("total", JsonVal::Float(gib_from_kib(swap_total))),
            ("used", JsonVal::Float(gib_from_kib(swap_used))),
            ("free", JsonVal::Float(gib_from_kib(swap_free))),
            ("percent", pct(swap_used, swap_total).into()),
        ])
    } else {
        JsonVal::Null
    };

    let ram_json = JsonVal::obj(vec![
        ("total", JsonVal::Float(gib_from_kib(total))),
        ("used", JsonVal::Float(gib_from_kib(used))),
        ("available", JsonVal::Float(gib_from_kib(available))),
        ("free", JsonVal::Float(gib_from_kib(mem_free))),
        ("cached", JsonVal::Float(gib_from_kib(cached_kib))),
        ("buffers", JsonVal::Float(gib_from_kib(buffers))),
        ("percent", pct(used, total).into()),
        ("totalBytes", JsonVal::Int((total * 1024) as i64)),
        ("usedBytes", JsonVal::Int((used * 1024) as i64)),
    ]);

    let out = Some((ram_json, swap_json));
    if let Ok(mut guard) = cache().lock() {
        guard.mem = Some((Instant::now(), out.clone()));
    }
    out
}

#[derive(Clone)]
struct DfRow {
    source: String,
    fstype: String,
    target: String,
    size: u64,
    used: u64,
    avail: u64,
    percent: Option<i64>,
    shared: bool,
}

pub fn storage() -> Vec<JsonVal> {
    if let Ok(guard) = cache().lock() {
        if let Some((at, ref val)) = guard.disk {
            if at.elapsed().as_millis() < CACHE_DISK_MS {
                return val.clone();
            }
        }
    }

    let res = run_cmd_timeout(
        "df",
        &["-B1", "--output=source,fstype,size,used,avail,pcent,target"],
        None,
        6000,
    );

    let mut rows: Vec<DfRow> = Vec::new();
    if res.code == 0 {
        for line in res.stdout.lines().skip(1) {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() < 7 {
                continue;
            }
            let source = parts[0];
            let fstype = parts[1];
            let (Ok(size), Ok(used), Ok(avail)) = (
                parts[2].parse::<u64>(),
                parts[3].parse::<u64>(),
                parts[4].parse::<u64>(),
            ) else {
                continue;
            };
            let joined_target = parts[6..].join(" ");
            let target = if joined_target.is_empty() {
                "/".to_string()
            } else {
                joined_target
            };
            if EXCLUDED_FSTYPES.contains(&fstype) {
                continue;
            }
            if source.starts_with("/dev/loop") || source == "none" {
                continue;
            }
            if target == "/bedrock" || target.starts_with(BEDROCK_PREFIX) {
                continue;
            }
            if size == 0 {
                continue;
            }
            rows.push(DfRow {
                source: source.to_string(),
                fstype: fstype.to_string(),
                target,
                size,
                used,
                avail,
                percent: pct(used, used.saturating_add(avail)),
                shared: false,
            });
        }
    }

    let mut kept: Vec<DfRow> = Vec::new();
    let mut seen: HashSet<(String, u64, u64)> = HashSet::new();
    for row in rows {
        let key = (row.source.clone(), row.size, row.used);
        if !ALWAYS_SHOW.contains(&row.target.as_str()) && seen.contains(&key) {
            continue;
        }
        seen.insert(key);
        kept.push(row);
    }

    if let Some(root_idx) = kept.iter().position(|r| r.target == "/") {
        let root_key = (
            kept[root_idx].source.clone(),
            kept[root_idx].size,
            kept[root_idx].used,
        );
        for (i, row) in kept.iter_mut().enumerate() {
            if i != root_idx && (row.source.clone(), row.size, row.used) == root_key {
                row.shared = true;
            }
        }
    }

    kept.sort_by_key(|row| {
        let mut exact = ALWAYS_SHOW
            .iter()
            .position(|&t| t == row.target)
            .unwrap_or(ALWAYS_SHOW.len());
        if row.target.starts_with("/home/") {
            exact = ALWAYS_SHOW.len() + 1;
        }
        (exact, std::cmp::Reverse(row.size))
    });

    let disks: Vec<JsonVal> = kept
        .into_iter()
        .map(|row| {
            JsonVal::obj(vec![
                ("target", JsonVal::Str(row.target)),
                ("source", JsonVal::Str(row.source)),
                ("fstype", JsonVal::Str(row.fstype)),
                ("total", JsonVal::Float(round1(row.size as f64 / GIB))),
                ("used", JsonVal::Float(round1(row.used as f64 / GIB))),
                ("free", JsonVal::Float(round1(row.avail as f64 / GIB))),
                ("percent", row.percent.into()),
                ("shared", JsonVal::Bool(row.shared)),
            ])
        })
        .collect();

    if let Ok(mut guard) = cache().lock() {
        guard.disk = Some((Instant::now(), disks.clone()));
    }
    disks
}

pub fn processes(limit: usize) -> Vec<JsonVal> {
    if let Ok(guard) = cache().lock() {
        if let Some((at, ref val)) = guard.proc_list {
            if at.elapsed().as_millis() < CACHE_PROC_MS {
                return val.clone();
            }
        }
    }

    let page_size = {
        let sc = unsafe { sysconf(30) }; // _SC_PAGESIZE = 30 on Linux
        if sc > 0 { sc as u64 } else { 4096 }
    };

    let mut top: Vec<(u64, String)> = Vec::with_capacity(limit + 1);
    if let Ok(rd) = fs::read_dir(Path::new("/proc")) {
        for entry in rd.flatten() {
            let fname = entry.file_name();
            let Some(s) = fname.to_str() else {
                continue;
            };
            if !s.bytes().all(|b| b.is_ascii_digit()) {
                continue;
            }
            let pid_dir = entry.path();
            let Ok(statm) = fs::read_to_string(pid_dir.join("statm")) else {
                continue;
            };
            let Some(res_pages_str) = statm.split_whitespace().nth(1) else {
                continue;
            };
            let Ok(res_pages) = res_pages_str.parse::<u64>() else {
                continue;
            };
            if res_pages == 0 {
                continue;
            }
            let rss_kib = (res_pages * page_size) / 1024;
            if rss_kib == 0 {
                continue;
            }
            if top.len() == limit && rss_kib <= top.last().map(|(r, _)| *r).unwrap_or(0) {
                continue;
            }
            let Ok(comm_raw) = fs::read_to_string(pid_dir.join("comm")) else {
                continue;
            };
            let comm = comm_raw.trim();
            if comm.is_empty() || matches!(comm, "ps" | "df") {
                continue;
            }
            top.push((rss_kib, comm.to_string()));
            top.sort_by(|a, b| b.0.cmp(&a.0));
            if top.len() > limit {
                top.truncate(limit);
            }
        }
    }

    let out: Vec<JsonVal> = top
        .into_iter()
        .map(|(rss_kib, name)| {
            JsonVal::obj(vec![
                ("name", JsonVal::Str(name)),
                ("rss", JsonVal::Float(round2(rss_kib as f64 / 1_048_576.0))),
            ])
        })
        .collect();

    if let Ok(mut guard) = cache().lock() {
        guard.proc_list = Some((Instant::now(), out.clone()));
    }
    out
}

pub fn status(include_processes: bool) -> JsonVal {
    let mem_state = memory();
    let disks = storage();
    let now_secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);

    let (disk_percent, disk_target) = if let Some(root) =
        disks.iter().find(|d| d.get_str("target") == Some("/"))
    {
        (root.get_i64("percent"), "/".to_string())
    } else if !disks.is_empty() {
        let fullest = disks
            .iter()
            .max_by_key(|d| d.get_i64("percent").unwrap_or(0))
            .unwrap();
        (
            fullest.get_i64("percent"),
            fullest.get_str("target").unwrap_or("").to_string(),
        )
    } else {
        (None, String::new())
    };

    if mem_state.is_none() && disks.is_empty() {
        return JsonVal::obj(vec![
            ("available", JsonVal::Bool(false)),
            ("now", JsonVal::Int(now_secs)),
            (
                "error",
                JsonVal::Str("Could not read /proc/meminfo or df.".to_string()),
            ),
            ("ram", JsonVal::Null),
            ("swap", JsonVal::Null),
            ("disks", JsonVal::Arr(Vec::new())),
            ("diskPercent", JsonVal::Null),
            ("processes", JsonVal::Arr(Vec::new())),
        ]);
    }

    let (ram, swap, err_msg) = match mem_state {
        Some((r, s)) => (r, s, String::new()),
        None => (
            JsonVal::Null,
            JsonVal::Null,
            "Memory information is unavailable.".to_string(),
        ),
    };

    JsonVal::obj(vec![
        ("available", JsonVal::Bool(true)),
        ("now", JsonVal::Int(now_secs)),
        ("error", JsonVal::Str(err_msg)),
        ("ram", ram),
        ("swap", swap),
        ("disks", JsonVal::Arr(disks)),
        ("diskPercent", disk_percent.into()),
        ("diskTarget", JsonVal::Str(disk_target)),
        (
            "processes",
            JsonVal::Arr(if include_processes {
                processes(3)
            } else {
                Vec::new()
            }),
        ),
    ])
}

extern "C" {
    fn sysconf(name: i32) -> isize;
}
