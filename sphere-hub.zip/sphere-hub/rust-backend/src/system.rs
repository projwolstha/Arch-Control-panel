//! Host probes: os-release, package managers, terminals, and reviewable install plans.

use std::collections::HashMap;
use std::fs;
use std::io::{self, BufRead, Write};
use std::os::unix::io::AsRawFd;
use std::path::Path;
use std::process::Command;

use crate::constants::{recipe_by_id, valid_package_name, MANAGERS, TERMINALS};
use crate::json::JsonVal;
use crate::pathutil::{default_config_path, executable, shlex_join, shlex_split, which};

pub const DISTRO_MARKERS: &[(&str, &str)] = &[
    ("/etc/arch-release", "pacman"),
    ("/etc/debian_version", "apt"),
    ("/etc/fedora-release", "dnf"),
    ("/etc/alpine-release", "apk"),
];

pub fn os_release() -> HashMap<String, String> {
    let mut map = HashMap::new();
    if let Ok(text) = fs::read_to_string("/etc/os-release") {
        for line in text.lines() {
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }
            if let Some((k, v)) = trimmed.split_once('=') {
                let val = match shlex_split(v) {
                    Ok(mut parts) if !parts.is_empty() => parts.remove(0),
                    _ => v.trim_matches('"').trim_matches('\'').to_string(),
                };
                map.insert(k.to_string(), val);
            }
        }
    }
    map
}

pub fn preferred_manager(release: &HashMap<String, String>, available: &[String]) -> String {
    for (marker, manager) in DISTRO_MARKERS {
        if Path::new(marker).exists() {
            if available.iter().any(|m| m == manager) {
                return (*manager).to_string();
            }
            return available.first().cloned().unwrap_or_default();
        }
    }
    let ident = format!(
        "{} {}",
        release.get("ID").map(|s| s.as_str()).unwrap_or(""),
        release.get("ID_LIKE").map(|s| s.as_str()).unwrap_or("")
    );
    let mut preferred = if ident.contains("arch") {
        "pacman"
    } else if ident.contains("debian") || ident.contains("ubuntu") {
        "apt"
    } else if ident.contains("fedora") || ident.contains("rhel") {
        "dnf"
    } else if ident.contains("suse") {
        "zypper"
    } else if ident.contains("alpine") {
        "apk"
    } else {
        ""
    };
    if !available.iter().any(|m| m == preferred) {
        preferred = available.first().map(|s| s.as_str()).unwrap_or("");
    }
    preferred.to_string()
}

pub fn detect_terminal() -> Vec<String> {
    if let Ok(term_env) = std::env::var("TERMINAL") {
        if !term_env.is_empty() {
            if let Ok(cmd) = shlex_split(&term_env) {
                if let Some(first) = cmd.first() {
                    let base = Path::new(first)
                        .file_name()
                        .and_then(|s| s.to_str())
                        .unwrap_or("");
                    if TERMINALS.contains(&base) && executable(first) {
                        return cmd;
                    }
                }
            }
        }
    }
    for term in TERMINALS {
        if which(term).is_some() {
            return vec![(*term).to_string()];
        }
    }
    Vec::new()
}

pub fn terminal_argv(command: &[String], title: &str) -> Result<Vec<String>, String> {
    let mut term = detect_terminal();
    if term.is_empty() {
        return Err(
            "No supported terminal was found. Open your own terminal and use the displayed command."
                .to_string(),
        );
    }
    let kind = Path::new(&term[0])
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("")
        .to_string();
    match kind.as_str() {
        "kitty" => {
            term.push("--title".to_string());
            term.push(title.to_string());
        }
        "ghostty" => {
            term.push(format!("--title={}", title));
            term.push("-e".to_string());
        }
        "foot" => {
            term.push(format!("--title={}", title));
        }
        "alacritty" => {
            term.push("--title".to_string());
            term.push(title.to_string());
            term.push("-e".to_string());
        }
        "wezterm" => {
            term.push("start".to_string());
            term.push("--".to_string());
        }
        "konsole" => {
            term.push("--separate".to_string());
            term.push("-e".to_string());
        }
        "gnome-terminal" => {
            term.push(format!("--title={}", title));
            term.push("--".to_string());
        }
        "xfce4-terminal" => {
            term.push(format!("--title={}", title));
            term.push("--execute".to_string());
        }
        _ => {
            term.push("-T".to_string());
            term.push(title.to_string());
            term.push("-e".to_string());
        }
    }
    term.extend(command.iter().cloned());
    Ok(term)
}

pub struct SystemInfo {
    pub distribution: String,
    pub distribution_id: String,
    pub managers: Vec<String>,
    pub preferred_manager: String,
    pub terminal: String,
    pub hyprland_session: bool,
    pub config_path: String,
}

impl SystemInfo {
    pub fn gather() -> Self {
        let release = os_release();
        let available: Vec<String> = MANAGERS
            .iter()
            .filter(|m| which(m).is_some())
            .map(|m| (*m).to_string())
            .collect();
        let preferred = preferred_manager(&release, &available);
        let term = detect_terminal();
        let hypr = !std::env::var("HYPRLAND_INSTANCE_SIGNATURE")
            .unwrap_or_default()
            .is_empty();
        Self {
            distribution: release
                .get("PRETTY_NAME")
                .cloned()
                .unwrap_or_else(|| "Linux".to_string()),
            distribution_id: release.get("ID").cloned().unwrap_or_default(),
            managers: available,
            preferred_manager: preferred,
            terminal: term.into_iter().next().unwrap_or_default(),
            hyprland_session: hypr,
            config_path: default_config_path().to_string_lossy().into_owned(),
        }
    }

    pub fn to_json(&self) -> JsonVal {
        JsonVal::obj(vec![
            ("distribution", JsonVal::Str(self.distribution.clone())),
            ("distributionId", JsonVal::Str(self.distribution_id.clone())),
            (
                "managers",
                JsonVal::Arr(
                    self.managers
                        .iter()
                        .map(|m| JsonVal::Str(m.clone()))
                        .collect(),
                ),
            ),
            (
                "preferredManager",
                JsonVal::Str(self.preferred_manager.clone()),
            ),
            ("terminal", JsonVal::Str(self.terminal.clone())),
            ("hyprlandSession", JsonVal::Bool(self.hyprland_session)),
            ("configPath", JsonVal::Str(self.config_path.clone())),
        ])
    }
}

pub struct InstallPlan {
    pub manager: String,
    pub package: String,
    pub argv: Vec<String>,
    pub command: String,
    pub terminal_available: bool,
    pub terminal: String,
    pub note: String,
}

impl InstallPlan {
    pub fn to_json(&self, with_type: bool) -> JsonVal {
        let mut fields = Vec::with_capacity(8);
        if with_type {
            fields.push(("type", JsonVal::Str("installPlan".to_string())));
        }
        fields.push(("manager", JsonVal::Str(self.manager.clone())));
        fields.push(("package", JsonVal::Str(self.package.clone())));
        fields.push((
            "argv",
            JsonVal::Arr(self.argv.iter().map(|a| JsonVal::Str(a.clone())).collect()),
        ));
        fields.push(("command", JsonVal::Str(self.command.clone())));
        fields.push(("terminalAvailable", JsonVal::Bool(self.terminal_available)));
        fields.push(("terminal", JsonVal::Str(self.terminal.clone())));
        fields.push(("note", JsonVal::Str(self.note.clone())));
        JsonVal::obj(fields)
    }
}

pub fn install_plan(
    recipe_id: Option<&str>,
    package: Option<&str>,
    manager: Option<&str>,
) -> Result<InstallPlan, String> {
    let info = SystemInfo::gather();
    let mgr = manager
        .filter(|s| !s.is_empty())
        .unwrap_or(info.preferred_manager.as_str())
        .to_string();
    if !info.managers.iter().any(|m| m == &mgr) || !MANAGERS.contains(&mgr.as_str()) {
        return Err(
            "Select an available package manager. No installation command was run.".to_string(),
        );
    }

    let pkg = if let Some(rid) = recipe_id.filter(|s| !s.is_empty()) {
        let recipe = recipe_by_id(rid).ok_or_else(|| "Unknown application recipe.".to_string())?;
        let mut mapped = recipe.package_for(&mgr).map(|s| s.to_string());
        if mgr == "apt"
            && rid == "firefox"
            && matches!(
                info.distribution_id.as_str(),
                "ubuntu" | "linuxmint" | "pop" | "neon"
            )
        {
            mapped = Some("firefox".to_string());
        }
        mapped.ok_or_else(|| {
            format!(
                "No verified package mapping for this app with {}. Try another available manager, or enter a package name you have checked. No repository will be added automatically.",
                mgr
            )
        })?
    } else {
        package.unwrap_or("").to_string()
    };

    if !valid_package_name(&pkg) {
        return Err(
            "Use a single package name (letters, numbers, +, ., _, :, or -). URLs, paths, flags and shell commands are not accepted."
                .to_string(),
        );
    }

    let base: Vec<String> = match mgr.as_str() {
        "pacman" => vec![
            "pacman".into(),
            "-S".into(),
            "--needed".into(),
            pkg.clone(),
        ],
        "apt" => vec!["apt".into(), "install".into(), pkg.clone()],
        "dnf" => vec!["dnf".into(), "install".into(), pkg.clone()],
        "zypper" => vec!["zypper".into(), "install".into(), pkg.clone()],
        "apk" => vec!["apk".into(), "add".into(), pkg.clone()],
        "flatpak" => vec![
            "flatpak".into(),
            "install".into(),
            "--user".into(),
            "flathub".into(),
            pkg.clone(),
        ],
        _ => unreachable!(),
    };
    let argv = if mgr == "flatpak" {
        base
    } else {
        let mut v = vec!["sudo".to_string()];
        v.extend(base);
        v
    };
    let command = shlex_join(&argv);
    Ok(InstallPlan {
        manager: mgr,
        package: pkg,
        argv,
        command,
        terminal_available: !info.terminal.is_empty(),
        terminal: info.terminal,
        note: "You must confirm again inside the terminal. Your package manager may ask for your password. No -y flags or repository setup are used.".to_string(),
    })
}

pub fn installer_cli(manager: &str, package: &str) -> i32 {
    let plan = match install_plan(None, Some(package), Some(manager)) {
        Ok(p) => p,
        Err(err) => {
            println!("Sphere: {}", err);
            return 2;
        }
    };
    println!("\nSPHERE / install an application\n");
    println!("Command:\n  {}\n", plan.command);
    println!("No repositories are added, and nothing has been installed yet.");
    println!("The package manager may request your password and confirmation.\n");

    let is_tty = unsafe { isatty(io::stdin().as_raw_fd()) } == 1;
    if !is_tty {
        println!("Refusing non-interactive installation. Open this action in a terminal.");
        return 2;
    }

    print!("Type INSTALL to run this command, or press Enter to cancel: ");
    let _ = io::stdout().flush();
    let mut answer = String::new();
    if io::stdin().lock().read_line(&mut answer).is_err() {
        println!("\nCancelled.");
        return 130;
    }
    if answer.trim_end_matches(&['\r', '\n'][..]) != "INSTALL" {
        println!("Cancelled. No installation was attempted.");
        return 0;
    }

    let status = match Command::new(&plan.argv[0]).args(&plan.argv[1..]).status() {
        Ok(s) => s.code().unwrap_or(1),
        Err(err) => {
            println!("Could not run the package manager: {}", err);
            return 2;
        }
    };
    if status == 0 {
        println!(
            "\nPackage manager exited successfully. Use Refresh apps in Sphere, then choose/launch the app."
        );
    } else {
        println!(
            "\nThe package manager did not complete successfully. Review its output above; Sphere has not marked the app installed."
        );
    }
    print!("\nPress Enter to close this terminal.");
    let _ = io::stdout().flush();
    let mut dummy = String::new();
    let _ = io::stdin().lock().read_line(&mut dummy);
    status
}

extern "C" {
    fn isatty(fd: i32) -> i32;
}
