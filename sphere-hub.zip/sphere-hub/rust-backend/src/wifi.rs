//! Wi-Fi listing and connection control through NetworkManager's `nmcli`.

use std::collections::{HashMap, HashSet};
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::os::unix::fs::OpenOptionsExt;
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Condvar, Mutex, OnceLock};
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use crate::constants::{cli_environment, run_cmd_timeout, spawn_small, CmdResult};
use crate::json::JsonVal;
use crate::pathutil::{is_executable_file, which};

const TIMEOUT_MS: u64 = 25_000;
const SCAN_TIMEOUT_MS: u64 = 25_000;
const CONNECT_TIMEOUT_MS: u64 = 60_000;
const MAX_SSID_BYTES: usize = 32;
const MAX_DETAIL: usize = 240;

const CLI_FALLBACKS: &[&str] = &[
    "/usr/bin/nmcli",
    "/bin/nmcli",
    "/usr/local/bin/nmcli",
    "/usr/sbin/nmcli",
    "/sbin/nmcli",
];

const FRIENDLY: &[(&str, &str)] = &[
    (
        "NetworkManager is not running",
        "NetworkManager is not running. Start it, then press Scan again.",
    ),
    (
        "Could not create NMClient object",
        "NetworkManager is not reachable. Start it, then press Scan again.",
    ),
    ("No Wi-Fi device found", "No Wi-Fi adapter was found on this system."),
    (
        "not authorized",
        "NetworkManager refused the change for this user (PolicyKit).",
    ),
    (
        "Secrets were required",
        "The saved password was rejected. Choose the network again and type the password.",
    ),
    (
        "no network with SSID",
        "That network is no longer in range. Press Scan and try again.",
    ),
    (
        "Connection activation failed",
        "NetworkManager could not activate this connection.",
    ),
    (
        "Device or resource busy",
        "The Wi-Fi adapter is busy (another connection is being set up).",
    ),
];

#[derive(Clone, Debug)]
pub struct WifiError {
    pub message: String,
    pub detail: String,
}

impl WifiError {
    pub fn new(msg: impl Into<String>, detail: impl Into<String>) -> Self {
        let d: String = detail.into();
        Self {
            message: msg.into(),
            detail: d.chars().take(MAX_DETAIL).collect(),
        }
    }
}

pub fn cli_path() -> Option<String> {
    if let Some(p) = which("nmcli") {
        return Some(p.to_string_lossy().into_owned());
    }
    for cand in CLI_FALLBACKS {
        if is_executable_file(Path::new(cand)) {
            return Some((*cand).to_string());
        }
    }
    None
}

pub fn available() -> bool {
    cli_path().is_some()
}

fn run_nmcli(args: &[&str], timeout_ms: u64) -> Result<CmdResult, WifiError> {
    let Some(cli) = cli_path() else {
        return Err(WifiError::new(
            "NetworkManager (nmcli) is not installed, so Wi-Fi cannot be controlled from Sphere.",
            "",
        ));
    };
    let env = cli_environment();
    let res = run_cmd_timeout(&cli, args, Some(&env), timeout_ms);
    if let Some(err) = res.spawn_error {
        return Err(WifiError::new(
            format!("nmcli could not be started: {} ({})", err, cli),
            "",
        ));
    }
    if res.timed_out {
        let detail = if !res.stdout.trim().is_empty() {
            res.stdout.trim()
        } else {
            res.stderr.trim()
        };
        return Err(WifiError::new(
            format!(
                "nmcli {} did not answer in {}s.",
                args.join(" "),
                timeout_ms / 1000
            ),
            detail,
        ));
    }
    Ok(res)
}

fn first_detail(res: &CmdResult) -> String {
    for line in res.stdout.lines().chain(res.stderr.lines()) {
        let t = line.trim();
        if !t.is_empty() {
            return t.chars().take(MAX_DETAIL).collect();
        }
    }
    String::new()
}

fn combined_message(res: &CmdResult) -> String {
    let out: Vec<&str> = res
        .stdout
        .lines()
        .map(|l| l.trim())
        .filter(|l| !l.is_empty())
        .collect();
    if !out.is_empty() {
        return out.join("\n");
    }
    res.stderr
        .lines()
        .map(|l| l.trim())
        .filter(|l| !l.is_empty())
        .collect::<Vec<_>>()
        .join("\n")
}

fn humanize(text: &str, fallback: &str) -> String {
    let trimmed = text.trim();
    let lower = trimmed.to_ascii_lowercase();
    for (needle, friendly) in FRIENDLY {
        if lower.contains(&needle.to_ascii_lowercase()) {
            return (*friendly).to_string();
        }
    }
    if !trimmed.is_empty() {
        trimmed.to_string()
    } else {
        fallback.to_string()
    }
}

fn reply(res: CmdResult, action: &str) -> Result<String, WifiError> {
    if res.code == 0 {
        return Ok(res.stdout);
    }
    let detail: String = combined_message(&res)
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
        .chars()
        .take(300)
        .collect();
    if detail.is_empty() {
        return Err(WifiError::new(format!("nmcli could not {}.", action), ""));
    }
    let friendly = humanize(&detail, "");
    if friendly == detail {
        return Err(WifiError::new(
            format!("nmcli could not {}: {}", action, detail),
            detail,
        ));
    }
    Err(WifiError::new(friendly, detail))
}

/// Split one `nmcli -t` line on unescaped colons, unescaping `\:` and `\\`.
pub fn split_terse(line: &str) -> Vec<String> {
    let mut fields = Vec::new();
    let mut cur = String::new();
    let mut chars = line.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '\\' {
            if let Some(next) = chars.next() {
                cur.push(next);
            }
            continue;
        }
        if ch == ':' {
            fields.push(std::mem::take(&mut cur));
        } else {
            cur.push(ch);
        }
    }
    fields.push(cur);
    fields
}

pub fn check_ssid(value: Option<&str>) -> Result<String, WifiError> {
    let Some(s) = value.filter(|v| !v.is_empty()) else {
        return Err(WifiError::new("Choose a Wi-Fi network first.", ""));
    };
    if s.chars().any(|c| (c as u32) < 32 || (c as u32) == 127) {
        return Err(WifiError::new(
            "That network name contains control characters; it was not used.",
            "",
        ));
    }
    if s.starts_with('-') {
        return Err(WifiError::new(
            "That network name would be read as an option by nmcli; it was not used.",
            "",
        ));
    }
    if s.len() > MAX_SSID_BYTES {
        return Err(WifiError::new(
            "A Wi-Fi network name is at most 32 bytes long.",
            "",
        ));
    }
    Ok(s.to_string())
}

pub fn check_passphrase(value: Option<&str>) -> Result<Option<String>, WifiError> {
    let Some(s) = value.filter(|v| !v.is_empty()) else {
        return Ok(None);
    };
    if s.chars().any(|c| (c as u32) < 32 || (c as u32) == 127) {
        return Err(WifiError::new(
            "That passphrase contains control characters; it was not used.",
            "",
        ));
    }
    if s.len() == 64 && s.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Ok(Some(s.to_string()));
    }
    let char_len = s.chars().count();
    if !(8..=63).contains(&char_len) {
        return Err(WifiError::new(
            "A WPA passphrase is 8 to 63 characters (or 64 hexadecimal digits).",
            "",
        ));
    }
    Ok(Some(s.to_string()))
}

pub fn radio_on() -> Option<bool> {
    let res = run_nmcli(&["-t", "radio", "wifi"], 10_000).ok()?;
    if res.code != 0 {
        return None;
    }
    let text = res.stdout.trim().to_ascii_lowercase();
    if text.starts_with("enabled") || text == "on" {
        Some(true)
    } else if text.starts_with("disabled") || text == "off" {
        Some(false)
    } else {
        None
    }
}

pub fn set_radio_sync(enabled: bool) -> Result<Option<bool>, WifiError> {
    let res = run_nmcli(
        &["radio", "wifi", if enabled { "on" } else { "off" }],
        15_000,
    )?;
    reply(res, "switch the Wi-Fi radio")?;
    Ok(radio_on())
}

fn network_manager_running() -> (&'static str, String) {
    let res = match run_nmcli(&["-t", "-f", "RUNNING", "general", "status"], 10_000) {
        Ok(r) => r,
        Err(e) => return ("unknown", e.message),
    };
    let said = res.stdout.trim().to_ascii_lowercase();
    if res.code == 0 {
        if matches!(said.as_str(), "running" | "yes" | "true") || said.starts_with("running") {
            return ("running", String::new());
        }
        if matches!(said.as_str(), "not running" | "no" | "false" | "stopped")
            || said.contains("not running")
        {
            return ("stopped", "NetworkManager is not running".to_string());
        }
    }
    let detail = first_detail(&res);
    let lower = detail.to_ascii_lowercase();
    if lower.contains("could not create nmclient") || lower.contains("not running") {
        return ("stopped", detail);
    }
    ("unknown", detail)
}

fn profiles() -> HashSet<String> {
    let Ok(res) = run_nmcli(&["-t", "-f", "NAME,TYPE", "connection", "show"], TIMEOUT_MS) else {
        return HashSet::new();
    };
    let Ok(text) = reply(res, "list saved connections") else {
        return HashSet::new();
    };
    let mut out = HashSet::new();
    for line in text.lines().filter(|l| !l.trim().is_empty()) {
        let f = split_terse(line);
        if f.len() >= 2 && matches!(f[1].as_str(), "802-11-wireless" | "wifi") {
            out.insert(f[0].clone());
        }
    }
    out
}

#[derive(Clone, Debug)]
pub struct NetRow {
    ssid: String,
    signal: i64,
    in_use: bool,
    saved: bool,
    label: String,
    secure: bool,
    wep: bool,
    enterprise: bool,
    sae: bool,
}

impl NetRow {
    fn to_json(&self) -> JsonVal {
        JsonVal::obj(vec![
            ("ssid", JsonVal::Str(self.ssid.clone())),
            ("signal", JsonVal::Int(self.signal)),
            ("inUse", JsonVal::Bool(self.in_use)),
            ("saved", JsonVal::Bool(self.saved)),
            ("label", JsonVal::Str(self.label.clone())),
            ("secure", JsonVal::Bool(self.secure)),
            ("wep", JsonVal::Bool(self.wep)),
            ("enterprise", JsonVal::Bool(self.enterprise)),
            ("sae", JsonVal::Bool(self.sae)),
        ])
    }
}

fn security_flags(sec: &str) -> (String, bool, bool, bool, bool) {
    let t = sec.trim();
    let label = if t.is_empty() || t == "--" {
        String::new()
    } else {
        t.to_string()
    };
    let upper = label.to_ascii_uppercase();
    let secure = !label.is_empty();
    let wep = upper.contains("WEP") && !upper.contains("WPA");
    let enterprise = upper.contains("802.1X");
    let sae = upper.contains("WPA3") || upper.contains("SAE");
    (label, secure, wep, enterprise, sae)
}

fn parse_networks(text: &str, saved: &HashSet<String>) -> Vec<NetRow> {
    let mut found: HashMap<String, NetRow> = HashMap::new();
    for line in text.lines().filter(|l| !l.trim().is_empty()) {
        let f = split_terse(line);
        if f.len() < 4 {
            continue;
        }
        let ssid = f[1].trim_matches('\0').trim().to_string();
        if ssid.is_empty() {
            continue;
        }
        let quality = f[2]
            .trim()
            .parse::<f64>()
            .map(|v| (v as i64).clamp(0, 100))
            .unwrap_or(0);
        let in_use = f[0].trim() == "*";
        let (label, secure, wep, enterprise, sae) = security_flags(&f[3]);
        let row = NetRow {
            saved: saved.contains(&ssid),
            ssid: ssid.clone(),
            signal: quality,
            in_use,
            label,
            secure,
            wep,
            enterprise,
            sae,
        };
        let replace = match found.get(&ssid) {
            None => true,
            Some(prev) => (row.in_use, row.signal) > (prev.in_use, prev.signal),
        };
        if replace {
            found.insert(ssid, row);
        }
    }
    let mut rows: Vec<NetRow> = found.into_values().collect();
    rows.sort_by(|a, b| {
        (!a.in_use, !a.saved, -a.signal, a.ssid.to_lowercase()).cmp(&(
            !b.in_use,
            !b.saved,
            -b.signal,
            b.ssid.to_lowercase(),
        ))
    });
    rows
}

fn list_networks(rescan: bool) -> Result<Vec<NetRow>, WifiError> {
    let args: &[&str] = if rescan {
        &[
            "-t",
            "-f",
            "IN-USE,SSID,SIGNAL,SECURITY",
            "device",
            "wifi",
            "list",
            "--rescan",
            "yes",
        ]
    } else {
        &[
            "-t",
            "-f",
            "IN-USE,SSID,SIGNAL,SECURITY",
            "device",
            "wifi",
            "list",
        ]
    };
    let res = run_nmcli(args, if rescan { SCAN_TIMEOUT_MS } else { TIMEOUT_MS })?;
    let has_lines = res.stdout.lines().any(|l| !l.trim().is_empty());
    if res.code != 0 && !has_lines {
        let detail = first_detail(&res);
        let mut friendly = humanize(&detail, "");
        if friendly.is_empty() {
            friendly = "nmcli could not list Wi-Fi networks.".to_string();
        } else if !detail.is_empty() && friendly == detail {
            friendly = format!("nmcli could not list Wi-Fi networks: {}", detail);
        }
        return Err(WifiError::new(friendly, detail));
    }
    let saved = profiles();
    Ok(parse_networks(&res.stdout, &saved))
}

fn device_states() -> Result<HashMap<String, String>, WifiError> {
    let res = run_nmcli(&["-t", "-f", "DEVICE,TYPE,STATE", "device", "status"], 12_000)?;
    let text = reply(res, "read device states")?;
    let mut map = HashMap::new();
    for line in text.lines().filter(|l| !l.trim().is_empty()) {
        let f = split_terse(line);
        if f.len() >= 3 && f[1] == "wifi" {
            map.insert(f[0].clone(), f[2].trim().to_ascii_lowercase());
        }
    }
    Ok(map)
}

fn active_connections() -> Result<Vec<(String, String)>, WifiError> {
    let res = run_nmcli(
        &["-t", "-f", "NAME,TYPE,STATE", "connection", "show", "--active"],
        12_000,
    )?;
    let text = reply(res, "read active connections")?;
    let mut out = Vec::new();
    for line in text.lines().filter(|l| !l.trim().is_empty()) {
        let f = split_terse(line);
        if f.len() >= 3 && matches!(f[1].as_str(), "802-11-wireless" | "wifi") {
            out.push((f[0].clone(), f[2].trim().to_ascii_lowercase()));
        }
    }
    Ok(out)
}

fn is_dev_connected(st: &str) -> bool {
    matches!(st, "connected" | "activated")
}

fn is_dev_connecting(st: &str) -> bool {
    matches!(
        st,
        "connecting"
            | "prepare"
            | "config"
            | "need-auth"
            | "ip-config"
            | "ip-check"
            | "secondaries"
            | "activating"
            | "deactivating"
    )
}

fn visual_state(
    avail: bool,
    radio: Option<bool>,
    devices: &HashMap<String, String>,
    connections: &[(String, String)],
) -> (&'static str, &'static str) {
    if !avail {
        return ("disconnected", "no-networkmanager");
    }
    if radio == Some(false) {
        return ("disconnected", "radio-off");
    }
    let has_pending = connections.iter().any(|(_, st)| st == "activating");
    let any_connected = devices.values().any(|s| is_dev_connected(s));
    let any_failed = devices.values().any(|s| s == "failed");
    let any_connecting = devices.values().any(|s| is_dev_connecting(s));
    if any_connected {
        if has_pending {
            return ("connecting", "auth-pending");
        }
        return ("connected", "connected");
    }
    if any_failed {
        return ("disconnected", "failed");
    }
    if any_connecting || has_pending {
        return (
            "connecting",
            if has_pending {
                "auth-pending"
            } else {
                "activating"
            },
        );
    }
    if devices.is_empty() {
        return ("disconnected", "no-device");
    }
    if devices.values().any(|s| s == "unmanaged") {
        return ("disconnected", "unmanaged");
    }
    ("disconnected", "disconnected")
}

struct ReadFacts {
    state: &'static str,
    reason: &'static str,
    radio_on: bool,
    devices: HashMap<String, String>,
    connections: Vec<(String, String)>,
    nm: &'static str,
    detail: String,
}

fn read_state() -> ReadFacts {
    if !available() {
        return ReadFacts {
            state: "disconnected",
            reason: "no-networkmanager",
            radio_on: false,
            devices: HashMap::new(),
            connections: Vec::new(),
            nm: "unknown",
            detail: "NetworkManager (nmcli) is not installed".to_string(),
        };
    }
    let (nm_state, mut nm_detail) = network_manager_running();
    let on = radio_on();
    let devices = match device_states() {
        Ok(d) => d,
        Err(e) => {
            if nm_detail.is_empty() {
                nm_detail = e.message;
            }
            HashMap::new()
        }
    };
    let connections = active_connections().unwrap_or_default();
    let (state, reason) = visual_state(true, on, &devices, &connections);
    ReadFacts {
        state,
        reason,
        radio_on: on.unwrap_or(false),
        devices,
        connections,
        nm: nm_state,
        detail: nm_detail,
    }
}

fn active_ssid(devices: &HashMap<String, String>) -> String {
    if !devices.values().any(|s| is_dev_connected(s)) {
        return String::new();
    }
    let Ok(res) = run_nmcli(&["-t", "-f", "GENERAL.CONNECTION", "device", "show"], 10_000) else {
        return String::new();
    };
    let Ok(text) = reply(res, "read the active connection") else {
        return String::new();
    };
    for line in text.lines().filter(|l| !l.trim().is_empty()) {
        let f = split_terse(line);
        if f.len() >= 2
            && f[0].starts_with("GENERAL.CONNECTION")
            && !f[1].is_empty()
            && f[1] != "--"
        {
            return f[1].clone();
        }
    }
    String::new()
}

fn problem_sentence(facts: &ReadFacts) -> String {
    if !available() {
        return "NetworkManager (nmcli) is not installed, so Wi-Fi cannot be controlled from Sphere. On Arch: sudo pacman -S networkmanager".to_string();
    }
    let detail = facts.detail.trim();
    let suffix = if detail.is_empty() {
        String::new()
    } else {
        format!(" — nmcli said: {}", detail)
    };
    if facts.nm == "stopped" {
        return format!(
            "NetworkManager is not running. Start it with: sudo systemctl start NetworkManager{}",
            suffix
        );
    }
    if !facts.radio_on {
        return format!(
            "Wi-Fi is switched off. Press Wi-Fi on to enable the radio (nmcli radio wifi on){}",
            suffix
        );
    }
    if facts.devices.is_empty() {
        return format!(
            "No Wi-Fi device was found. Check that the adapter is present (lspci -nn | grep -i network) and not blocked by rfkill.{}",
            suffix
        );
    }
    let has_unmanaged_or_unavail = facts
        .devices
        .values()
        .any(|s| matches!(s.as_str(), "unmanaged" | "unavailable"));
    let any_active_or_conn = facts
        .devices
        .values()
        .any(|s| is_dev_connected(s) || is_dev_connecting(s));
    if has_unmanaged_or_unavail && !any_active_or_conn {
        return format!(
            "The Wi-Fi device is not managed by NetworkManager, so it cannot scan. Check /etc/NetworkManager/conf.d for an [unmanaged-devices] rule (and that another tool such as netctl or iwd is not driving it).{}",
            suffix
        );
    }
    if facts.nm == "unknown" && !detail.is_empty() {
        return format!("NetworkManager could not be queried: {}", detail);
    }
    String::new()
}

static SCAN_ACTIVE: AtomicBool = AtomicBool::new(false);
static SCAN_ABANDONED: AtomicBool = AtomicBool::new(false);

pub fn scanning() -> bool {
    SCAN_ACTIVE.load(Ordering::SeqCst)
}

pub fn stop_scan() {
    SCAN_ABANDONED.store(true, Ordering::SeqCst);
}

pub fn status(rescan: bool, include_networks: bool, override_rows: Option<Vec<NetRow>>) -> JsonVal {
    if !available() {
        let msg = "NetworkManager (nmcli) is not installed, so Wi-Fi cannot be controlled from Sphere. On Arch: sudo pacman -S networkmanager";
        return JsonVal::obj(vec![
            ("available", JsonVal::Bool(false)),
            ("radioOn", JsonVal::Bool(false)),
            ("active", JsonVal::Null),
            ("networks", JsonVal::Arr(Vec::new())),
            ("state", JsonVal::Str("disconnected".to_string())),
            ("reason", JsonVal::Str("no-networkmanager".to_string())),
            ("devices", JsonVal::Obj(Vec::new())),
            ("connections", JsonVal::Arr(Vec::new())),
            ("nm", JsonVal::Str("unknown".to_string())),
            ("scanning", JsonVal::Bool(scanning())),
            ("problem", JsonVal::Str(msg.to_string())),
            ("error", JsonVal::Str(msg.to_string())),
            ("detail", JsonVal::Str(String::new())),
        ]);
    }

    let facts = read_state();
    let mut listed: Vec<NetRow> = Vec::new();
    let mut active_json = JsonVal::Null;

    if include_networks && facts.radio_on {
        match override_rows {
            Some(rows) => listed = rows,
            None => match list_networks(rescan) {
                Ok(rows) => listed = rows,
                Err(err) => {
                    return JsonVal::obj(vec![
                        ("available", JsonVal::Bool(true)),
                        ("radioOn", JsonVal::Bool(radio_on().unwrap_or(false))),
                        ("active", JsonVal::Null),
                        ("networks", JsonVal::Arr(Vec::new())),
                        ("state", JsonVal::Str("disconnected".to_string())),
                        ("reason", JsonVal::Str("error".to_string())),
                        ("devices", JsonVal::Obj(Vec::new())),
                        ("connections", JsonVal::Arr(Vec::new())),
                        ("nm", JsonVal::Str("unknown".to_string())),
                        ("scanning", JsonVal::Bool(scanning())),
                        ("problem", JsonVal::Str(err.message.clone())),
                        ("error", JsonVal::Str(err.message)),
                        ("detail", JsonVal::Str(err.detail)),
                    ]);
                }
            },
        }
        if let Some(active_row) = listed.iter().find(|r| r.in_use) {
            active_json = active_row.to_json();
        }
    } else if facts.state == "connected" {
        let ssid = active_ssid(&facts.devices);
        if !ssid.is_empty() {
            active_json = JsonVal::obj(vec![
                ("ssid", JsonVal::Str(ssid)),
                ("inUse", JsonVal::Bool(true)),
            ]);
        }
    }

    let prob = problem_sentence(&facts);
    let dev_obj = JsonVal::Obj(
        facts
            .devices
            .into_iter()
            .map(|(k, v)| (k, JsonVal::Str(v)))
            .collect(),
    );
    let conn_arr = JsonVal::Arr(
        facts
            .connections
            .into_iter()
            .map(|(name, st)| {
                JsonVal::obj(vec![
                    ("name", JsonVal::Str(name)),
                    ("state", JsonVal::Str(st)),
                ])
            })
            .collect(),
    );

    JsonVal::obj(vec![
        ("available", JsonVal::Bool(true)),
        ("radioOn", JsonVal::Bool(facts.radio_on)),
        ("active", active_json),
        (
            "networks",
            JsonVal::Arr(listed.into_iter().map(|r| r.to_json()).collect()),
        ),
        ("state", JsonVal::Str(facts.state.to_string())),
        ("reason", JsonVal::Str(facts.reason.to_string())),
        ("devices", dev_obj),
        ("connections", conn_arr),
        ("nm", JsonVal::Str(facts.nm.to_string())),
        ("scanning", JsonVal::Bool(scanning())),
        ("problem", JsonVal::Str(prob)),
        ("error", JsonVal::Str(String::new())),
        ("detail", JsonVal::Str(facts.detail)),
    ])
}

fn activate_with_secret(ssid: &str, passphrase: &str) -> Result<String, WifiError> {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let tmp = std::env::temp_dir().join(format!(
        "sphere-wifi-{}-{}.passwd",
        std::process::id(),
        nanos
    ));
    let mut f = OpenOptions::new()
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(&tmp)
        .map_err(|e| WifiError::new(format!("Could not create passwd-file: {}", e), ""))?;
    let line = format!("802-11-wireless-security.psk:{}\n", passphrase);
    let write_res = f.write_all(line.as_bytes());
    drop(f);
    if let Err(e) = write_res {
        let _ = fs::remove_file(&tmp);
        return Err(WifiError::new(format!("Could not write passwd-file: {}", e), ""));
    }

    let tmp_str = tmp.to_string_lossy().into_owned();
    let res = run_nmcli(
        &[
            "--wait",
            "30",
            "connection",
            "up",
            "id",
            ssid,
            "passwd-file",
            &tmp_str,
        ],
        CONNECT_TIMEOUT_MS,
    );
    let _ = fs::remove_file(&tmp);
    reply(res?, &format!("activate {}", ssid))
}

pub fn connect_sync(
    ssid: Option<&str>,
    passphrase: Option<&str>,
    security: &str,
) -> Result<String, WifiError> {
    let ssid = check_ssid(ssid)?;
    let pass = check_passphrase(passphrase)?;
    let (_lbl, _sec, wep, enterprise, sae) = security_flags(security);
    if enterprise {
        return Err(WifiError::new(
            "Enterprise (802.1X) networks need certificates and an identity; join this one with your system tools.",
            "",
        ));
    }
    if wep {
        return Err(WifiError::new(
            "WEP networks are not supported here; join this one with your system tools.",
            "",
        ));
    }
    let Some(secret) = pass else {
        let res = run_nmcli(
            &["--wait", "30", "device", "wifi", "connect", &ssid],
            CONNECT_TIMEOUT_MS,
        )?;
        reply(res, &format!("connect to {}", ssid))?;
        return Ok(ssid);
    };
    let key_mgmt = if sae { "sae" } else { "wpa-psk" };
    if !profiles().contains(&ssid) {
        let add = run_nmcli(
            &[
                "connection",
                "add",
                "type",
                "wifi",
                "con-name",
                &ssid,
                "ssid",
                &ssid,
                "wifi-sec.key-mgmt",
                key_mgmt,
            ],
            TIMEOUT_MS,
        )?;
        reply(add, "create a connection profile")?;
    }
    if activate_with_secret(&ssid, &secret).is_err() {
        let mod_res = run_nmcli(
            &[
                "connection",
                "modify",
                "id",
                &ssid,
                "wifi-sec.key-mgmt",
                key_mgmt,
            ],
            TIMEOUT_MS,
        )?;
        reply(mod_res, &format!("update {}", ssid))?;
        activate_with_secret(&ssid, &secret)?;
    }
    Ok(ssid)
}

pub fn disconnect_sync() -> Result<String, WifiError> {
    let devs = device_states()?;
    let Some((dev, _)) = devs.into_iter().find(|(_, st)| is_dev_connected(st)) else {
        return Err(WifiError::new("No Wi-Fi interface is currently connected.", ""));
    };
    let res = run_nmcli(&["device", "disconnect", &dev], TIMEOUT_MS)?;
    reply(res, &format!("disconnect {}", dev))?;
    Ok(dev)
}

pub struct Monitor {
    state: Mutex<Option<JsonVal>>,
    wake: (Mutex<bool>, Condvar),
    stop_flag: AtomicBool,
    panel_open: AtomicBool,
    started: AtomicBool,
    on_change: Box<dyn Fn(JsonVal) + Send + Sync>,
}

impl Monitor {
    pub fn new<F>(on_change: F) -> Arc<Self>
    where
        F: Fn(JsonVal) + Send + Sync + 'static,
    {
        Arc::new(Self {
            state: Mutex::new(None),
            wake: (Mutex::new(false), Condvar::new()),
            stop_flag: AtomicBool::new(false),
            panel_open: AtomicBool::new(false),
            started: AtomicBool::new(false),
            on_change: Box::new(on_change),
        })
    }

    pub fn current(&self) -> JsonVal {
        if let Ok(guard) = self.state.lock() {
            if let Some(ref s) = *guard {
                return s.clone();
            }
        }
        self.wake();
        JsonVal::obj(vec![
            ("available", JsonVal::Bool(available())),
            ("radioOn", JsonVal::Bool(false)),
            ("active", JsonVal::Null),
            ("networks", JsonVal::Arr(Vec::new())),
            ("state", JsonVal::Str("disconnected".to_string())),
            ("reason", JsonVal::Str(String::new())),
            ("devices", JsonVal::Obj(Vec::new())),
            ("connections", JsonVal::Arr(Vec::new())),
            ("nm", JsonVal::Str("unknown".to_string())),
            ("scanning", JsonVal::Bool(scanning())),
            ("problem", JsonVal::Str(String::new())),
            ("error", JsonVal::Str(String::new())),
            ("detail", JsonVal::Str(String::new())),
        ])
    }

    pub fn set_open(&self, is_open: bool) {
        self.panel_open.store(is_open, Ordering::SeqCst);
        self.wake();
    }

    pub fn refresh(&self) {
        self.wake();
    }

    pub fn wake(&self) {
        let (lock, cvar) = &self.wake;
        if let Ok(mut w) = lock.lock() {
            *w = true;
            cvar.notify_all();
        }
    }

    fn publish(&self, next: JsonVal) {
        let changed = if let Ok(mut guard) = self.state.lock() {
            let diff = guard.as_ref() != Some(&next);
            *guard = Some(next.clone());
            diff
        } else {
            false
        };
        if changed {
            (self.on_change)(next);
        }
    }

    pub fn start(self: &Arc<Self>) {
        if self.started.swap(true, Ordering::SeqCst) {
            return;
        }
        let me = Arc::clone(self);
        spawn_small("sphere-wifi-mon", move || {
            while !me.stop_flag.load(Ordering::SeqCst) {
                let open = me.panel_open.load(Ordering::SeqCst);
                let next = status(false, open, None);
                me.publish(next);
                let wait = if me.panel_open.load(Ordering::SeqCst) {
                    Duration::from_secs(2)
                } else {
                    Duration::from_secs(20)
                };
                let (lock, cvar) = &me.wake;
                if let Ok(mut w) = lock.lock() {
                    if !*w && !me.stop_flag.load(Ordering::SeqCst) {
                        let (mut nw, _) = cvar.wait_timeout(w, wait).unwrap_or_else(|e| e.into_inner());
                        *nw = false;
                    } else {
                        *w = false;
                    }
                }
            }
        });
    }

    pub fn stop(&self) {
        self.stop_flag.store(true, Ordering::SeqCst);
        stop_scan();
        self.wake();
    }

    pub fn scan(self: &Arc<Self>) {
        static SCAN_MTX: OnceLock<Mutex<()>> = OnceLock::new();
        let _guard = SCAN_MTX.get_or_init(|| Mutex::new(())).lock();
        if SCAN_ACTIVE.swap(true, Ordering::SeqCst) {
            return;
        }
        SCAN_ABANDONED.store(false, Ordering::SeqCst);
        let mut cur = self.current();
        cur.set("scanning", JsonVal::Bool(true));
        cur.set("problem", JsonVal::Str(String::new()));
        self.publish(cur);

        let me = Arc::clone(self);
        spawn_small("sphere-wifi-scan", move || {
            let mut retried = false;
            let mut detail = String::new();
            let listed = match list_networks(true) {
                Ok(first) if !first.is_empty() => first,
                Ok(_) => {
                    thread::sleep(Duration::from_secs(2));
                    retried = true;
                    match list_networks(true) {
                        Ok(second) => second,
                        Err(e) => {
                            detail = if e.detail.is_empty() {
                                e.message
                            } else {
                                format!("{}: {}", e.message, e.detail)
                            };
                            Vec::new()
                        }
                    }
                }
                Err(e) => {
                    detail = if e.detail.is_empty() {
                        e.message
                    } else {
                        format!("{}: {}", e.message, e.detail)
                    };
                    Vec::new()
                }
            };
            SCAN_ACTIVE.store(false, Ordering::SeqCst);
            if SCAN_ABANDONED.load(Ordering::SeqCst) {
                return;
            }
            let empty = listed.is_empty();
            let mut st = status(false, true, Some(listed));
            if empty && !detail.is_empty() {
                let mut prob = humanize(&detail, &detail);
                if prob == detail {
                    prob = format!("The scan failed: {}", detail);
                }
                st.set("problem", JsonVal::Str(prob));
                st.set(
                    "detail",
                    JsonVal::Str(detail.chars().take(MAX_DETAIL).collect()),
                );
            } else if empty {
                st.set("problem", JsonVal::Str(problem_sentence(&read_state())));
            }
            st.set("scanning", JsonVal::Bool(false));
            st.set("retried", JsonVal::Bool(retried));
            me.publish(st);
        });
    }

    pub fn set_radio(self: &Arc<Self>, enabled: bool) {
        let me = Arc::clone(self);
        spawn_small("sphere-wifi-radio", move || {
            if let Err(err) = set_radio_sync(enabled) {
                let mut st = me.current();
                st.set("problem", JsonVal::Str(err.message.clone()));
                st.set("error", JsonVal::Str(err.message));
                st.set("detail", JsonVal::Str(err.detail));
                me.publish(st);
            }
            me.wake();
        });
    }

    pub fn connect(
        self: &Arc<Self>,
        ssid: Option<String>,
        passphrase: Option<String>,
        security: String,
    ) {
        let me = Arc::clone(self);
        spawn_small("sphere-wifi-conn", move || {
            if let Err(err) = connect_sync(ssid.as_deref(), passphrase.as_deref(), &security) {
                let mut st = me.current();
                st.set("problem", JsonVal::Str(err.message.clone()));
                st.set("error", JsonVal::Str(err.message));
                st.set("detail", JsonVal::Str(err.detail));
                me.publish(st);
            }
            me.wake();
        });
    }

    pub fn disconnect(self: &Arc<Self>) {
        let me = Arc::clone(self);
        spawn_small("sphere-wifi-disc", move || {
            if let Err(err) = disconnect_sync() {
                let mut st = me.current();
                st.set("problem", JsonVal::Str(err.message.clone()));
                st.set("error", JsonVal::Str(err.message));
                st.set("detail", JsonVal::Str(err.detail));
                me.publish(st);
            }
            me.wake();
        });
    }
}
