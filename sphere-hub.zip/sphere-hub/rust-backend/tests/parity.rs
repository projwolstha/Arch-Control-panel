//! Integration and parity tests for the Rust backend modules.

use std::fs;
use std::path::PathBuf;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use sphere_backend::battery;
use sphere_backend::bluetooth;
use sphere_backend::bridge::Bridge;
use sphere_backend::config::ConfigStore;
use sphere_backend::constants::valid_package_name;
use sphere_backend::json::{parse_json, JsonVal};
use sphere_backend::organize::{Organizer, Rules, unique_path};
use sphere_backend::resources;
use sphere_backend::wifi;

fn temp_test_dir(tag: &str) -> PathBuf {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_nanos();
    let p = std::env::temp_dir().join(format!("sphere-rust-test-{}-{}", tag, nanos));
    fs::create_dir_all(&p).unwrap();
    p
}

#[test]
fn wifi_terse_and_validation_parity() {
    let fields = wifi::split_terse(r"*:My\:Cafe\\5G:88:WPA2 WPA3");
    assert_eq!(fields, vec!["*", r"My:Cafe\5G", "88", "WPA2 WPA3"]);

    assert!(wifi::check_ssid(Some("HomeNetwork")).is_ok());
    assert!(wifi::check_ssid(Some("-bad-flag")).is_err());
    assert!(wifi::check_ssid(Some("")).is_err());

    assert_eq!(wifi::check_passphrase(None).unwrap(), None);
    assert!(wifi::check_passphrase(Some("short")).is_err());
    assert_eq!(
        wifi::check_passphrase(Some("correct-horse-battery")).unwrap(),
        Some("correct-horse-battery".to_string())
    );
    let hex64 = "a".repeat(64);
    assert_eq!(wifi::check_passphrase(Some(&hex64)).unwrap(), Some(hex64));
}

#[test]
fn bluetooth_mac_and_package_validation() {
    assert!(bluetooth::valid_mac("AA:BB:CC:11:22:33"));
    assert!(!bluetooth::valid_mac("AA:BB:CC:11:22"));
    assert!(!bluetooth::valid_mac("GG:BB:CC:11:22:33"));

    assert!(valid_package_name("firefox-esr"));
    assert!(valid_package_name("org.mozilla.firefox"));
    assert!(!valid_package_name("--evil-flag"));
    assert!(!valid_package_name("a;rm -rf /"));
}

#[test]
fn config_store_atomic_roundtrip_and_bounds() {
    let dir = temp_test_dir("cfg");
    let cfg_path = dir.join("state.json");
    let mut store = ConfigStore::new(Some(&cfg_path));
    assert_eq!(store.slots.len(), 8);
    assert_eq!(store.preferences.rotation_seconds, 90);

    let upd = parse_json(r#"{"paused":true,"rotationSeconds":5,"screenName":"DP-1"}"#).unwrap();
    store.preferences.apply_update(&upd).unwrap();
    assert_eq!(store.preferences.paused, true);
    assert_eq!(store.preferences.rotation_seconds, 20); // clamped >= 20
    store.save().unwrap();

    let reloaded = ConfigStore::new(Some(&cfg_path));
    assert_eq!(reloaded.preferences.paused, true);
    assert_eq!(reloaded.preferences.rotation_seconds, 20);
    assert_eq!(reloaded.preferences.screen_name, "DP-1");

    // Reject wrong preference value type
    let bad = parse_json(r#"{"paused":"yes"}"#).unwrap();
    assert!(store.preferences.apply_update(&bad).is_err());
    let _ = fs::remove_dir_all(&dir);
}

#[test]
fn sysfs_battery_and_meminfo_readers() {
    let dir = temp_test_dir("sys");
    let bat0 = dir.join("BAT0");
    fs::create_dir_all(&bat0).unwrap();
    fs::write(bat0.join("type"), "Battery\n").unwrap();
    fs::write(bat0.join("capacity"), "82\n").unwrap();
    fs::write(bat0.join("status"), "Discharging\n").unwrap();
    fs::write(bat0.join("energy_now"), "41000000\n").unwrap();
    fs::write(bat0.join("energy_full"), "50000000\n").unwrap();
    fs::write(bat0.join("energy_full_design"), "55000000\n").unwrap();
    fs::write(bat0.join("power_now"), "10250000\n").unwrap();
    fs::write(bat0.join("voltage_now"), "12400000\n").unwrap();
    fs::write(bat0.join("cycle_count"), "115\n").unwrap();

    std::env::set_var("SPHERE_POWER_SUPPLY", &dir);
    let b = battery::status();
    assert_eq!(b.get_bool("present"), Some(true));
    assert_eq!(b.get_i64("percent"), Some(82));
    assert_eq!(b.get_str("state"), Some("discharging"));
    assert_eq!(b.get_i64("cycles"), Some(115));
    std::env::remove_var("SPHERE_POWER_SUPPLY");

    let mem_file = dir.join("meminfo");
    fs::write(
        &mem_file,
        "MemTotal:       16777216 kB\nMemFree:         4194304 kB\nMemAvailable:    8388608 kB\nBuffers:          524288 kB\nCached:          2097152 kB\nSwapTotal:       4194304 kB\nSwapFree:        3145728 kB\n",
    )
    .unwrap();
    std::env::set_var("SPHERE_MEMINFO", &mem_file);
    let r = resources::status(true);
    assert_eq!(r.get_bool("available"), Some(true));
    assert_eq!(r.get("ram").and_then(|v| v.get_i64("percent")), Some(50));
    assert_eq!(r.get("swap").and_then(|v| v.get_i64("percent")), Some(25));
    std::env::remove_var("SPHERE_MEMINFO");

    let _ = fs::remove_dir_all(&dir);
}

#[test]
fn organizer_rules_scan_run_and_undo() {
    let dir = temp_test_dir("org");
    let home = dir.join("home");
    let dl = home.join("Downloads");
    fs::create_dir_all(&dl).unwrap();

    std::env::set_var("HOME", &home);
    std::env::set_var("JARVIS_CONFIG_DIR", dir.join("cfg"));
    std::env::set_var("JARVIS_STATE_DIR", dir.join("state"));

    let rules = Rules::from_json(Rules::default_json());
    assert_eq!(
        rules.category_for_extension("pkg-1.0.pkg.tar.zst"),
        Some("Installers".to_string())
    );
    assert_eq!(
        rules.category_for_extension("backup.tar.gz"),
        Some("Archives".to_string())
    );
    assert!(rules.ignored("video.mp4.part"));

    // Create files and backdate mtime > 60s by setting min_age_seconds = 0 in rules
    let org = Organizer::new();
    org.ensure_dirs();
    let mut custom_rules = Rules::default_json();
    custom_rules.set(
        "options",
        JsonVal::obj(vec![
            ("min_age_seconds", JsonVal::Int(0)),
            ("include_subfolders", JsonVal::Bool(false)),
            ("central_destination", JsonVal::Str(String::new())),
        ]),
    );
    fs::write(&org.rules_path, custom_rules.to_json_pretty()).unwrap();

    fs::write(dl.join("photo.png"), b"png-bytes").unwrap();
    fs::write(dl.join("notes.pdf"), b"pdf-bytes").unwrap();

    // Refuse system paths
    assert!(org.refuse("/usr").is_err());
    assert!(org.refuse(home.to_str().unwrap()).is_err());

    // Scan -> Run -> Undo
    let scan = org.scan(dl.to_str().unwrap(), Some(200));
    assert_eq!(scan.get_bool("ok"), Some(true));
    assert_eq!(scan.get_i64("files"), Some(2));

    let run = org.run(dl.to_str().unwrap(), |_| {});
    assert_eq!(run.get_bool("ok"), Some(true));
    assert_eq!(run.get_i64("moved"), Some(2));
    assert!(dl.join("Images/photo.png").is_file());
    assert!(dl.join("Documents/notes.pdf").is_file());

    // Unique collision naming for compound .tar.gz
    let existing = dl.join("archive.tar.gz");
    fs::write(&existing, b"1").unwrap();
    let cand = unique_path(&existing);
    assert_eq!(
        cand.file_name().unwrap().to_str().unwrap(),
        "archive (1).tar.gz"
    );

    let undo = org.undo();
    assert_eq!(undo.get_i64("restored"), Some(2));
    assert!(dl.join("photo.png").is_file());
    assert!(dl.join("notes.pdf").is_file());

    let _ = fs::remove_dir_all(&dir);
}

#[test]
fn bridge_request_protocol_parity() {
    let dir = temp_test_dir("bridge");
    let cfg = dir.join("state.json");
    let bridge = Bridge::new(Some(&cfg), |_| {});

    let snap = bridge.snapshot(false);
    assert_eq!(snap.get_str("type"), Some("snapshot"));
    assert!(snap.get("apps").and_then(|v| v.as_arr()).is_some());
    assert_eq!(
        snap.get("slots").and_then(|v| v.as_arr()).map(|a| a.len()),
        Some(8)
    );

    let assign = parse_json(r#"{"action":"assign","slot":0,"target":{"kind":"recipe","id":"firefox"}}"#).unwrap();
    let assigned = bridge.request(&assign).unwrap();
    assert_eq!(assigned.get_str("type"), Some("snapshot"));

    let unknown = parse_json(r#"{"action":"exec"}"#).unwrap();
    assert!(bridge.request(&unknown).is_err());

    bridge.signal_stop();
    let _ = Duration::from_millis(10);
    let _ = fs::remove_dir_all(&dir);
}
