#!/bin/sh
# Sphere Hub — Battery preparation for Arch (sourced by the installer, and by
# up3.sh). Same contract as bluetooth-prep.sh: every check reports and continues,
# because a desktop with no battery is a supported machine, not an error.
#
# Set SPHERE_BAT_DRY_RUN=1 to print the plan and change nothing.

BAT_INSTALLED=""
BAT_FAILED=""
BAT_PKGS_WANTED="upower power-profiles-daemon"
BAT_SERVICES_WANTED="upower power-profiles-daemon"

bat_say() { printf '%s\n' "$*"; }
# Privilege escalation, resolved once: sudo, then doas, then pkexec — the same
# order installer/packages.py uses. Arch users often have doas and no sudo, and
# a bare `sudo` there fails every install and every service enable below.
BAT_ELEVATOR=""
for _sphere_e in sudo doas pkexec; do
    if command -v "$_sphere_e" >/dev/null 2>&1; then BAT_ELEVATOR=$_sphere_e; break; fi
done
if [ -z "$BAT_ELEVATOR" ]; then
    printf '%s\n' 'Sphere: no sudo, doas or pkexec found — cannot install packages or enable services.' >&2
fi
bat_note() { printf '%s\n' "  ! $*"; }
bat_die_note() { printf '%s\n' "  ! $*" >&2; }

bat_run() {
    if [ "${SPHERE_BAT_DRY_RUN:-0}" = "1" ]; then
        printf '%s\n' "  would run: $*"
        return 0
    fi
    "$@"
}

bat_have() { command -v "$1" >/dev/null 2>&1; }

bat_pkg_installed() {
    pacman -Q "$1" >/dev/null 2>&1
}

# Installed, or at least known to the sync database: anything else would abort
# the whole transaction and take upower with it.
bat_pkg_available() {
    pacman -Q "$1" >/dev/null 2>&1 || pacman -Si "$1" >/dev/null 2>&1
}

bat_sync_ready() {
    pacman -Si bash >/dev/null 2>&1
}

# ── 1. dependencies: only the missing ones ──────────────────────────────────
bat_install_missing() {
    if ! bat_have pacman; then
        bat_note "pacman was not found: this preparation step is for Arch Linux."
        return 1
    fi
    if ! bat_sync_ready; then
        bat_die_note "pacman's sync database is empty. Run '${BAT_ELEVATOR} pacman -Syu' first, then re-run this script."
        return 1
    fi
    _want=""
    _skip=""
    for pkg in $BAT_PKGS_WANTED; do
        if bat_pkg_installed "$pkg"; then continue; fi
        if bat_pkg_available "$pkg"; then _want="$_want $pkg"; else _skip="$_skip $pkg"; fi
    done
    if [ -n "$_skip" ]; then
        BAT_SKIPPED="$_skip"
        bat_say "  not in the Arch repositories, skipped:$_skip"
    fi
    if [ -z "$_want" ]; then
        bat_say "  dependencies: all present"
        return 0
    fi
    bat_say "  installing missing packages:$_want"
    if bat_run "${BAT_ELEVATOR}" pacman -S --needed --noconfirm $_want; then
        for pkg in $_want; do BAT_INSTALLED="$BAT_INSTALLED $pkg"; done
    else
        BAT_FAILED="$BAT_FAILED pacman($_want )"
        bat_note "pacman could not install:$_want — continuing without it"
        return 1
    fi
    return 0
}

# ── 2. services ─────────────────────────────────────────────────────────────
# A package can be installed while its unit file is not visible to the running
# systemd (layered roots such as Bedrock do this). Check before enabling, so the
# message says what is true instead of "Unit ... does not exist".
bat_unit_known() {
    systemctl list-unit-files "$1.service" 2>/dev/null | grep -q "^$1\.service"
}

bat_enable_service() {
    _name="$1"
    if ! bat_have systemctl; then
        bat_note "systemctl is not available; start $_name by hand."
        return 1
    fi
    if systemctl is-active --quiet "$_name" 2>/dev/null; then
        bat_say "  $_name: already running"
        return 0
    fi
    if ! bat_unit_known "$_name"; then
        bat_note "$_name.service is not installed for the running systemd; continuing — the panel reads /sys/class/power_supply directly."
        return 1
    fi
    if bat_run "${BAT_ELEVATOR}" systemctl enable --now "$_name"; then
        if [ "${SPHERE_BAT_DRY_RUN:-0}" = "1" ]; then
            bat_say "  $_name: would be enabled and started"
        else
            bat_say "  $_name: enabled and started"
        fi
    else
        bat_note "could not enable $_name — run: ${BAT_ELEVATOR} systemctl enable --now $_name"
        return 1
    fi
}

# ── 3. is there a battery at all? ───────────────────────────────────────────
# Printed either way; the panel is built to say "No battery detected" on a
# desktop and must never crash there, so neither does this script.
bat_check_power_supply() {
    _root="/sys/class/power_supply"
    if [ ! -d "$_root" ]; then
        bat_say "  power supplies: $_root is missing (no power-supply support in this kernel)"
        bat_say "  continuing: the power panel will read 'No battery detected' and everything else works"
        return 0
    fi
    _list="$(ls "$_root" 2>/dev/null | tr '\n' ' ')"
    bat_say "  power supplies: ${_list:-(none)}"
    BAT_DEVICES=""
    for _dev in "$_root"/BAT*; do
        [ -e "$_dev" ] || continue
        _name="$(basename "$_dev")"
        _cap="$(cat "$_dev/capacity" 2>/dev/null || true)"
        _sta="$(cat "$_dev/status" 2>/dev/null || true)"
        BAT_DEVICES="$BAT_DEVICES $_name"
        if [ -n "$_cap" ]; then
            bat_say "  battery: $_name ${_cap}%${_sta:+ ($_sta)}"
        else
            bat_say "  battery: $_name present"
        fi
    done
    if [ -z "$BAT_DEVICES" ]; then
        bat_say "  battery: none found — the power panel will say 'No battery detected' (this is normal on a desktop)"
    fi
    return 0
}

# ── 4. upower agrees with sysfs? ────────────────────────────────────────────
bat_check_upower() {
    if ! bat_have upower; then
        bat_note "upower is not installed; the adapter falls back to reading /sys/class/power_supply directly."
        return 0
    fi
    _devs="$(upower -e 2>/dev/null | grep -c 'battery_' 2>/dev/null || true)"
    if [ "${_devs:-0}" -gt 0 ] 2>/dev/null; then
        bat_say "  upower: $_devs battery device(s) reported"
    elif [ -n "$BAT_DEVICES" ]; then
        bat_say "  upower: the daemon is not answering, but sysfs has${BAT_DEVICES}"
        bat_say "  continuing: the panel reads /sys/class/power_supply itself, so the charge is still shown"
    else
        bat_say "  upower: no battery device (desktop or VM) — the panel will explain this"
    fi
    return 0
}

# ── 5. the whole sequence, plus the summary ─────────────────────────────────
bat_prepare() {
    BAT_INSTALLED=""
    BAT_FAILED=""
    BAT_SKIPPED=""
    BAT_DEVICES=""
    bat_say "Power preparation (Arch):"
    bat_install_missing || true
    for _svc in $BAT_SERVICES_WANTED; do bat_enable_service "$_svc" || true; done
    bat_check_power_supply || true
    bat_check_upower || true

    bat_say ""
    bat_say "Summary:"
    if [ -n "$BAT_INSTALLED" ]; then
        if [ "${SPHERE_BAT_DRY_RUN:-0}" = "1" ]; then
            bat_say "  would install:$BAT_INSTALLED"
        else
            bat_say "  installed:$BAT_INSTALLED"
        fi
    else
        bat_say "  installed: nothing (all dependencies were already present)"
    fi
    if [ -n "$BAT_FAILED" ]; then bat_say "  failed:$BAT_FAILED"; fi
    for _svc in $BAT_SERVICES_WANTED; do
        if bat_have systemctl; then
            if systemctl is-active --quiet "$_svc" 2>/dev/null; then
                bat_say "  service: $_svc running"
            elif ! bat_unit_known "$_svc"; then
                bat_say "  service: $_svc unit not installed (optional; the panel reads sysfs)"
            else
                bat_say "  service: $_svc NOT running"
            fi
        else
            bat_say "  service: $_svc unknown (no systemctl)"
        fi
    done
    if [ -n "$BAT_DEVICES" ]; then
        bat_say "  battery:${BAT_DEVICES}"
    else
        bat_say "  battery: none (the power panel will say 'No battery detected')"
    fi
    bat_say "  reload Quickshell to pick up the new panel: sphere-setup restart"
}
