#!/bin/sh
# Sphere Hub — Bluetooth preparation for Arch (sourced by the installer, and by
# up2.sh). Every check reports and continues: only a failed pacman transaction is
# treated as an error, because it is the only thing the user can act on.
#
# Set SPHERE_BT_DRY_RUN=1 to print the plan and change nothing.

BT_INSTALLED=""
BT_FAILED=""
BT_PKGS_WANTED="bluez bluez-utils util-linux quickshell networkmanager qt6-base qt6-declarative qt6-wayland qt6-svg qt6-imageformats"
BT_FONTS_WANTED="noto-fonts"

bt_say() { printf '%s\n' "$*"; }
# Privilege escalation, resolved once: sudo, then doas, then pkexec — the same
# order installer/packages.py uses. Arch users often have doas and no sudo, and
# a bare `sudo` there fails every install and every service enable below.
BT_ELEVATOR=""
for _sphere_e in sudo doas pkexec; do
    if command -v "$_sphere_e" >/dev/null 2>&1; then BT_ELEVATOR=$_sphere_e; break; fi
done
if [ -z "$BT_ELEVATOR" ]; then
    printf '%s\n' 'Sphere: no sudo, doas or pkexec found — cannot install packages or enable services.' >&2
fi
bt_die_note() { printf '%s\n' "  ! $*"; }

bt_run() {
    if [ "${SPHERE_BT_DRY_RUN:-0}" = "1" ]; then
        printf '%s\n' "  would run: $*"
        return 0
    fi
    "$@"
}

bt_have() { command -v "$1" >/dev/null 2>&1; }

bt_pkg_installed() {
    pacman -Q "$1" >/dev/null 2>&1
}

# Installed, or at least known to pacman's sync database. A name that is neither
# would abort the whole transaction ("target not found") and take every other
# package with it, so it is dropped and reported instead.
bt_pkg_available() {
    pacman -Q "$1" >/dev/null 2>&1 || pacman -Si "$1" >/dev/null 2>&1
}

# A fresh Arch install has an empty sync database until the first -Syu: every
# lookup answers nothing, and `pacman -S` fails with "database file ... is not
# valid". bash is always in core, so it is the probe.
bt_sync_ready() {
    pacman -Si bash >/dev/null 2>&1
}

# ── 1. dependencies: only the missing ones ──────────────────────────────────
bt_install_missing() {
    if ! bt_have pacman; then
        bt_die_note "pacman was not found: this preparation step is for Arch Linux."
        return 1
    fi
    if ! bt_sync_ready; then
        bt_die_note "pacman's sync database is empty. Run '${BT_ELEVATOR} pacman -Syu' first (Arch never refreshes half a system), then re-run this script."
        return 1
    fi
    _want=""
    _skip=""
    for pkg in $BT_PKGS_WANTED; do
        if bt_pkg_installed "$pkg"; then continue; fi
        if bt_pkg_available "$pkg"; then _want="$_want $pkg"; else _skip="$_skip $pkg"; fi
    done
    if [ -n "$_skip" ]; then
        BT_SKIPPED="$_skip"
        bt_say "  not in the Arch repositories, skipped:$_skip"
    fi
    # A font is only needed when neither Noto nor DejaVu is present.
    if ! bt_pkg_installed noto-fonts && ! bt_pkg_installed ttf-dejavu; then
        _want="$_want $BT_FONTS_WANTED"
    fi
    if [ -z "$_want" ]; then
        bt_say "  dependencies: all present"
        return 0
    fi
    bt_say "  installing missing packages:$_want"
    if bt_run "${BT_ELEVATOR}" pacman -S --needed --noconfirm $_want; then
        for pkg in $_want; do BT_INSTALLED="$BT_INSTALLED $pkg"; done
    else
        BT_FAILED="$BT_FAILED pacman($_want )"
        bt_die_note "pacman could not install:$_want — continuing without it"
        return 1
    fi
    return 0
}

# ── 2. services ─────────────────────────────────────────────────────────────
bt_enable_service() {
    _name="$1"
    if ! bt_have systemctl; then
        bt_die_note "systemctl is not available; start $_name by hand."
        return 1
    fi
    if systemctl is-active --quiet "$_name" 2>/dev/null; then
        bt_say "  $_name: already running"
        return 0
    fi
    if bt_run "${BT_ELEVATOR}" systemctl enable --now "$_name"; then
        if [ "${SPHERE_BT_DRY_RUN:-0}" = "1" ]; then
            bt_say "  $_name: would be enabled and started"
        else
            bt_say "  $_name: enabled and started"
        fi
    else
        bt_die_note "could not enable $_name — run: ${BT_ELEVATOR} systemctl enable --now $_name"
        return 1
    fi
}

# ── 3. adapter and rfkill ───────────────────────────────────────────────────
bt_check_adapter() {
    if ! bt_have bluetoothctl; then
        bt_die_note "bluetoothctl is missing, so the adapter cannot be checked."
        return 1
    fi
    if ! bluetoothctl list 2>/dev/null | grep -q '^Controller '; then
        bt_die_note "no Bluetooth adapter found (bluetoothctl list is empty)."
        bt_die_note "  Plug in/enable the adapter; the panel will say 'No Bluetooth adapter' until then."
        return 1
    fi
    bt_say "  adapter: $(bluetoothctl list 2>/dev/null | grep -m1 '^Controller ')"
}

bt_check_rfkill() {
    if ! bt_have rfkill; then
        bt_die_note "rfkill is not installed; skipping the radio-block check."
        return 0
    fi
    _status="$(rfkill list bluetooth 2>/dev/null || true)"
    case "$_status" in
        *"Soft blocked: yes"*|*"Hard blocked: yes"*)
            bt_say "  rfkill: blocked — unblocking"
            if bt_run "${BT_ELEVATOR}" rfkill unblock bluetooth; then
                bt_say "  rfkill: unblocked"
            else
                bt_die_note "rfkill could not be unblocked. If this is a hardware switch, enable it first."
            fi;;
        "") bt_die_note "rfkill reported nothing for bluetooth (no radio?).";;
        *) bt_say "  rfkill: not blocked";;
    esac
}

# ── 4. groups ───────────────────────────────────────────────────────────────
bt_groups() {
    _user="$(id -un)"
    for _group in wheel bluetooth; do
        if getent group "$_group" >/dev/null 2>&1; then
            if ! id -nG "$_user" 2>/dev/null | tr ' ' '\n' | grep -qx "$_group"; then
                if bt_run "${BT_ELEVATOR}" gpasswd -a "$_user" "$_group"; then
                    bt_say "  group: added $_user to $_group (re-login to apply)"
                    BT_GROUPS_ADDED="$BT_GROUPS_ADDED $_group"
                else
                    bt_die_note "could not add $_user to $_group (not fatal)."
                fi
            fi
        fi
    done
}

# ── 5. the whole sequence, plus the summary ─────────────────────────────────
bt_prepare() {
    BT_INSTALLED=""
    BT_FAILED=""
    BT_SKIPPED=""
    BT_GROUPS_ADDED=""
    bt_say "Wi-Fi + Bluetooth preparation (Arch):"
    bt_install_missing || true
    bt_enable_service bluetooth || true
    bt_enable_service NetworkManager || true
    bt_check_adapter || true
    bt_check_rfkill || true
    bt_groups || true

    bt_say ""
    bt_say "Summary:"
    if [ -n "$BT_INSTALLED" ]; then
        if [ "${SPHERE_BT_DRY_RUN:-0}" = "1" ]; then
            bt_say "  would install:$BT_INSTALLED"
        else
            bt_say "  installed:$BT_INSTALLED"
        fi
    else
        bt_say "  installed: nothing (all dependencies were already present)"
    fi
    if [ -n "$BT_FAILED" ]; then bt_say "  failed:$BT_FAILED"; fi
    if [ -n "$BT_SKIPPED" ]; then
        bt_say "  skipped (no such package in the Arch repositories):$BT_SKIPPED"
    fi
    if [ -n "$BT_GROUPS_ADDED" ]; then bt_say "  groups added:$BT_GROUPS_ADDED (log out and back in)"; fi
    for _svc in bluetooth NetworkManager; do
        if bt_have systemctl; then
            if systemctl is-active --quiet "$_svc" 2>/dev/null; then
                bt_say "  service: $_svc running"
            else
                bt_say "  service: $_svc NOT running"
            fi
        else
            bt_say "  service: $_svc unknown (no systemctl)"
        fi
    done
    if bt_have bluetoothctl && bluetoothctl list 2>/dev/null | grep -q '^Controller '; then
        bt_say "  adapter: present"
    else
        bt_say "  adapter: none found (the panel will explain this)"
    fi
    bt_say "  reload Quickshell to pick up the new panel: sphere-setup restart"
}
