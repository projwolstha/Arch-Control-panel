"""Sphere's embedded installer bootstrap.

This file is not run on its own: tools/build.py pastes it into the single-file
``sphere-setup.sh``, between the POSIX preflight and the base64 payload, and
replaces its ``PAYLOAD_SHA256`` placeholder with the digest of the payload archive.
``sphere-setup.sh`` then feeds it to ``python3`` on stdin with the script path as
argv[1], so nothing is ever extracted before that digest matches.

The payload is a gzipped tar of ``manager.py``, ``installer/`` and ``native/``;
``checksums.json`` inside it is checked file by file before anything executes.
"""
import base64
import hashlib
import io
import json
import os
import pathlib
import runpy
import sys
import tarfile
import tempfile

MARKER = b"\n__SPHERE_PAYLOAD_V1__\n"
PAYLOAD_SHA256 = "PAYLOAD_SHA256"
MAX_ENCODED = 8_000_000
MAX_EXTRACTED = 10_000_000


def payload_bytes(script):
    """Return the decoded payload, after checking its size and pinned digest."""
    raw = script.read_bytes()
    if raw.count(MARKER) != 1:
        raise ValueError("Missing or ambiguous embedded payload marker")
    encoded = b"".join(raw.split(MARKER, 1)[1].split())
    if len(encoded) > MAX_ENCODED:
        raise ValueError("Oversized payload")
    data = base64.b64decode(encoded, validate=True)
    if hashlib.sha256(data).hexdigest() != PAYLOAD_SHA256:
        raise ValueError("Installer payload SHA-256 mismatch; download may be damaged")
    return data


def extract(data, root):
    """Write every regular payload member below ``root`` — nothing else is accepted."""
    total = 0
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        for member in archive.getmembers():
            relative = pathlib.Path(member.name)
            if not member.isfile() or relative.is_absolute() or ".." in relative.parts:
                raise ValueError("Unsafe payload member")
            total += member.size
            if total > MAX_EXTRACTED:
                raise ValueError("Oversized extracted payload")
            target = root/relative
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.extractfile(member) as stream:
                target.write_bytes(stream.read())
            target.chmod(0o600)


def verify(root):
    """Check the embedded inventory, file by file, before importing anything."""
    inventory = json.loads((root/"checksums.json").read_text())
    for name, expected in inventory.items():
        relative = pathlib.Path(name)
        if relative.is_absolute() or ".." in relative.parts or hashlib.sha256((root/relative).read_bytes()).hexdigest() != expected:
            raise ValueError("Embedded file integrity failure: "+name)


def main(script, arguments):
    data = payload_bytes(script)
    with tempfile.TemporaryDirectory(prefix="sphere-native-setup-") as temporary:
        root = pathlib.Path(temporary)
        extract(data, root)
        verify(root)
        # The manager needs to know which single file it may reinstall itself from.
        os.environ["SPHERE_INSTALLER_FILE"] = str(script)
        sys.argv = [str(root/"manager.py"), *arguments]
        runpy.run_path(str(root/"manager.py"), run_name="__main__")


try:
    main(pathlib.Path(sys.argv[1]).resolve(), sys.argv[2:])
except (ValueError, OSError, tarfile.TarError) as error:
    print("Sphere bootstrap error: "+str(error), file=sys.stderr)
    sys.exit(1)
