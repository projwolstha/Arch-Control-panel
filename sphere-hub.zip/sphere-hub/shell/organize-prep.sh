#!/bin/sh
# Sphere Hub — file organizer preparation for Arch (sourced by the installer,
# by sphere-setup and by up10.sh).
#
# The organizer is a plain Python 3 program with a JSON contract, so the only
# things it needs from the system are an interpreter, `file` (for the MIME
# fallback when a name has no useful extension) and `xdg-open` (the RULES button
# opens ~/.config/jarvis/organize.json in the user's editor). Watching is done by
# polling file sizes, so inotify-tools is deliberately not requested.
#
# Every check reports and continues: a missing package never aborts an install,
# because the panel explains the failure instead of crashing.
#
# Set SPHERE_OG_DRY_RUN=1 to print the plan and change nothing.

# The packages this feature actually uses. Polling replaces inotify, so nothing
# from inotify-tools is wanted here.
packages="python xdg-utils file"

OG_INSTALLED=""
OG_FAILED=""
OG_RULES_CREATED=""

og_say() { printf '%s\n' "$*"; }
# Privilege escalation, resolved once: sudo, then doas, then pkexec — the same
# order installer/packages.py uses. Arch users often have doas and no sudo, and
# a bare `sudo` there fails every install and every service enable below.
OG_ELEVATOR=""
for _sphere_e in sudo doas pkexec; do
    if command -v "$_sphere_e" >/dev/null 2>&1; then OG_ELEVATOR=$_sphere_e; break; fi
done
if [ -z "$OG_ELEVATOR" ]; then
    printf '%s\n' 'Sphere: no sudo, doas or pkexec found — cannot install packages or enable services.' >&2
fi
og_die_note() { printf '%s\n' "  ! $*"; }

og_run() {
    if [ "${SPHERE_OG_DRY_RUN:-0}" = "1" ]; then
        printf '%s\n' "  would run: $*"
        return 0
    fi
    "$@"
}

og_have() { command -v "$1" >/dev/null 2>&1; }

og_pkg_installed() {
    pacman -Q "$1" >/dev/null 2>&1
}

# Installed, or at least known to the sync database: a name that is neither
# aborts the whole pacman transaction, taking the other targets with it.
og_pkg_available() {
    pacman -Q "$1" >/dev/null 2>&1 || pacman -Si "$1" >/dev/null 2>&1
}

og_sync_ready() {
    pacman -Si bash >/dev/null 2>&1
}

og_bin() { printf '%s\n' "${JARVIS_ORGANIZE:-$HOME/.local/bin/jarvis-organize}"; }
og_rules() { printf '%s\n' "${XDG_CONFIG_HOME:-$HOME/.config}/jarvis/organize.json"; }

# ── 1. dependencies: only the missing ones ─────────────────────────────────
og_install_missing() {
    if ! og_have pacman; then
        og_die_note "pacman was not found: this preparation step is for Arch Linux."
        return 1
    fi
    if ! og_sync_ready; then
        og_die_note "pacman's sync database is empty. Run '${OG_ELEVATOR} pacman -Syu' first, then re-run this script."
        return 1
    fi
    _want=""
    _skip=""
    for pkg in $packages; do
        if og_pkg_installed "$pkg"; then continue; fi
        if og_pkg_available "$pkg"; then _want="$_want $pkg"; else _skip="$_skip $pkg"; fi
    done
    if [ -n "$_skip" ]; then
        OG_SKIPPED="$_skip"
        og_say "  not in the Arch repositories, skipped:$_skip"
    fi
    # `file` ships the /usr/bin/file binary (package `file`), `xdg-utils` the
    # opener, and python is already guaranteed by Sphere itself. Check the
    # binaries too, in case a package is present under another name.
    og_have python || _want="$_want python"
    og_have file || _want="$_want file"
    if [ -z "$_want" ]; then
        og_say "  dependencies: all present"
        return 0
    fi
    og_say "  installing missing packages:$_want"
    if og_run "${OG_ELEVATOR}" pacman -S --needed --noconfirm $_want; then
        for pkg in $_want; do OG_INSTALLED="$OG_INSTALLED $pkg"; done
    else
        OG_FAILED="$OG_FAILED pacman($_want )"
        og_die_note "pacman could not install:$_want — the panel keeps working without it"
        return 1
    fi
    return 0
}

# ── 2. the command itself ───────────────────────────────────────────────────
# sphere-setup installs this file; up10.sh runs the prep step after it. If the
# command is missing, say exactly what to do instead of failing silently.
og_check_command() {
    _bin="$(og_bin)"
    if [ -f "$_bin" ]; then
        # it must be executable for a terminal, and for Quickshell's Process
        if [ ! -x "$_bin" ] && [ "${SPHERE_OG_DRY_RUN:-0}" != "1" ]; then
            chmod 755 "$_bin" 2>/dev/null && og_say "  command: made $_bin executable (755)" \
                || og_die_note "could not chmod $_bin — run: chmod 755 '$_bin'"
        fi
        if [ -x "$_bin" ] || [ "${SPHERE_OG_DRY_RUN:-0}" = "1" ]; then
            og_say "  command: $_bin"
            return 0
        fi
    fi
    # A first install reaches here before the installer has written the command:
    # say where it comes from instead of calling a healthy run broken.
    og_say "  command: $_bin (installed by the installer below, or by sphere-setup install)"
    return 1
}

# ── 3. the rules file and the state folder ──────────────────────────────────
# Defaults are written once and never touched again: a user who edits a category
# or an ignore pattern keeps that edit across reinstalls.
og_seed_rules() {
    _bin="$(og_bin)"
    _rules="$(og_rules)"
    if [ -f "$_rules" ]; then
        og_say "  rules: kept $(og_rules) (never overwritten)"
        return 0
    fi
    if [ -x "$_bin" ]; then
        # `init` is the backend's own door: it writes the default rules, the
        # state folder and the first status line, in one place.
        if og_run "$_bin" init >/dev/null 2>&1; then
            OG_RULES_CREATED="yes"
            og_say "  rules: created $_rules with the default categories"
            return 0
        fi
        og_die_note "could not write $_rules — the backend's init failed."
        return 1
    fi
    og_say "  rules: $_rules (the installer writes the defaults when it installs the command)"
    return 1
}

og_state_dir() {
    _state="${XDG_STATE_HOME:-$HOME/.local/state}/jarvis/organize"
    if [ "${SPHERE_OG_DRY_RUN:-0}" = "1" ]; then
        og_say "  state: would create $_state"
        return 0
    fi
    if mkdir -p "$_state" 2>/dev/null; then
        og_say "  state: $_state"
    else
        og_die_note "could not create $_state — undo history will not survive."
    fi
}

# ── 4. the whole sequence, plus the summary ────────────────────────────────
og_prepare() {
    OG_INSTALLED=""
    OG_SKIPPED=""
    OG_FAILED=""
    OG_RULES_CREATED=""
    og_say "File organizer preparation (Arch):"
    og_install_missing || true
    og_check_command || true
    og_seed_rules || true
    og_state_dir || true

    og_say ""
    og_say "Summary:"
    if [ -n "$OG_INSTALLED" ]; then
        if [ "${SPHERE_OG_DRY_RUN:-0}" = "1" ]; then
            og_say "  would install:$OG_INSTALLED"
        else
            og_say "  installed:$OG_INSTALLED"
        fi
    elif ! og_have pacman; then
        og_say "  installed: nothing (pacman is not available on this system)"
    else
        og_say "  installed: nothing (python, xdg-utils and file were already present)"
    fi
    if [ -n "$OG_FAILED" ]; then og_say "  failed:$OG_FAILED"; fi
    if [ -n "$OG_SKIPPED" ]; then og_say "  skipped (no such package):$OG_SKIPPED"; fi
    if [ -n "$OG_RULES_CREATED" ]; then
        og_say "  rules: default categories written to $(og_rules)"
    else
        og_say "  rules: $(og_rules) (existing file kept as it is)"
    fi
    og_say "  nothing is moved until you press ORGANIZE NOW: the default is a preview."
    og_say "  reload Quickshell to pick up the new panel: sphere-setup restart"
}
