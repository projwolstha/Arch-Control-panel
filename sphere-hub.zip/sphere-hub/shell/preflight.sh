#!/bin/sh
# Sphere Hub 6.16.0 — ONE self-contained native Hyprland/Quickshell setup + manager.
# Inspect with a text editor. Run as your desktop user, NEVER "sudo bash".
# Default: install. Management: status doctor start stop restart picker repair logs
# enable disable pause resume lock unlock refresh toggle uninstall. --dry-run changes nothing.
# Embedded artwork, native QML, stdlib Python adapter, manager and self-tests follow.
set -eu
if [ "$(uname -s)" != Linux ]; then
  printf '%s\n' 'Sphere requires Linux, Wayland and Hyprland; it is not a browser app.' >&2
  exit 1
fi
SELF=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)/$(basename -- "$0")
if [ "$(id -u)" -eq 0 ]; then
  case " $* " in
    *" --dry-run "*|*" --plan "*|*" --help "*|*" -h "*|*" --version "*) ;;
    *) printf '%s\n' 'Run as your normal desktop user, not with sudo. OS packages alone request privilege.' >&2; exit 1 ;;
  esac
fi
if ! command -v python3 >/dev/null 2>&1 || ! python3 -c 'import sys;sys.exit(sys.version_info < (3,10))' 2>/dev/null; then
  case " $* " in
    *" --dry-run "*|*" --plan "*) printf '%s\n' 'Dry run: Python >=3.10 is needed; it would be installed using your system package manager. No changes made.'; exit 0 ;;
  esac
  if command -v sudo >/dev/null 2>&1; then ELEVATOR=sudo
  elif command -v doas >/dev/null 2>&1; then ELEVATOR=doas
  elif command -v pkexec >/dev/null 2>&1; then ELEVATOR=pkexec
  else printf '%s\n' 'Python is missing and no sudo/doas/pkexec privilege helper is available.' >&2; exit 1
  fi
  printf '%s\n' 'Sphere: automatically installing Python. Your OS may request authentication.'
  # The distribution family decides the order, not the order of the checks:
  # trying apt first meant that on Arch with any apt shim on PATH (Bedrock, a
  # container base image) apt "won" and then failed, and `set -e` took the
  # whole setup down before pacman was ever reached. Each candidate is now
  # skipped when it is not installed and falls through to the next when it
  # fails, so one unreachable mirror cannot stop the bootstrap.
  ORDER='apt pacman dnf zypper'
  FAMILY=$(. /etc/os-release 2>/dev/null && printf '%s %s' "${ID:-}" "${ID_LIKE:-}") || FAMILY=''
  case " $FAMILY " in
    *" arch "*|*" archlinux "*) ORDER='pacman apt dnf zypper' ;;
  esac
  if [ -f /etc/arch-release ]; then ORDER='pacman apt dnf zypper'; fi
  BOOTSTRAPPED=0
  for MANAGER in $ORDER; do
    case "$MANAGER" in
      pacman)
        command -v pacman >/dev/null 2>&1 || continue
        if "$ELEVATOR" pacman -S --needed --noconfirm python ca-certificates; then BOOTSTRAPPED=1; break; fi
        printf '%s\n' 'Sphere: pacman could not install Python; if this is a fresh Arch install run `sudo pacman -Syu` first. Trying the next manager.' >&2 ;;
      apt)
        command -v apt-get >/dev/null 2>&1 || continue
        if "$ELEVATOR" apt-get update && "$ELEVATOR" apt-get install -y --no-install-recommends python3 ca-certificates; then BOOTSTRAPPED=1; break; fi
        printf '%s\n' 'Sphere: apt-get could not install Python. Trying the next manager.' >&2 ;;
      dnf)
        command -v dnf >/dev/null 2>&1 || continue
        if "$ELEVATOR" dnf install -y python3 ca-certificates; then BOOTSTRAPPED=1; break; fi
        printf '%s\n' 'Sphere: dnf could not install Python. Trying the next manager.' >&2 ;;
      zypper)
        command -v zypper >/dev/null 2>&1 || continue
        if "$ELEVATOR" zypper --non-interactive install python3 ca-certificates; then BOOTSTRAPPED=1; break; fi
        printf '%s\n' 'Sphere: zypper could not install Python. Trying the next manager.' >&2 ;;
    esac
  done
  if [ "$BOOTSTRAPPED" -ne 1 ]; then
    printf '%s\n' 'No supported package manager could install Python (a manager is only tried when it is installed).' >&2
    exit 1
  fi
fi
if ! python3 -c 'import sys;sys.exit(sys.version_info < (3,10))'; then
  printf '%s\n' 'Your distribution does not provide Python >=3.10. It was not replaced with an untrusted build.' >&2
  exit 1
fi
exec python3 - "$SELF" "$@" <<'SPHERE_BOOTSTRAP_PYTHON'
