#!/bin/sh
# Sphere Hub — System Resources preparation for Arch (sourced by the installer,
# and by up4.sh). Same contract as bluetooth-prep.sh and battery-prep.sh: every
# check reports and continues, and nothing here is fatal except a pacman
# transaction the user can actually act on.
#
# Set SPHERE_RES_DRY_RUN=1 to print the plan and change nothing.

RES_INSTALLED=""
RES_FAILED=""
# df is coreutils, ps is procps-ng, the Qt 6 modules are what Quickshell paints
# with, noto-fonts is the face the panel's type uses.
RES_PKGS_WANTED="quickshell coreutils procps-ng util-linux qt6-base qt6-declarative qt6-wayland qt6-svg qt6-imageformats"

res_say() { printf '%s\n' "$*"; }
# Privilege escalation, resolved once: sudo, then doas, then pkexec — the same
# order installer/packages.py uses. Arch users often have doas and no sudo, and
# a bare `sudo` there fails every install and every service enable below.
RES_ELEVATOR=""
for _sphere_e in sudo doas pkexec; do
    if command -v "$_sphere_e" >/dev/null 2>&1; then RES_ELEVATOR=$_sphere_e; break; fi
done
if [ -z "$RES_ELEVATOR" ]; then
    printf '%s\n' 'Sphere: no sudo, doas or pkexec found — cannot install packages or enable services.' >&2
fi
res_note() { printf '%s\n' "  ! $*"; }
res_die_note() { printf '%s\n' "  ! $*" >&2; }

res_run() {
    if [ "${SPHERE_RES_DRY_RUN:-0}" = "1" ]; then
        printf '%s\n' "  would run: $*"
        return 0
    fi
    "$@"
}

res_have() { command -v "$1" >/dev/null 2>&1; }

res_pkg_installed() {
    pacman -Q "$1" >/dev/null 2>&1
}

# Installed, or at least known to the sync database: anything else would abort
# the whole transaction and take the Qt packages with it.
res_pkg_available() {
    pacman -Q "$1" >/dev/null 2>&1 || pacman -Si "$1" >/dev/null 2>&1
}

res_sync_ready() {
    pacman -Si bash >/dev/null 2>&1
}

# ── 1. dependencies: only the missing ones ──────────────────────────────────
res_install_missing() {
    if ! res_have pacman; then
        res_note "pacman was not found: this preparation step is for Arch Linux."
        return 1
    fi
    if ! res_sync_ready; then
        res_die_note "pacman's sync database is empty. Run '${RES_ELEVATOR} pacman -Syu' first, then re-run this script."
        return 1
    fi
    _want=""
    _skip=""
    for pkg in $RES_PKGS_WANTED; do
        if res_pkg_installed "$pkg"; then continue; fi
        if res_pkg_available "$pkg"; then _want="$_want $pkg"; else _skip="$_skip $pkg"; fi
    done
    if [ -n "$_skip" ]; then
        RES_SKIPPED="$_skip"
        res_say "  not in the Arch repositories, skipped:$_skip"
    fi
    # A font is only needed when neither Noto nor DejaVu is present.
    if ! res_pkg_installed noto-fonts && ! res_pkg_installed ttf-dejavu; then
        _want="$_want noto-fonts"
    fi
    if [ -z "$_want" ]; then
        res_say "  dependencies: all present"
        return 0
    fi
    res_say "  installing missing packages:$_want"
    if res_run "${RES_ELEVATOR}" pacman -S --needed --noconfirm $_want; then
        for pkg in $_want; do RES_INSTALLED="$RES_INSTALLED $pkg"; done
    else
        RES_FAILED="$RES_FAILED pacman($_want )"
        res_note "pacman could not install:$_want — continuing without it"
        return 1
    fi
    return 0
}

# ── 2. can the two sources actually be read? ────────────────────────────────
res_check_memory() {
    if [ -r /proc/meminfo ]; then
        _total="$(awk '/^MemTotal:/ {print $2}' /proc/meminfo 2>/dev/null)"
        _avail="$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo 2>/dev/null)"
        _swap="$(awk '/^SwapTotal:/ {print $2}' /proc/meminfo 2>/dev/null)"
        if [ -n "$_total" ] && [ "${_total:-0}" -gt 0 ] 2>/dev/null; then
            _gib=$((_total / 1048576))
            _agib=$((_avail / 1048576))
            res_say "  memory: ${_gib} GiB total, ${_agib} GiB available"
        else
            res_say "  memory: /proc/meminfo has no MemTotal (unusual kernel)"
        fi
        if [ "${_swap:-0}" -gt 0 ] 2>/dev/null; then
            res_say "  swap: $((_swap / 1048576)) GiB configured"
        else
            res_say "  swap: none configured (the panel hides that row)"
        fi
    else
        res_note "/proc/meminfo is not readable; the panel will say so instead of guessing."
        return 1
    fi
    return 0
}

res_check_storage() {
    if ! res_have df; then
        res_note "df is missing (coreutils); the storage rows will be empty."
        return 1
    fi
    _rows="$(df -B1 --output=source,fstype,size,used,avail,pcent,target 2>/dev/null | tail -n +2 | wc -l)"
    if [ "${_rows:-0}" -gt 0 ] 2>/dev/null; then
        res_say "  storage: df reports $_rows mounts; the panel keeps the physical ones"
        df -B1 --output=fstype,target,pcent 2>/dev/null | tail -n +2 |
        grep -vE '^(tmpfs|devtmpfs|overlay|squashfs|efivarfs|proc|sysfs|cgroup2?) ' |
        head -4 | while read -r _f _t _p; do
            res_say "    $_t ($_f) $_p"
        done
    else
        res_note "df returned no rows; the storage section will be empty (not an error)."
        return 1
    fi
    if ! res_have ps; then
        res_note "ps is missing (procps-ng); the top-processes line stays hidden."
    fi
    return 0
}

# ── 3. the whole sequence, plus the summary ─────────────────────────────────
res_prepare() {
    RES_INSTALLED=""
    RES_FAILED=""
    RES_SKIPPED=""
    res_say "System resources preparation (Arch):"
    res_install_missing || true
    res_check_memory || true
    res_check_storage || true

    res_say ""
    res_say "Summary:"
    if [ -n "$RES_INSTALLED" ]; then
        if [ "${SPHERE_RES_DRY_RUN:-0}" = "1" ]; then
            res_say "  would install:$RES_INSTALLED"
        else
            res_say "  installed:$RES_INSTALLED"
        fi
    else
        res_say "  installed: nothing (all dependencies were already present)"
    fi
    if [ -n "$RES_FAILED" ]; then res_say "  failed:$RES_FAILED"; fi
    res_say "  panel: ring position 6 — SYSTEM · Memory and storage"
    res_say "  reload Quickshell to pick up the new panel: sphere-setup restart"
}
