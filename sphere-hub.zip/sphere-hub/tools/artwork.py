"""Deterministic SVG asset manifest & generator entry points for Sphere Hub."""
from __future__ import annotations

from pathlib import Path

ASSETS = Path(__file__).resolve().parents[1] / "native" / "assets"

RUNE_SEEDS = tuple(range(60))
SIGIL_STATION_SEEDS = (1, 2, 3, 4, 5)


def rune_glyph_svg(index: int) -> str:
    return (ASSETS / f"rune-{index:02d}.svg").read_text()


def core_orb_svg() -> str:
    return (ASSETS / "core-orb.svg").read_text()


def core_halo_svg() -> str:
    return (ASSETS / "core-halo.svg").read_text()


def core_scrim_svg() -> str:
    return (ASSETS / "core-scrim.svg").read_text()


def core_sweep_svg() -> str:
    return (ASSETS / "core-sweep.svg").read_text()
