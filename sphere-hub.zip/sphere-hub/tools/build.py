#!/usr/bin/env python3
"""Build the self-contained `dist/sphere-setup-6.18.0.sh` installer from the repo tree."""
from __future__ import annotations

import base64
import gzip
import hashlib
import io
import json
import os
import tarfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
DIST = REPO / "dist"
EXCLUDED_DIRS = {
    ".git",
    ".github",
    "__pycache__",
    "dist",
    "target",
    ".cargo",
}
PAYLOAD_ROOTS = (
    "Cargo.toml",
    "Cargo.lock",
    "manager.py",
    "config",
    "installer",
    "native",
    "rust-backend",
    "shell",
    "tools",
)


def iter_payload_files() -> list[Path]:
    files: list[Path] = []
    for entry in PAYLOAD_ROOTS:
        root = REPO / entry
        if not root.exists():
            continue
        if root.is_file():
            files.append(root)
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = sorted(d for d in dirnames if d not in EXCLUDED_DIRS)
            for fname in sorted(filenames):
                if fname.endswith((".pyc", ".pyo")):
                    continue
                full = Path(dirpath) / fname
                if full.is_file() and not full.is_symlink():
                    files.append(full)
    return sorted(files, key=lambda p: p.relative_to(REPO).as_posix())


def write_checksums(files: list[Path]) -> Path:
    manifest = {}
    for path in files:
        rel = path.relative_to(REPO).as_posix()
        manifest[rel] = hashlib.sha256(path.read_bytes()).hexdigest()
    out = REPO / "checksums.json"
    out.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    return out


def build_payload_tar_gz(files: list[Path]) -> bytes:
    raw_buf = io.BytesIO()
    with tarfile.open(fileobj=raw_buf, mode="w") as tf:
        for path in files:
            rel = path.relative_to(REPO).as_posix()
            data = path.read_bytes()
            info = tarfile.TarInfo(name=rel)
            info.size = len(data)
            info.mtime = 1700000000
            info.uid = 0
            info.gid = 0
            info.uname = ""
            info.gname = ""
            info.type = tarfile.REGTYPE
            info.mode = 0o755 if os.access(path, os.X_OK) else 0o644
            tf.addfile(info, io.BytesIO(data))
    gz_buf = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=gz_buf, mtime=0, compresslevel=9) as gz:
        gz.write(raw_buf.getvalue())
    return gz_buf.getvalue()


def strip_shebang(text: str) -> str:
    lines = text.splitlines()
    if lines and lines[0].startswith("#!"):
        lines = lines[1:]
    return "\n".join(lines)


def build_installer() -> Path:
    files = iter_payload_files()
    checksums = write_checksums(files)
    all_files = sorted([*files, checksums], key=lambda p: p.relative_to(REPO).as_posix())
    payload = build_payload_tar_gz(all_files)
    payload_sha = hashlib.sha256(payload).hexdigest()
    b64_payload = base64.b64encode(payload).decode("ascii")

    org_prep = strip_shebang((REPO / "shell" / "organize-prep.sh").read_text())
    bt_prep = strip_shebang((REPO / "shell" / "bluetooth-prep.sh").read_text())
    bat_prep = strip_shebang((REPO / "shell" / "battery-prep.sh").read_text())
    res_prep = strip_shebang((REPO / "shell" / "resources-prep.sh").read_text())
    preflight = strip_shebang((REPO / "shell" / "preflight.sh").read_text())
    bootstrap = (REPO / "shell" / "bootstrap.py").read_text().replace(
        'PAYLOAD_SHA256 = "PAYLOAD_SHA256"', f'PAYLOAD_SHA256 = "{payload_sha}"', 1
    )
    if not bootstrap.endswith("SPHERE_BOOTSTRAP_PYTHON\n"):
        bootstrap = bootstrap.rstrip("\n") + "\nSPHERE_BOOTSTRAP_PYTHON\n"

    marker_tag = f"# >>> SPHERE_HUB_INSTALLER (sphere-setup-6.18.0-{payload_sha[:8]}.sh)"
    wrapper = f"""#!/bin/sh
# Sphere Hub 6.18.0 — Self-contained native Wayland/Hyprland + Rust backend installer.
# Run as your normal desktop user, NEVER as root (`sudo`).
set -u
SPHERE_UP2_DRY_RUN=0
SPHERE_UP2_SKIP_DEPS=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) SPHERE_UP2_DRY_RUN=1 ;;
    --no-deps) SPHERE_UP2_SKIP_DEPS=1 ;;
  esac
done

if [ "$(id -u)" -eq 0 ]; then
  case " $* " in
    *" --dry-run "*|*" --version "*|*" --help "*|*" -h "*) ;;
    *) printf '%s\\n' 'Run as your normal desktop user, not with sudo.' >&2; exit 1 ;;
  esac
fi
{org_prep}

{bt_prep}

{bat_prep}

{res_prep}

SPHERE_DEGRADED=0
SPHERE_UP2_RUN_PREP=1
for arg in "$@"; do
    case "$arg" in
        --version|--help|-h|--plan|status|doctor|start|stop|restart|picker|repair|logs|\\
        enable|disable|pause|resume|lock|unlock|refresh|toggle|uninstall)
            SPHERE_UP2_RUN_PREP=0 ;;
    esac
done
if [ "$SPHERE_UP2_SKIP_DEPS" = "1" ]; then
    printf '%s\\n' 'Skipping the organizer, Wi-Fi/Bluetooth, power and system preparation (--no-deps).'
elif [ "$SPHERE_UP2_RUN_PREP" = "0" ]; then
    :
elif [ "$SPHERE_UP2_DRY_RUN" = "1" ]; then
    SPHERE_OG_DRY_RUN=1 og_prepare
    printf '\\n'
    SPHERE_BT_DRY_RUN=1 bt_prepare
    printf '\\n'
    SPHERE_BAT_DRY_RUN=1 bat_prepare
    printf '\\n'
    SPHERE_RES_DRY_RUN=1 res_prepare
else
    og_prepare || SPHERE_DEGRADED=1
    printf '\\n'
    bt_prepare || SPHERE_DEGRADED=1
    printf '\\n'
    bat_prepare || SPHERE_DEGRADED=1
    printf '\\n'
    res_prepare || SPHERE_DEGRADED=1
fi

SPHERE_UP2_ARGS=""
for arg in "$@"; do
    case "$arg" in --no-deps) ;; *) SPHERE_UP2_ARGS="$SPHERE_UP2_ARGS $arg" ;; esac
done
SPHERE_UP2_TMP=${{TMPDIR:-/tmp}}/sphere-hub-installer.$$.sh
trap 'rm -f "$SPHERE_UP2_TMP"' EXIT INT TERM
MARKER='{marker_tag}'
sed -n "/^$MARKER$/,\\$p" "$0" | sed '1d' > "$SPHERE_UP2_TMP"
if [ ! -s "$SPHERE_UP2_TMP" ]; then
    printf '%s\\n' 'Installer is truncated: embedded payload missing.' >&2
    exit 1
fi
printf '\\n'
# shellcheck disable=SC2086
sh "$SPHERE_UP2_TMP" $SPHERE_UP2_ARGS
STATUS=$?
if [ "$SPHERE_DEGRADED" = "1" ]; then
    printf '%s\\n' '' 'Note: a preparation step reported a problem above;'
    printf '%s\\n' 'the panels explain the same condition in their own words.'
fi
exit $STATUS

{marker_tag}
{preflight}
{bootstrap}
__SPHERE_PAYLOAD_V1__
{b64_payload}
"""
    DIST.mkdir(exist_ok=True)
    target = DIST / "sphere-setup-6.18.0.sh"
    target.write_text(wrapper)
    target.chmod(0o755)
    return target


if __name__ == "__main__":
    built = build_installer()
    print(f"Built {built} ({built.stat().st_size:,} bytes)")
